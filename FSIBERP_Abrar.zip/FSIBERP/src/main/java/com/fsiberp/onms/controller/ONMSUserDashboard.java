package com.fsiberp.onms.controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fsiberp.bms.model.BMSView;
import com.fsiberp.frms.controller.PostGRESQLConnUtils;
import com.fsiberp.onms.model.OfficeNote;
import com.fsiberp.onms.repository.OfficeNoteRepository;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/officenote/user/")
public class ONMSUserDashboard {
	
	private OfficeNoteRepository officeNoteRepository;
	
	public ONMSUserDashboard(OfficeNoteRepository officeNoteRepository) {
			this.officeNoteRepository = officeNoteRepository;
	    }
	
	@GetMapping("viewform/{userid}/{formid}/{id}")
    public ResponseEntity<?> viewForms(@PathVariable("userid") String userid, @PathVariable("formid") String formid,
    		@PathVariable("id") Long id){
		
		if (formid.equals("5001")) {
		    OfficeNote officeNote = officeNoteRepository.findAllByUseridAndFormidAndId(userid, formid, id);
		    if (officeNote == null) {
		        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		    } 
		// Set download URLs if the document paths are not null
	    List<String> documentPaths = officeNote.getDocumentPaths();
	    if (documentPaths != null && !documentPaths.isEmpty()) {
	        List<String> documentDownloadUrls = new ArrayList<>();

	        for (int i = 0; i < documentPaths.size(); i++) {
	            // Add the proper URL pattern to download the document
	        	 String documentDownloadUrl = "/api/officenote/download/document/" + officeNote.getId() + "/" + i;
	                documentDownloadUrls.add(documentDownloadUrl);
	        }

	        officeNote.setDocumentDownloadUrl(documentDownloadUrls); // Add this field in the model for URLs
	    }

	    return new ResponseEntity<>(officeNote, HttpStatus.OK);
	}
		else {
		    return new ResponseEntity<>("Invalid formid", HttpStatus.BAD_REQUEST);
		}
}
	
	@GetMapping("pending/{id}")
    public List<BMSView> pendingForms(@PathVariable("id") String userid){
		
		Connection con = null;
		List<BMSView> officenote = new ArrayList<>();
		List<BMSView> dashboard = new ArrayList<>();
		
        try {
            con = PostGRESQLConnUtils.getPostGreSQLConnection();
            con.setAutoCommit(false);
            Statement stmt = con.createStatement();
            
            ResultSet on = stmt.executeQuery("SELECT * FROM onms_office_note far "
            		+ "JOIN sys_app_user sau ON far.userid = sau.user_id "
            		+ "WHERE userid = '" + userid + "' AND "
            		+ "('Pending' = ANY(far.other_aprvl_status ) "
            		+ "OR far.div_head_status = 'Pending' "
            		+ "OR far.amd_status = 'Pending' "
            		+ "OR far.dmd_status = 'Pending' "
            		+ "OR far.md_status = 'Pending' ) "
            		+ "AND NOT ('Rejected' = ANY(far.other_aprvl_status ) "
            		+ " OR far.div_head_status = 'Rejected' "
            		+ " OR far.amd_status = 'Rejected' "
            		+ " OR far.dmd_status = 'Rejected' "
            		+ " OR far.md_status = 'Rejected' )");
            
            if (on != null) {
	            while (on.next()) {
	            	BMSView bmsView = new BMSView();
	
	            	long id = on.getLong("id");
	                String users = on.getString("user_id");
	                String username = on.getString("user_name");
	                String branchcode = on.getString("branch_code");
	                String divhead = on.getString("div_head_status");
	                String dmdstatus = on.getString("dmd_status");
	                String amdstatus = on.getString("amd_status");
	                String mdstatus = on.getString("md_status");
	                Timestamp submittime = on.getTimestamp("submit_time");
	                String subject = on.getString("note_subject");
	                int draft = on.getInt("delegation");
	                String strDraft = String.valueOf(draft);
	                
	                String dept = on.getString("department");
	                if (dept.equals("I C T Div., Head Office, Dhaka")) {
	                	dept = on.getString("unit");
	    	        }
	
	                bmsView.setId(id);
	                bmsView.setUserid(users);
	                bmsView.setUsername(username);
	                bmsView.setBranchcode(branchcode);
	                bmsView.setUnitheadstatus(divhead);
	                bmsView.setDmdstatus(dmdstatus);
	                bmsView.setAmdstatus(amdstatus);
	                bmsView.setMdstatus(mdstatus);
	                bmsView.setSubmittime(submittime);
	                bmsView.setFormname(subject);
	                bmsView.setDepartment(dept);
	                bmsView.setFormid(strDraft);
	
	                officenote.add(bmsView);
	            }
            }
            dashboard.addAll(officenote);
            con.close();
        } 
        catch (Exception e) {
            e.printStackTrace(); 
        }
        
        return dashboard;
	}
	
	@GetMapping("accepted/{id}")
    public List<BMSView> acceptedForms(@PathVariable("id") String userid){
		
		Connection con = null;
		List<BMSView> officenote = new ArrayList<>();
		List<BMSView> dashboard = new ArrayList<>();
		
        try {
            con = PostGRESQLConnUtils.getPostGreSQLConnection();
            con.setAutoCommit(false);
            Statement stmt = con.createStatement();
            
            ResultSet on = stmt.executeQuery("SELECT * FROM onms_office_note far "
            		+ "JOIN sys_app_user sau ON far.userid = sau.user_id "
            		+ "WHERE userid = '" + userid + "' AND "
            		+ " (far.md_status = 'Accepted' "
            		+ "OR far.md_status = 'On Leave')");
            
            if (on != null) {
	            while (on.next()) {
	            	BMSView bmsView = new BMSView();
	
	            	long id = on.getLong("id");
	                String users = on.getString("user_id");
	                String username = on.getString("user_name");
	                String branchcode = on.getString("branch_code");
	                String divhead = on.getString("div_head_status");
	                String dmdstatus = on.getString("dmd_status");
	                String amdstatus = on.getString("amd_status");
	                String mdstatus = on.getString("md_status");
	                Timestamp submittime = on.getTimestamp("submit_time");
	                String subject = on.getString("note_subject");
	                int draft = on.getInt("delegation");
	                String strDraft = String.valueOf(draft);
	                
	                String dept = on.getString("department");
	                if (dept.equals("I C T Div., Head Office, Dhaka")) {
	                	dept = on.getString("unit");
	    	        }
	
	                bmsView.setId(id);
	                bmsView.setUserid(users);
	                bmsView.setUsername(username);
	                bmsView.setBranchcode(branchcode);
	                bmsView.setUnitheadstatus(divhead);
	                bmsView.setDmdstatus(dmdstatus);
	                bmsView.setAmdstatus(amdstatus);
	                bmsView.setMdstatus(mdstatus);
	                bmsView.setSubmittime(submittime);
	                bmsView.setFormname(subject);
	                bmsView.setDepartment(dept);
	                bmsView.setFormid(strDraft);
	
	                officenote.add(bmsView);
	            }
            }
            dashboard.addAll(officenote);
            con.close();
        } 
        catch (Exception e) {
            e.printStackTrace(); 
        }
        
        return dashboard;
	}
	
	@GetMapping("rejected/{id}")
    public List<BMSView> rejectedForms(@PathVariable("id") String userid){
		
		Connection con = null;
		List<BMSView> officenote = new ArrayList<>();
		List<BMSView> dashboard = new ArrayList<>();
		
        try {
            con = PostGRESQLConnUtils.getPostGreSQLConnection();
            con.setAutoCommit(false);
            Statement stmt = con.createStatement();
            
            ResultSet on = stmt.executeQuery("SELECT * FROM onms_office_note far "
            		+ "JOIN sys_app_user sau ON far.userid = sau.user_id "
            		+ "WHERE userid = '" + userid + "' AND "
            		+ "('Rejected' = ANY(far.other_aprvl_status ) "
            		+ "OR far.div_head_status = 'Rejected' "
            		+ "OR far.amd_status = 'Rejected' "
            		+ "OR far.dmd_status = 'Rejected' "
            		+ "OR far.md_status = 'Rejected' ) ");
            
            if (on != null) {
	            while (on.next()) {
	            	BMSView bmsView = new BMSView();
	
	            	long id = on.getLong("id");
	                String users = on.getString("user_id");
	                String username = on.getString("user_name");
	                String branchcode = on.getString("branch_code");
	                String divhead = on.getString("div_head_status");
	                String dmdstatus = on.getString("dmd_status");
	                String amdstatus = on.getString("amd_status");
	                String mdstatus = on.getString("md_status");
	                Timestamp submittime = on.getTimestamp("submit_time");
	                String subject = on.getString("note_subject");
	                int draft = on.getInt("delegation");
	                String strDraft = String.valueOf(draft);
	                
	                String dept = on.getString("department");
	                if (dept.equals("I C T Div., Head Office, Dhaka")) {
	                	dept = on.getString("unit");
	    	        }
	
	                bmsView.setId(id);
	                bmsView.setUserid(users);
	                bmsView.setUsername(username);
	                bmsView.setBranchcode(branchcode);
	                bmsView.setUnitheadstatus(divhead);
	                bmsView.setDmdstatus(dmdstatus);
	                bmsView.setAmdstatus(amdstatus);
	                bmsView.setMdstatus(mdstatus);
	                bmsView.setSubmittime(submittime);
	                bmsView.setFormname(subject);
	                bmsView.setDepartment(dept);
	                bmsView.setFormid(strDraft);
	
	                officenote.add(bmsView);
	            }
            }
            dashboard.addAll(officenote);
            con.close();
        } 
        catch (Exception e) {
            e.printStackTrace(); 
        }
        
        return dashboard;
	}

}
