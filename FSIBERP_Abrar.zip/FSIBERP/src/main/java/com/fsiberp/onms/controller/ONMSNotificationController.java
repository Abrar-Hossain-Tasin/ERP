package com.fsiberp.onms.controller;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fsiberp.onms.model.ONMSNotification;
import com.fsiberp.onms.services.ONMSNotificationService;


@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/onms/notifications/")
public class ONMSNotificationController {

    private final ONMSNotificationService onmsNotificationService;

    public ONMSNotificationController(ONMSNotificationService onmsNotificationService) {
        this.onmsNotificationService = onmsNotificationService;
    }

    @GetMapping("{userid}")
    public List<ONMSNotification> getUserNotifications(@PathVariable("userid") String userid) {
        return onmsNotificationService.getNotifications(userid);
    }

    @PutMapping("view/{id}")
    public void markNotificationAsViewed(@PathVariable("id") Long id) {
    	onmsNotificationService.markAsViewed(id);
    }
}