package com.fsiberp.onms.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.fsiberp.onms.model.ONMSNotification;


import org.springframework.stereotype.Repository;
@Repository

	public interface ONMSNotificationRepository extends JpaRepository<ONMSNotification, Long> {
	    List<ONMSNotification> findByUserid(String userid);
	    List<ONMSNotification> findByFormid(String formid);
	    List<ONMSNotification> findByUseridAndFormid(String userid, String formid);
	    List<ONMSNotification> findByUseridAndFormidAndSubmissionId(String userid, String formid, Long submissionId);

	}


