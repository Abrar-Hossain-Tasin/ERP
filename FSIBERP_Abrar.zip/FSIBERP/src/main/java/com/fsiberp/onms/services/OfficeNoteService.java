package com.fsiberp.onms.services;

import java.sql.Timestamp;
import com.fsiberp.onms.model.ONMSStatusUpdateRequest;
import com.fsiberp.onms.model.OfficeNote;

public interface OfficeNoteService {
    OfficeNote createForm(OfficeNote officeNote);
    OfficeNote backwardForm(String formId, String userid, Long id);
    boolean isDivHeadUser(String userid, OfficeNote officeNote);
    boolean isMdDmdAmdUser(String userid, OfficeNote officeNote);
    boolean isOtherApprovalUser(String userid, OfficeNote officeNote);
    
    OfficeNote updateStatus(Long id, String userid, ONMSStatusUpdateRequest request, 
    	    Timestamp currentTimestamp, String osUserName, String clientIpAddress);
}
