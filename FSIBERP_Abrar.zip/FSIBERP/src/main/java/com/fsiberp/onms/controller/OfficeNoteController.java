package com.fsiberp.onms.controller;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.apache.tika.Tika;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fsiberp.bms.model.UnitHead;
import com.fsiberp.bms.repository.BMSDivisionNameRepository;
import com.fsiberp.bms.repository.UnitHeadRepository;
import com.fsiberp.frms.model.BranchInfo;
import com.fsiberp.frms.model.DivisionName;
import com.fsiberp.frms.model.FunctionalRole;
import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.AuthRepository;
import com.fsiberp.frms.repository.BranchInfoRepository;
import com.fsiberp.frms.repository.FunctionalRoleRepository;
import com.fsiberp.frms.repository.ProfileRepository;
import com.fsiberp.frms.services.ProfileService;
import com.fsiberp.onms.model.Comment;
import com.fsiberp.onms.model.ONMSNotification;
import com.fsiberp.onms.model.OfficeNote;
import com.fsiberp.onms.repository.CommentRepository;
import com.fsiberp.onms.repository.ONMSNotificationRepository;
import com.fsiberp.onms.repository.OfficeNoteRepository;
import com.fsiberp.onms.services.OfficeNoteService;

import jakarta.validation.Valid;

import org.springframework.core.io.UrlResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/officenote/")
public class OfficeNoteController {

	private OfficeNoteService officeNoteService;
	private ProfileService profileService;
	private FunctionalRoleRepository functionalRoleRepository;
	private OfficeNoteRepository officeNoteRepository;
	private BMSDivisionNameRepository bmsDivisionNameRepository;
	private UnitHeadRepository unitHeadRepository;
	private AuthRepository authRepository;
	private ProfileRepository profileRepository;
	private BranchInfoRepository branchInfoRepository;
	private CommentRepository commentRepository;
	private ONMSNotificationRepository onmsNotificationRepository;

	@Value("${file.upload-dir}")
	private String uploadDir;

	public OfficeNoteController(OfficeNoteService officeNoteService, ProfileService profileService,
			BMSDivisionNameRepository bmsDivisionNameRepository, UnitHeadRepository unitHeadRepository,
			FunctionalRoleRepository functionalRoleRepository, OfficeNoteRepository officeNoteRepository,
			AuthRepository authRepository, ProfileRepository profileRepository,
			BranchInfoRepository branchInfoRepository, CommentRepository commentRepository,
			ONMSNotificationRepository onmsNotificationRepository) {
		this.officeNoteService = officeNoteService;
		this.profileService = profileService;
		this.functionalRoleRepository = functionalRoleRepository;
		this.officeNoteRepository = officeNoteRepository;
		this.bmsDivisionNameRepository = bmsDivisionNameRepository;
		this.unitHeadRepository = unitHeadRepository;
		this.authRepository = authRepository;
		this.profileRepository = profileRepository;
		this.branchInfoRepository = branchInfoRepository;
		this.commentRepository = commentRepository;
		this.onmsNotificationRepository = onmsNotificationRepository;
	}

//	    @PostMapping("/save/{id}")
//	    public ResponseEntity<?> createForm(
//	            @PathVariable("id") String userid,
//	            @ModelAttribute @Valid OfficeNote officeNote,
//	            @RequestParam(value = "documents", required = false) MultipartFile[] documents) {
//
//	        User user = profileService.getUserByUserid(userid);
//
//	        // Set OfficeNote properties
//	        officeNote.setUserid(user.getUserid());
//	        officeNote.setFormid("5001");
//	        officeNote.setDivHeadStatus("Pending");
//	        officeNote.setAmdStatus("Pending");
//	        officeNote.setDmdStatus("Pending");
//	        officeNote.setMdStatus("Pending");
//	        officeNote.setSubmitDate(new Date(System.currentTimeMillis()));
//	        officeNote.setSubmitTime(new Timestamp(System.currentTimeMillis()));
//	        
//	        final long FILE_SIZE_LIMIT = 250 * 1024; 
//	        List<String> documentPaths = new ArrayList<>();
//
//	        try {
//	            if (documents != null && documents.length > 0) {
//	                for (MultipartFile document : documents) {
//	                    if (document != null && !document.isEmpty()) {
//	                        
//	                        if (document.getSize() > FILE_SIZE_LIMIT) {
//	                            Map<String, String> errorResponse = new HashMap<>();
//	                            errorResponse.put("error", document.getOriginalFilename() + " size exceeds 250 KB");
//	                            return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
//	                        }
//	                        
//	                        // Use Tika to detect the file type
//	                        String fileType = getFileTypeFromTika(document);
//	                        if (!"application/pdf".equals(fileType) && !"image/jpeg".equals(fileType) && !"image/png".equals(fileType)) {
//	                            Map<String, String> errorResponse = new HashMap<>();
//	                            errorResponse.put("error", "Invalid file type. Only PDF, JPEG, and PNG files are allowed.");
//	                            return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
//	                        }
//
//	                        // Check file extension (allow only PDF, JPEG, and PNG)
//	                        String fileExtension = getFileExtension(document.getOriginalFilename());
//	                        if (!"pdf".equalsIgnoreCase(fileExtension) &&
//	                            !"jpg".equalsIgnoreCase(fileExtension) &&
//	                            !"jpeg".equalsIgnoreCase(fileExtension) &&
//	                            !"png".equalsIgnoreCase(fileExtension)) {
//	                            Map<String, String> errorResponse = new HashMap<>();
//	                            errorResponse.put("error", "Invalid file extension. Only PDF, JPG, JPEG, and PNG files are allowed.");
//	                            return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
//	                        }
//
//	                        String documentPath = saveFile(userid, document);
//	                        documentPaths.add(documentPath);
//	                    }
//	                }
//	                officeNote.setDocumentPaths(documentPaths);
//	            }
//	        } catch (IOException e) {
//	            Map<String, String> errorResponse = new HashMap<>();
//	            errorResponse.put("error", "An error occurred while processing the file: " + e.getMessage());
//	            return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
//	        }
//	        // Save the form and return a success response
//	        OfficeNote savedForm = officeNoteService.createForm(officeNote);
//	        return new ResponseEntity<>(savedForm, HttpStatus.CREATED);
//	    }
//
//	    // Save file to disk
//	    private String saveFile(String userid, MultipartFile file) throws IOException {
//	        String originalFilename = file.getOriginalFilename();
//	        
//	        // Sanitize the original filename
//	        String sanitizedFilename = sanitizeFileName(originalFilename);
//	        
//	        // Construct the final filename using the sanitized filename
//	        String filename = userid + "_" + 5001 + "_" + System.currentTimeMillis()  + "~"  + sanitizedFilename;
//	        
//	        Path filePath = Paths.get(uploadDir, filename);
//
//	        try (InputStream inputStream = file.getInputStream()) {
//	            Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
//	        }
//
//	        return filePath.toString();
//	    }
//
//	    // Sanitize file name
//	    private String sanitizeFileName(String originalFilename) {
//	        // Replace any special characters with underscores
//	        return originalFilename.replaceAll("[^a-zA-Z0-9.-]", "_");
//	    }
//
//	    // Extract file extension
//	    private String getFileExtension(String filename) {
//	        if (filename == null || filename.isEmpty()) {
//	            return "";
//	        }
//	        int dotIndex = filename.lastIndexOf(".");
//	        if (dotIndex == -1) {
//	            return ""; // No extension found
//	        }
//	        return filename.substring(dotIndex + 1);
//	    }
//
//	    // Use Tika to detect file type
//	    private String getFileTypeFromTika(MultipartFile file) throws IOException {
//	        Tika tika = new Tika();
//	        try (InputStream inputStream = file.getInputStream()) {
//	            return tika.detect(inputStream);
//	        }
//	    }

	@PostMapping("/save/{id}")
	public ResponseEntity<?> createForm(@PathVariable("id") String userid, @ModelAttribute @Valid OfficeNote officeNote,
			@RequestParam(value = "documents", required = false) MultipartFile[] documents) {

		User user = profileService.getUserByUserid(userid);

		// Set OfficeNote properties
		officeNote.setUserid(user.getUserid());
		officeNote.setFormid("5001");
		officeNote.setDivHeadStatus("Pending");
		officeNote.setAmdStatus("Pending");
		officeNote.setDmdStatus("Pending");
		officeNote.setMdStatus("Pending");
		officeNote.setSubmitDate(new Date(System.currentTimeMillis()));
		officeNote.setSubmitTime(new Timestamp(System.currentTimeMillis()));

		final long FILE_SIZE_LIMIT = 250 * 1024;
		List<String> documentPaths = new ArrayList<>();

		try {
			if (documents != null && documents.length > 0) {
				for (MultipartFile document : documents) {
					if (document != null && !document.isEmpty()) {

						if (document.getSize() > FILE_SIZE_LIMIT) {
							Map<String, String> errorResponse = new HashMap<>();
							errorResponse.put("error", document.getOriginalFilename() + " size exceeds 250 KB");
							return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
						}

						// Use Tika to detect the file type
						String fileType = getFileTypeFromTika(document);
						if (!"application/pdf".equals(fileType) && !"image/jpeg".equals(fileType)
								&& !"image/png".equals(fileType)) {
							Map<String, String> errorResponse = new HashMap<>();
							errorResponse.put("error", "Invalid file type. Only PDF, JPEG, and PNG files are allowed.");
							return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
						}

						// Check file extension (allow only PDF, JPEG, and PNG)
						String fileExtension = getFileExtension(document.getOriginalFilename());
						if (!"pdf".equalsIgnoreCase(fileExtension) && !"jpg".equalsIgnoreCase(fileExtension)
								&& !"jpeg".equalsIgnoreCase(fileExtension) && !"png".equalsIgnoreCase(fileExtension)) {
							Map<String, String> errorResponse = new HashMap<>();
							errorResponse.put("error",
									"Invalid file extension. Only PDF, JPG, JPEG, and PNG files are allowed.");
							return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
						}

						String documentPath = saveFile(userid, document);
						documentPaths.add(documentPath);
					}
				}
				officeNote.setDocumentPaths(documentPaths);
			}
		} catch (IOException e) {
			Map<String, String> errorResponse = new HashMap<>();
			errorResponse.put("error", "An error occurred while processing the file: " + e.getMessage());
			return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		// Save the form and return a success response
		OfficeNote savedForm = officeNoteService.createForm(officeNote);
		return new ResponseEntity<>(savedForm, HttpStatus.CREATED);
	}

	// Save file to disk
	private String saveFile(String userid, MultipartFile file) throws IOException {
		String originalFilename = file.getOriginalFilename();

		// Sanitize the original filename
		String sanitizedFilename = sanitizeFileName(originalFilename);

		// Construct the final filename using the sanitized filename
		String filename = userid + "_" + 5001 + "_" + System.currentTimeMillis() + "~" + sanitizedFilename;

		Path filePath = Paths.get(uploadDir, filename);

		try (InputStream inputStream = file.getInputStream()) {
			Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
		}

		return filePath.toString();
	}

	// Sanitize file name
	private String sanitizeFileName(String originalFilename) {
		// Replace any special characters with underscores
		return originalFilename.replaceAll("[^a-zA-Z0-9.-]", "_");
	}

	// Extract file extension
	private String getFileExtension(String filename) {
		if (filename == null || filename.isEmpty()) {
			return "";
		}
		int dotIndex = filename.lastIndexOf(".");
		if (dotIndex == -1) {
			return ""; // No extension found
		}
		return filename.substring(dotIndex + 1);
	}

	// Use Tika to detect file type
	private String getFileTypeFromTika(MultipartFile file) throws IOException {
		Tika tika = new Tika();
		try (InputStream inputStream = file.getInputStream()) {
			return tika.detect(inputStream);
		}
	}

	@GetMapping("/viewform/{id}")
	public ResponseEntity<OfficeNote> viewForm(@PathVariable("id") String userid) {
		OfficeNote officeNote = officeNoteRepository.findTopByUseridOrderByIdDesc(userid);

		if (officeNote == null) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

		// Set download URLs if the document paths are not null
		List<String> documentPaths = officeNote.getDocumentPaths();
		if (documentPaths != null && !documentPaths.isEmpty()) {
			List<String> documentDownloadUrls = new ArrayList<>();

			for (int i = 0; i < documentPaths.size(); i++) {
				// Add the proper URL pattern to download the document
				String documentDownloadUrl = "/api/officenote/download/document/" + officeNote.getId() + "/" + i;
				documentDownloadUrls.add(documentDownloadUrl);
			}

			officeNote.setDocumentDownloadUrl(documentDownloadUrls); // Add this field in the model for URLs
		}

		return new ResponseEntity<>(officeNote, HttpStatus.OK);
	}

	@GetMapping("/download/document/{id}/{index}")
	public ResponseEntity<Resource> downloadDocument(@PathVariable("id") Long id, @PathVariable("index") int index) {
		OfficeNote officeNote = officeNoteRepository.findById(id).orElse(null);
		if (officeNote == null) {
			return ResponseEntity.notFound().build(); // Return 404 if the OfficeNote is not found
		}

		List<String> documentPaths = officeNote.getDocumentPaths();
		if (documentPaths == null || index < 0 || index >= documentPaths.size()) {
			return ResponseEntity.notFound().build(); // Return 404 if the index is invalid
		}

		String documentPath = documentPaths.get(index);
		try {
			// Resolve the full file path using the document path from the entity
			Path filePath = Paths.get(documentPath); // documentPath should already be a complete file path
			Resource resource = new UrlResource(filePath.toUri()); // Use UrlResource to load the file

			if (!resource.exists() || !resource.isReadable()) {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build(); // Handle file read error
			}

			// Retrieve the original filename and content type
			String originalFilename = filePath.getFileName().toString();
			String contentType = Files.probeContentType(filePath);
			if (contentType == null) {
				contentType = MediaType.APPLICATION_OCTET_STREAM_VALUE; // Default content type
			}

			// Return the file as a downloadable resource
			return ResponseEntity.ok()
					.header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + originalFilename + "\"")
					.contentType(MediaType.parseMediaType(contentType)).body(resource);
		} catch (IOException e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build(); // Handle internal server errors
		}
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<?> updateOfficeNote(@PathVariable("id") Long id, @ModelAttribute OfficeNote updateOfficeNote,
			@RequestParam(value = "documents", required = false) MultipartFile[] documents) {

		OfficeNote officeNote = officeNoteRepository.findById(id)
				.orElseThrow(() -> new NoSuchElementException("OfficeNote not found for id: " + id));

		officeNote.setNoteSubject(updateOfficeNote.getNoteSubject());
		officeNote.setNoteBody(updateOfficeNote.getNoteBody());
		officeNote.setOtherApprovalStatuses(updateOfficeNote.getOtherApprovalStatuses());
		officeNote.setSubmitTime(new Timestamp(System.currentTimeMillis()));
		officeNote.setSubmitDate(new Date(System.currentTimeMillis()));
		officeNote.setDelegation(updateOfficeNote.getDelegation());

		final long FILE_SIZE_LIMIT = 250 * 1024;
		List<String> documentPaths = officeNote.getDocumentPaths();
		if (documentPaths == null) {
			documentPaths = new ArrayList<>();
		}

		try {
			if (documents != null && documents.length > 0) {
				for (MultipartFile document : documents) {
					if (document != null && !document.isEmpty()) {

						if (document.getSize() > FILE_SIZE_LIMIT) {
							Map<String, String> errorResponse = new HashMap<>();
							errorResponse.put("error", document.getOriginalFilename() + " size exceeds 250 KB");
							return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
						}

						Tika tika = new Tika();
						try (InputStream inputStream = document.getInputStream()) {
							String fileType = tika.detect(inputStream);

							if (!"application/pdf".equals(fileType) && !"image/jpeg".equals(fileType)
									&& !"image/png".equals(fileType)) {
								Map<String, String> errorResponse = new HashMap<>();
								errorResponse.put("error",
										"Invalid file type. Only PDF, JPEG, and PNG files are allowed.");
								return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
							}

							String fileExtension = getFileExtension(document.getOriginalFilename());
							if (!"pdf".equalsIgnoreCase(fileExtension) && !"jpg".equalsIgnoreCase(fileExtension)
									&& !"jpeg".equalsIgnoreCase(fileExtension)
									&& !"png".equalsIgnoreCase(fileExtension)) {
								Map<String, String> errorResponse = new HashMap<>();
								errorResponse.put("error",
										"Invalid file extension. Only PDF, JPG, JPEG, and PNG files are allowed.");
								return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
							}

							String documentPath = saveFile(officeNote.getUserid(), document);
							documentPaths.add(documentPath);
						}
					}
				}
			}
		} catch (IOException e) {
			Map<String, String> errorResponse = new HashMap<>();
			errorResponse.put("error", "An error occurred while processing the file: " + e.getMessage());
			return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		if (updateOfficeNote.getOtherApprovalUserIds() != null
				&& !updateOfficeNote.getOtherApprovalUserIds().isEmpty()) {

			String newFirstApprovalUserId = updateOfficeNote.getOtherApprovalUserIds().get(0);
			String oldFirstApprovalUserId = officeNote.getOtherApprovalUserIds().isEmpty() ? null
					: officeNote.getOtherApprovalUserIds().get(0);

			if (officeNote.getOtherApprovalUserIds() == null || officeNote.getOtherApprovalUserIds().isEmpty()) {
				List<ONMSNotification> existingNotifications = onmsNotificationRepository
						.findByUseridAndFormidAndSubmissionId(officeNote.getDivHeadUserid(), officeNote.getFormid(),
								officeNote.getId());

				if (existingNotifications != null && !existingNotifications.isEmpty()) {
					User submittingUser = profileService.getUserByUserid(officeNote.getUserid());
					String submittingUsername = submittingUser != null ? submittingUser.getUsername() : "Unknown User";

					for (ONMSNotification notification : existingNotifications) {
						notification.setUserid(newFirstApprovalUserId);
						notification.setViewed(false);
						notification.setMessage("A new Office Note request has been submitted by " + submittingUsername
								+ " (" + officeNote.getUserid() + ").");
						onmsNotificationRepository.save(notification);
					}
				}
			}

			else if (oldFirstApprovalUserId != null && !newFirstApprovalUserId.equals(oldFirstApprovalUserId)) {
				List<ONMSNotification> existingNotifications = onmsNotificationRepository
						.findByUseridAndFormidAndSubmissionId(oldFirstApprovalUserId, officeNote.getFormid(),
								officeNote.getId());

				if (existingNotifications != null && !existingNotifications.isEmpty()) {
					User submittingUser = profileService.getUserByUserid(officeNote.getUserid());
					String submittingUsername = submittingUser != null ? submittingUser.getUsername() : "Unknown User";

					for (ONMSNotification notification : existingNotifications) {
						notification.setUserid(newFirstApprovalUserId);
						notification.setViewed(false);
						notification.setMessage("A new Office Note request has been submitted by " + submittingUsername
								+ " (" + officeNote.getUserid() + ").");
						onmsNotificationRepository.save(notification);
					}
				}
			}

			if (officeNote.getOtherApprovalUserIds() == null) {
				officeNote.setOtherApprovalUserIds(new ArrayList<>());
			}
			if (officeNote.getOtherApprovalUsernames() == null) {
				officeNote.setOtherApprovalUsernames(new ArrayList<>());
			}

			officeNote.setOtherApprovalUserIds(updateOfficeNote.getOtherApprovalUserIds());

			officeNote.setOtherApprovalUsernames(updateOfficeNote.getOtherApprovalUsernames());

		}

		OfficeNote updatedOfficeNote = officeNoteRepository.save(officeNote);
		return ResponseEntity.ok(updatedOfficeNote);
	}

	@DeleteMapping("removefile/{id}/{fileIndex}")
	public ResponseEntity<?> removeFile(@PathVariable("id") Long id, @PathVariable("fileIndex") int fileIndex) {

		OfficeNote officeNote = officeNoteRepository.findById(id)
				.orElseThrow(() -> new NoSuchElementException("OfficeNote not found with id: " + id));

		List<String> documentPaths = officeNote.getDocumentPaths();

		if (fileIndex < 0 || fileIndex >= documentPaths.size()) {
			return new ResponseEntity<>("Invalid file index", HttpStatus.BAD_REQUEST);
		}

		String filePath = documentPaths.get(fileIndex);

		File file = new File(filePath);
		if (file.exists() && file.delete()) {

			documentPaths.remove(fileIndex);
			officeNote.setDocumentPaths(documentPaths);

			officeNoteRepository.save(officeNote);

			return new ResponseEntity<>("File removed successfully", HttpStatus.OK);
		} else {
			return new ResponseEntity<>("Failed to delete file from the server", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("view/{id}")
	public ResponseEntity<User> showForms(@PathVariable("id") String userid) {
		User user = profileService.getUserByUserid(userid);
		return new ResponseEntity<>(user, HttpStatus.OK);
	}

	@GetMapping("official/{id}")
	public ResponseEntity<Map<String, Object>> officialList(@PathVariable("id") String userid) {

		User user = profileService.getUserByUserid(userid);

		Map<String, Object> response = new LinkedHashMap<>();

		DivisionName divisionName;

		List<String> unitfuncDesig;
		List<UnitHead> unithead = null;
		if (user.getBranchcode().equals("0100")) {
			unitfuncDesig = Arrays.asList("FD001");
			unithead = unitHeadRepository.findActiveUnitHeads(user.getDepartment(), user.getBranchcode(), unitfuncDesig,
					"Active");
		} else {
			if (user.getRoleid() == 2) {
				BranchInfo branchInfo = branchInfoRepository.findByBranchcode(user.getBranchcode());
				if (branchInfo != null) {
					if (!branchInfo.getZonalcode().equals("0100")) {
						unitfuncDesig = Arrays.asList("FD011");
						unithead = unitHeadRepository.findAllActiveUnitHeads(branchInfo.getZonalcode(), unitfuncDesig,
								"Active");

					} else {
						unitfuncDesig = Arrays.asList("FD003", "FD011");
						unithead = unitHeadRepository.findActiveUnitHeads(user.getDepartment(), user.getBranchcode(),
								unitfuncDesig, "Active");
					}
				} else {
					unitfuncDesig = Arrays.asList("FD003", "FD011");
					unithead = unitHeadRepository.findActiveUnitHeads(user.getDepartment(), user.getBranchcode(),
							unitfuncDesig, "Active");
				}
			} else {

				unitfuncDesig = Arrays.asList("FD003", "FD011");
				unithead = unitHeadRepository.findActiveUnitHeads(user.getDepartment(), user.getBranchcode(),
						unitfuncDesig, "Active");
			}
		}

		if (unithead.size() == 0) {
			response.put("divhead", "No User Found");
			response.put("divheadid", null);
			response.put("divheadstatus", "Pending");
		}

		String department = user.getDepartment();

		if (user.getBranchcode().equals("0100")) {
			divisionName = bmsDivisionNameRepository.findByDivisionname(user.getDepartment());
		} else if (user.getBranchcode().equals("9000") || user.getBranchcode().equals("9001")
				|| user.getBranchcode().equals("9501")) {
			divisionName = bmsDivisionNameRepository.findByDivisionname(user.getDepartment());
		} else {
			divisionName = bmsDivisionNameRepository.findById(2);
		}

		FunctionalRole md = functionalRoleRepository.findByFunctionalrole("md")
				.orElseThrow(NoSuchElementException::new);
		User mdname = profileService.getUserByUserid(md.getUserid());

		User dmduser = profileService.getUserByUserid(divisionName.getDmdid());
		User amduser = profileService.getUserByUserid(divisionName.getAmdid());

		for (UnitHead unitHead : unithead) {

			if (unithead.size() > 1) {
				User appuser = profileRepository.findByDepartmentAndUsergrp(department, unitHead.getFuncdesignation());
				if (appuser != null) {
					response.put("divhead", appuser.getUsername());
					response.put("divheadid", appuser.getUserid());
					response.put("divheaddesg", appuser.getDesignation());
					response.put("divheadstatus", "Pending");
				} else {
					response.put("divhead", "No User Found");
					response.put("divheadid", null);
					response.put("divheadstatus", "Pending");
				}
			} else {
				User unitid = profileRepository.findByEmpid(unitHead.getEmpcode());
				response.put("divhead", unitid.getUsername());
				response.put("divheadid", unitid.getUserid());
				response.put("divheaddesg", unitid.getDesignation());
				response.put("divheadstatus", "Pending");
			}
		}

		response.put("dmd", dmduser.getUsername());
		response.put("dmdid", dmduser.getUserid());
		response.put("dmddesg", dmduser.getDesignation());
		response.put("dmdstatus", "Pending");
		response.put("amd", amduser.getUsername());
		response.put("amdid", amduser.getUserid());
		response.put("amddesg", amduser.getDesignation());
		response.put("amdstatus", "Pending");
		response.put("md", mdname.getUsername());
		response.put("mdid", mdname.getUserid());
		response.put("mdstatus", "Pending");
		response.put("mddesg", mdname.getDesignation());

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@GetMapping("emplist/{id}")
	public List<User> emplist(@PathVariable(name = "id") String userid) {
		User user = profileService.getUserByUserid(userid);

		if (user.getBranchcode().equals("0100")) {
			return authRepository.findAllByDepartmentAndUseridNot(user.getDepartment(), userid);
		} else {
			return authRepository.findAllByBranchcodeAndUseridNot(user.getBranchcode(), userid);
		}

	}

	@PutMapping("backward/{userid}/{formId}/{id}")
	public ResponseEntity<Map<String, String>> backwardForm(@PathVariable("userid") String userid,
			@PathVariable("formId") String formId, @PathVariable("id") Long id,
			@RequestBody Map<String, String> requestBody) {
		Map<String, String> response = new HashMap<>();
		try {

			String comment = requestBody.get("comment");

			OfficeNote officeNote = officeNoteService.backwardForm(formId, userid, id);

			String responseUserId;
			if (officeNoteService.isDivHeadUser(userid, officeNote)) {
				responseUserId = officeNote.getUserid();
			} else if (officeNoteService.isMdDmdAmdUser(userid, officeNote)) {
				responseUserId = officeNote.getDivHeadUserid();
			} else if (officeNoteService.isOtherApprovalUser(userid, officeNote)) {
				responseUserId = officeNote.getUserid();
			} else {
				throw new IllegalArgumentException("Invalid user role for backwarding the form.");
			}

			if (comment != null && !comment.trim().isEmpty()) {
				User actionUser = profileRepository.findByUserid(userid)
						.orElseThrow(() -> new NoSuchElementException("User not found"));

				Comment newComment = new Comment();
				newComment.setUserid(userid);
				newComment.setUsername(actionUser.getUsername());
				newComment.setMessage(comment); // Save only the comment value
				newComment.setFuserid(officeNote.getUserid());
				newComment.setFormid(formId);
				newComment.setSubmissionId(id);
				commentRepository.save(newComment);
			}

			String username = profileRepository.findByUserid(responseUserId).map(User::getUsername)
					.orElse("Unknown User");

			String message = String.format("Note has been successfully sent back to %s (%s) for modification.",
					username, responseUserId);
			response.put("message", message);

			return ResponseEntity.ok(response);
		} catch (NoSuchElementException e) {
			response.put("message", "Form not found.");
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
		} catch (Exception e) {
			response.put("message", "An error occurred: " + e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
	}

}
