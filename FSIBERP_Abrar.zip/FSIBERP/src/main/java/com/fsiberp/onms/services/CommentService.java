package com.fsiberp.onms.services;

import com.fsiberp.onms.model.Comment;
import java.util.List;

public interface CommentService {
   
    List<Comment> getCommentsByFormDetails(String fuserid, String formid, Long submissionId);
}
