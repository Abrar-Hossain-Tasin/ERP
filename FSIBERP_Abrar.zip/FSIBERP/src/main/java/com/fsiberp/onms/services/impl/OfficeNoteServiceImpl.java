package com.fsiberp.onms.services.impl;


import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.FunctionalRoleRepository;
import com.fsiberp.frms.repository.ProfileRepository;
import com.fsiberp.frms.services.EmailService;
import com.fsiberp.frms.services.ProfileService;
import com.fsiberp.onms.model.ONMSStatusUpdateRequest;
import com.fsiberp.onms.model.OfficeNote;
import com.fsiberp.onms.repository.OfficeNoteRepository;
import com.fsiberp.onms.services.ONMSNotificationService;
import com.fsiberp.onms.services.OfficeNoteService;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.NoSuchElementException;
import org.springframework.stereotype.Service;

@Service
public class OfficeNoteServiceImpl implements OfficeNoteService {

    private final OfficeNoteRepository officeNoteRepository;
    private final ONMSNotificationService onmsNotificationService; // Added NotificationService
    private final ProfileRepository profileRepository;
    private final ProfileService profileService;
    private final FunctionalRoleRepository functionalRoleRepository;
    private EmailService emailService;

    
    public OfficeNoteServiceImpl(OfficeNoteRepository officeNoteRepository, ONMSNotificationService onmsNotificationService, 
    		ProfileRepository profileRepository, ProfileService profileService, FunctionalRoleRepository functionalRoleRepository, EmailService emailService) {
        
    	this.officeNoteRepository = officeNoteRepository;
        this.onmsNotificationService = onmsNotificationService;
        this.profileRepository = profileRepository;
        this.profileService = profileService;
        this.functionalRoleRepository =functionalRoleRepository;
        this.emailService = emailService;
    }
    

    
    @Override
    public OfficeNote createForm(OfficeNote officeNote) {
        OfficeNote savedForm = officeNoteRepository.save(officeNote);

      
        String receivedUserId = null;
        if (officeNote.getOtherApprovalUserIds() != null && !officeNote.getOtherApprovalUserIds().isEmpty()) {
        	receivedUserId = officeNote.getOtherApprovalUserIds().get(0);
        } else {
        	receivedUserId = officeNote.getDivHeadUserid(); 
        }

        User submittingUser = profileService.getUserByUserid(officeNote.getUserid());
        String submittingUsername = submittingUser != null ? submittingUser.getUsername() : "Unknown User";

       
        if (receivedUserId != null) {
            onmsNotificationService.createNotification(
            		receivedUserId,
                "A new Office Note request has been submitted by " + submittingUsername + " (" + officeNote.getUserid() + ").",
                officeNote.getUserid(),
                officeNote.getFormid(),
                savedForm.getId(),
                false
            );

      
            emailService.sendNotificationEmail(submittingUser, receivedUserId, 3);
        }

        return savedForm;
    }

    
    
    @Override
    public OfficeNote backwardForm(String formId, String userid, Long id) {
        // Retrieve the OfficeNote by formId, id, and related user
        OfficeNote officeNote = officeNoteRepository.findByFormIdAndIdAndRelatedUser(formId, id, userid);

        if (officeNote == null) {
            throw new NoSuchElementException("Form not found or you are not authorized to access this form.");
        }

        // Determine the target user
        String targetUserId = determineTargetUser(userid, officeNote);

        // Reset the form statuses based on the user's role
        resetStatusesAndDates(userid, officeNote);

        // Retrieve the username of the current user
        User user = profileRepository.findByUserid(userid)
                .orElseThrow(() -> new NoSuchElementException("User not found"));
        String username = user.getUsername();

        // Send notifications
        sendNotifications(userid, targetUserId, username, officeNote);

        return officeNoteRepository.save(officeNote);
    }

    private void resetStatusesAndDates(String userid, OfficeNote officeNote) {
        if (isMdDmdAmdUser(userid, officeNote)) {
            // Reset MD, DMD, and AMD statuses
            officeNote.setMdStatus("Pending");
            officeNote.setDmdStatus("Pending");
            officeNote.setAmdStatus("Pending");
        }
        
        else if (isDivHeadUser(userid, officeNote)) {
            // Reset only OtherApprovalStatuses
            int size = officeNote.getOtherApprovalUserIds().size();
            List<String> pendingStatuses = new ArrayList<>(Collections.nCopies(size, "Pending"));
            officeNote.setOtherApprovalStatuses(pendingStatuses);
            officeNote.setDivHeadStatus("Pending");
        } else if (isOtherApprovalUser(userid, officeNote)) {
            // Reset OtherApprovalStatuses based on the index
            List<String> otherApprovalUserIds = officeNote.getOtherApprovalUserIds();
            int userIndex = otherApprovalUserIds.indexOf(userid);

            if (userIndex != -1) {
                List<String> updatedStatuses = new ArrayList<>(officeNote.getOtherApprovalStatuses());
                for (int i = 0; i <= userIndex; i++) {
                    updatedStatuses.set(i, "Pending");
                }
                officeNote.setOtherApprovalStatuses(updatedStatuses);
            }
        } else {
            throw new IllegalArgumentException("Invalid user role for resetting statuses.");
        }

        // Reset submission dates as needed
        officeNote.setOtherApprovalSubmissionDates(null);
    }

    private String determineTargetUser(String userid, OfficeNote officeNote) {
        if (isMdDmdAmdUser(userid, officeNote)) {
            return officeNote.getDivHeadUserid(); // MD, DMD, and AMD users backward to Div Head
        } else if (isDivHeadUser(userid, officeNote)) {
            return officeNote.getUserid(); // Div Head backward to original user
        } else if (isOtherApprovalUser(userid, officeNote)) {
            return officeNote.getUserid(); // Users in OtherApprovalUserIds backward to original user
        } else {
            throw new IllegalArgumentException("You are not authorized to backward this form.");
        }
    }


    private void sendNotifications(String userid, String targetUserId, String username, OfficeNote officeNote) {
        List<String> acknowledgmentUsers = new ArrayList<>();

        if (isMdDmdAmdUser(userid, officeNote)) {

            if (officeNote.getMdUserid() != null && !officeNote.getMdUserid().equals(userid)) {
                acknowledgmentUsers.add(officeNote.getMdUserid());
            }
            if (officeNote.getDmdUserid() != null && !officeNote.getDmdUserid().equals(userid)) {
                acknowledgmentUsers.add(officeNote.getDmdUserid());
            }
            if (officeNote.getAmdUserid() != null && !officeNote.getAmdUserid().equals(userid)) {
                acknowledgmentUsers.add(officeNote.getAmdUserid());
            }
        } else if (isDivHeadUser(userid, officeNote)) {
          
            acknowledgmentUsers.addAll(officeNote.getOtherApprovalUserIds());
            acknowledgmentUsers.remove(userid); 
        } else if (isOtherApprovalUser(userid, officeNote)) {
           
            List<String> otherApprovalUserIds = officeNote.getOtherApprovalUserIds();
            int backwardUserIndex = otherApprovalUserIds.indexOf(userid);

            if (backwardUserIndex != -1) {
                acknowledgmentUsers.addAll(otherApprovalUserIds.subList(0, backwardUserIndex));
            }
        } else {
            throw new IllegalArgumentException("Invalid role for sending notifications.");
        }

        acknowledgmentUsers.remove(targetUserId); 

        // Send acknowledgment notifications
        for (String ackUserId : acknowledgmentUsers) {
            onmsNotificationService.createNotification(
                    ackUserId,
                    String.format("An Office Note request related to you has been returned for modification by %s (%s).",
                            username, userid),
                    officeNote.getUserid(),
                    officeNote.getFormid(),
                    officeNote.getId(),
                    false
            );
        }

        // Notify the target user if different
        if (!userid.equals(targetUserId)) {
            onmsNotificationService.createNotification(
                    targetUserId,
                    String.format("You have received an Office Note request that has been backwarded for modification by %s (%s). Please check comments for modification.",
                            username, userid),
                    officeNote.getUserid(),
                    officeNote.getFormid(),
                    officeNote.getId(),
                    false
            );
        }
    }
    
    @Override
    public boolean isDivHeadUser(String userid, OfficeNote officeNote) {
        return userid.equals(officeNote.getDivHeadUserid());
    }

    @Override
    public boolean isMdDmdAmdUser(String userid, OfficeNote officeNote) {
        return userid.equals(officeNote.getMdUserid())
                || userid.equals(officeNote.getDmdUserid())
                || userid.equals(officeNote.getAmdUserid());
    }

    @Override
    public boolean isOtherApprovalUser(String userid, OfficeNote officeNote) {
        return officeNote.getOtherApprovalUserIds() != null
                && officeNote.getOtherApprovalUserIds().contains(userid);
    }



    @Override
    public OfficeNote updateStatus(Long id, String userid, ONMSStatusUpdateRequest request, 
            Timestamp currentTimestamp, String osUserName, String clientIpAddress) {
//    	User userinfo = profileService.getUserByUserid(userid);
        OfficeNote officeNote = officeNoteRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Form not found"));

        // Define status reversal notification message
        String reversalMessage = "Your Office Note request status was reversed from Accepted to Rejected by %s (%s).";
        String ignoreMessage = "Please ignore the previous notification; the status of the Office Note request has been reversed.";

        // Get form submitter details
        User formSubmitter = profileService.getUserByUserid(officeNote.getUserid());
        String submitterName = formSubmitter != null ? formSubmitter.getUsername() : "Unknown User";
        String deptName = formSubmitter != null ? formSubmitter.getDepartment() : "Unknown Branch";
        String branchCode = formSubmitter != null ? formSubmitter.getBranchcode() : "Unknown Code";

        // Initialize otherApprovalStatuses if null
        if (officeNote.getOtherApprovalStatuses() == null) {
            officeNote.setOtherApprovalStatuses(new ArrayList<>());
        }

     
        if (officeNote.getOtherApprovalSubmissionDates() == null) {
            officeNote.setOtherApprovalSubmissionDates(new ArrayList<>());
        }

        if (officeNote.getOtherApprovalOSUser() == null) {
            officeNote.setOtherApprovalOSUser(new ArrayList<>());
        }
        if (officeNote.getOtherApprovalMachineIP() == null) {
            officeNote.setOtherApprovalMachineIP(new ArrayList<>());
        }
        
        while (officeNote.getOtherApprovalStatuses().size() < officeNote.getOtherApprovalUserIds().size()) {
            officeNote.getOtherApprovalStatuses().add(null);  // Add default status (null or "Pending")
        }
        while (officeNote.getOtherApprovalSubmissionDates().size() < officeNote.getOtherApprovalUserIds().size()) {
            officeNote.getOtherApprovalSubmissionDates().add(null);  // Add default date (null)
        }
        while (officeNote.getOtherApprovalOSUser().size() < officeNote.getOtherApprovalUserIds().size()) {
            officeNote.getOtherApprovalOSUser().add(null);  // Default to null
        }
        while (officeNote.getOtherApprovalMachineIP().size() < officeNote.getOtherApprovalUserIds().size()) {
            officeNote.getOtherApprovalMachineIP().add(null);  // Default to null
        }

     // Loop through each approval user in sequence
        for (int i = 0; i < officeNote.getOtherApprovalUserIds().size(); i++) {
            String currentApproverUserId = officeNote.getOtherApprovalUserIds().get(i);
            if (userid.equals(currentApproverUserId)) {
                String previousStatus = officeNote.getOtherApprovalStatuses().get(i);
                String newStatus = request.getStatus();

             
                if (newStatus != null) {
             
                    officeNote.getOtherApprovalStatuses().set(i, newStatus);
                    officeNote.getOtherApprovalSubmissionDates().set(i, currentTimestamp);
                    officeNote.getOtherApprovalOSUser().set(i, osUserName);
                    officeNote.getOtherApprovalMachineIP().set(i, clientIpAddress);
                    
                    

                    // Trigger reversal notification if status changes from Accepted to Rejected
                    if ("Accepted".equalsIgnoreCase(previousStatus) && "Rejected".equalsIgnoreCase(newStatus)) {
                        onmsNotificationService.createNotification(officeNote.getUserid(),
                                String.format(reversalMessage, userid, "Approver " + i), officeNote.getUserid(),
                                officeNote.getFormid(), officeNote.getId(), false);

                        // Send ignore notification to the next authorized person
                        if (i + 1 < officeNote.getOtherApprovalUserIds().size()) {
                            String nextApproverUserId = officeNote.getOtherApprovalUserIds().get(i + 1);
                            onmsNotificationService.createNotification(nextApproverUserId,
                                    String.format(ignoreMessage + " (Form submitted by: %s, %s [%s])", submitterName,
                                            deptName, branchCode),
                                    officeNote.getUserid(), officeNote.getFormid(), officeNote.getId(), false);
                        }
                    } else {
                    	
                       User actionUser = profileRepository.findByUserid(userid)
                               .orElseThrow(() -> new NoSuchElementException("User not found"));
                       String actionUserName = actionUser.getUsername();
                       
                       onmsNotificationService.createNotification(officeNote.getUserid(),
                               "Your Office Note request was " + newStatus.toLowerCase() + " by " 
                               + actionUserName + " (" + userid + ")",
                               officeNote.getUserid(), officeNote.getFormid(), officeNote.getId(), false);
                   }

                    // Notify the next approver if the status is Accepted
                    if ("Accepted".equalsIgnoreCase(newStatus)) {
                        if (i + 1 < officeNote.getOtherApprovalUserIds().size()) {
                            String nextApproverUserId = officeNote.getOtherApprovalUserIds().get(i + 1);
                            onmsNotificationService.createNotification(nextApproverUserId,
                                    String.format(
                                            "A new Office Note request from %s (%s), %s [%s] requires your approval.",
                                            submitterName, officeNote.getUserid(), deptName, branchCode),
                                    officeNote.getUserid(), officeNote.getFormid(), officeNote.getId(), false);
                        
                        

                            
//                          Checker email
                          emailService.sendNotificationEmail(formSubmitter,officeNote.getOtherApprovalUserIds().get(i + 1),3); 
                          
                        } else if (officeNote.getDivHeadUserid() != null) {
                            // Notify div head after the last approver
                            onmsNotificationService.createNotification(officeNote.getDivHeadUserid(),
                                    String.format(
                                            "A new Office Note request from %s (%s), %s [%s] requires your approval.",
                                            submitterName, officeNote.getUserid(), deptName, branchCode),
                                    officeNote.getUserid(), officeNote.getFormid(), officeNote.getId(), false);
                        
                         // unit head email
                          emailService.sendNotificationEmail(formSubmitter,officeNote.getDivHeadUserid(),3); 
                       
                        }
                        
                        
                    }
                }

              
            }
        }
         // Div Head
            if (userid.equals(officeNote.getDivHeadUserid())) {
                String previousStatus = officeNote.getDivHeadStatus();
                String newStatus = request.getStatus();

                // Update status and send notifications if status changes
                if (newStatus != null && !newStatus.equals(previousStatus)) {
                    officeNote.setDivHeadStatus(newStatus);
                    officeNote.setDivHeadSubmissionDate(currentTimestamp);
                    officeNote.setDivHeadMachineIP(clientIpAddress);
                    officeNote.setDivOSUser(osUserName);
                    

                    if ("Accepted".equalsIgnoreCase(previousStatus) && "Rejected".equalsIgnoreCase(newStatus)) {
                        // Send reversal notification to submitter
                    	onmsNotificationService.createNotification(
                            officeNote.getUserid(),
                            String.format(reversalMessage, officeNote.getDivHeadUsername(), officeNote.getDivHeadUserid()),
                            officeNote.getUserid(),
                            officeNote.getFormid(),
                            officeNote.getId(),
                            false
                        );

                        // Send ignore notification to the DMD
                        if (officeNote.getDmdUserid() != null) {
                        	onmsNotificationService.createNotification(
                                officeNote.getDmdUserid(),
                                String.format(ignoreMessage + " (Form submitted by: %s, %s [%s])", submitterName, deptName, branchCode),
                                officeNote.getUserid(),
                                officeNote.getFormid(),
                                officeNote.getId(),
                                false
                            );
                        }
                    } else {
                    	onmsNotificationService.createNotification(
                            officeNote.getUserid(),
                            "Your Office Note request was " + newStatus.toLowerCase() + " by " + officeNote.getDivHeadUsername() +
                                " (" + officeNote.getDivHeadUserid() + ")",
                            officeNote.getUserid(),
                            officeNote.getFormid(),
                            officeNote.getId(),
                            false
                        );
                    }

                 // After Div Head approval, check DMD's functional role status
                    String dmdFunctionalStatus = functionalRoleRepository.findStatusByUserid(officeNote.getDmdUserid());
                    if ("Accepted".equalsIgnoreCase(newStatus) && officeNote.getDmdUserid() != null) {
                        // Check if the DMD's functional status is "Active"
                        if ("Active".equalsIgnoreCase(dmdFunctionalStatus)) {
                            // Notify the DMD that a new Office Note request requires their approval
                        	onmsNotificationService.createNotification(
                                officeNote.getDmdUserid(),
                                String.format("A new Office Note request from %s (%s), %s [%s] requires your approval.",
                                    submitterName, officeNote.getUserid(), deptName, branchCode),
                                officeNote.getUserid(),
                                officeNote.getFormid(),
                                officeNote.getId(),
                                false
                            );
                        
                        
                	// unit head email
                       emailService.sendNotificationEmail(formSubmitter,officeNote.getDmdUserid(),3); 
                       
                        } else {
                            // If DMD's status is not Active, forward the notification and update DMD status
                        	onmsNotificationService.createNotification(
                                officeNote.getDmdUserid(),
                                String.format("A new Office Note request from %s (%s), %s [%s] requires your approval. " +
                                        "However, your current status is 'On Leave'. The request will be forwarded to AMD.",
                                    submitterName, officeNote.getUserid(), deptName, branchCode),
                                officeNote.getUserid(),
                                officeNote.getFormid(),
                                officeNote.getId(),
                                false
                            );

                            // Update DMD status and notify submitter
                            officeNote.setDmdStatus(dmdFunctionalStatus);
                            officeNote.setDmdSubmissionDate(currentTimestamp);
                            officeNote.setDmdMachineIP(clientIpAddress);
                            officeNote.setDmdOSUser(osUserName);

                            onmsNotificationService.createNotification(
                                officeNote.getUserid(),
                                "The DMD is currently 'On Leave'. Your Office Note has been forwarded to the AMD.",
                                officeNote.getUserid(),
                                officeNote.getFormid(),
                                officeNote.getId(),
                                false
                            );

                            // Notify the AMD user (if present) about DMD's unavailability (on leave or inactive)
                            if (officeNote.getAmdUserid() != null && !"Active".equalsIgnoreCase(dmdFunctionalStatus)) {
                            	onmsNotificationService.createNotification(
                                    officeNote.getAmdUserid(),
                                    String.format("The DMD is currently 'On Leave'. Please review the Office Note request carefully as it has been forwarded to you for approval."
                                  ),
                                    officeNote.getUserid(),
                                    officeNote.getFormid(),
                                    officeNote.getId(),
                                    false
                                );
                            }
                            
                            
                        	// unit head email
                            emailService.sendNotificationEmail(formSubmitter,officeNote.getAmdUserid(),3); 
                            
                        }
                    }
                }

                
            }

            
     
            

            // Dmd
               else if (userid.equals(officeNote.getDmdUserid())) {
                   String previousStatus = officeNote.getDmdStatus();
                   String newStatus = request.getStatus();

                   // Update status and send notifications if status changes
                   if (newStatus != null && !newStatus.equals(previousStatus)) {
                       officeNote.setDmdStatus(newStatus);
                       officeNote.setDmdSubmissionDate(currentTimestamp);
                       officeNote.setDmdMachineIP(clientIpAddress);
                       officeNote.setDmdOSUser(osUserName);

                       if ("Accepted".equalsIgnoreCase(previousStatus) && "Rejected".equalsIgnoreCase(newStatus)) {
                           // Send reversal notification to submitter
                    	   onmsNotificationService.createNotification(
                               officeNote.getUserid(),
                               String.format(reversalMessage, officeNote.getDmdUsername(), officeNote.getDmdUserid()),
                               officeNote.getUserid(),
                               officeNote.getFormid(),
                               officeNote.getId(),
                               false
                           );

                           // Send ignore notification to the DMD
                           if (officeNote.getAmdUserid() != null) {
                        	   onmsNotificationService.createNotification(
                                   officeNote.getAmdUserid(),
                                   String.format(ignoreMessage + " (Form submitted by: %s, %s [%s])", submitterName, deptName, branchCode),
                                   officeNote.getUserid(),
                                   officeNote.getFormid(),
                                   officeNote.getId(),
                                   false
                               );
                           }
                       } else {
                    	   onmsNotificationService.createNotification(
                               officeNote.getUserid(),
                               "Your Office Note request was " + newStatus.toLowerCase() + " by " + officeNote.getDmdUsername() +
                                   " (" + officeNote.getDmdUserid() + ")",
                               officeNote.getUserid(),
                               officeNote.getFormid(),
                               officeNote.getId(),
                               false
                           );
                       }
                       
                       
                    // After Dmd approval, check AMD's functional role status
                       String amdFunctionalStatus = functionalRoleRepository.findStatusByUserid(officeNote.getAmdUserid());
                       if ("Accepted".equalsIgnoreCase(newStatus) && officeNote.getAmdUserid() != null) {
                           // Check if the AMD's functional status is "Active"
                           if ("Active".equalsIgnoreCase(amdFunctionalStatus)) {
                               // Notify the AMD that a new Office Note request requires their approval
                        	   onmsNotificationService.createNotification(
                                   officeNote.getAmdUserid(),
                                   String.format("A new Office Note request from %s (%s), %s [%s] requires your approval.",
                                       submitterName, officeNote.getUserid(), deptName, branchCode),
                                   officeNote.getUserid(),
                                   officeNote.getFormid(),
                                   officeNote.getId(),
                                   false
                               );
                           
                	// amd email
                    emailService.sendNotificationEmail(formSubmitter,officeNote.getAmdUserid(),3); 
                        	   
                           } else {
                               // If AMD's status is not Active, forward the notification and update AMD status
                        	   onmsNotificationService.createNotification(
                                   officeNote.getAmdUserid(),
                                   String.format("A new Office Note request from %s (%s), %s [%s] requires your approval. " +
                                           "However, your current status is 'On Leave'. The request will be forwarded to MD.",
                                       submitterName, officeNote.getUserid(), deptName, branchCode),
                                   officeNote.getUserid(),
                                   officeNote.getFormid(),
                                   officeNote.getId(),
                                   false
                               );

                               // Update AMD status and notify submitter
                               officeNote.setAmdStatus(amdFunctionalStatus);
                               officeNote.setAmdSubmissionDate(currentTimestamp);
                               officeNote.setAmdMachineIP(clientIpAddress);
                               officeNote.setAmdOSUser(osUserName);

                               onmsNotificationService.createNotification(
                                   officeNote.getUserid(),
                                   "The AMD is currently 'On Leave'. Your Office Note has been forwarded to the MD.",
                                   officeNote.getUserid(),
                                   officeNote.getFormid(),
                                   officeNote.getId(),
                                   false
                               );

                               // Notify the MD user (if present) about AMD's unavailability (on leave or inactive)
                               if (officeNote.getMdUserid() != null && !"Active".equalsIgnoreCase(amdFunctionalStatus)) {
                            	   onmsNotificationService.createNotification(
                                       officeNote.getMdUserid(),
                                       String.format("The AMD is currently 'On Leave'. Please review the Office Note request carefully as it has been forwarded to you for approval."),
                                       officeNote.getUserid(),
                                       officeNote.getFormid(),
                                       officeNote.getId(),
                                       false
                                   );
                               }
                               
                            // Md email
                              emailService.sendNotificationEmail(formSubmitter,officeNote.getMdUserid(),3); 
                           }
                       }
                   }

                  
               }
            
            
         
           // amd
               else if (userid.equals(officeNote.getAmdUserid())) {
                   String previousStatus = officeNote.getAmdStatus();
                   String newStatus = request.getStatus();

                   // Update status and send notifications if status changes
                   if (newStatus != null && !newStatus.equals(previousStatus)) {
                       officeNote.setAmdStatus(newStatus);
                       officeNote.setAmdSubmissionDate(currentTimestamp);
                       officeNote.setAmdMachineIP(clientIpAddress);
                       officeNote.setAmdOSUser(osUserName);

                       if ("Accepted".equalsIgnoreCase(previousStatus) && "Rejected".equalsIgnoreCase(newStatus)) {
                           // Send reversal notification to submitter
                    	   onmsNotificationService.createNotification(
                               officeNote.getUserid(),
                               String.format(reversalMessage, officeNote.getAmdUsername(), officeNote.getAmdUserid()),
                               officeNote.getUserid(),
                               officeNote.getFormid(),
                               officeNote.getId(),
                               false
                           );

                           // Send ignore notification to the MD
                           if (officeNote.getMdUserid() != null) {
                        	   onmsNotificationService.createNotification(
                                   officeNote.getMdUserid(),
                                   String.format(ignoreMessage + " (Form submitted by: %s, %s [%s])", submitterName, deptName, branchCode),
                                   officeNote.getUserid(),
                                   officeNote.getFormid(),
                                   officeNote.getId(),
                                   false
                               );
                           }
                       } else {
                    	   onmsNotificationService.createNotification(
                               officeNote.getUserid(),
                               "Your Office Note request was " + newStatus.toLowerCase() + " by " + officeNote.getAmdUsername() +
                                   " (" + officeNote.getAmdUserid() + ")",
                               officeNote.getUserid(),
                               officeNote.getFormid(),
                               officeNote.getId(),
                               false
                           );
                       }
                       // If the new status is "Accepted", notify the MD
                       if ("Accepted".equalsIgnoreCase(newStatus) && officeNote.getMdUserid() != null) {
                    	   onmsNotificationService.createNotification(
                               officeNote.getMdUserid(),
                               String.format("A new Office Note request from %s (%s), %s [%s] has been approved by the AMD and requires your attention.",
                                   submitterName, officeNote.getUserid(), deptName, branchCode),
                               officeNote.getUserid(),
                               officeNote.getFormid(),
                               officeNote.getId(),
                               false
                           );
                       
                	// md email
                    emailService.sendNotificationEmail(formSubmitter,officeNote.getMdUserid(),3); 
                      
                       }
                   }
               }
         // MD
               else if (userid.equals(officeNote.getMdUserid())) {
                   String previousStatus = officeNote.getMdStatus();
                   String newStatus = request.getStatus();

                   // Update status and send notifications if status changes
                   if (newStatus != null && !newStatus.equals(previousStatus)) {
                       officeNote.setMdStatus(newStatus);
                       officeNote.setMdSubmissionDate(currentTimestamp);
                       officeNote.setMdMachineIP(clientIpAddress);
                       officeNote.setMdOSUser(osUserName);

                       // If status changed from Accepted to Rejected, send reversal notification
                       if ("Accepted".equalsIgnoreCase(previousStatus) && "Rejected".equalsIgnoreCase(newStatus)) {
                           // Send reversal notification to submitter
                    	   onmsNotificationService.createNotification(
                               officeNote.getUserid(),
                               String.format(reversalMessage, officeNote.getMdUsername(), officeNote.getMdUserid()),
                               officeNote.getUserid(),
                               officeNote.getFormid(),
                               officeNote.getId(),
                               false
                           );


                       } else {
                    	   onmsNotificationService.createNotification(
                               officeNote.getUserid(),
                               "Your Office Note request was " + newStatus.toLowerCase() + " by " + officeNote.getMdUsername() +
                                   " (" + officeNote.getMdUserid() + ")",
                               officeNote.getUserid(),
                               officeNote.getFormid(),
                               officeNote.getId(),
                               false
                           );
                    	   
                    	// unit head email
                    emailService.sendNotificationEmailForUser(formSubmitter, officeNote.getUserid(), 3); 
                       }
                   }
               }

        return officeNoteRepository.save(officeNote);
    }

    }