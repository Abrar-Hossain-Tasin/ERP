package com.fsiberp.onms.controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fsiberp.bms.model.BMSView;
import com.fsiberp.bms.model.UnitHead;
import com.fsiberp.bms.repository.UnitHeadRepository;
import com.fsiberp.frms.controller.PostGRESQLConnUtils;
import com.fsiberp.frms.model.FunctionalRole;
import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.FunctionalRoleRepository;
import com.fsiberp.frms.services.ProfileService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/officenote/admin/")
public class ONMSAdminDashboard {
	
	private ProfileService profileService;
	private FunctionalRoleRepository functionalRoleRepository;
	private UnitHeadRepository unitHeadRepository;
	
	public ONMSAdminDashboard(ProfileService profileService, 
			FunctionalRoleRepository functionalRoleRepository, UnitHeadRepository unitHeadRepository) {
		
	        this.profileService = profileService;
	        this.functionalRoleRepository = functionalRoleRepository;
	        this.unitHeadRepository = unitHeadRepository;
	    }
	
	@GetMapping("pending/{id}")
    public List<BMSView> pendingForms(@PathVariable("id") String userid){
		
		FunctionalRole functionalRole = functionalRoleRepository.findByUseridAndStatus(userid, "Active");
		User user = profileService.getUserByUserid(userid);

		Connection con = null;
		List<BMSView> officenote = new ArrayList<>();
		List<BMSView> dashboard = new ArrayList<>();
		
        try {
            con = PostGRESQLConnUtils.getPostGreSQLConnection();
            con.setAutoCommit(false);
            Statement stmt = con.createStatement();
            
            ResultSet on = null;
            if (functionalRole != null && ( functionalRole.getFunctionalroleid() == 9 || 
            		functionalRole.getFunctionalroleid() == 10 || functionalRole.getFunctionalroleid() == 12)) {
            	
            	if (functionalRole.getFunctionalroleid() == 9) {
            		on = stmt.executeQuery("SELECT * FROM onms_office_note far "
            				+ "JOIN sys_app_user sau ON far.userid = sau.user_id "
            				+ "WHERE far.amd_userid = '" + userid + "' "
            				+ "AND ( far.dmd_status = 'Accepted' OR far.dmd_status = 'On Leave' ) "
            				+ "AND far.amd_status = 'Pending'");
            	}
            	else if (functionalRole.getFunctionalroleid() == 10) {
            		on = stmt.executeQuery("SELECT * FROM onms_office_note far "
            				+ "JOIN sys_app_user sau ON far.userid = sau.user_id "
            				+ "WHERE far.dmd_userid = '" + userid + "' "
            				+ "AND ( far.div_head_status = 'Accepted' "
            				+ "AND far.dmd_status = 'Pending')");
            	}
            	else if (functionalRole.getFunctionalroleid() == 12) {
            		on = stmt.executeQuery("SELECT * FROM onms_office_note far "
            				+ "JOIN sys_app_user sau ON far.userid = sau.user_id "
            				+ "WHERE far.md_userid = '" + userid + "' "
            				+ "AND ( far.amd_status = 'Accepted' OR far.amd_status = 'On Leave' ) "
            				+ "AND far.md_status = 'Pending'");
            	}
            }
            else {
            	
            	List<String> divDesig = Arrays.asList("FD001", "FD003");
			    List<UnitHead> divhead1 = unitHeadRepository.findByEmpcodeAndFuncdescodeAndStatus(user.getEmpid(), divDesig, "Active"); 
 			   
			    if (divhead1.size()!= 0) {
			    	on = stmt.executeQuery("SELECT * FROM onms_office_note far "
			    			+ "JOIN sys_app_user sau ON far.userid = sau.user_id "
			    			+ "WHERE far.div_head_userid = '" + userid + "' "
			    			+ "AND far.div_head_status = 'Pending' "
			    			+ "AND NOT EXISTS (SELECT 1 "
			    			+ "FROM unnest(far.other_aprvl_status) AS status "
			    			+ "WHERE status <> 'Accepted');");
			    	
			    }
			    else {
		            	
			    	on = stmt.executeQuery("SELECT * FROM onms_office_note far "
			    			+ "JOIN sys_app_user sau ON far.userid = sau.user_id "
			    			+ "WHERE EXISTS ( SELECT 1 "
			    			+ "FROM unnest(far.other_aprvl_userid) WITH ORDINALITY AS userid(id, index) "
			    			+ "JOIN unnest(far.other_aprvl_status) WITH ORDINALITY AS status(stat, index) "
			    			+ "ON userid.index = status.index "
			    			+ "WHERE userid.id = '" + userid + "' AND status.stat = 'Pending');");
		            
			    }
            }
            
            if (on != null) {
            	
	            while (on.next()) {
	            	BMSView bmsView = new BMSView();
	
	                long id = on.getLong("id");
	                String users = on.getString("user_id");
	                String username = on.getString("user_name");
	                String branchcode = on.getString("branch_code");
	                String divhead = on.getString("div_head_status");
	                String dmdstatus = on.getString("dmd_status");
	                String amdstatus = on.getString("amd_status");
	                String mdstatus = on.getString("md_status");
	                Timestamp submittime = on.getTimestamp("submit_time");
	                String subject = on.getString("note_subject");
	                
	                String dept = on.getString("department");
	                if (dept.equals("I C T Div., Head Office, Dhaka")) {
	                	dept = on.getString("unit");
	    	        }
	
	                bmsView.setId(id);
	                bmsView.setUserid(users);
	                bmsView.setUsername(username);
	                bmsView.setBranchcode(branchcode);
	                bmsView.setUnitheadstatus(divhead);
	                bmsView.setDmdstatus(dmdstatus);
	                bmsView.setAmdstatus(amdstatus);
	                bmsView.setMdstatus(mdstatus);
	                bmsView.setSubmittime(submittime);
	                bmsView.setFormname(subject);
	                bmsView.setDepartment(dept);
	
	                officenote.add(bmsView);
	            }
            }
            
            dashboard.addAll(officenote);
            con.close();
        } 
        catch (Exception e) {
            e.printStackTrace(); 
        }
        
        return dashboard;
	}
	
	@GetMapping("accepted/{id}")
    public List<BMSView> acceptedForms(@PathVariable("id") String userid){
		
		FunctionalRole functionalRole = functionalRoleRepository.findByUseridAndStatus(userid, "Active");
		User user = profileService.getUserByUserid(userid);
		
		Connection con = null;
		List<BMSView> officenote = new ArrayList<>();
		List<BMSView> dashboard = new ArrayList<>();
		
        try {
            con = PostGRESQLConnUtils.getPostGreSQLConnection();
            con.setAutoCommit(false);
            Statement stmt = con.createStatement();
            
            ResultSet on = null;
            
            if (functionalRole != null && ( functionalRole.getFunctionalroleid() == 9 || 
            		functionalRole.getFunctionalroleid() == 10 || functionalRole.getFunctionalroleid() == 12)) {
            	
            	if (functionalRole.getFunctionalroleid() == 9) {
            		on = stmt.executeQuery("SELECT * FROM onms_office_note far "
            				+ "JOIN sys_app_user sau ON far.userid = sau.user_id "
            				+ "WHERE far.amd_userid = '" + userid + "' "
            				+ "AND ( far.amd_status = 'Accepted' "
            				+ "OR far.amd_status = 'On Leave')");
            	}
            	else if (functionalRole.getFunctionalroleid() == 10) {
            		on = stmt.executeQuery("SELECT * FROM onms_office_note far "
            				+ "JOIN sys_app_user sau ON far.userid = sau.user_id "
            				+ "WHERE far.dmd_userid = '" + userid + "' "
            				+ "AND (far.dmd_status = 'Accepted' "
            				+ "OR far.dmd_status = 'On Leave')");
            	}
            	else if (functionalRole.getFunctionalroleid() == 12) {
            		on = stmt.executeQuery("SELECT * FROM onms_office_note far "
            				+ "JOIN sys_app_user sau ON far.userid = sau.user_id "
            				+ "WHERE far.md_userid = '" + userid + "' "
            				+ "AND (far.md_status = 'Accepted' "
            				+ "OR far.md_status = 'On Leave')");
            	}
            	
            	
            }
            else {
            	
            	List<String> divDesig = Arrays.asList("FD001", "FD003");
			    List<UnitHead> divhead1 = unitHeadRepository.findByEmpcodeAndFuncdescodeAndStatus(user.getEmpid(), divDesig, "Active"); 
 			   
			    if (divhead1.size()!= 0) {
			    	on = stmt.executeQuery("SELECT * FROM onms_office_note far "
			    			+ "JOIN sys_app_user sau ON far.userid = sau.user_id "
			    			+ "WHERE far.div_head_userid = '" + userid + "' "
			    			+ "AND far.div_head_status = 'Accepted' ");
			    	
			    	if (on != null) {
		            	
			            while (on.next()) {
			            	BMSView bmsView = new BMSView();
			
			                long id = on.getLong("id");
			                String users = on.getString("user_id");
			                String username = on.getString("user_name");
			                String branchcode = on.getString("branch_code");
			                String divhead = on.getString("div_head_status");
			                String dmdstatus = on.getString("dmd_status");
			                String amdstatus = on.getString("amd_status");
			                String mdstatus = on.getString("md_status");
			                Timestamp submittime = on.getTimestamp("submit_time");
			                String subject = on.getString("note_subject");
			                
			                String dept = on.getString("department");
			                if (dept.equals("I C T Div., Head Office, Dhaka")) {
			                	dept = on.getString("unit");
			    	        }
			
			                bmsView.setId(id);
			                bmsView.setUserid(users);
			                bmsView.setUsername(username);
			                bmsView.setBranchcode(branchcode);
			                bmsView.setUnitheadstatus(divhead);
			                bmsView.setDmdstatus(dmdstatus);
			                bmsView.setAmdstatus(amdstatus);
			                bmsView.setMdstatus(mdstatus);
			                bmsView.setSubmittime(submittime);
			                bmsView.setFormname(subject);
			                bmsView.setDepartment(dept);
			
			                officenote.add(bmsView);
			            }
		            }
			    }
			    else {
		            	
			    	on = stmt.executeQuery("SELECT * FROM onms_office_note far "
			    			+ "JOIN sys_app_user sau ON far.userid = sau.user_id "
			    			+ "WHERE EXISTS ( SELECT 1 "
			    			+ "FROM unnest(far.other_aprvl_userid) WITH ORDINALITY AS userid(id, index) "
			    			+ "JOIN unnest(far.other_aprvl_status) WITH ORDINALITY AS status(stat, index) "
			    			+ "ON userid.index = status.index "
			    			+ "WHERE userid.id = '" + userid + "' AND status.stat = 'Accepted');");
			    }
            }
            
            if (on != null) {
            	
	            while (on.next()) {
	            	BMSView bmsView = new BMSView();
	
	                long id = on.getLong("id");
	                String users = on.getString("user_id");
	                String username = on.getString("user_name");
	                String branchcode = on.getString("branch_code");
	                String divhead = on.getString("div_head_status");
	                String dmdstatus = on.getString("dmd_status");
	                String amdstatus = on.getString("amd_status");
	                String mdstatus = on.getString("md_status");
	                Timestamp submittime = on.getTimestamp("submit_time");
	                String subject = on.getString("note_subject");
	                
	                String dept = on.getString("department");
	                if (dept.equals("I C T Div., Head Office, Dhaka")) {
	                	dept = on.getString("unit");
	    	        }
	
	                bmsView.setId(id);
	                bmsView.setUserid(users);
	                bmsView.setUsername(username);
	                bmsView.setBranchcode(branchcode);
	                bmsView.setUnitheadstatus(divhead);
	                bmsView.setDmdstatus(dmdstatus);
	                bmsView.setAmdstatus(amdstatus);
	                bmsView.setMdstatus(mdstatus);
	                bmsView.setSubmittime(submittime);
	                bmsView.setFormname(subject);
	                bmsView.setDepartment(dept);
	
	                officenote.add(bmsView);
	            }
            }
            dashboard.addAll(officenote);
            con.close();
        } 
        catch (Exception e) {
            e.printStackTrace(); 
        }
        
        return dashboard;
	}
	
	@GetMapping("rejected/{id}")
    public List<BMSView> rejectedForms(@PathVariable("id") String userid){
		
		FunctionalRole functionalRole = functionalRoleRepository.findByUseridAndStatus(userid, "Active");
		User user = profileService.getUserByUserid(userid);
		
		Connection con = null;
		List<BMSView> officenote = new ArrayList<>();
		List<BMSView> dashboard = new ArrayList<>();
		
        try {
            con = PostGRESQLConnUtils.getPostGreSQLConnection();
            con.setAutoCommit(false);
            Statement stmt = con.createStatement();
            
            ResultSet on = null;
            
            if (functionalRole != null && ( functionalRole.getFunctionalroleid() == 9 || 
            		functionalRole.getFunctionalroleid() == 10 || functionalRole.getFunctionalroleid() == 12)) {
            	
            	if (functionalRole.getFunctionalroleid() == 9) {
            		on = stmt.executeQuery("SELECT * FROM onms_office_note far "
            				+ "JOIN sys_app_user sau ON far.userid = sau.user_id "
            				+ "WHERE far.amd_userid = '" + userid + "' "
            				+ "AND far.amd_status = 'Rejected'");
            	}
            	else if (functionalRole.getFunctionalroleid() == 10) {
            		on = stmt.executeQuery("SELECT * FROM onms_office_note far "
            				+ "JOIN sys_app_user sau ON far.userid = sau.user_id "
            				+ "WHERE far.dmd_userid = '" + userid + "' "
            				+ "AND far.dmd_status = 'Rejected'");
            	}
            	else if (functionalRole.getFunctionalroleid() == 12) {
            		on = stmt.executeQuery("SELECT * FROM onms_office_note far "
            				+ "JOIN sys_app_user sau ON far.userid = sau.user_id "
            				+ "WHERE far.md_userid = '" + userid + "' "
            				+ "AND far.md_status = 'Rejected'");
            	}
            	
            	
            }
            else {
            	
            	List<String> divDesig = Arrays.asList("FD001", "FD003");
			    List<UnitHead> divhead1 = unitHeadRepository.findByEmpcodeAndFuncdescodeAndStatus(user.getEmpid(), divDesig, "Active"); 
 			   
			    if (divhead1.size()!= 0) {
			    	on = stmt.executeQuery("SELECT * FROM onms_office_note far "
			    			+ "JOIN sys_app_user sau ON far.userid = sau.user_id "
			    			+ "WHERE far.div_head_userid = '" + userid + "' "
			    			+ "AND far.div_head_status = 'Rejected' ");
			    	
			    	if (on != null) {
		            	
			            while (on.next()) {
			            	BMSView bmsView = new BMSView();
			
			                long id = on.getLong("id");
			                String users = on.getString("user_id");
			                String username = on.getString("user_name");
			                String branchcode = on.getString("branch_code");
			                String divhead = on.getString("div_head_status");
			                String dmdstatus = on.getString("dmd_status");
			                String amdstatus = on.getString("amd_status");
			                String mdstatus = on.getString("md_status");
			                Timestamp submittime = on.getTimestamp("submit_time");
			                String subject = on.getString("note_subject");
			                
			                String dept = on.getString("department");
			                if (dept.equals("I C T Div., Head Office, Dhaka")) {
			                	dept = on.getString("unit");
			    	        }
			
			                bmsView.setId(id);
			                bmsView.setUserid(users);
			                bmsView.setUsername(username);
			                bmsView.setBranchcode(branchcode);
			                bmsView.setUnitheadstatus(divhead);
			                bmsView.setDmdstatus(dmdstatus);
			                bmsView.setAmdstatus(amdstatus);
			                bmsView.setMdstatus(mdstatus);
			                bmsView.setSubmittime(submittime);
			                bmsView.setFormname(subject);
			                bmsView.setDepartment(dept);
			
			                officenote.add(bmsView);
			            }
		            }
			    }
			    else {
		            	
			    	on = stmt.executeQuery("SELECT * FROM onms_office_note far "
			    			+ "JOIN sys_app_user sau ON far.userid = sau.user_id "
			    			+ "WHERE EXISTS ( SELECT 1 "
			    			+ "FROM unnest(far.other_aprvl_userid) WITH ORDINALITY AS userid(id, index) "
			    			+ "JOIN unnest(far.other_aprvl_status) WITH ORDINALITY AS status(stat, index) "
			    			+ "ON userid.index = status.index "
			    			+ "WHERE userid.id = '" + userid + "' AND status.stat = 'Rejected');");
			    }
            }
            
            if (on != null) {
            	
	            while (on.next()) {
	            	BMSView bmsView = new BMSView();
	
	                long id = on.getLong("id");
	                String users = on.getString("user_id");
	                String username = on.getString("user_name");
	                String branchcode = on.getString("branch_code");
	                String divhead = on.getString("div_head_status");
	                String dmdstatus = on.getString("dmd_status");
	                String amdstatus = on.getString("amd_status");
	                String mdstatus = on.getString("md_status");
	                Timestamp submittime = on.getTimestamp("submit_time");
	                String subject = on.getString("note_subject");
	                
	                String dept = on.getString("department");
	                if (dept.equals("I C T Div., Head Office, Dhaka")) {
	                	dept = on.getString("unit");
	    	        }
	
	                bmsView.setId(id);
	                bmsView.setUserid(users);
	                bmsView.setUsername(username);
	                bmsView.setBranchcode(branchcode);
	                bmsView.setUnitheadstatus(divhead);
	                bmsView.setDmdstatus(dmdstatus);
	                bmsView.setAmdstatus(amdstatus);
	                bmsView.setMdstatus(mdstatus);
	                bmsView.setSubmittime(submittime);
	                bmsView.setFormname(subject);
	                bmsView.setDepartment(dept);
	
	                officenote.add(bmsView);
	            }
            }
            dashboard.addAll(officenote);
            con.close();
        } 
        catch (Exception e) {
            e.printStackTrace(); 
        }
        
        return dashboard;
	}

}
