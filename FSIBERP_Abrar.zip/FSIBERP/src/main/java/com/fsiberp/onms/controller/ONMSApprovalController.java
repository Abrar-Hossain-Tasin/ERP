package com.fsiberp.onms.controller;

import java.sql.Timestamp;
import java.util.Map;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.fsiberp.onms.model.ONMSStatusUpdateRequest;
import com.fsiberp.onms.services.OfficeNoteService;

import jakarta.servlet.http.HttpServletRequest;
import com.fsiberp.bms.exception.InvalidFormIdException;

@RestController
@RequestMapping("/api/onms/approval")
@CrossOrigin(origins = "*", maxAge = 3600)
public class ONMSApprovalController {

    private final OfficeNoteService officeNoteService;

    public ONMSApprovalController(OfficeNoteService officeNoteService) {
        this.officeNoteService = officeNoteService;
    }

    @PutMapping("/{userid}/{formId}/{id}")
    public ResponseEntity<?> updateStatus(
            @PathVariable("userid") String userid,
            @PathVariable("formId") String formId,
            @PathVariable("id") Long id,
            @RequestBody ONMSStatusUpdateRequest request,
            HttpServletRequest httpRequest) {

        Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());

        // Retrieve Windows user name and client IP address
        String osUserName = System.getProperty("user.name");
        String clientIpAddress = httpRequest.getRemoteAddr();

        if (request.getFormUpdates() != null && !request.getFormUpdates().isEmpty()) {
            // Batch update case
            for (Map<String, Object> formUpdate : request.getFormUpdates()) {
                Long batchId = Long.valueOf(formUpdate.get("id").toString());
                String batchFormId = formUpdate.get("formId").toString();

                switch (batchFormId) {
                    case "5001": // OfficeNote
                        officeNoteService.updateStatus(
                                batchId, userid, request, currentTimestamp, osUserName, clientIpAddress);
                        break;
                    default:
                        throw new InvalidFormIdException("Invalid form ID: " + batchFormId);
                }
            }
            return ResponseEntity.ok("Batch update successful");
        } else {
            // Single update case
            switch (formId) {
                case "5001": // OfficeNote
                    return ResponseEntity.ok(
                            officeNoteService.updateStatus(
                                    id, userid, request, currentTimestamp, osUserName, clientIpAddress));
                default:
                    throw new InvalidFormIdException("Invalid form ID: " + formId);
            }
        }
    }
}
