package com.fsiberp.onms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.fsiberp.onms.model.OfficeNote;

//@Repository
//public interface OfficeNoteRepository extends JpaRepository<OfficeNote, Long> {
//	OfficeNote findTopByUseridOrderByIdDesc(String userid);
//	List<OfficeNote> findByUserid(String userid);
//	OfficeNote findAllByUseridAndFormidAndId(String userid, String formid, Long id);
//
//	@Query(value = "SELECT * FROM onms_office_note WHERE other_aprvl_userid @> ARRAY[:userid]::character varying[]", nativeQuery = true)
//	List<OfficeNote> findByOtherApprovalUserIdNative(@Param("userid") String userid);
//
//	@Query(value = "SELECT * FROM onms_office_note o " +
//	        "WHERE o.form_id = :formId AND o.id = :id " +
//	        "AND (o.userid = :userId OR o.div_head_userid = :userId " +
//	        "OR o.amd_userid = :userId OR o.dmd_userid = :userId " +
//	        "OR o.md_userid = :userId OR :userId = ANY(o.other_aprvl_userid))", 
//	        nativeQuery = true)
//	OfficeNote findByFormIdAndIdAndRelatedUser(@Param("formId") String formId, 
//	                                           @Param("id") Long id, 
//	                                           @Param("userId") String userId);
//}

@Repository
public interface OfficeNoteRepository extends JpaRepository<OfficeNote, Long> {
	OfficeNote findTopByUseridOrderByIdDesc(String userid);
	List<OfficeNote> findByUserid(String userid);
	OfficeNote findAllByUseridAndFormidAndId(String userid, String formid, Long id);

	@Query(value = "SELECT * FROM onms_office_note WHERE other_aprvl_userid @> ARRAY[:userid]::character varying[]", nativeQuery = true)
	List<OfficeNote> findByOtherApprovalUserIdNative(@Param("userid") String userid);

	@Query(value = "SELECT * FROM onms_office_note o " +
	        "WHERE o.form_id = :formId AND o.id = :id " +
	        "AND (o.userid = :userId OR o.div_head_userid = :userId " +
	        "OR o.amd_userid = :userId OR o.dmd_userid = :userId " +
	        "OR o.md_userid = :userId OR :userId = ANY(o.other_aprvl_userid))", 
	        nativeQuery = true)
	OfficeNote findByFormIdAndIdAndRelatedUser(@Param("formId") String formId, 
	                                           @Param("id") Long id, 
	                                           @Param("userId") String userId);
}