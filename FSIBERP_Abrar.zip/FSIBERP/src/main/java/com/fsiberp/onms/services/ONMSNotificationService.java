package com.fsiberp.onms.services;

import java.util.List;

import com.fsiberp.onms.model.ONMSNotification;

public interface ONMSNotificationService {
	ONMSNotification createNotification(String userid, String message, String fuserid, String formid, Long submissionId, boolean viewed);
	void onmsArchiveOldNotifications();
    void markAsViewed(Long id);
    boolean areNotificationsViewed(String formId); 
    void markNotificationsAsViewedForUserAndForm(String userid, String formId);
    void markNotificationsAsViewedForUserAndForm(String userid, String formid, Long submissionId);
    List<ONMSNotification> getNotifications(String userid);
}
