package com.fsiberp.onms.model;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PostPersist;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "onms_office_note")
public class OfficeNote {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Long id;

	    @Column(name = "userid", length = 255)
	    private String userid;
	    
		@Column(name = "form_id")
		private String formid;
	    
	    private String refNo;

	    @PostPersist
	    public void generateRefNo() {
	        if (id != null) {
	            String currentYear = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
	            String paddedSubmissionId = String.format("%05d", id);
	            this.refNo = currentYear + "-5001/" + paddedSubmissionId;
	        }
	    }

	    @Column(name = "delegation")
	    private int delegation;

	    @Column(name = "note_subject", length = 255)
	    private String noteSubject;
	    
	    @Column(name = "note_body", columnDefinition = "TEXT")
	    private String noteBody;

	    @Column(name = "submit_date")
	    private Date submitDate;

	    @Column(name = "submit_time")
	    private Timestamp submitTime;

	    @Column(name = "div_head_userid", length = 50)
	    private String divHeadUserid;

	    @Column(name = "div_head_username", length = 50)
	    private String divHeadUsername;

	    @Column(name = "div_head_status", length = 50)
	    private String divHeadStatus;

	    @Column(name = "div_head_subdate")
	    private Timestamp divHeadSubmissionDate;

	    @Column(name = "other_aprvl_userid", columnDefinition = "character varying[]")
	    private List<String> otherApprovalUserIds;

	    @Column(name = "other_aprvl_username", columnDefinition = "character varying[]")
	    private List<String> otherApprovalUsernames;

	    @Column(name = "other_aprvl_status", columnDefinition = "character varying[]")
	    private List<String> otherApprovalStatuses;

	    @Column(name = "other_aprvl_subdate", columnDefinition = "timestamp[]")
	    private List<Timestamp> otherApprovalSubmissionDates;


	    @Column(name = "amd_userid", length = 50)
	    private String amdUserid;

	    @Column(name = "amd_username", length = 50)
	    private String amdUsername;

	    @Column(name = "amd_status", length = 50)
	    private String amdStatus;

	    @Column(name = "amd_subdate")
	    private Timestamp amdSubmissionDate;

	    @Column(name = "dmd_userid", length = 50)
	    private String dmdUserid;

	    @Column(name = "dmd_username", length = 50)
	    private String dmdUsername;

	    @Column(name = "dmd_status", length = 50)
	    private String dmdStatus;

	    @Column(name = "dmd_subdate")
	    private Timestamp dmdSubmissionDate;

	    @Column(name = "md_userid", length = 50)
	    private String mdUserid;

	    @Column(name = "md_username", length = 50)
	    private String mdUsername;

	    @Column(name = "md_status", length = 50)
	    private String mdStatus;

	    @Column(name = "md_subdate")
	    private Timestamp mdSubmissionDate;
	    
		@Size(max = 1024)
		@Column(name = "document_paths")
		private List<String> documentPaths;

		@Transient
		private List<String> documentDownloadUrl;
		
		@Column(name = "div_head_machine_ip", length = 50)
	    private String divHeadMachineIP;
		
		@Column(name = "other_aprvl_machine_ip", columnDefinition = "character varying[]")
	    private List<String> otherApprovalMachineIP;
		
		@Column(name = "dmd_machine_ip", length = 50)
	    private String dmdMachineIP;
		
		@Column(name = "amd_machine_ip", length = 50)
	    private String amdMachineIP;
		
		@Column(name = "md_machine_ip", length = 50)
	    private String mdMachineIP;
		
		@Column(name = "div_head_os_user", length = 50)
	    private String divOSUser;
		
		@Column(name = "other_aprvl_os_user", columnDefinition = "character varying[]")
	    private List<String> otherApprovalOSUser;
		
		@Column(name = "dmd_os_user", length = 50)
	    private String dmdOSUser;
		
		@Column(name = "amd_os_user", length = 50)
	    private String amdOSUser;
		
		@Column(name = "md_os_user", length = 50)
	    private String mdOSUser;
	    
	    public OfficeNote() {
			super();

		}

				public OfficeNote(Long id, String userid, String formid, String refNo, String noteSubject, String noteBody,
				Date submitDate, Timestamp submitTime, String divHeadUserid, String divHeadUsername, String divHeadStatus,
				Timestamp divHeadSubmissionDate, List<String> otherApprovalUserIds, List<String> otherApprovalUsernames,
				List<String> otherApprovalStatuses, List<Timestamp> otherApprovalSubmissionDates, String amdUserid,
				String amdUsername, String amdStatus, Timestamp amdSubmissionDate, String dmdUserid, String dmdUsername,
				String dmdStatus, Timestamp dmdSubmissionDate, String mdUserid, String mdUsername, String mdStatus,
				Timestamp mdSubmissionDate, @Size(max = 1024) List<String> documentPaths, List<String> documentDownloadUrl,
				String divHeadMachineIP, List<String> otherApprovalMachineIP, String dmdMachineIP, String amdMachineIP,
				String mdMachineIP, String divOSUser, List<String> otherApprovalOSUser, String dmdOSUser, String amdOSUser,
				String mdOSUser, int delegation) {
			super();
			this.id = id;
			this.userid = userid;
			this.formid = formid;
			this.refNo = refNo;
			this.noteSubject = noteSubject;
			this.noteBody = noteBody;
			this.submitDate = submitDate;
			this.submitTime = submitTime;
			this.divHeadUserid = divHeadUserid;
			this.divHeadUsername = divHeadUsername;
			this.divHeadStatus = divHeadStatus;
			this.divHeadSubmissionDate = divHeadSubmissionDate;
			this.otherApprovalUserIds = otherApprovalUserIds;
			this.otherApprovalUsernames = otherApprovalUsernames;
			this.otherApprovalStatuses = otherApprovalStatuses;
			this.otherApprovalSubmissionDates = otherApprovalSubmissionDates;
			this.amdUserid = amdUserid;
			this.amdUsername = amdUsername;
			this.amdStatus = amdStatus;
			this.amdSubmissionDate = amdSubmissionDate;
			this.dmdUserid = dmdUserid;
			this.dmdUsername = dmdUsername;
			this.dmdStatus = dmdStatus;
			this.dmdSubmissionDate = dmdSubmissionDate;
			this.mdUserid = mdUserid;
			this.mdUsername = mdUsername;
			this.mdStatus = mdStatus;
			this.mdSubmissionDate = mdSubmissionDate;
			this.documentPaths = documentPaths;
			this.documentDownloadUrl = documentDownloadUrl;
			this.divHeadMachineIP = divHeadMachineIP;
			this.otherApprovalMachineIP = otherApprovalMachineIP;
			this.dmdMachineIP = dmdMachineIP;
			this.amdMachineIP = amdMachineIP;
			this.mdMachineIP = mdMachineIP;
			this.divOSUser = divOSUser;
			this.otherApprovalOSUser = otherApprovalOSUser;
			this.dmdOSUser = dmdOSUser;
			this.amdOSUser = amdOSUser;
			this.mdOSUser = mdOSUser;
			this.delegation =delegation;
		}

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getUserid() {
			return userid;
		}

		public void setUserid(String userid) {
			this.userid = userid;
		}

		public String getRefNo() {
			return refNo;
		}

		public void setRefNo(String refNo) {
			this.refNo = refNo;
		}

		public String getNoteSubject() {
			return noteSubject;
		}

		public void setNoteSubject(String noteSubject) {
			this.noteSubject = noteSubject;
		}

		public String getNoteBody() {
			return noteBody;
		}

		public void setNoteBody(String noteBody) {
			this.noteBody = noteBody;
		}

		public Date getSubmitDate() {
			return submitDate;
		}

		public void setSubmitDate(Date submitDate) {
			this.submitDate = submitDate;
		}

		public Timestamp getSubmitTime() {
			return submitTime;
		}

		public void setSubmitTime(Timestamp submitTime) {
			this.submitTime = submitTime;
		}

		public String getDivHeadUserid() {
			return divHeadUserid;
		}

		public void setDivHeadUserid(String divHeadUserid) {
			this.divHeadUserid = divHeadUserid;
		}

		public String getDivHeadUsername() {
			return divHeadUsername;
		}

		public void setDivHeadUsername(String divHeadUsername) {
			this.divHeadUsername = divHeadUsername;
		}

		public String getDivHeadStatus() {
			return divHeadStatus;
		}

		public void setDivHeadStatus(String divHeadStatus) {
			this.divHeadStatus = divHeadStatus;
		}

		public Timestamp getDivHeadSubmissionDate() {
			return divHeadSubmissionDate;
		}

		public void setDivHeadSubmissionDate(Timestamp divHeadSubmissionDate) {
			this.divHeadSubmissionDate = divHeadSubmissionDate;
		}

		public List<String> getOtherApprovalUserIds() {
			return otherApprovalUserIds;
		}

		public void setOtherApprovalUserIds(List<String> otherApprovalUserIds) {
			this.otherApprovalUserIds = otherApprovalUserIds;
		}

		public List<String> getOtherApprovalUsernames() {
			return otherApprovalUsernames;
		}

		public void setOtherApprovalUsernames(List<String> otherApprovalUsernames) {
			this.otherApprovalUsernames = otherApprovalUsernames;
		}

		public List<String> getOtherApprovalStatuses() {
			return otherApprovalStatuses;
		}

		public void setOtherApprovalStatuses(List<String> otherApprovalStatuses) {
			this.otherApprovalStatuses = otherApprovalStatuses;
		}

		public List<Timestamp> getOtherApprovalSubmissionDates() {
			return otherApprovalSubmissionDates;
		}

		public void setOtherApprovalSubmissionDates(List<Timestamp> otherApprovalSubmissionDates) {
			this.otherApprovalSubmissionDates = otherApprovalSubmissionDates;
		}

		public String getAmdUserid() {
			return amdUserid;
		}

		public void setAmdUserid(String amdUserid) {
			this.amdUserid = amdUserid;
		}

		public String getAmdUsername() {
			return amdUsername;
		}

		public void setAmdUsername(String amdUsername) {
			this.amdUsername = amdUsername;
		}

		public String getAmdStatus() {
			return amdStatus;
		}

		public void setAmdStatus(String amdStatus) {
			this.amdStatus = amdStatus;
		}

		public Timestamp getAmdSubmissionDate() {
			return amdSubmissionDate;
		}

		public void setAmdSubmissionDate(Timestamp amdSubmissionDate) {
			this.amdSubmissionDate = amdSubmissionDate;
		}

		public String getDmdUserid() {
			return dmdUserid;
		}

		public void setDmdUserid(String dmdUserid) {
			this.dmdUserid = dmdUserid;
		}

		public String getDmdUsername() {
			return dmdUsername;
		}

		public void setDmdUsername(String dmdUsername) {
			this.dmdUsername = dmdUsername;
		}

		public String getDmdStatus() {
			return dmdStatus;
		}

		public void setDmdStatus(String dmdStatus) {
			this.dmdStatus = dmdStatus;
		}

		public Timestamp getDmdSubmissionDate() {
			return dmdSubmissionDate;
		}

		public void setDmdSubmissionDate(Timestamp dmdSubmissionDate) {
			this.dmdSubmissionDate = dmdSubmissionDate;
		}

		public String getMdUserid() {
			return mdUserid;
		}

		public void setMdUserid(String mdUserid) {
			this.mdUserid = mdUserid;
		}

		public String getMdUsername() {
			return mdUsername;
		}

		public void setMdUsername(String mdUsername) {
			this.mdUsername = mdUsername;
		}

		public String getMdStatus() {
			return mdStatus;
		}

		public void setMdStatus(String mdStatus) {
			this.mdStatus = mdStatus;
		}

		public Timestamp getMdSubmissionDate() {
			return mdSubmissionDate;
		}

		public void setMdSubmissionDate(Timestamp mdSubmissionDate) {
			this.mdSubmissionDate = mdSubmissionDate;
		}

		public String getFormid() {
			return formid;
		}

		public void setFormid(String formid) {
			this.formid = formid;
		}

		public List<String> getDocumentPaths() {
			return documentPaths;
		}

		public void setDocumentPaths(List<String> documentPaths) {
			this.documentPaths = documentPaths;
		}

		public List<String> getDocumentDownloadUrl() {
			return documentDownloadUrl;
		}

		public void setDocumentDownloadUrl(List<String> documentDownloadUrl) {
			this.documentDownloadUrl = documentDownloadUrl;
		}

		public String getDivHeadMachineIP() {
			return divHeadMachineIP;
		}

		public void setDivHeadMachineIP(String divHeadMachineIP) {
			this.divHeadMachineIP = divHeadMachineIP;
		}

		public List<String> getOtherApprovalMachineIP() {
			return otherApprovalMachineIP;
		}

		public void setOtherApprovalMachineIP(List<String> otherApprovalMachineIP) {
			this.otherApprovalMachineIP = otherApprovalMachineIP;
		}

		public String getDmdMachineIP() {
			return dmdMachineIP;
		}

		public void setDmdMachineIP(String dmdMachineIP) {
			this.dmdMachineIP = dmdMachineIP;
		}

		public String getAmdMachineIP() {
			return amdMachineIP;
		}

		public void setAmdMachineIP(String amdMachineIP) {
			this.amdMachineIP = amdMachineIP;
		}

		public String getMdMachineIP() {
			return mdMachineIP;
		}

		public void setMdMachineIP(String mdMachineIP) {
			this.mdMachineIP = mdMachineIP;
		}

		public String getDivOSUser() {
			return divOSUser;
		}

		public void setDivOSUser(String divOSUser) {
			this.divOSUser = divOSUser;
		}

		public List<String> getOtherApprovalOSUser() {
			return otherApprovalOSUser;
		}

		public void setOtherApprovalOSUser(List<String> otherApprovalOSUser) {
			this.otherApprovalOSUser = otherApprovalOSUser;
		}

		public String getDmdOSUser() {
			return dmdOSUser;
		}

		public void setDmdOSUser(String dmdOSUser) {
			this.dmdOSUser = dmdOSUser;
		}

		public String getAmdOSUser() {
			return amdOSUser;
		}

		public void setAmdOSUser(String amdOSUser) {
			this.amdOSUser = amdOSUser;
		}

		public String getMdOSUser() {
			return mdOSUser;
		}

		public void setMdOSUser(String mdOSUser) {
			this.mdOSUser = mdOSUser;
		}

		public int getDelegation() {
			return delegation;
		}

		public void setDelegation(int delegation) {
			this.delegation = delegation;
		}
		
		
}
