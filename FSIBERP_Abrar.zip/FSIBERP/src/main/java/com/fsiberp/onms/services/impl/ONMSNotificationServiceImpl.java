package com.fsiberp.onms.services.impl;

import java.util.List;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;


import com.fsiberp.onms.exception.ResourceNotFoundException;
import com.fsiberp.onms.model.ONMSNotification;
import com.fsiberp.onms.repository.ONMSNotificationRepository;
import com.fsiberp.onms.services.ONMSNotificationService;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.transaction.Transactional;

@Service
public class ONMSNotificationServiceImpl implements ONMSNotificationService {

    private final ONMSNotificationRepository notificationRepository;
    private EntityManager entityManager;

    public ONMSNotificationServiceImpl(ONMSNotificationRepository notificationRepository,
    		EntityManager entityManager) {
        this.notificationRepository = notificationRepository;
        this.entityManager = entityManager;
    }

    @Override
    public ONMSNotification createNotification(String userid, String message, String fuserid, String formid, Long submissionId, boolean viewed) {
        ONMSNotification notification = new ONMSNotification();
        notification.setUserid(userid);
        notification.setMessage(message);
        notification.setFuserid(fuserid);
        notification.setFormid(formid);
        notification.setSubmissionId(submissionId);
        notification.setViewed(viewed);

        return notificationRepository.save(notification); // Save and return ONMSNotification
    }

    @Override
    public List<ONMSNotification> getNotifications(String userid) {
        return notificationRepository.findByUserid(userid);
    }

    @Override
    public void markAsViewed(Long id) {
    	ONMSNotification notification = notificationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Notification not found with ID: " + id));
        notification.setViewed(true);
        notificationRepository.save(notification);
    }

    @Override
    public boolean areNotificationsViewed(String formId) {
        List<ONMSNotification> notifications = notificationRepository.findByFormid(formId);
        return notifications.stream().allMatch(ONMSNotification::isViewed);
    }

    @Override
    public void markNotificationsAsViewedForUserAndForm(String userid, String formId) {
        List<ONMSNotification> notifications = notificationRepository.findByUseridAndFormid(userid, formId);
        if (notifications.isEmpty()) {
            throw new ResourceNotFoundException("No notifications found for User ID: " + userid + " and Form ID: " + formId);
        }
        for (ONMSNotification notification : notifications) {
            notification.setViewed(true);
        }
        notificationRepository.saveAll(notifications);
    }

    @Override
    public void markNotificationsAsViewedForUserAndForm(String userid, String formid, Long submissionId) {
        List<ONMSNotification> notifications = notificationRepository.findByUseridAndFormidAndSubmissionId(userid, formid, submissionId);
        if (notifications.isEmpty()) {
            throw new ResourceNotFoundException("No notifications found for User ID: " + userid + ", Form ID: " + formid + " and Submission ID: " + submissionId);
        }
        for (ONMSNotification notification : notifications) {
            notification.setViewed(true); // Mark notification as viewed
        }
        notificationRepository.saveAll(notifications);
    }
    
    @Override
    @Transactional
    @Scheduled(cron = "0 0 0 */30 * ?") // Runs at midnight every 30 days

    public void onmsArchiveOldNotifications() {
        // Move notifications older than 30 days to archived_notifications
        String moveQuery = "INSERT INTO sys_onms_notifications_archive (id, created_at, message, userid, viewed, formid, fuserid, submission_id) " +
                           "SELECT id, created_at, message, userid, viewed, formid, fuserid, submission_id " +
                           "FROM sys_onms_notifications " +
                           "WHERE created_at < NOW() - INTERVAL '30 days'";

        // Execute the move operation
        Query moveToArchive = entityManager.createNativeQuery(moveQuery);
        int movedRows = moveToArchive.executeUpdate();
        System.out.println("Moved " + movedRows + " notifications to onms_archived_notifications.");

        // Delete old notifications after moving them
        String deleteQuery = "DELETE FROM sys_onms_notifications WHERE created_at < NOW() - INTERVAL '30 days'";
        Query deleteOldNotifications = entityManager.createNativeQuery(deleteQuery);
        int deletedRows = deleteOldNotifications.executeUpdate();
        System.out.println("Deleted " + deletedRows + " old notifications from sys_onms_notifications.");
    }
}
