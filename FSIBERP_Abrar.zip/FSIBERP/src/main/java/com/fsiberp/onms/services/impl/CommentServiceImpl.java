package com.fsiberp.onms.services.impl;

import com.fsiberp.onms.model.Comment;
import com.fsiberp.onms.repository.CommentRepository;
import com.fsiberp.onms.services.CommentService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CommentServiceImpl implements CommentService {

    private final CommentRepository commentRepository;

    public CommentServiceImpl(CommentRepository commentRepository) {
        this.commentRepository = commentRepository;
    }

    @Override
    public List<Comment> getCommentsByFormDetails(String fuserid, String formid, Long submissionId) {

        return commentRepository.findByFuseridAndFormidAndSubmissionId(fuserid, formid, submissionId);
    }
}
