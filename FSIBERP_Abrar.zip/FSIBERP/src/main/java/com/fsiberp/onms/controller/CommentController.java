package com.fsiberp.onms.controller;

import com.fsiberp.onms.model.Comment;
import com.fsiberp.onms.services.CommentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/onms/comments/")
public class CommentController {

    private final CommentService commentService;

    public CommentController(CommentService commentService) {
        this.commentService = commentService;
    }

    
    @GetMapping("{fuserid}/{formid}/{submissionId}")
    public ResponseEntity<List<Comment>> getComments(@PathVariable String fuserid,
                                                     @PathVariable String formid,
                                                     @PathVariable Long submissionId) {
        List<Comment> comments = commentService.getCommentsByFormDetails(fuserid, formid, submissionId);
        return new ResponseEntity<>(comments, HttpStatus.OK);
    }
}
