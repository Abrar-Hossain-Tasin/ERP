package com.fsiberp.onms.exception;

public class InvalidFormIdException extends RuntimeException {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidFormIdException(String message) {
        super(message);
    }
}
