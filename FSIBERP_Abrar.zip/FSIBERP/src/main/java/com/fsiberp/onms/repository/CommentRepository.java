package com.fsiberp.onms.repository;

import org.springframework.stereotype.Repository;

import com.fsiberp.onms.model.Comment;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface CommentRepository extends JpaRepository<Comment, Long> {
	List<Comment> findByFuseridAndFormidAndSubmissionId(String fuserid, String formid, Long submissionId);
}

