package com.fsiberp.bmms.controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fsiberp.bmms.model.BoardMemo;
import com.fsiberp.bmms.repository.BoardMemoRepository;
import com.fsiberp.bms.model.BMSView;
import com.fsiberp.frms.controller.PostGRESQLConnUtils;
import com.fsiberp.onms.model.OfficeNote;
import com.fsiberp.onms.repository.OfficeNoteRepository;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/boardmemo/user/")
public class BMMSUserDashboard {
	
	private BoardMemoRepository boardMemoRepository;
	
	public BMMSUserDashboard(BoardMemoRepository boardMemoRepository) {
			this.boardMemoRepository = boardMemoRepository;
	    }
	
	@GetMapping("viewform/{userid}/{formid}/{id}")
    public ResponseEntity<?> viewForms(@PathVariable("userid") String userid, @PathVariable("formid") String formid,
    		@PathVariable("id") Long id){
		
		if (formid.equals("6001")) {
		    BoardMemo boardMemo = boardMemoRepository.findAllByUseridAndFormidAndId(userid, formid, id);
		    if (boardMemo == null) {
		        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		    } 
		// Set download URLs if the document paths are not null
	    List<String> documentPaths = boardMemo.getDocumentPaths();
	    if (documentPaths != null && !documentPaths.isEmpty()) {
	        List<String> documentDownloadUrls = new ArrayList<>();

	        for (int i = 0; i < documentPaths.size(); i++) {
	            // Add the proper URL pattern to download the document
	        	 String documentDownloadUrl = "/api/officenote/download/document/" + boardMemo.getId() + "/" + i;
	                documentDownloadUrls.add(documentDownloadUrl);
	        }

	        boardMemo.setDocumentDownloadUrl(documentDownloadUrls); // Add this field in the model for URLs
	    }

	    return new ResponseEntity<>(boardMemo, HttpStatus.OK);
	}
		else {
		    return new ResponseEntity<>("Invalid formid", HttpStatus.BAD_REQUEST);
		}
}
	
	@GetMapping("pending/{id}")
    public List<BMSView> pendingForms(@PathVariable("id") String userid){
		
		Connection con = null;
		List<BMSView> boardMemo = new ArrayList<>();
		List<BMSView> dashboard = new ArrayList<>();
		
        try {
            con = PostGRESQLConnUtils.getPostGreSQLConnection();
            con.setAutoCommit(false);
            Statement stmt = con.createStatement();
            
            ResultSet bm = stmt.executeQuery("SELECT * FROM bmms_board_memo far "
            		+ "JOIN sys_app_user sau ON far.userid = sau.user_id "
            		+ "WHERE userid = '" + userid + "' AND "
            		+ "( far.div_head_status = 'Pending' "
            		+ "OR far.amd_status = 'Pending' "
            		+ "OR far.dmd_status = 'Pending' "
            		+ "OR far.md_status = 'Pending' ) "
            		+ "AND NOT (far.div_head_status = 'Rejected' "
            		+ " OR far.amd_status = 'Rejected' "
            		+ " OR far.dmd_status = 'Rejected' "
            		+ " OR far.md_status = 'Rejected' )");
            
            if (bm != null) {
	            while (bm.next()) {
	            	BMSView bmsView = new BMSView();
	
	            	long id = bm.getLong("id");
	                String users = bm.getString("user_id");
	                String username = bm.getString("user_name");
	                String branchcode = bm.getString("branch_code");
	                String divhead = bm.getString("div_head_status");
	                String dmdstatus = bm.getString("dmd_status");
	                String amdstatus = bm.getString("amd_status");
	                String mdstatus = bm.getString("md_status");
	                Timestamp submittime = bm.getTimestamp("submit_time");
	                String subject = bm.getString("memo_subject");
	                int draft = bm.getInt("draft");
	                String strDraft = String.valueOf(draft);
	                
	                String dept = bm.getString("department");
	                if (dept.equals("I C T Div., Head Office, Dhaka")) {
	                	dept = bm.getString("unit");
	    	        }
	
	                bmsView.setId(id);
	                bmsView.setUserid(users);
	                bmsView.setUsername(username);
	                bmsView.setBranchcode(branchcode);
	                bmsView.setUnitheadstatus(divhead);
	                bmsView.setDmdstatus(dmdstatus);
	                bmsView.setAmdstatus(amdstatus);
	                bmsView.setMdstatus(mdstatus);
	                bmsView.setSubmittime(submittime);
	                bmsView.setFormname(subject);
	                bmsView.setDepartment(dept);
	                bmsView.setFormid(strDraft);
	
	                boardMemo.add(bmsView);
	            }
            }
            dashboard.addAll(boardMemo);
            con.close();
        } 
        catch (Exception e) {
            e.printStackTrace(); 
        }
        
        return dashboard;
	}
	
	@GetMapping("accepted/{id}")
    public List<BMSView> acceptedForms(@PathVariable("id") String userid){
		
		Connection con = null;
		List<BMSView> boardMemo = new ArrayList<>();
		List<BMSView> dashboard = new ArrayList<>();
		
        try {
            con = PostGRESQLConnUtils.getPostGreSQLConnection();
            con.setAutoCommit(false);
            Statement stmt = con.createStatement();
            
            ResultSet bm = stmt.executeQuery("SELECT * FROM bmms_board_memo far "
            		+ "JOIN sys_app_user sau ON far.userid = sau.user_id "
            		+ "WHERE userid = '" + userid + "' AND "
            		+ " (far.md_status = 'Accepted' "
            		+ "OR far.md_status = 'On Leave')");
            
            if (bm != null) {
	            while (bm.next()) {
	            	BMSView bmsView = new BMSView();
	
	            	long id = bm.getLong("id");
	                String users = bm.getString("user_id");
	                String username = bm.getString("user_name");
	                String branchcode = bm.getString("branch_code");
	                String divhead = bm.getString("div_head_status");
	                String dmdstatus = bm.getString("dmd_status");
	                String amdstatus = bm.getString("amd_status");
	                String mdstatus = bm.getString("md_status");
	                Timestamp submittime = bm.getTimestamp("submit_time");
	                String subject = bm.getString("memo_subject");
	                int draft = bm.getInt("draft");
	                String strDraft = String.valueOf(draft);
	                
	                String dept = bm.getString("department");
	                if (dept.equals("I C T Div., Head Office, Dhaka")) {
	                	dept = bm.getString("unit");
	    	        }
	
	                bmsView.setId(id);
	                bmsView.setUserid(users);
	                bmsView.setUsername(username);
	                bmsView.setBranchcode(branchcode);
	                bmsView.setUnitheadstatus(divhead);
	                bmsView.setDmdstatus(dmdstatus);
	                bmsView.setAmdstatus(amdstatus);
	                bmsView.setMdstatus(mdstatus);
	                bmsView.setSubmittime(submittime);
	                bmsView.setFormname(subject);
	                bmsView.setDepartment(dept);
	                bmsView.setFormid(strDraft);
	
	                boardMemo.add(bmsView);
	            }
            }
            dashboard.addAll(boardMemo);
            con.close();
        } 
        catch (Exception e) {
            e.printStackTrace(); 
        }
        
        return dashboard;
	}
	
	@GetMapping("rejected/{id}")
    public List<BMSView> rejectedForms(@PathVariable("id") String userid){
		
		Connection con = null;
		List<BMSView> boardMemo = new ArrayList<>();
		List<BMSView> dashboard = new ArrayList<>();
		
        try {
            con = PostGRESQLConnUtils.getPostGreSQLConnection();
            con.setAutoCommit(false);
            Statement stmt = con.createStatement();
            
            ResultSet bm = stmt.executeQuery("SELECT * FROM bmms_board_memo far "
            		+ "JOIN sys_app_user sau ON far.userid = sau.user_id "
            		+ "WHERE userid = '" + userid + "' AND "
            		+ "(far.div_head_status = 'Rejected' "
            		+ "OR far.amd_status = 'Rejected' "
            		+ "OR far.dmd_status = 'Rejected' "
            		+ "OR far.md_status = 'Rejected' ) ");
            
            if (bm != null) {
	            while (bm.next()) {
	            	BMSView bmsView = new BMSView();
	
	            	long id = bm.getLong("id");
	                String users = bm.getString("user_id");
	                String username = bm.getString("user_name");
	                String branchcode = bm.getString("branch_code");
	                String divhead = bm.getString("div_head_status");
	                String dmdstatus = bm.getString("dmd_status");
	                String amdstatus = bm.getString("amd_status");
	                String mdstatus = bm.getString("md_status");
	                Timestamp submittime = bm.getTimestamp("submit_time");
	                String subject = bm.getString("memo_subject");
	                int draft = bm.getInt("draft");
	                String strDraft = String.valueOf(draft);
	                
	                String dept = bm.getString("department");
	                if (dept.equals("I C T Div., Head Office, Dhaka")) {
	                	dept = bm.getString("unit");
	    	        }
	
	                bmsView.setId(id);
	                bmsView.setUserid(users);
	                bmsView.setUsername(username);
	                bmsView.setBranchcode(branchcode);
	                bmsView.setUnitheadstatus(divhead);
	                bmsView.setDmdstatus(dmdstatus);
	                bmsView.setAmdstatus(amdstatus);
	                bmsView.setMdstatus(mdstatus);
	                bmsView.setSubmittime(submittime);
	                bmsView.setFormname(subject);
	                bmsView.setDepartment(dept);
	                bmsView.setFormid(strDraft);
	
	                boardMemo.add(bmsView);
	            }
            }
            dashboard.addAll(boardMemo);
            con.close();
        } 
        catch (Exception e) {
            e.printStackTrace(); 
        }
        
        return dashboard;
	}

}
