package com.fsiberp.bmms.controller;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.apache.tika.Tika;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fsiberp.bmms.model.BoardMemo;
import com.fsiberp.bmms.repository.BoardMemoRepository;
import com.fsiberp.bmms.services.BoardMemoService;
import com.fsiberp.bms.model.UnitHead;
import com.fsiberp.bms.repository.BMSDivisionNameRepository;
import com.fsiberp.bms.repository.UnitHeadRepository;
import com.fsiberp.frms.model.BranchInfo;
import com.fsiberp.frms.model.DivisionName;
import com.fsiberp.frms.model.FunctionalRole;
import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.AuthRepository;
import com.fsiberp.frms.repository.BranchInfoRepository;
import com.fsiberp.frms.repository.FunctionalRoleRepository;
import com.fsiberp.frms.repository.ProfileRepository;
import com.fsiberp.frms.services.ProfileService;
import com.fsiberp.onms.model.Comment;
import com.fsiberp.onms.model.ONMSNotification;
import com.fsiberp.onms.model.OfficeNote;
import com.fsiberp.onms.repository.CommentRepository;
import com.fsiberp.onms.repository.ONMSNotificationRepository;
import com.fsiberp.onms.repository.OfficeNoteRepository;
import com.fsiberp.onms.services.OfficeNoteService;
import com.google.cloud.translate.Translate;
import com.google.cloud.translate.TranslateOptions;
import com.google.cloud.translate.Translation;

import jakarta.validation.Valid;

import org.springframework.core.io.UrlResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/boardmemo/")
public class BoardMemoController {

	private BoardMemoService boardMemoService;
	private ProfileService profileService;
	private FunctionalRoleRepository functionalRoleRepository;
	private BoardMemoRepository boardMemoRepository;
	private BMSDivisionNameRepository bmsDivisionNameRepository;
	private UnitHeadRepository unitHeadRepository;
	private AuthRepository authRepository;
	private ProfileRepository profileRepository;
	private BranchInfoRepository branchInfoRepository;
	private CommentRepository commentRepository;
	private ONMSNotificationRepository onmsNotificationRepository;

	@Value("${file.upload-dir}")
	private String uploadDir;

	public BoardMemoController(BoardMemoService boardMemoService, ProfileService profileService,
			BMSDivisionNameRepository bmsDivisionNameRepository, UnitHeadRepository unitHeadRepository,
			FunctionalRoleRepository functionalRoleRepository, BoardMemoRepository boardMemoRepository,
			AuthRepository authRepository, ProfileRepository profileRepository,
			BranchInfoRepository branchInfoRepository, CommentRepository commentRepository,
			ONMSNotificationRepository onmsNotificationRepository) {
		this.boardMemoService = boardMemoService;
		this.profileService = profileService;
		this.functionalRoleRepository = functionalRoleRepository;
		this.boardMemoRepository = boardMemoRepository;
		this.bmsDivisionNameRepository = bmsDivisionNameRepository;
		this.unitHeadRepository = unitHeadRepository;
		this.authRepository = authRepository;
		this.profileRepository = profileRepository;
		this.branchInfoRepository = branchInfoRepository;
		this.commentRepository = commentRepository;
		this.onmsNotificationRepository = onmsNotificationRepository;
	}
	
	
	@PostMapping("/save/{id}")
	public ResponseEntity<?> createForm(@PathVariable("id") String userid, @ModelAttribute @Valid BoardMemo boardMemo,
			@RequestParam(value = "documents", required = false) MultipartFile[] documents) {

		User user = profileService.getUserByUserid(userid);

		
		boardMemo.setUserid(user.getUserid());
		boardMemo.setFormid("6001");
		boardMemo.setDivHeadStatus("Pending");
		boardMemo.setAmdStatus("Pending");
		boardMemo.setDmdStatus("Pending");
		boardMemo.setMdStatus("Pending");
		boardMemo.setSubmitDate(new Date(System.currentTimeMillis()));
		boardMemo.setSubmitTime(new Timestamp(System.currentTimeMillis()));

		final long FILE_SIZE_LIMIT = 250 * 1024;
		List<String> documentPaths = new ArrayList<>();

		try {
			if (documents != null && documents.length > 0) {
				for (MultipartFile document : documents) {
					if (document != null && !document.isEmpty()) {

						if (document.getSize() > FILE_SIZE_LIMIT) {
							Map<String, String> errorResponse = new HashMap<>();
							errorResponse.put("error", document.getOriginalFilename() + " size exceeds 250 KB");
							return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
						}

						// Use Tika to detect the file type
						String fileType = getFileTypeFromTika(document);
						if (!"application/pdf".equals(fileType) && !"image/jpeg".equals(fileType)
								&& !"image/png".equals(fileType)) {
							Map<String, String> errorResponse = new HashMap<>();
							errorResponse.put("error", "Invalid file type. Only PDF, JPEG, and PNG files are allowed.");
							return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
						}

						// Check file extension (allow only PDF, JPEG, and PNG)
						String fileExtension = getFileExtension(document.getOriginalFilename());
						if (!"pdf".equalsIgnoreCase(fileExtension) && !"jpg".equalsIgnoreCase(fileExtension)
								&& !"jpeg".equalsIgnoreCase(fileExtension) && !"png".equalsIgnoreCase(fileExtension)) {
							Map<String, String> errorResponse = new HashMap<>();
							errorResponse.put("error",
									"Invalid file extension. Only PDF, JPG, JPEG, and PNG files are allowed.");
							return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
						}

						String documentPath = saveFile(userid, document);
						documentPaths.add(documentPath);
					}
				}
				boardMemo.setDocumentPaths(documentPaths);
			}
		} catch (IOException e) {
			Map<String, String> errorResponse = new HashMap<>();
			errorResponse.put("error", "An error occurred while processing the file: " + e.getMessage());
			return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		// Save the form and return a success response
		BoardMemo savedForm = boardMemoService.createForm(boardMemo);
		return new ResponseEntity<>(savedForm, HttpStatus.CREATED);
	}

	// Save file to disk
	private String saveFile(String userid, MultipartFile file) throws IOException {
		String originalFilename = file.getOriginalFilename();

		// Sanitize the original filename
		String sanitizedFilename = sanitizeFileName(originalFilename);

		// Construct the final filename using the sanitized filename
		String filename = userid + "_" + 5001 + "_" + System.currentTimeMillis() + "~" + sanitizedFilename;

		Path filePath = Paths.get(uploadDir, filename);

		try (InputStream inputStream = file.getInputStream()) {
			Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
		}

		return filePath.toString();
	}

	// Sanitize file name
	private String sanitizeFileName(String originalFilename) {
		// Replace any special characters with underscores
		return originalFilename.replaceAll("[^a-zA-Z0-9.-]", "_");
	}

	// Extract file extension
	private String getFileExtension(String filename) {
		if (filename == null || filename.isEmpty()) {
			return "";
		}
		int dotIndex = filename.lastIndexOf(".");
		if (dotIndex == -1) {
			return ""; // No extension found
		}
		return filename.substring(dotIndex + 1);
	}

	// Use Tika to detect file type
	private String getFileTypeFromTika(MultipartFile file) throws IOException {
		Tika tika = new Tika();
		try (InputStream inputStream = file.getInputStream()) {
			return tika.detect(inputStream);
		}
	}
	@GetMapping("/viewform/{id}")
	public ResponseEntity<BoardMemo> viewForm(@PathVariable("id") String userid) {
		BoardMemo boardMemo = boardMemoRepository.findTopByUseridOrderByIdDesc(userid);

		if (boardMemo == null) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

		// Set download URLs if the document paths are not null
		List<String> documentPaths = boardMemo.getDocumentPaths();
		if (documentPaths != null && !documentPaths.isEmpty()) {
			List<String> documentDownloadUrls = new ArrayList<>();

			for (int i = 0; i < documentPaths.size(); i++) {
				// Add the proper URL pattern to download the document
				String documentDownloadUrl = "/api/officenote/download/document/" + boardMemo.getId() + "/" + i;
				documentDownloadUrls.add(documentDownloadUrl);
			}

			boardMemo.setDocumentDownloadUrl(documentDownloadUrls); // Add this field in the model for URLs
		}

		return new ResponseEntity<>(boardMemo, HttpStatus.OK);
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<?> updateBoardMemo(@PathVariable("id") Long id, @ModelAttribute BoardMemo updateBoardMemo,
			@RequestParam(value = "documents", required = false) MultipartFile[] documents) {

		BoardMemo boardMemo = boardMemoRepository.findById(id)
				.orElseThrow(() -> new NoSuchElementException("Board Memo not found for id: " + id));

		boardMemo.setMemoSubject(updateBoardMemo.getMemoSubject());
		boardMemo.setMemoBody(updateBoardMemo.getMemoBody());
		boardMemo.setSubmitTime(new Timestamp(System.currentTimeMillis()));
		boardMemo.setSubmitDate(new Date(System.currentTimeMillis()));
		boardMemo.setDraft(updateBoardMemo.getDraft());

		final long FILE_SIZE_LIMIT = 250 * 1024;
		List<String> documentPaths = boardMemo.getDocumentPaths();
		if (documentPaths == null) {
			documentPaths = new ArrayList<>();
		}

		try {
			if (documents != null && documents.length > 0) {
				for (MultipartFile document : documents) {
					if (document != null && !document.isEmpty()) {

						if (document.getSize() > FILE_SIZE_LIMIT) {
							Map<String, String> errorResponse = new HashMap<>();
							errorResponse.put("error", document.getOriginalFilename() + " size exceeds 250 KB");
							return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
						}

						Tika tika = new Tika();
						try (InputStream inputStream = document.getInputStream()) {
							String fileType = tika.detect(inputStream);

							if (!"application/pdf".equals(fileType) && !"image/jpeg".equals(fileType)
									&& !"image/png".equals(fileType)) {
								Map<String, String> errorResponse = new HashMap<>();
								errorResponse.put("error",
										"Invalid file type. Only PDF, JPEG, and PNG files are allowed.");
								return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
							}

							String fileExtension = getFileExtension(document.getOriginalFilename());
							if (!"pdf".equalsIgnoreCase(fileExtension) && !"jpg".equalsIgnoreCase(fileExtension)
									&& !"jpeg".equalsIgnoreCase(fileExtension)
									&& !"png".equalsIgnoreCase(fileExtension)) {
								Map<String, String> errorResponse = new HashMap<>();
								errorResponse.put("error",
										"Invalid file extension. Only PDF, JPG, JPEG, and PNG files are allowed.");
								return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
							}

							String documentPath = saveFile(boardMemo.getUserid(), document);
							documentPaths.add(documentPath);
						}
					}
				}
			}
		} catch (IOException e) {
			Map<String, String> errorResponse = new HashMap<>();
			errorResponse.put("error", "An error occurred while processing the file: " + e.getMessage());
			return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
		}

//		if (updateOfficeNote.getOtherApprovalUserIds() != null
//				&& !updateOfficeNote.getOtherApprovalUserIds().isEmpty()) {
//
//			String newFirstApprovalUserId = updateOfficeNote.getOtherApprovalUserIds().get(0);
//			String oldFirstApprovalUserId = officeNote.getOtherApprovalUserIds().isEmpty() ? null
//					: officeNote.getOtherApprovalUserIds().get(0);
//
//			if (officeNote.getOtherApprovalUserIds() == null || officeNote.getOtherApprovalUserIds().isEmpty()) {
//				List<ONMSNotification> existingNotifications = onmsNotificationRepository
//						.findByUseridAndFormidAndSubmissionId(officeNote.getDivHeadUserid(), officeNote.getFormid(),
//								officeNote.getId());
//
//				if (existingNotifications != null && !existingNotifications.isEmpty()) {
//					User submittingUser = profileService.getUserByUserid(officeNote.getUserid());
//					String submittingUsername = submittingUser != null ? submittingUser.getUsername() : "Unknown User";
//
//					for (ONMSNotification notification : existingNotifications) {
//						notification.setUserid(newFirstApprovalUserId);
//						notification.setViewed(false);
//						notification.setMessage("A new Office Note request has been submitted by " + submittingUsername
//								+ " (" + officeNote.getUserid() + ").");
//						onmsNotificationRepository.save(notification);
//					}
//				}
//			}
//
//			else if (oldFirstApprovalUserId != null && !newFirstApprovalUserId.equals(oldFirstApprovalUserId)) {
//				List<ONMSNotification> existingNotifications = onmsNotificationRepository
//						.findByUseridAndFormidAndSubmissionId(oldFirstApprovalUserId, officeNote.getFormid(),
//								officeNote.getId());
//
//				if (existingNotifications != null && !existingNotifications.isEmpty()) {
//					User submittingUser = profileService.getUserByUserid(officeNote.getUserid());
//					String submittingUsername = submittingUser != null ? submittingUser.getUsername() : "Unknown User";
//
//					for (ONMSNotification notification : existingNotifications) {
//						notification.setUserid(newFirstApprovalUserId);
//						notification.setViewed(false);
//						notification.setMessage("A new Office Note request has been submitted by " + submittingUsername
//								+ " (" + officeNote.getUserid() + ").");
//						onmsNotificationRepository.save(notification);
//					}
//				}
//			}
//
//			if (officeNote.getOtherApprovalUserIds() == null) {
//				officeNote.setOtherApprovalUserIds(new ArrayList<>());
//			}
//			if (officeNote.getOtherApprovalUsernames() == null) {
//				officeNote.setOtherApprovalUsernames(new ArrayList<>());
//			}
//
//			officeNote.setOtherApprovalUserIds(updateOfficeNote.getOtherApprovalUserIds());
//
//			officeNote.setOtherApprovalUsernames(updateOfficeNote.getOtherApprovalUsernames());
//
//		}

		BoardMemo updatedBoardMemo = boardMemoRepository.save(boardMemo);
		return ResponseEntity.ok(updatedBoardMemo);
	}
	
}