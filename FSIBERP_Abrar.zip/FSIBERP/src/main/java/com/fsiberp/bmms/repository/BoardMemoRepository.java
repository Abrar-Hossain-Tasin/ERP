package com.fsiberp.bmms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.fsiberp.bmms.model.BoardMemo;



@Repository
public interface BoardMemoRepository extends JpaRepository<BoardMemo, Long> {
	BoardMemo findTopByUseridOrderByIdDesc(String userid);
	List<BoardMemo> findByUserid(String userid);
	BoardMemo findAllByUseridAndFormidAndId(String userid, String formid, Long id);


}