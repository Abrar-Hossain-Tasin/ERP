package com.fsiberp.bmms.services.impl;


import com.fsiberp.bmms.model.BoardMemo;
import com.fsiberp.bmms.repository.BoardMemoRepository;
import com.fsiberp.bmms.services.BoardMemoService;
import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.FunctionalRoleRepository;
import com.fsiberp.frms.repository.ProfileRepository;
import com.fsiberp.frms.services.EmailService;
import com.fsiberp.frms.services.ProfileService;
import com.fsiberp.onms.model.ONMSStatusUpdateRequest;
import com.fsiberp.onms.model.OfficeNote;
import com.fsiberp.onms.repository.OfficeNoteRepository;
import com.fsiberp.onms.services.ONMSNotificationService;
import com.fsiberp.onms.services.OfficeNoteService;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.NoSuchElementException;
import org.springframework.stereotype.Service;

@Service
public class BoardMemoServiceImpl implements BoardMemoService {

    private final BoardMemoRepository boardMemoRepository;
    //private final ONMSNotificationService onmsNotificationService; // Added NotificationService
    private final ProfileRepository profileRepository;
    private final ProfileService profileService;
    private final FunctionalRoleRepository functionalRoleRepository;
    private EmailService emailService;

    
    public BoardMemoServiceImpl(BoardMemoRepository boardMemoRepository, 
    		ProfileRepository profileRepository, ProfileService profileService, FunctionalRoleRepository functionalRoleRepository, EmailService emailService) {
        
    	this.boardMemoRepository = boardMemoRepository;
       // this.onmsNotificationService = onmsNotificationService;
        this.profileRepository = profileRepository;
        this.profileService = profileService;
        this.functionalRoleRepository =functionalRoleRepository;
        this.emailService = emailService;
    }
    

    
    @Override
    public BoardMemo createForm(BoardMemo boardMemo) {
    	BoardMemo savedForm = boardMemoRepository.save(boardMemo);

      
//        String receivedUserId = null;
//        if (boardMemo.getOtherApprovalUserIds() != null && !boardMemo.getOtherApprovalUserIds().isEmpty()) {
//        	receivedUserId = boardMemo.getOtherApprovalUserIds().get(0);
//        } else {
//        	receivedUserId = boardMemo.getDivHeadUserid(); 
//        }

//        User submittingUser = profileService.getUserByUserid(boardMemo.getUserid());
//        String submittingUsername = submittingUser != null ? submittingUser.getUsername() : "Unknown User";

       
//        if (receivedUserId != null) {
//            onmsNotificationService.createNotification(
//            		receivedUserId,
//                "A new Office Note request has been submitted by " + submittingUsername + " (" + boardMemo.getUserid() + ").",
//                boardMemo.getUserid(),
//                boardMemo.getFormid(),
//                savedForm.getId(),
//                false
//            );

//      
//            emailService.sendNotificationEmail(submittingUser, receivedUserId, 3);
//        }

        return savedForm;
    }

	
}
