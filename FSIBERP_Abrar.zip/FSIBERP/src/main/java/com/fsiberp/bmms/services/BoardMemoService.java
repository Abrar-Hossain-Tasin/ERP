package com.fsiberp.bmms.services;

import com.fsiberp.bmms.model.BoardMemo;


public interface BoardMemoService {
	BoardMemo createForm(BoardMemo boardMemo);
//    OfficeNote backwardForm(String formId, String userid, Long id);
//    boolean isDivHeadUser(String userid, OfficeNote officeNote);
//    boolean isMdDmdAmdUser(String userid, OfficeNote officeNote);
//    boolean isOtherApprovalUser(String userid, OfficeNote officeNote);
//    
//    OfficeNote updateStatus(Long id, String userid, ONMSStatusUpdateRequest request, 
//    	    Timestamp currentTimestamp, String osUserName, String clientIpAddress);
}
