package com.fsiberp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication(scanBasePackages = "com.fsiberp")
@EnableScheduling
public class FsiberpApplication {
    public static void main(String[] args) {
        SpringApplication.run(FsiberpApplication.class, args);
    }
}
