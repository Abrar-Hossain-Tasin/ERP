package com.fsiberp.frms.services.impl;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.stereotype.Service;

import com.fsiberp.frms.model.FunctionalRole;
import com.fsiberp.frms.model.GroupEmail;
import com.fsiberp.frms.model.IctDepartment;
import com.fsiberp.frms.model.StatusUpdateRequest;
import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.AuthRepository;
import com.fsiberp.frms.repository.FunctionalRoleRepository;
import com.fsiberp.frms.repository.GroupEmailRepository;
import com.fsiberp.frms.repository.IctDepartmentRepository;
import com.fsiberp.frms.repository.ProfileRepository;
import com.fsiberp.frms.services.EmailService;
import com.fsiberp.frms.services.GroupEmailService;
import com.fsiberp.frms.services.NotificationService;
import com.fsiberp.frms.services.ProfileService;

import jakarta.transaction.Transactional;

@Service
public class GroupEmailServiceImpl implements GroupEmailService {
	
	private final FunctionalRoleRepository functionalRoleRepository;
    private final NotificationService notificationService; // Added NotificationService
    private final ProfileRepository profileRepository;
    private final ProfileService profileService;
    private final GroupEmailRepository groupEmailRepository;
    private final AuthRepository authRepository;
    private final IctDepartmentRepository ictDepartmentRepository;
    private EmailService emailService;
    
    // Constructor updated to include NotificationService
    public GroupEmailServiceImpl(FunctionalRoleRepository functionalRoleRepository,GroupEmailRepository groupEmailRepository,
            NotificationService notificationService, ProfileRepository profileRepository, ProfileService profileService,
            AuthRepository authRepository, IctDepartmentRepository ictDepartmentRepository,
            EmailService emailService) {
        this.functionalRoleRepository = functionalRoleRepository;
        this.notificationService = notificationService;
        this.profileRepository = profileRepository;
        this.profileService = profileService;
        this.groupEmailRepository = groupEmailRepository;
        this.authRepository = authRepository;
        this.ictDepartmentRepository = ictDepartmentRepository;
        this.emailService = emailService;
    }
    
    public GroupEmail createForm(GroupEmail groupEmail) {
    	GroupEmail savedForm = groupEmailRepository.save(groupEmail);
        if (groupEmail.getUnitheaduserid() != null) {
            User user = profileService.getUserByUserid(groupEmail.getUserid());
            String username = user != null ? user.getUsername() : "Unknown User";

            
            notificationService.createNotification(groupEmail.getUnitheaduserid(),
					"A new Group Email request has been submitted by " + username + " ("
							+ groupEmail.getUserid() + ").",
							groupEmail.getUserid(),
                groupEmail.getFormid(), 
                groupEmail.getId(),     
                false                    
            );
        }
        return savedForm;
    }

    @Transactional
    public GroupEmail saveForm(GroupEmail form) {
        // Save the form temporarily to generate the ID
    	GroupEmail savedForm = groupEmailRepository.save(form);

        // Generate the reference value using the generated ID
        String currentYear = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        String paddedSubmissionId = String.format("%05d", savedForm.getId()); // Padded with zeros
        String referenceValue = currentYear + "-1005/" + paddedSubmissionId;

        // Set the reference value
        savedForm.setReferenceValue(referenceValue);

        // Save the form again with the reference value
        savedForm = groupEmailRepository.save(savedForm);

        // Trigger notification for the unit head if the userid is set
        if (savedForm.getUnitheaduserid() != null) {
            User user = profileService.getUserByUserid(savedForm.getUserid());
            String username = user != null ? user.getUsername() : "Unknown User";

           
            notificationService.createNotification(savedForm.getUnitheaduserid(),
					"A new Group Email request has been submitted by " + username + " ("
							+ savedForm.getUserid() + ").",
							savedForm.getUserid(),
                savedForm.getFormid(), 
                savedForm.getId(),     
                false                    
            );
            
//          unit head email
            emailService.sendNotificationEmail(user, savedForm.getUnitheaduserid(),1);
        }

        return savedForm;
    }

    @Override
    public GroupEmail updateStatus(Long id, String userid, StatusUpdateRequest request, Timestamp currentTimestamp) {
        // Find the form by ID
    	GroupEmail groupEmail = groupEmailRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Form not found"));

      
        
        // Unit Head status update logic
        if ("Pending".equals(groupEmail.getUnitheadstatus()) || 
            "Rejected".equals(groupEmail.getUnitheadstatus()) || 
            groupEmail.getUnitheadstatus() == null) {

        	groupEmail.setUnitheadstatus(request.getStatus());
        	groupEmail.setUnitheadcmnt(request.getComment());
        	groupEmail.setUnitheadsubdate(currentTimestamp);

            notificationService.createNotification(
            		groupEmail.getUserid(),
                "Your Group Email request was " + request.getStatus().toLowerCase() + 
                " by Unit Head " + groupEmail.getUnitheadusername() + " (" + groupEmail.getUnitheaduserid() + ")",
                groupEmail.getUserid(),
                groupEmail.getFormid(),
                groupEmail.getId(),
                false 
            );

            if ("Accepted".equalsIgnoreCase(request.getStatus())) {
                User user = profileService.getUserByUserid(groupEmail.getUserid());
//                String username = user != null ? user.getUsername() : "Unknown User";

                User formSubmitter = profileService.getUserByUserid(groupEmail.getUserid());
				String deptName = formSubmitter != null ? formSubmitter.getDepartment() : "Unknown Branch";
				String branchCode = formSubmitter != null ? formSubmitter.getBranchcode() : "Unknown Code";

                
                notificationService.createNotification(
                		groupEmail.getIsrmheaduserid(),
                		"A new Group Email request from "+ formSubmitter.getUsername() + " (" + formSubmitter.getUserid()  + "), " + deptName + " (" + branchCode + ") requires your approval.",
						groupEmail.getUserid(),
                    groupEmail.getFormid(),
                    groupEmail.getId(),
                    false
                );
                
//              isrm head email
                emailService.sendNotificationEmail(user, groupEmail.getIsrmheaduserid(),1);
            }

        // ISRM status update logic
        } else if ("Accepted".equalsIgnoreCase(groupEmail.getUnitheadstatus()) && 
                   "Pending".equalsIgnoreCase(groupEmail.getIsrmheadstatus())) {
            FunctionalRole functionalRole = functionalRoleRepository.findByUserid(userid)
                    .orElseThrow(() -> new NoSuchElementException("No such user role found"));

            if ("isrm".equalsIgnoreCase(functionalRole.getFunctionalrole())) {
            	groupEmail.setIsrmheadstatus(request.getStatus());
            	groupEmail.setIsrmheadcmnt(request.getComment());
            	groupEmail.setIsrmheadsubdate(currentTimestamp);

                notificationService.createNotification(
                		groupEmail.getUserid(),
                    "Your Group Email request was " + request.getStatus().toLowerCase() + 
                    " by ISRM Head " + groupEmail.getIsrmheadusername() + " (" + groupEmail.getIsrmheaduserid() + ").",
                    groupEmail.getUserid(),
                    groupEmail.getFormid(),
                    groupEmail.getId(),
                    false 
                );

                if ("Accepted".equalsIgnoreCase(request.getStatus())) {
                    User user = profileService.getUserByUserid(groupEmail.getUserid());
//                    String username = user != null ? user.getUsername() : "Unknown User";

                    User formSubmitter = profileService.getUserByUserid(groupEmail.getUserid());
    				String deptName = formSubmitter != null ? formSubmitter.getDepartment() : "Unknown Branch";
    				String branchCode = formSubmitter != null ? formSubmitter.getBranchcode() : "Unknown Code";

                    
                    notificationService.createNotification(
                    		groupEmail.getCitouserid(),
                    		"A new Group Email request from "+ formSubmitter.getUsername() + " (" + formSubmitter.getUserid()  + "), " + deptName + " (" + branchCode + ") requires your approval.",
    						groupEmail.getUserid(),
                        groupEmail.getFormid(),
                        groupEmail.getId(),
                        false
                    );
                    
//                  cito email
                    emailService.sendNotificationEmail(user, groupEmail.getCitouserid(),1);
                }
            }

        // CITO status update logic
        } else if ("Accepted".equalsIgnoreCase(groupEmail.getIsrmheadstatus()) && 
                   "Pending".equalsIgnoreCase(groupEmail.getCitostatus())) {
            FunctionalRole functionalRole = functionalRoleRepository.findByUserid(userid)
                    .orElseThrow(() -> new NoSuchElementException("No such user role found"));

            if ("cito".equalsIgnoreCase(functionalRole.getFunctionalrole())) {
            	groupEmail.setCitostatus(request.getStatus());
            	groupEmail.setCitocmnt(request.getComment());
            	groupEmail.setCitosubdate(currentTimestamp);

                notificationService.createNotification(
                		groupEmail.getUserid(),
                    "Your Group Email request was " + request.getStatus().toLowerCase() + 
                    " by CITO " + groupEmail.getCitousername() + " (" + groupEmail.getCitouserid() + ").",
                    groupEmail.getUserid(),
                    groupEmail.getFormid(),
                    groupEmail.getId(),
                    false 
                );

                if ("Accepted".equalsIgnoreCase(request.getStatus())) {
                    User user = profileService.getUserByUserid(groupEmail.getUserid());
//                    String username = user != null ? user.getUsername() : "Unknown User";

                    User formSubmitter = profileService.getUserByUserid(groupEmail.getUserid());
    				String deptName = formSubmitter != null ? formSubmitter.getDepartment() : "Unknown Branch";
    				String branchCode = formSubmitter != null ? formSubmitter.getBranchcode() : "Unknown Code";

                    
                    notificationService.createNotification(
                    		groupEmail.getImplbyunitheaduserid(),
                    		"A new Group Email request from "+ formSubmitter.getUsername() + " (" + formSubmitter.getUserid()  + "), " + deptName + " (" + branchCode + ") requires your approval.",
    						groupEmail.getUserid(),
                        groupEmail.getFormid(),
                        groupEmail.getId(),
                        false // Not viewed by default
                    );
                    

//                  impl unit head email
                    emailService.sendNotificationEmail(user, groupEmail.getImplbyunitheaduserid(),1);
                }
            }

        // Implementation Head status update logic
        } else if ("Accepted".equalsIgnoreCase(groupEmail.getCitostatus()) && 
                   "Pending".equalsIgnoreCase(groupEmail.getImplbyunitheadstatus())) {
        	groupEmail.setImplbyunitheadstatus(request.getStatus());
        	groupEmail.setImplbyunitheadcmnt(request.getComment());
        	groupEmail.setImplbyunitheadsubdate(currentTimestamp);

            notificationService.createNotification(
            		groupEmail.getUserid(),
                "Your Group Email request was " + request.getStatus().toLowerCase() + 
                " by the head of the Implementers Unit.",
                groupEmail.getUserid(),
                groupEmail.getFormid(),
                groupEmail.getId(),
                false // Not viewed by default
            );

            if ("Accepted".equalsIgnoreCase(request.getStatus())) {
                // Notify the System Administration Unit
                List<User> systemAdmins = profileRepository.findByUnitAndRoleid("System Administration Unit", 3);
                for (User sysAdmin : systemAdmins) {
                	
                	User formSubmitter = profileService.getUserByUserid(groupEmail.getUserid());
    				String deptName = formSubmitter != null ? formSubmitter.getDepartment() : "Unknown Branch";
    				String branchCode = formSubmitter != null ? formSubmitter.getBranchcode() : "Unknown Code";

                	
                    notificationService.createNotification(
                        sysAdmin.getUserid(),
                        "A new Group Email request from "+ formSubmitter.getUsername() + " (" + formSubmitter.getUserid()  + "), " + deptName + " (" + branchCode + ") requires your approval.",
						groupEmail.getUserid(),
                        groupEmail.getFormid(),
                        groupEmail.getId(),
                        false
                    );
                }
                

//              dept email
                  User userinfo = authRepository.findByUserid(groupEmail.getUserid()).orElse(null);
	                IctDepartment existingUser = ictDepartmentRepository.findById(groupEmail.getImplementedbydeptid()).orElse(null);
	                emailService.sendNotificationEmailForDept(userinfo, existingUser.getDeptmail(),1);
            }

        // Final implementation step
        } else if ("Done".equalsIgnoreCase(request.getStatus())) {
            User user = profileRepository.findByUserid(userid)
                    .orElseThrow(() -> new NoSuchElementException("No such user found"));

            groupEmail.setImplementedbystatus(request.getStatus());
            groupEmail.setImplementedbyuserid(userid);
            groupEmail.setImplementedbyusername(user.getUsername());
            groupEmail.setImplementedbysubdate(currentTimestamp);

            notificationService.createNotification(
            		groupEmail.getUserid(),
                "Your Group Email request has been fully completed by " + 
                		groupEmail.getImplementedbyusername() + " (" + groupEmail.getImplementedbyuserid() + ").",
                		groupEmail.getUserid(),
                		groupEmail.getFormid(),
                		groupEmail.getId(),
                false // Not viewed (false)
            );

            if ("Accepted".equalsIgnoreCase(groupEmail.getImplbyunitheadstatus())) {
                List<User> systemAdmins = profileRepository.findByUnitAndRoleid("System Administration Unit", 3);

                for (User sysAdmin : systemAdmins) {
                    notificationService.markNotificationsAsViewedForUserAndForm(
                        sysAdmin.getUserid(), groupEmail.getFormid(), groupEmail.getId() 
                    );
                }
                

//              user email
              
  	            User userinfo = authRepository.findByUserid(groupEmail.getUserid()).orElse(null);
  	            	emailService.sendNotificationEmailForUser(userinfo, groupEmail.getUserid(),1);
            }
        }

        // Save the updated createEmail object and return it
        return groupEmailRepository.save(groupEmail);
    }

    
}
