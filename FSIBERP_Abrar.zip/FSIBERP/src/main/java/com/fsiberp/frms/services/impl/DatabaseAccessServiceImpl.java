package com.fsiberp.frms.services.impl;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;
import java.util.NoSuchElementException;
import org.springframework.stereotype.Service;

import com.fsiberp.frms.model.DatabaseAccess;
import com.fsiberp.frms.model.FunctionalRole;
import com.fsiberp.frms.model.IctDepartment;
import com.fsiberp.frms.model.StatusUpdateRequest;
import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.AuthRepository;
import com.fsiberp.frms.repository.DatabaseAccessRepository;
import com.fsiberp.frms.repository.FunctionalRoleRepository;
import com.fsiberp.frms.repository.IctDepartmentRepository;
import com.fsiberp.frms.repository.ProfileRepository;
import com.fsiberp.frms.services.DatabaseAccessService;
import com.fsiberp.frms.services.EmailService;
import com.fsiberp.frms.services.NotificationService;
import com.fsiberp.frms.services.ProfileService;
import jakarta.transaction.Transactional;

@Service
public class DatabaseAccessServiceImpl implements DatabaseAccessService {

	private final FunctionalRoleRepository functionalRoleRepository;
	private final NotificationService notificationService; // Added NotificationService
	private final ProfileRepository profileRepository;
	private final ProfileService profileService;
	private final DatabaseAccessRepository databaseAccessRepository;
	private final AuthRepository authRepository;
	private final IctDepartmentRepository ictDepartmentRepository;
	private EmailService emailService;

	// Constructor updated to include NotificationService
	public DatabaseAccessServiceImpl(FunctionalRoleRepository functionalRoleRepository,
			DatabaseAccessRepository databaseAccessRepository, NotificationService notificationService,
			ProfileRepository profileRepository, ProfileService profileService, AuthRepository authRepository,
			IctDepartmentRepository ictDepartmentRepository, EmailService emailService) {
		this.functionalRoleRepository = functionalRoleRepository;
		this.notificationService = notificationService;
		this.profileRepository = profileRepository;
		this.profileService = profileService;
		this.databaseAccessRepository = databaseAccessRepository;
		this.authRepository = authRepository;
		this.ictDepartmentRepository = ictDepartmentRepository;
		this.emailService = emailService;
	}

	@Override
	public DatabaseAccess createForm(DatabaseAccess databaseAccess) {
		DatabaseAccess savedForm = databaseAccessRepository.save(databaseAccess);
		if (databaseAccess.getUnitheaduserid() != null) {
			User user = profileService.getUserByUserid(databaseAccess.getUserid());
			String username = user != null ? user.getUsername() : "Unknown User";

			notificationService.createNotification(databaseAccess.getUnitheaduserid(),
					"A new Database Access Right request has been submitted by " + username + " ("
							+ databaseAccess.getUserid() + ").",
					databaseAccess.getUserid(), databaseAccess.getFormid(), databaseAccess.getId(), false);
		}
		return savedForm;
	}

	@Transactional
	public DatabaseAccess saveForm(DatabaseAccess form) {
		// Save the form temporarily to generate the ID
		DatabaseAccess savedForm = databaseAccessRepository.save(form);

		// Generate the reference value using the generated ID
		String currentYear = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
		String paddedSubmissionId = String.format("%05d", savedForm.getId()); // Padded with zeros
		String referenceValue = currentYear + "-1015/" + paddedSubmissionId;

		// Set the reference value
		savedForm.setReferencevalue(referenceValue);

		// Save the form again with the reference value
		savedForm = databaseAccessRepository.save(savedForm);

		// Trigger notification for the unit head if the userid is set
		if (savedForm.getUnitheaduserid() != null) {
			User user = profileService.getUserByUserid(savedForm.getUserid());
			String username = user != null ? user.getUsername() : "Unknown User";

			notificationService.createNotification(savedForm.getUnitheaduserid(),
					"A new Database Access Right request has been submitted by " + username + " ("
							+ savedForm.getUserid() + ").",
					savedForm.getUserid(), savedForm.getFormid(), savedForm.getId(), false);

//            unit head email
			emailService.sendNotificationEmail(user, savedForm.getUnitheaduserid(),1);
		}

		return savedForm;
	}

	@Override
	public DatabaseAccess updateStatus(Long id, String userid, StatusUpdateRequest request,
			Timestamp currentTimestamp) {
		// Find the form by ID
		DatabaseAccess databaseAccess = databaseAccessRepository.findById(id)
				.orElseThrow(() -> new NoSuchElementException("Form not found"));

		// Unit Head status update logic
		if ("Pending".equals(databaseAccess.getUnitheadstatus())
				|| "Rejected".equals(databaseAccess.getUnitheadstatus())
				|| databaseAccess.getUnitheadstatus() == null) {

			databaseAccess.setUnitheadstatus(request.getStatus());
			databaseAccess.setUnitheadcmnt(request.getComment());
			databaseAccess.setUnitheadsubdate(currentTimestamp);

			notificationService.createNotification(databaseAccess.getUserid(),
					"Your Database Access Right request was " + request.getStatus().toLowerCase() + " by Unit Head "
							+ databaseAccess.getUnitheadusername() + " (" + databaseAccess.getUnitheaduserid() + ")",
					databaseAccess.getUserid(), databaseAccess.getFormid(), databaseAccess.getId(), false // Not viewed
																											// by
																											// default
			);

			if ("Accepted".equalsIgnoreCase(request.getStatus())) {
				User user = profileService.getUserByUserid(databaseAccess.getUserid());
//				String username = user != null ? user.getUsername() : "Unknown User";

				User formSubmitter = profileService.getUserByUserid(databaseAccess.getUserid());
				String deptName = formSubmitter != null ? formSubmitter.getDepartment() : "Unknown Branch";
				String branchCode = formSubmitter != null ? formSubmitter.getBranchcode() : "Unknown Code";

				notificationService.createNotification(databaseAccess.getIsrmheaduserid(),
						"A new Database Access Right request from "+ formSubmitter.getUsername() + "(" + formSubmitter.getUserid()  + "), " + deptName + " (" + branchCode + ") requires your approval.",
						databaseAccess.getUserid(), databaseAccess.getFormid(), databaseAccess.getId(), false);

//                isrm head email
				emailService.sendNotificationEmail(user, databaseAccess.getIsrmheaduserid(),1);
			}

			// ISRM status update logic
		} else if ("Accepted".equalsIgnoreCase(databaseAccess.getUnitheadstatus())
				&& "Pending".equalsIgnoreCase(databaseAccess.getIsrmheadstatus())) {
			FunctionalRole functionalRole = functionalRoleRepository.findByUserid(userid)
					.orElseThrow(() -> new NoSuchElementException("No such user role found"));

			if ("isrm".equalsIgnoreCase(functionalRole.getFunctionalrole())) {
				databaseAccess.setIsrmheadstatus(request.getStatus());
				databaseAccess.setIsrmheadcmnt(request.getComment());
				databaseAccess.setIsrmheadsubdate(currentTimestamp);

				notificationService.createNotification(databaseAccess.getUserid(),
						"Your Database Access Right request was " + request.getStatus().toLowerCase()
								+ " by ISRM Head " + databaseAccess.getIsrmheadusername() + " ("
								+ databaseAccess.getIsrmheaduserid() + ").",
						databaseAccess.getUserid(), databaseAccess.getFormid(), databaseAccess.getId(), false);

				if ("Accepted".equalsIgnoreCase(request.getStatus())) {
					User user = profileService.getUserByUserid(databaseAccess.getUserid());
//					String username = user != null ? user.getUsername() : "Unknown User";

					User formSubmitter = profileService.getUserByUserid(databaseAccess.getUserid());
					String deptName = formSubmitter != null ? formSubmitter.getDepartment() : "Unknown Branch";
					String branchCode = formSubmitter != null ? formSubmitter.getBranchcode() : "Unknown Code";

					notificationService.createNotification(databaseAccess.getCitouserid(),
							"A new Database Access Right request from "+ formSubmitter.getUsername() + "(" + formSubmitter.getUserid()  + "), " + deptName + " (" + branchCode + ") requires your approval.",
							databaseAccess.getUserid(), databaseAccess.getFormid(), databaseAccess.getId(), false);

//                    cito email
					emailService.sendNotificationEmail(user, databaseAccess.getCitouserid(),1);
				}
			}

			// CITO status update logic
		} else if ("Accepted".equalsIgnoreCase(databaseAccess.getIsrmheadstatus())
				&& "Pending".equalsIgnoreCase(databaseAccess.getCitostatus())) {
			FunctionalRole functionalRole = functionalRoleRepository.findByUserid(userid)
					.orElseThrow(() -> new NoSuchElementException("No such user role found"));

			if ("cito".equalsIgnoreCase(functionalRole.getFunctionalrole())) {
				databaseAccess.setCitostatus(request.getStatus());
				databaseAccess.setCitocmnt(request.getComment());
				databaseAccess.setCitosubdate(currentTimestamp);

				notificationService.createNotification(databaseAccess.getUserid(),
						"Your Database Access Right request was " + request.getStatus().toLowerCase() + " by CITO "
								+ databaseAccess.getCitousername() + " (" + databaseAccess.getCitouserid() + ").",
						databaseAccess.getUserid(), databaseAccess.getFormid(), databaseAccess.getId(), false // Not
																												// viewed
																												// by
																												// default
				);

				if ("Accepted".equalsIgnoreCase(request.getStatus())) {
					User user = profileService.getUserByUserid(databaseAccess.getUserid());
//					String username = user != null ? user.getUsername() : "Unknown User";

					User formSubmitter = profileService.getUserByUserid(databaseAccess.getUserid());
					String deptName = formSubmitter != null ? formSubmitter.getDepartment() : "Unknown Branch";
					String branchCode = formSubmitter != null ? formSubmitter.getBranchcode() : "Unknown Code";

					notificationService.createNotification(databaseAccess.getImplbyunitheaduserid(),
							"A new Database Access Right request from "+ formSubmitter.getUsername() + "(" + formSubmitter.getUserid()  + "), " + deptName + " (" + branchCode + ") requires your approval.",
							databaseAccess.getUserid(), databaseAccess.getFormid(), databaseAccess.getId(), false // Not																							// default
					);

//                    impl unit head email
					emailService.sendNotificationEmail(user, databaseAccess.getImplbyunitheaduserid(),1);
				}
			}

			// Implementation Head status update logic
		} else if ("Accepted".equalsIgnoreCase(databaseAccess.getCitostatus())
				&& "Pending".equalsIgnoreCase(databaseAccess.getImplbyunitheadstatus())) {
			databaseAccess.setImplbyunitheadstatus(request.getStatus());
			databaseAccess.setImplbyunitheadcmnt(request.getComment());
			databaseAccess.setImplbyunitheadsubdate(currentTimestamp);

			notificationService.createNotification(databaseAccess.getUserid(),
					"Your Database Access Right request was " + request.getStatus().toLowerCase()
							+ " by the head of the Implementers Unit.",
					databaseAccess.getUserid(), databaseAccess.getFormid(), databaseAccess.getId(), false // Not viewed
																											// by
																											// default
			);

			if ("Accepted".equalsIgnoreCase(request.getStatus())) {
				// Fetch the user by implbyunitheaduserid
				User implHeadUser = profileRepository.findByUserid(databaseAccess.getImplbyunitheaduserid())
						.orElseThrow(() -> new NoSuchElementException("User not found"));

				// Get the unit of the implHeadUser
				String userUnit = implHeadUser.getUnit(); // Assuming the User entity has a 'unit' field

				// Notify the admins of the dynamically retrieved unit
				List<User> systemAdmins = profileRepository.findByUnitAndRoleid(userUnit, 3);
				for (User sysAdmin : systemAdmins) {

					User formSubmitter = profileService.getUserByUserid(databaseAccess.getUserid());
					String deptName = formSubmitter != null ? formSubmitter.getDepartment() : "Unknown Branch";
					String branchCode = formSubmitter != null ? formSubmitter.getBranchcode() : "Unknown Code";

					notificationService.createNotification(sysAdmin.getUserid(),
							"A new Database Access Right request from "+ formSubmitter.getUsername() + "(" + formSubmitter.getUserid()  + "), " + deptName + " (" + branchCode + ") requires your approval.",
							databaseAccess.getUserid(), databaseAccess.getFormid(), databaseAccess.getId(), false);
				}

//                dept email
				User userinfo = authRepository.findByUserid(databaseAccess.getUserid()).orElse(null);
				IctDepartment existingUser = ictDepartmentRepository.findById(databaseAccess.getImplementedbydeptid())
						.orElse(null);
				emailService.sendNotificationEmailForDept(userinfo, existingUser.getDeptmail(),1);
			}

			// Final implementation step
		} else if ("Done".equalsIgnoreCase(request.getStatus())) {
			// Fetch the user by userid
			User user = profileRepository.findByUserid(userid)
					.orElseThrow(() -> new NoSuchElementException("No such user found"));

			// Update databaseAccess fields for implementation
			databaseAccess.setImplementedbystatus(request.getStatus());
			databaseAccess.setImplementedbyuserid(userid);
			databaseAccess.setImplementedbyusername(user.getUsername());
			databaseAccess.setImplementedbysubdate(currentTimestamp);

			// Create a notification for the user
			notificationService.createNotification(databaseAccess.getUserid(),
					"Your Database Access Right request has been fully completed by "
							+ databaseAccess.getImplementedbyusername() + " (" + databaseAccess.getImplementedbyuserid()
							+ ").",
					databaseAccess.getUserid(), databaseAccess.getFormid(), databaseAccess.getId(), false // Not viewed
																											// by
																											// default
			);

			if ("Accepted".equalsIgnoreCase(databaseAccess.getImplbyunitheadstatus())) {

				User implHeadUser = profileRepository.findByUserid(databaseAccess.getImplbyunitheaduserid())
						.orElseThrow(() -> new NoSuchElementException("Implementation head user not found"));

				// Retrieve the unit for the implementation head
				String userUnit = implHeadUser.getUnit();

				List<User> systemAdmins = profileRepository.findByUnitAndRoleid(userUnit, 3);
				for (User sysAdmin : systemAdmins) {
					notificationService.markNotificationsAsViewedForUserAndForm(sysAdmin.getUserid(),
							databaseAccess.getFormid(), databaseAccess.getId());
				}
			}

//            user email
			User userinfo = authRepository.findByUserid(databaseAccess.getUserid()).orElse(null);
			emailService.sendNotificationEmailForUser(userinfo, databaseAccess.getUserid(),1);
		}

		// Save the updated createEmail object and return it
		return databaseAccessRepository.save(databaseAccess);
	}
}
