package com.fsiberp.frms.repository;

import com.fsiberp.frms.model.CBSUserPermission;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface CBSUserPermissionRepository extends JpaRepository<CBSUserPermission, Long> {
	Optional<CBSUserPermission> findById(Long id);
	List<CBSUserPermission> findByUserid(String userid);
	CBSUserPermission findAllByUseridAndFormidAndId(String userid, String formid, Long id);
	
	@Query("SELECT c FROM CBSUserPermission c WHERE c.userid = :userid AND c.id = (SELECT MAX(c2.id) FROM CBSUserPermission c2 WHERE c2.userid = :userid)")
	List<CBSUserPermission> findByUseridAndIdIsMax(String userid);
	
	@Query("SELECT c FROM CBSUserPermission c WHERE c.userid = :userid AND c.id < :id ORDER BY c.id DESC")
	List<CBSUserPermission> findRecordsBeforeId(String userid, Long id, Pageable pageable);
	
	List<CBSUserPermission> findByImplementedbydeptid(Integer implementedbydeptid);
	
	List<CBSUserPermission> findByImplementedbystatus(String implementedbystatus);
	List<CBSUserPermission> findByImplementedbystatusAndDepartment(String implementedbystatus, String department);
	List<CBSUserPermission> findByImplementedbystatusAndBranchCode(String implementedbystatus, String branchCode);
}
