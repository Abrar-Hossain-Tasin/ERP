package com.fsiberp.frms.services.impl;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.stereotype.Service;

import com.fsiberp.frms.model.AccessControl;
import com.fsiberp.frms.model.AccessControlUser;
import com.fsiberp.frms.model.IctDepartment;
import com.fsiberp.frms.model.StatusUpdateRequest;
import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.AccessControlRepository;
import com.fsiberp.frms.repository.AccessControlUserRepository;
import com.fsiberp.frms.repository.AuthRepository;
import com.fsiberp.frms.repository.IctDepartmentRepository;
import com.fsiberp.frms.services.AccessControlService;
import com.fsiberp.frms.services.EmailService;
import com.fsiberp.frms.services.NotificationService;
import com.fsiberp.frms.services.ProfileService;

import jakarta.transaction.Transactional;

@Service
public class AccessControlServiceImpl implements AccessControlService {
	
	
		private AccessControlRepository accessControlRepository;
		private final NotificationService notificationService; 
		private final ProfileService profileService;
		private final AuthRepository authRepository;
		private final IctDepartmentRepository ictDepartmentRepository;
		private AccessControlUserRepository accessControlUserRepository;
		private final EmailService emailService;
    
    public AccessControlServiceImpl(AccessControlRepository accessControlRepository,AccessControlUserRepository accessControlUserRepository,
            NotificationService notificationService, ProfileService profileService,
            AuthRepository authRepository, IctDepartmentRepository ictDepartmentRepository,
            EmailService emailService) {
       
    	this.accessControlRepository = accessControlRepository;
        this.notificationService = notificationService;
        this.profileService = profileService;
        this.authRepository = authRepository;
        this.ictDepartmentRepository = ictDepartmentRepository;
        this.accessControlUserRepository = accessControlUserRepository;
        this.emailService = emailService;
    }

 @Override
    public AccessControl createForm(AccessControl accessControl) {
    	AccessControl savedForm = accessControlRepository.save(accessControl);
        if (accessControl.getUnitheaduserid() != null) {
            User user = profileService.getUserByUserid(accessControl.getUserid());
            String username = user != null ? user.getUsername() : "Unknown User";

       
            notificationService.createNotification(
            		accessControl.getUnitheaduserid(),
                "A new Access Control request has been submitted by " + username + " (" + accessControl.getUserid() + ")",
                accessControl.getUserid(),
                accessControl.getFormid(), 
                accessControl.getId(),     
                false                    
            );
        }
        return savedForm;
    }
    
    @Transactional
    public AccessControl saveForm(AccessControl form) {
        // Save the form temporarily to generate the ID
    	AccessControl savedForm = accessControlRepository.save(form);

        // Generate the reference value using the generated ID
        String currentYear = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        String paddedSubmissionId = String.format("%05d", savedForm.getId()); // Padded with zeros
        String referenceValue = currentYear + "-1002/" + paddedSubmissionId;

        // Set the reference value
        savedForm.setReferenceValue(referenceValue);

        // Save the form again with the reference value
        savedForm = accessControlRepository.save(savedForm);

        // Trigger notification for the unit head if the userid is set
        if (savedForm.getUnitheaduserid() != null) {
            User user = profileService.getUserByUserid(savedForm.getUserid());
            String username = user != null ? user.getUsername() : "Unknown User";

            notificationService.createNotification(
                savedForm.getUnitheaduserid(),
                "A new Access Control request has been submitted by " + username + " (" + savedForm.getUserid() + ")",
                savedForm.getUserid(),
                savedForm.getFormid(), 
                savedForm.getId(),     
                false                    
            );
            
//          unit head email
            	emailService.sendNotificationEmail(user,savedForm.getUnitheaduserid(),1);
            
        }

        return savedForm;
    }
   
    @Override
    public AccessControl updateStatus(Long id, String userid, StatusUpdateRequest request, Timestamp currentTimestamp) {
        AccessControl accessControl = accessControlRepository.findById(id)
                .orElseThrow(NoSuchElementException::new);

        // Fetch the user's information
        User user = profileService.getUserByUserid(userid);
        String username = user != null ? user.getUsername() : "Unknown User";
//        String userUnit = user != null ? user.getUnit() : "Unknown Unit";
//        String userDepartment = user != null ? user.getDepartment() : "Unknown";

        // Unit Head status update
        if (userid.equals(accessControl.getUnitheaduserid()) && ("Pending".equalsIgnoreCase(accessControl.getUnitheadstatus()) || "Rejected".equalsIgnoreCase(accessControl.getUnitheadstatus()))) {
            accessControl.setUnitheadstatus(request.getStatus());
            accessControl.setUnitheadcmnt(request.getComment());
            accessControl.setUnitheadsubdate(currentTimestamp);

            // Notify form submitter
            notificationService.createNotification(
                    accessControl.getUserid(),
                    "Your Access Control form has been " + request.getStatus().toLowerCase() + " by " + accessControl.getUnitheadusername(),
                    accessControl.getUserid(),
                    accessControl.getFormid(),
                    accessControl.getId(),
                    false
            );

            // Notify ISRM Head if the status is accepted
            if ("Accepted".equalsIgnoreCase(request.getStatus())) {
                // Fetch form submitter information
                User formSubmitter = profileService.getUserByUserid(accessControl.getUserid());
                String submitterName = formSubmitter != null ? formSubmitter.getUsername() : "Unknown User";         
                String deptName = formSubmitter != null ? formSubmitter.getDepartment() : "Unknown Branch";
                String branchCode = formSubmitter != null ? formSubmitter.getBranchcode() : "Unknown Code";
                notificationService.createNotification(
                        accessControl.getIsrmheaduserid(),
      
                        "A new Access Control request from " + submitterName + "(" + formSubmitter.getUserid()  + "), " + deptName + " (" + branchCode + ") requires your approval.",
                    
                        accessControl.getUserid(),
                        accessControl.getFormid(),
                        accessControl.getId(),
                        false
                );
            }
//          isrm head email
            emailService.sendNotificationEmail(user,accessControl.getIsrmheaduserid(),1);
        }

        // ISRM Head status update
        if (userid.equals(accessControl.getIsrmheaduserid()) && ("Pending".equalsIgnoreCase(accessControl.getIsrmheadstatus()))) {
            accessControl.setIsrmheadstatus(request.getStatus());
            accessControl.setIsrmheadcmnt(request.getComment());
            accessControl.setIsrmheadsubdate(currentTimestamp);

            // Notify form submitter
            notificationService.createNotification(
                    accessControl.getUserid(),
                    "Your Access Control form has been " + request.getStatus().toLowerCase() + " by ISRM head " + accessControl.getIsrmheadusername(),
                    accessControl.getUserid(),
                    accessControl.getFormid(),
                    accessControl.getId(),
                    false
            );

            // Notify CITO if the status is accepted
            if ("Accepted".equalsIgnoreCase(request.getStatus())) {
                // Fetch form submitter information
                User formSubmitter = profileService.getUserByUserid(accessControl.getUserid());
                String submitterName = formSubmitter != null ? formSubmitter.getUsername() : "Unknown User";
                String deptName = formSubmitter != null ? formSubmitter.getDepartment() : "Unknown Branch";
                String branchCode = formSubmitter != null ? formSubmitter.getBranchcode() : "Unknown Code";
                
                notificationService.createNotification(
                        accessControl.getCitouserid(),
                        "A new Access Control request from " + submitterName + "(" + formSubmitter.getUserid() + "), " + deptName + " (" + branchCode + ") requires your approval.",
                        accessControl.getUserid(),
                        accessControl.getFormid(),
                        accessControl.getId(),
                        false
                );
            }
//          cito email
            emailService.sendNotificationEmail(user,accessControl.getCitouserid(),1);
        }


        // CITO status update
        if (userid.equals(accessControl.getCitouserid()) && ("Pending".equalsIgnoreCase(accessControl.getCitostatus()))) {
            accessControl.setCitostatus(request.getStatus());
            accessControl.setCitocmnt(request.getComment());
            accessControl.setCitosubdate(currentTimestamp);

            // Notify form submitter
            notificationService.createNotification(
                    accessControl.getUserid(),
                    "Your Access Control form has been " + request.getStatus().toLowerCase() + " by CITO " + accessControl.getCitousername(),
                    accessControl.getUserid(),
                    accessControl.getFormid(),
                    accessControl.getId(),
                    false
            );

            if ("Accepted".equalsIgnoreCase(request.getStatus())) {
                boolean hasOtherAccess = Arrays.asList(accessControl.getDooraccess()).size() > 1;

                if (!hasOtherAccess) {
                    // Notify Network Head (if no other access)
                    User formSubmitter = profileService.getUserByUserid(accessControl.getUserid());
                    String submitterName = formSubmitter != null ? formSubmitter.getUsername() : "Unknown User";
                    String deptName = formSubmitter != null ? formSubmitter.getDepartment() : "Unknown Branch";
                    String branchCode = formSubmitter != null ? formSubmitter.getBranchcode() : "Unknown Code";

                    notificationService.createNotification(
                            accessControl.getNetworkheaduserid(),
                            "A new Access Control request from " + submitterName + "(" + formSubmitter.getUserid() + "), " + deptName + " (" + branchCode + ") requires your approval.",
                            accessControl.getUserid(),
                            accessControl.getFormid(),
                            accessControl.getId(),
                            false
                    );
                }

//              Network Head email
                emailService.sendNotificationEmail(user,accessControl.getNetworkheaduserid(),1);
            }
        }

        // Network Head status update
        if (userid.equals(accessControl.getNetworkheaduserid()) && ("Pending".equalsIgnoreCase(accessControl.getNetworkheadstatus()))) {
            accessControl.setNetworkheadstatus(request.getStatus());
            accessControl.setNetworkheadcmnt(request.getComment());
            accessControl.setNetworkheadsubdate(currentTimestamp);

            // Notify form submitter
            notificationService.createNotification(
                    accessControl.getUserid(),
                    "Your Access Control form has been " + request.getStatus().toLowerCase() + " by Network Head " + accessControl.getNetworkheadusername(),
                    accessControl.getUserid(),
                    accessControl.getFormid(),
                    accessControl.getId(),
                    false
            );

            // If accepted, notify all members of AccessControlUser
            if ("Accepted".equalsIgnoreCase(request.getStatus())) {
                List<AccessControlUser> networkAdmins = accessControlUserRepository.findAll(); // Fetch all users
                User formSubmitter = profileService.getUserByUserid(accessControl.getUserid());
                String submitterName = formSubmitter != null ? formSubmitter.getUsername() : "Unknown User";
                String deptName = formSubmitter != null ? formSubmitter.getDepartment() : "Unknown Branch";
                String branchCode = formSubmitter != null ? formSubmitter.getBranchcode() : "Unknown Code";

                for (AccessControlUser admin : networkAdmins) {
                    notificationService.createNotification(
                            admin.getUserid(),
                            "A new Access Control request from " + submitterName + "(" + formSubmitter.getUserid() + "), " + deptName + " (" + branchCode + ") requires your approval.",
                            accessControl.getUserid(),
                            accessControl.getFormid(),
                            accessControl.getId(),
                            false
                    );
                }
                

//              Implementer's email
                
                User userinfo = authRepository.findByUserid(accessControl.getUserid()).orElse(null);
                IctDepartment existingUser = ictDepartmentRepository.findById(accessControl.getImplementedbydeptid()).orElse(null);
                emailService.sendNotificationEmailForDept(userinfo, existingUser.getDeptmail(),1);
                
            }
        }

        // Network implemented by (Done) statuses
        if ("Done".equalsIgnoreCase(request.getStatus())) {
            List<AccessControlUser> networkAdmins = accessControlUserRepository.findAll(); // Fetch all users
            for (AccessControlUser networkAdmin : networkAdmins) {
                notificationService.markNotificationsAsViewedForUserAndForm(networkAdmin.getUserid(), accessControl.getFormid());
            }

            
            accessControl.setNetworkimplementedbystatus(request.getStatus());
            accessControl.setNetworkimplementedbyuserid(userid);
            accessControl.setNetworkimplementedbyusername(username);
            accessControl.setNetworkimplementedbycmnt(request.getComment());
            accessControl.setNetworkimplementedbysubdate(currentTimestamp);
            
            // Prepare the notification message
            String notificationMessage = "Your Access Control request has been fully completed by " +
                    accessControl.getNetworkimplementedbyusername() + " (" + accessControl.getNetworkimplementedbyuserid() + ").";

            // Check for comments and append if available
            if (request.getComment() != null && !request.getComment().isEmpty()) {
                notificationMessage += " Comments: " + request.getComment();
            }

            // Send notification
            notificationService.createNotification(
                    accessControl.getUserid(),
                    notificationMessage,
                    accessControl.getUserid(),
                    accessControl.getFormid(),
                    accessControl.getId(),
                    false
            );
        }


        // User email
        User userinfo = authRepository.findByUserid(accessControl.getUserid()).orElse(null);
        
        emailService.sendNotificationEmailForUser(userinfo, accessControl.getUserid(),1);
        return accessControlRepository.save(accessControl);
    }
}