package com.fsiberp.frms.controller;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.apache.tika.Tika;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import com.fsiberp.frms.model.AccessControl;
import com.fsiberp.frms.model.FunctionalRole;
import com.fsiberp.frms.model.Notification;
import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.AccessControlRepository;
import com.fsiberp.frms.repository.FunctionalRoleRepository;
import com.fsiberp.frms.repository.NotificationRepository;
import com.fsiberp.frms.services.AccessControlService;
import com.fsiberp.frms.services.EmailService;
import com.fsiberp.frms.services.ProfileService;

import jakarta.validation.Valid;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;


@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/accesscontrol/")
public class AccessControlController {

    private AccessControlService accessControlService;
    private ProfileService profileService;
    private FunctionalRoleRepository functionalRoleRepository;
    private AccessControlRepository accessControlRepository;
    private NotificationRepository notificationRepository;
    private final EmailService emailService;
    
    @Value("${file.upload-dir}")
    private String uploadDir;

    public AccessControlController(AccessControlService accessControlService, ProfileService profileService, 
    		NotificationRepository notificationRepository, FunctionalRoleRepository functionalRoleRepository, 
    		AccessControlRepository accessControlRepository, EmailService emailService) {
        this.accessControlService = accessControlService;
        this.profileService = profileService;
        this.functionalRoleRepository = functionalRoleRepository;
        this.accessControlRepository = accessControlRepository;
        this.notificationRepository = notificationRepository;
        this.emailService = emailService;
    }

    @GetMapping("view/{id}")
    public ResponseEntity<User> showForms(@PathVariable("id") String userid) {
        User user = profileService.getUserByUserid(userid);
       
        FunctionalRole citoRole = functionalRoleRepository.findByFunctionalroleAndStatus("cito" , "Active")
                .orElseThrow(NoSuchElementException::new);
        User citoinfo = profileService.getUserByUserid(citoRole.getUserid());
        
        FunctionalRole networkRole = functionalRoleRepository.findByFunctionalroleAndStatus("network", "Active")
                .orElseThrow(NoSuchElementException::new);
        User networkinfo = profileService.getUserByUserid(networkRole.getUserid());

        FunctionalRole gsdRole = functionalRoleRepository.findByFunctionalroleAndStatus("gsd", "Active")
                .orElseThrow(NoSuchElementException::new);
        User gsdinfo = profileService.getUserByUserid(gsdRole.getUserid()); 

        FunctionalRole isrmRole = functionalRoleRepository.findByFunctionalroleAndStatus("isrm" , "Active")
                .orElseThrow(NoSuchElementException::new);
        User isrminfo = profileService.getUserByUserid(isrmRole.getUserid());
		

        user.setCreatedby(citoinfo.getUsername());
        user.setUsergrp(isrminfo.getUsername());
        user.setUnit(networkinfo.getUsername());
        user.setConfirmPassword(gsdinfo.getUsername());
        user.setPassword("Pending");

        return new ResponseEntity<>(user, HttpStatus.OK);
    }
    
    @PostMapping("save/{id}")
    public ResponseEntity<?> createForm(@PathVariable("id") String userid,
                                        @ModelAttribute @Valid AccessControl accessControl,
                                        @RequestParam(value = "employeeIdCard", required = false) MultipartFile employeeIdCard,
                                        @RequestParam(value = "joiningLetter", required = false) MultipartFile joiningLetter,
                                        @RequestParam(value = "dooraccess", required = false) String[] dooraccess) {

        User user = profileService.getUserByUserid(userid);

        FunctionalRole citoRole = functionalRoleRepository.findByFunctionalroleAndStatus("cito", "Active")
                .orElseThrow(NoSuchElementException::new);
        User citoinfo = profileService.getUserByUserid(citoRole.getUserid());

        FunctionalRole isrmRole = functionalRoleRepository.findByFunctionalroleAndStatus("isrm", "Active")
                .orElseThrow(NoSuchElementException::new);
        User isrminfo = profileService.getUserByUserid(isrmRole.getUserid());

        FunctionalRole networkRole = functionalRoleRepository.findByFunctionalroleAndStatus("network", "Active")
                .orElseThrow(NoSuchElementException::new);
        User networkinfo = profileService.getUserByUserid(networkRole.getUserid());

        accessControl.setFormid("1002");
        accessControl.setUserid(user.getUserid());
        accessControl.setCitouserid(citoinfo.getUserid());
        accessControl.setCitousername(citoinfo.getUsername());
        accessControl.setCitostatus("Pending");
        accessControl.setIsrmheaduserid(isrminfo.getUserid());
        accessControl.setIsrmheadusername(isrminfo.getUsername());
        accessControl.setIsrmheadstatus("Pending");
        accessControl.setUnitheadstatus("Pending");

        accessControl.setBranchCode(user.getBranchcode());
        if (user.getDepartment().equals("I C T Div., Head Office, Dhaka")) {
            accessControl.setDepartment(user.getUnit());
        } else {
            accessControl.setDepartment(user.getDepartment());
        }

        accessControl.setNetworkheaduserid(networkinfo.getUserid());
        accessControl.setNetworkheadusername(networkinfo.getUsername());
        accessControl.setNetworkheadstatus("Pending");
        accessControl.setNetworkimplementedbystatus("Pending");
        accessControl.setImplementedbydeptid(14);

        accessControl.setSubmitdate(new Date(System.currentTimeMillis()));
        accessControl.setSubmittime(new Timestamp(System.currentTimeMillis()));

        // File size limit in bytes (250 KB)
        final long maxFileSize = 250 * 1024;

        try {
            // Handling Employee ID Card file
            if (employeeIdCard != null && !employeeIdCard.isEmpty()) {
                if (employeeIdCard.getSize() > maxFileSize) {
                    Map<String, String> errorResponse = new HashMap<>();
                    errorResponse.put("error", "Employee ID Card exceeds the maximum allowed size of 250 KB.");
                    return ResponseEntity.badRequest().body(errorResponse);
                }

                // Validate file type
                String fileType = getFileTypeFromTika(employeeIdCard);
                if (!"application/pdf".equals(fileType) && !"image/jpeg".equals(fileType) && !"image/png".equals(fileType)) {
                    Map<String, String> errorResponse = new HashMap<>();
                    errorResponse.put("error", "Invalid file type. Only PDF, JPEG, and PNG files are allowed.");
                    return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
                }

                // Check file extension (allow only PDF, JPEG, PNG)
                String fileExtension = getFileExtension(employeeIdCard.getOriginalFilename());
                if (!"pdf".equalsIgnoreCase(fileExtension) && !"jpg".equalsIgnoreCase(fileExtension) &&
                    !"jpeg".equalsIgnoreCase(fileExtension) && !"png".equalsIgnoreCase(fileExtension)) {
                    Map<String, String> errorResponse = new HashMap<>();
                    errorResponse.put("error", "Invalid file extension. Only PDF, JPG, JPEG, and PNG files are allowed.");
                    return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
                }

                String employeeIdCardPath = saveFile(userid, employeeIdCard);
                accessControl.setEmployeeIdCardPath(employeeIdCardPath);
            }

            // Handling Joining Letter file
            if (joiningLetter != null && !joiningLetter.isEmpty()) {
                if (joiningLetter.getSize() > maxFileSize) {
                    Map<String, String> errorResponse = new HashMap<>();
                    errorResponse.put("error", "Joining Letter exceeds the maximum allowed size of 250 KB.");
                    return ResponseEntity.badRequest().body(errorResponse);
                }

                // Validate file type
                String fileType = getFileTypeFromTika(joiningLetter);
                if (!"application/pdf".equals(fileType) && !"image/jpeg".equals(fileType) && !"image/png".equals(fileType)) {
                    Map<String, String> errorResponse = new HashMap<>();
                    errorResponse.put("error", "Invalid file type. Only PDF, JPEG, and PNG files are allowed.");
                    return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
                }

                // Check file extension (allow only PDF, JPEG, PNG)
                String fileExtension = getFileExtension(joiningLetter.getOriginalFilename());
                if (!"pdf".equalsIgnoreCase(fileExtension) && !"jpg".equalsIgnoreCase(fileExtension) &&
                    !"jpeg".equalsIgnoreCase(fileExtension) && !"png".equalsIgnoreCase(fileExtension)) {
                    Map<String, String> errorResponse = new HashMap<>();
                    errorResponse.put("error", "Invalid file extension. Only PDF, JPG, JPEG, and PNG files are allowed.");
                    return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
                }

                String joiningLetterPath = saveFile(userid, joiningLetter);
                accessControl.setJoiningLetterPath(joiningLetterPath);
            }

        } catch (IOException e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", "An error occurred while processing files: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }

        AccessControl savedForm = accessControlService.saveForm(accessControl);
        return new ResponseEntity<>(savedForm, HttpStatus.CREATED);
    }

    private String saveFile(String userid, MultipartFile file) throws IOException {
        String originalFilename = file.getOriginalFilename();
        
        // Sanitize the original filename
        String sanitizedFilename = sanitizeFileName(originalFilename);
        
        // Construct the final filename using the sanitized filename
        String filename = userid + "_" + 1002 + "_" + System.currentTimeMillis()  + "~"  + sanitizedFilename;
        
        Path filePath = Paths.get(uploadDir, filename);

        try (InputStream inputStream = file.getInputStream()) {
            Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
        }

        return filePath.toString();
    }

    private String sanitizeFileName(String originalFilename) {
        // Replace any special characters with underscores
        String sanitizedFileName = originalFilename.replaceAll("[^a-zA-Z0-9.-]", "_");
        return sanitizedFileName;
    }

    private String getFileExtension(String filename) {
        if (filename == null || filename.isEmpty()) {
            return "";
        }
        int dotIndex = filename.lastIndexOf(".");
        if (dotIndex == -1) {
            return ""; // No extension found
        }
        return filename.substring(dotIndex + 1);
    }

    // Use Tika to detect file type
    private String getFileTypeFromTika(MultipartFile file) throws IOException {
        Tika tika = new Tika();
        try (InputStream inputStream = file.getInputStream()) {
            return tika.detect(inputStream);
        }
    }
    
    @GetMapping("viewform/{id}")
    public ResponseEntity<AccessControl> viewForms(@PathVariable("id") String userid) {
        AccessControl accessControl = accessControlRepository.findTopByUseridOrderByIdDesc(userid);
        if (accessControl == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        // Set download URLs if paths are not null
        if (accessControl.getEmployeeIdCardPath() != null) {
            String idCardDownloadUrl = "/api/accesscontrol/download/idCard/" + accessControl.getId();
            accessControl.setEmployeeIdCardDownloadUrl(idCardDownloadUrl);
        }
        if (accessControl.getJoiningLetterPath() != null) {
            String joiningLetterDownloadUrl = "/api/accesscontrol/download/joiningLetter/" + accessControl.getId();
            accessControl.setJoiningLetterDownloadUrl(joiningLetterDownloadUrl);
        }

        return new ResponseEntity<>(accessControl, HttpStatus.OK);
    }

    @GetMapping("download/idCard/{id}")
    public ResponseEntity<Resource> downloadIdCard(@PathVariable("id") Long id) {
        AccessControl accessControl = accessControlRepository.findById(id).orElse(null);
        if (accessControl == null || accessControl.getEmployeeIdCardPath() == null) {
            return ResponseEntity.notFound().build();
        }
        try {
            Path filePath = Paths.get(accessControl.getEmployeeIdCardPath());
            Resource resource = new UrlResource(filePath.toUri());

            String originalFilename = filePath.getFileName().toString();
            String contentType = Files.probeContentType(filePath);
            if (contentType == null) {
                contentType = MediaType.APPLICATION_OCTET_STREAM_VALUE; // Default for unknown content types
            }

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + originalFilename + "\"")
                    .contentType(MediaType.parseMediaType(contentType))
                    .body(resource);
        } catch (IOException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    @GetMapping("download/joiningLetter/{id}")
    public ResponseEntity<Resource> downloadJoiningLetter(@PathVariable("id") Long id) {
        AccessControl accessControl = accessControlRepository.findById(id).orElse(null);
        if (accessControl == null || accessControl.getJoiningLetterPath() == null) {
            return ResponseEntity.notFound().build();
        }
        try {
            Path filePath = Paths.get(accessControl.getJoiningLetterPath());
            Resource resource = new UrlResource(filePath.toUri());

            String originalFilename = filePath.getFileName().toString();
            String contentType = Files.probeContentType(filePath);

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + originalFilename + "\"")
                    .contentType(MediaType.parseMediaType(contentType))
                    .body(resource);
        } catch (IOException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    @PutMapping("update/{id}")
    public ResponseEntity<?> updateAccessControl(
            @PathVariable("id") Long id, 
            @ModelAttribute @Valid AccessControl updatedAccessControl,
            @RequestParam(value = "employeeIdCard", required = false) MultipartFile employeeIdCard,
            @RequestParam(value = "joiningLetter", required = false) MultipartFile joiningLetter,
            @RequestParam(value = "dooraccess", required = false) String[] dooraccess) {

  

        AccessControl accessControl;
        Map<String, String> response = new HashMap<>();

        try {
            accessControl = accessControlRepository.findById(id)
                    .orElseThrow(() -> new NoSuchElementException("AccessControl not found with ID: " + id));
        } catch (NoSuchElementException e) {
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }

        accessControl.setCardnumber(updatedAccessControl.getCardnumber());
        accessControl.setDooraccess(updatedAccessControl.getDooraccess());
        accessControl.setExistingaccessinfo(updatedAccessControl.getExistingaccessinfo());
        accessControl.setUnitheadstatus("Pending");
        accessControl.setImplementedbydeptid(14);

        try {
            final long maxFileSize = 250 * 1024; // 250 KB
            if (employeeIdCard != null && !employeeIdCard.isEmpty()) {
                if (employeeIdCard.getSize() > maxFileSize) {
                    response.put("error", "Employee ID card file size exceeds the limit of 250 KB.");
                    return ResponseEntity.badRequest().body(response);
                }
                
                // Used Apache Tika to check the actual content type of the file
                Tika tika = new Tika();
                String fileType = tika.detect(employeeIdCard.getInputStream());
                if (!"application/pdf".equals(fileType) && !"image/jpeg".equals(fileType) && !"image/png".equals(fileType)) {
                    Map<String, String> errorResponse = new HashMap<>();
                    errorResponse.put("error", "Invalid file type. Only PDF, JPEG, and PNG files are allowed.");
                    return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
                }
	            
	         // Check file extension (allow only PDF, JPEG, and PNG)
	            String fileExtension = getFileExtension(employeeIdCard.getOriginalFilename());
	            if (!"pdf".equalsIgnoreCase(fileExtension) && !"jpg".equalsIgnoreCase(fileExtension) && !"jpeg".equalsIgnoreCase(fileExtension) && !"png".equalsIgnoreCase(fileExtension)) {
	                Map<String, String> errorResponse = new HashMap<>();
	                errorResponse.put("error", "Invalid file extension. Only PDF, JPG, JPEG, and PNG files are allowed.");
	                return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	            }
                
                // Delete old file and save new one
                if (accessControl.getEmployeeIdCardPath() != null) {
                    new File(accessControl.getEmployeeIdCardPath()).delete();
                }
                accessControl.setEmployeeIdCardPath(saveFile(accessControl.getUserid(), employeeIdCard));
            }

            if (joiningLetter != null && !joiningLetter.isEmpty()) {
                if (joiningLetter.getSize() > maxFileSize) {
                    response.put("error", "Joining letter file size exceeds the limit of 250 KB.");
                    return ResponseEntity.badRequest().body(response);
                }
                
             // Used Apache Tika to check the actual content type of the file
                Tika tika = new Tika();
                String fileType = tika.detect(joiningLetter.getInputStream());
                if (!"application/pdf".equals(fileType) && !"image/jpeg".equals(fileType) && !"image/png".equals(fileType)) {
                    Map<String, String> errorResponse = new HashMap<>();
                    errorResponse.put("error", "Invalid file type. Only PDF, JPEG, and PNG files are allowed.");
                    return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
                }
	            
	         // Check file extension (allow only PDF, JPEG, and PNG)
	            String fileExtension = getFileExtension(joiningLetter.getOriginalFilename());
	            if (!"pdf".equalsIgnoreCase(fileExtension) && !"jpg".equalsIgnoreCase(fileExtension) && !"jpeg".equalsIgnoreCase(fileExtension) && !"png".equalsIgnoreCase(fileExtension)) {
	                Map<String, String> errorResponse = new HashMap<>();
	                errorResponse.put("error", "Invalid file extension. Only PDF, JPG, JPEG, and PNG files are allowed.");
	                return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	            }
                
                // Delete old file and save new one
                if (accessControl.getJoiningLetterPath() != null) {
                    new File(accessControl.getJoiningLetterPath()).delete();
                }
                accessControl.setJoiningLetterPath(saveFile(accessControl.getUserid(), joiningLetter));
            }
        } catch (IOException e) {
            response.put("error", "An error occurred while processing files.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }

        
        if (!updatedAccessControl.getUnitheaduserid().equals(accessControl.getUnitheaduserid())) {
	          String newUnitHeadUserId = updatedAccessControl.getUnitheaduserid();
	          User newUnitHeadUser = profileService.getUserByUserid(newUnitHeadUserId);
	          String newUnitHeadUsername = newUnitHeadUser != null ? newUnitHeadUser.getUsername() : "Unknown User";

	  
	          List<Notification> existingNotifications = notificationRepository.findByUseridAndFormidAndSubmissionId(
	        		  accessControl.getUnitheaduserid(),
	        		  accessControl.getFormid(),
	        		  accessControl.getId()
	          );

	   
	          User user = profileService.getUserByUserid(updatedAccessControl.getUnitheaduserid());
	          String username = user != null ? user.getUsername() : "Unknown User";
	          for (Notification notification : existingNotifications) {
	              notification.setUserid(newUnitHeadUserId);
	              notification.setViewed(false);
	              notification.setMessage(
	                  "A new Access Control request has been submitted by " + username + " (" + accessControl.getUserid() + ")."
	              );
	              notificationRepository.save(notification);
	          }

	       // unit head email
	          emailService.sendNotificationEmail(user,accessControl.getUnitheaduserid(),1);
	          
	          accessControl.setUnitheaduserid(newUnitHeadUserId);
	          accessControl.setUnitheadusername(newUnitHeadUsername);
	      }
 
        accessControl.setSubmittime(new Timestamp(System.currentTimeMillis()));
        accessControl.setSubmitdate(new Date(System.currentTimeMillis()));

      
        AccessControl updatedForm = accessControlRepository.save(accessControl);

        return new ResponseEntity<>(updatedForm, HttpStatus.OK);
    }

    @DeleteMapping("removefile/{id}/{fileType}")
    public ResponseEntity<String> removeFile(
            @PathVariable("id") Long id,
            @PathVariable("fileType") String fileType) {
  
        AccessControl accessControl = accessControlRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("AccessControl entry not found with ID: " + id));

        String filePath = null;

  
        if ("employeeIdCard".equalsIgnoreCase(fileType)) {
            filePath = accessControl.getEmployeeIdCardPath();
            accessControl.setEmployeeIdCardPath(null); 
        } else if ("joiningLetter".equalsIgnoreCase(fileType)) {
            filePath = accessControl.getJoiningLetterPath();
            accessControl.setJoiningLetterPath(null); 
        } else {
            return ResponseEntity.badRequest().body("Invalid file type. Use 'employeeIdCard' or 'joiningLetter'.");
        }

  
        if (filePath != null) {
            File file = new File(filePath);
            if (file.exists()) {
                if (file.delete()) {
                   
                    accessControlRepository.save(accessControl);
                    return ResponseEntity.ok("File removed successfully");
                } else {
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to delete the file");
                }
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("File not found on the server");
            }
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("File path not found in the database");
        }
    }


}
