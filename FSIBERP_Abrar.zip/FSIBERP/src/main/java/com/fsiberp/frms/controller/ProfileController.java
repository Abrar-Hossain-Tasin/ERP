package com.fsiberp.frms.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fsiberp.frms.model.User;
import com.fsiberp.frms.services.ProfileService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;


@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/users/")
public class ProfileController {
	
	private ProfileService profileService;
    
    public ProfileController(ProfileService profileService) {
        this.profileService = profileService;
    }
    
    @GetMapping("{id}")
    public ResponseEntity<User> getUserByUserid(@PathVariable("id") String userid){
        User user = profileService.getUserByUserid(userid);
        return new ResponseEntity<>(user, HttpStatus.OK);
    }
    
	@PutMapping("{id}")
	public ResponseEntity<User> updateUser(@PathVariable("id") String userid, @Valid @RequestBody User user,
			HttpServletRequest request) {
		user.setUserid(userid);
		// Get the client's IP address
		String clientIp = request.getRemoteAddr();
		user.setMachineIp(clientIp); // Set the client IP address in the machine_ip column
		User updatedUser = profileService.updateUser(user);
		return new ResponseEntity<>(updatedUser, HttpStatus.OK);
	}


}
