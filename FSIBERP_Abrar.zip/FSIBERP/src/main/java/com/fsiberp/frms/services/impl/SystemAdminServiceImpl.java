package com.fsiberp.frms.services.impl;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.fsiberp.frms.model.FunctionalRole;
import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.FunctionalRoleRepository;
import com.fsiberp.frms.services.SystemAdminService;

import jakarta.transaction.Transactional;

import com.fsiberp.frms.repository.AuthRepository;


@Service
	public class SystemAdminServiceImpl implements SystemAdminService {

	    @Autowired
	    private AuthRepository authRepository;
	    
	    @Autowired
	    private FunctionalRoleRepository functionalRoleRepository;
	   
	    @Autowired
	    private ScheduledExecutorService scheduler; 

	    // Add a new member
	    @Override
	    public FunctionalRole addMember(FunctionalRole functionalRole) {
	        return functionalRoleRepository.save(functionalRole);
	    }

	    @Override
	    public FunctionalRole updateMember(String userid, FunctionalRole updatedRole) {
	        Optional<FunctionalRole> existingRoleOpt = functionalRoleRepository.findByUserid(userid);
	        
	        if (existingRoleOpt.isPresent()) {
	            FunctionalRole existingRole = existingRoleOpt.get();

	            // Update only non-null fields from the incoming object
	            if (updatedRole.getFunctionalrole() != null) {
	                existingRole.setFunctionalrole(updatedRole.getFunctionalrole());
	            }

	            if (updatedRole.getFunctionalroleid() != null) {
	                existingRole.setFunctionalroleid(updatedRole.getFunctionalroleid());
	            }

	            if (updatedRole.getStatus() != null) {
	                existingRole.setStatus(updatedRole.getStatus());
	            }

	            // Save the updated entity
	            return functionalRoleRepository.save(existingRole);
	        }
	        
	        return null;
	    }  
	    
	    
	    // Get all members
	    @Override
	    public List<FunctionalRole> getAllMembers() {
	        return functionalRoleRepository.findAll();
	    }

	   // Get a member by ID
	    @Override
	    public Optional<FunctionalRole> getMemberByUserId(String userid) {
	        return functionalRoleRepository.findByUserid(userid);
	    }
	    
	    
	    @Transactional
	    @Override
	    public boolean temporarilyUpdateRole(String userid, Integer newRoleId, Integer hours) {
	        Optional<User> userOpt = authRepository.findByUserid(userid);
	        if (userOpt.isPresent()) {
	            User user = userOpt.get();
	            Integer originalRoleId = user.getRoleid();
	            
	            // Update role_id to newRoleId
	            user.setRoleid(newRoleId);
	            authRepository.save(user);

	            // Schedule revert task
	            scheduler.schedule(() -> {
	                user.setRoleid(originalRoleId);
	                authRepository.save(user);
	            }, hours, TimeUnit.HOURS);

	            return true;
	        }
	        return false;
	    }
}
