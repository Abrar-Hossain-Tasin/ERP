package com.fsiberp.frms.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fsiberp.frms.model.AccessControlUser;


@Repository
public interface AccessControlUserRepository extends JpaRepository<AccessControlUser, Integer> {
	AccessControlUser findByUserid(String userid);
}
