package com.fsiberp.frms.services;

import com.fsiberp.frms.model.BranchInfo;
import java.util.List;

public interface BranchInfoService {
    List<BranchInfo> getAllBranches();
}
