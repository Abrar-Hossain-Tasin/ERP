package com.fsiberp.frms.model;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
@Table( name = "sys_functional_role" )
public class FunctionalRole {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotBlank
	@Size(max = 50)
	@Column(name = "user_id")
	private String userid;
	
	@Size(max = 50)
	@Column(name = "functional_role")
	private String functionalrole;
	
	@Column(name = "functional_role_id")
	private Integer functionalroleid;
	
	@Size(max = 50)
	@Column(name = "status")
	private String status;
	
	@Size(max = 50)
	@Column(name = "created_by")
	private String createdby;
	
	@Column(name = "create_date")
	private Date createdate;
	
	public FunctionalRole() {
		  
	  }

	public FunctionalRole(Long id, String userid, String functionalrole, String status, 
			String createdby, Date createdate, Integer functionalroleid) {
		super();
		this.id = id;
		this.userid = userid;
		this.functionalrole = functionalrole;
		this.status = status;
		this.createdby = createdby;
		this.createdate = createdate;
		this.functionalroleid = functionalroleid;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getFunctionalrole() {
		return functionalrole;
	}

	public void setFunctionalrole(String functionalrole) {
		this.functionalrole = functionalrole;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public Date getCreatedate() {
		return createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}

	public Integer getFunctionalroleid() {
		return functionalroleid;
	}

	public void setFunctionalroleid(Integer functionalroleid) {
		this.functionalroleid = functionalroleid;
	}
}
