package com.fsiberp.frms.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.fsiberp.frms.model.FunctionalRole;
import org.springframework.stereotype.Repository;

@Repository
public interface FunctionalRoleRepository extends JpaRepository<FunctionalRole, Long> {
	Optional<FunctionalRole> findByFunctionalroleAndStatus(String functionalrole, String status);
	Optional<FunctionalRole> findByFunctionalrole(String functionalrole);
    FunctionalRole findByUseridAndStatus(String userid, String status);
    Optional<FunctionalRole> findByUserid(String userid);

    @Query("SELECT sf FROM FunctionalRole sf "
    	       + "WHERE sf.userid = :userid "
    	       + "AND sf.functionalrole IN :functionalRole "
    	       + "AND sf.status = :status")
    	List<FunctionalRole> findByUseridAndFunctionalroleAndStatus(
    	    @Param("userid") String userid,
    	    @Param("functionalRole") List<String> functionalrole,
    	    @Param("status") String status);
    
    @Query("SELECT sf FROM FunctionalRole sf "
 	       + "WHERE sf.userid = :userid "
 	       + "AND sf.functionalrole IN :functionalRole ")
 	List<FunctionalRole> findByUseridAndFunctionalrole(
 	    @Param("userid") String userid,
 	    @Param("functionalRole") List<String> functionalrole);
    
    @Query("SELECT sf.status FROM FunctionalRole sf WHERE sf.userid = :userid")
    String findStatusByUserid(@Param("userid") String userid);


}
