package com.fsiberp.frms.controller;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fsiberp.frms.model.DatabaseAccess;
import com.fsiberp.frms.model.FunctionalRole;
import com.fsiberp.frms.model.IctDepartment;
import com.fsiberp.frms.model.Notification;
import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.DatabaseAccessRepository;
import com.fsiberp.frms.repository.FunctionalRoleRepository;
import com.fsiberp.frms.repository.IctDepartmentRepository;
import com.fsiberp.frms.repository.NotificationRepository;
import com.fsiberp.frms.services.DatabaseAccessService;
import com.fsiberp.frms.services.EmailService;
import com.fsiberp.frms.services.ProfileService;

import jakarta.validation.Valid;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/database/")
public class DatabaseAccessController {

	
	private ProfileService profileService;
	private FunctionalRoleRepository functionalRoleRepository;
	private DatabaseAccessService databaseAccessService;
	private DatabaseAccessRepository databaseAccessRepository;
	private IctDepartmentRepository ictDepartmentRepository;
	private NotificationRepository notificationRepository;
    private EmailService emailService;
	
	public DatabaseAccessController(ProfileService profileService, NotificationRepository notificationRepository,
			FunctionalRoleRepository functionalRoleRepository, DatabaseAccessRepository databaseAccessRepository,
			DatabaseAccessService databaseAccessService, IctDepartmentRepository ictDepartmentRepository,
			EmailService emailService) {
			
	        this.profileService = profileService;
	        this.functionalRoleRepository = functionalRoleRepository;
	        this.databaseAccessRepository = databaseAccessRepository;
	        this.databaseAccessService = databaseAccessService;
	        this.ictDepartmentRepository = ictDepartmentRepository;
	        this.notificationRepository = notificationRepository;
	        this.emailService = emailService;
	    }
	
	@GetMapping("view/{id}")
    public ResponseEntity<User> showForms(@PathVariable("id") String userid){
        User user = profileService.getUserByUserid(userid);
    
        return new ResponseEntity<>(user, HttpStatus.OK);
    }

	
	@PostMapping("save/{id}")
	public ResponseEntity<DatabaseAccess> createForm(@PathVariable("id") String userid, @RequestBody @Valid DatabaseAccess databaseAccess) {
		System.out.println("inside DatabaseAccess " );
	    User user = profileService.getUserByUserid(userid);

	    // Fetch CITO role and user information
	    FunctionalRole citoRole = functionalRoleRepository.findByFunctionalroleAndStatus("cito", "Active")
	            .orElseThrow(NoSuchElementException::new);
	    User citoinfo = profileService.getUserByUserid(citoRole.getUserid());

	    // Fetch ISRM role and user information
	    FunctionalRole isrmRole = functionalRoleRepository.findByFunctionalroleAndStatus("isrm", "Active")
	            .orElseThrow(NoSuchElementException::new);
	    User isrminfo = profileService.getUserByUserid(isrmRole.getUserid());

	    databaseAccess.setFormid("1015"); // Set form ID (might be generated differently)
	    databaseAccess.setUserid(user.getUserid());

	    // Set CITO information
	    databaseAccess.setCitouserid(citoinfo.getUserid());
	    databaseAccess.setCitousername(citoinfo.getUsername());
	    databaseAccess.setCitostatus("Pending");

	    // Set ISRM information
	    databaseAccess.setIsrmheaduserid(isrminfo.getUserid());
	    databaseAccess.setIsrmheadusername(isrminfo.getUsername());
	    databaseAccess.setIsrmheadstatus("Pending");

	    // Default pending statuses
	    databaseAccess.setImplbyunitheadstatus("Pending");
	    databaseAccess.setUnitheadstatus("Pending");
	    databaseAccess.setImplementedbystatus("Pending");
	    databaseAccess.setBranchCode(user.getBranchcode());
	    
	    if (user.getDepartment().equals("I C T Div., Head Office, Dhaka")) {
	    	databaseAccess.setDepartment(user.getUnit());
        }
        else {        	
        	databaseAccess.setDepartment(user.getDepartment());
        }
	    
	    // Fetch the Implbyunithead user
	    User implHeadUser = profileService.getUserByUserid(databaseAccess.getImplbyunitheaduserid());

	    // Get the unit name of the Implbyunithead user
	    String implHeadUnitName = implHeadUser.getUnit(); // Assuming the User entity has a 'unit' field

	    // Fetch the corresponding department by matching unit name
	    IctDepartment department = ictDepartmentRepository.findByDeptname(implHeadUnitName);
	    
//	    // Check if the department was found
	    if (department == null) {
	        throw new NoSuchElementException("Department not found for unit: " + implHeadUnitName);
	    }

	    // Set the department ID based on the unit name match
	    databaseAccess.setImplementedbydeptid(department.getId()); // Save the matched department ID

	    // Set submission date and time
	    databaseAccess.setSubmitdate(new Date(System.currentTimeMillis()));
	    databaseAccess.setSubmittime(new Timestamp(System.currentTimeMillis()));

	    // Save the form using the updated saveForm method in the service
	    DatabaseAccess savedForm = databaseAccessService.saveForm(databaseAccess);

	    return new ResponseEntity<>(savedForm, HttpStatus.CREATED);
	}

	@PutMapping("update/{id}")
	public ResponseEntity<DatabaseAccess> updateDatabaseAccess(@PathVariable("id") Long id, @RequestBody @Valid DatabaseAccess updatabaseAccess) {
		
		DatabaseAccess databaseAccess = databaseAccessRepository.findById(id)
	            .orElseThrow(NoSuchElementException::new);
	 
		databaseAccess.setAction(updatabaseAccess.getAction());
		databaseAccess.setOther(updatabaseAccess.getOther());
		databaseAccess.setActype(updatabaseAccess.getActype());
		databaseAccess.setAccesstodatabase(updatabaseAccess.getAccesstodatabase());
		databaseAccess.setTempdatefrom(updatabaseAccess.getTempdatefrom());
		databaseAccess.setTempdateto(updatabaseAccess.getTempdateto());
		databaseAccess.setTemptimeto(updatabaseAccess.getTemptimeto());
		databaseAccess.setTemptimefrom(updatabaseAccess.getTemptimefrom());
		databaseAccess.setUnitheadstatus("Pending");
		
		databaseAccess.setImplbyunitheaduserid(updatabaseAccess.getImplbyunitheaduserid());
		databaseAccess.setImplbyunitheadusername(updatabaseAccess.getImplbyunitheadusername());
		databaseAccess.setImplementedbyusername(updatabaseAccess.getImplementedbyusername());
		
		
		 if (!updatabaseAccess.getUnitheaduserid().equals(databaseAccess.getUnitheaduserid())) {
	          String newUnitHeadUserId = updatabaseAccess.getUnitheaduserid();
	          User newUnitHeadUser = profileService.getUserByUserid(newUnitHeadUserId);
	          String newUnitHeadUsername = newUnitHeadUser != null ? newUnitHeadUser.getUsername() : "Unknown User";

	  
	          List<Notification> existingNotifications = notificationRepository.findByUseridAndFormidAndSubmissionId(
	        		  databaseAccess.getUnitheaduserid(),
	        		  databaseAccess.getFormid(),
	        		  databaseAccess.getId()
	          );

	          User user = profileService.getUserByUserid(updatabaseAccess.getUnitheaduserid());
	          
	          User submittingUser = profileService.getUserByUserid(databaseAccess.getUserid());
	          String submittingUsername = submittingUser != null ? submittingUser.getUsername() : "Unknown User";
	          
//	          String username = user != null ? user.getUsername() : "Unknown User";
	          for (Notification notification : existingNotifications) {
	              notification.setUserid(newUnitHeadUserId);
	              notification.setViewed(false);
	              notification.setMessage(
	                  "A new Database Access request has been submitted by " + submittingUsername +
	                  " (" + databaseAccess.getUserid() + ")."
	              );
	              notificationRepository.save(notification);
	          }

//	          unit head email
	          emailService.sendNotificationEmail(user,updatabaseAccess.getUserid(),1);
	       
	          databaseAccess.setUnitheaduserid(newUnitHeadUserId);
	          databaseAccess.setUnitheadusername(newUnitHeadUsername);
	      }

		
		databaseAccess.setSubmittime(new Timestamp(System.currentTimeMillis()));
		databaseAccess.setSubmitdate(new Date(System.currentTimeMillis())); 
		
		DatabaseAccess updatedForm = databaseAccessRepository.save(databaseAccess);
	    return new ResponseEntity<>(updatedForm, HttpStatus.OK);
	}

}


