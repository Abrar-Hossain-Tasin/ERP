package com.fsiberp.frms.services.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.ProfileRepository;
import com.fsiberp.frms.services.ProfileService;


@Service
public class ProfileServiceImpl implements ProfileService {
	
private ProfileRepository profileRepository;
    
    public ProfileServiceImpl(ProfileRepository profileRepository) {
        this.profileRepository = profileRepository;
    }

    @Override
    public User createUser(User user) {
        return profileRepository.save(user);
    }

    @Override
    public User getUserByUserid(String userid) {
        Optional<User> optionalUser = profileRepository.findByUserid(userid);
        return optionalUser.get();
    }
    
    @Override
    public List<User> getAllUnitUsers(String unit) {
    	List<User> optionalUser = profileRepository.findByUnit(unit);
        return optionalUser;
    }

    @Override
    public List<User> getAllUsers() {
        return profileRepository.findAll();
    }

    @Override
    public User updateUser(User user) {
        User existingUser = profileRepository.findByUserid(user.getUserid()).get();
        existingUser.setEmail(user.getEmail());
        User updatedUser = profileRepository.save(existingUser);
        return updatedUser;
    }

    @Override
    public void deleteUser(Long userId) {
    	profileRepository.deleteById(userId);
    }

}
