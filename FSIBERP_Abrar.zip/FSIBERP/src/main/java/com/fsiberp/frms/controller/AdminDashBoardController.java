package com.fsiberp.frms.controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fsiberp.bms.model.UnitHead;
import com.fsiberp.bms.repository.UnitHeadRepository;
import com.fsiberp.frms.model.AccessControlUser;
import com.fsiberp.frms.model.DivisionName;
import com.fsiberp.frms.model.FunctionalRole;
import com.fsiberp.frms.model.IctDepartment;
import com.fsiberp.frms.model.ListView;
import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.AccessControlUserRepository;
import com.fsiberp.frms.repository.DivisionNameRepository;
import com.fsiberp.frms.repository.FunctionalRoleRepository;
import com.fsiberp.frms.repository.IctDepartmentRepository;
import com.fsiberp.frms.repository.ProfileRepository;
import com.fsiberp.frms.services.ProfileService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/admin/")
public class AdminDashBoardController {
	
	private FunctionalRoleRepository functionalRoleRepository;
	private ProfileService profileService;
	private IctDepartmentRepository ictDepartmentRepository;
	private AccessControlUserRepository accessControlUserRepository;
	private UnitHeadRepository unitHeadRepository;
	private ProfileRepository profileRepository;
	private DivisionNameRepository divisionNameRepository;
	
	public AdminDashBoardController(FunctionalRoleRepository functionalRoleRepository, ProfileService profileService,
			IctDepartmentRepository ictDepartmentRepository, AccessControlUserRepository accessControlUserRepository,
			UnitHeadRepository unitHeadRepository,ProfileRepository profileRepository, DivisionNameRepository divisionNameRepository) {
	        this.functionalRoleRepository = functionalRoleRepository;
	        this.profileService = profileService;
	        this.ictDepartmentRepository = ictDepartmentRepository;
	        this.accessControlUserRepository = accessControlUserRepository;
	        this.unitHeadRepository = unitHeadRepository;
	        this.profileRepository = profileRepository;
	        this.divisionNameRepository = divisionNameRepository;
	    }
	
	@GetMapping("pending/{id}")
    public List<ListView> pendingForms(@PathVariable("id") String userid) throws SQLException, ClassNotFoundException{
		
		FunctionalRole functionalRole = functionalRoleRepository.findByUseridAndStatus(userid, "Active");
		User user = profileService.getUserByUserid(userid);
		
		Connection con = null;
		
		List<ListView> dashboard = new ArrayList<>();
		
		List<ListView> accessRights = new ArrayList<>();
		List<ListView> accessControls = new ArrayList<>();
		List<ListView> changeRequest = new ArrayList<>();
		List<ListView> createMail = new ArrayList<>();
		List<ListView> createDomain = new ArrayList<>();
		List<ListView> incidentReport = new ArrayList<>();
		List<ListView> groupMail = new ArrayList<>();
		List<ListView> cbsUserPermission = new ArrayList<>();
		List<ListView> cbsUserPermission1 = new ArrayList<>();
		List<ListView> databaseAccess = new ArrayList<>();
		
		con = PostGRESQLConnUtils.getPostGreSQLConnection();
        con.setAutoCommit(false);
        Statement stmt = con.createStatement();
		
        int flag = 0;
        
//		Check the functional role of that user
		
		if (functionalRole!=null) {
			
//		If user is 'cito'
			if (functionalRole.getFunctionalroleid() == 1) {
				
				flag = 1;
				
				try {
		          
		//        For Access Controls Form
		        
		        ResultSet ac = stmt.executeQuery("SELECT * FROM form_access_control far "
		                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
		                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		                + "WHERE far.cito_userid = '" + userid + "' "
		                + "AND (far.isrm_head_status = 'Accepted' "
		        		+ "AND far.cito_status = 'Pending') ");
		        
		        if (ac != null) {
			        while (ac.next()) {
			        	ListView listView = new ListView();
			
			            long id = ac.getLong("id");
			            String users = ac.getString("user_id");
			            String username = ac.getString("user_name");
			            String formid = ac.getString("form_id");
			            String formname = ac.getString("form_name");
			            String unitheadstatus = ac.getString("unit_head_status");
			            String citostatus = ac.getString("cito_status");
			            Timestamp submittime = ac.getTimestamp("submit_time");
			
			            listView.setId(id);
			            listView.setUserid(users);
			            listView.setUsername(username);
			            listView.setFormid(formid);
			            listView.setFormname(formname);
			            listView.setUnitheadstatus(unitheadstatus);
			            listView.setCitostatus(citostatus);
			            listView.setSubmittime(submittime);
			            
			            String branchcode = ac.getString("branch_code");
			            listView.setBranchcode(branchcode);
			
			            accessControls.add(listView);
			        }
		        }
		        dashboard.addAll(accessControls);
		            
		//      For Creating Mail Form
				        
				        ResultSet cm = stmt.executeQuery("SELECT * FROM form_create_email far "
				                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
				                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
				                + "WHERE far.cito_userid = '" + userid + "' "
				                + "AND (far.isrm_head_status = 'Accepted' "
				                + "AND far.cito_status = 'Pending') ");
				      if (cm != null) {
					      while (cm.next()) {
					      	ListView listView = new ListView();
					
					          long id = cm.getLong("id");
					          String users = cm.getString("user_id");
					          String username = cm.getString("user_name");
					          String formid = cm.getString("form_id");
					          String formname = cm.getString("form_name");
					          String unitheadstatus = cm.getString("unit_head_status");
					          String citostatus = cm.getString("cito_status");
					          Timestamp submittime = cm.getTimestamp("submit_time");
					          
					          listView.setId(id);
					          listView.setUserid(users);
					          listView.setUsername(username);
					          listView.setFormid(formid);
					          listView.setFormname(formname);
					          listView.setUnitheadstatus(unitheadstatus);
					          listView.setCitostatus(citostatus);
					          listView.setSubmittime(submittime);
					          
					          String branchcode = cm.getString("branch_code");
				              listView.setBranchcode(branchcode);
					
					          createMail.add(listView);
					      }
				      }
				      dashboard.addAll(createMail);
				      

	//      For Create Domain Form
				        
				        ResultSet cd = stmt.executeQuery("SELECT * FROM form_create_domain far "
				                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
				                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
				                + "WHERE far.cito_userid = '" + userid + "' "
				                + "AND (far.isrm_head_status = 'Accepted' "
				                + "AND far.sa_head_status = 'Accepted' "
				                + "AND far.cito_status = 'Pending') ");
				      if (cd != null) {
					      while (cd.next()) {
					      	ListView listView = new ListView();
					
					          long id = cd.getLong("id");
					          String users = cd.getString("user_id");
					          String username = cd.getString("user_name");
					          String formid = cd.getString("form_id");
					          String formname = cd.getString("form_name");
					          String unitheadstatus = cd.getString("unit_head_status");
					          String citostatus = cd.getString("cito_status");
					          Timestamp submittime = cd.getTimestamp("submit_time");
					          
					          listView.setId(id);
					          listView.setUserid(users);
					          listView.setUsername(username);
					          listView.setFormid(formid);
					          listView.setFormname(formname);
					          listView.setUnitheadstatus(unitheadstatus);
					          listView.setCitostatus(citostatus);
					          listView.setSubmittime(submittime);
					          
					          String branchcode = cd.getString("branch_code");
				              listView.setBranchcode(branchcode);
					
					          createDomain.add(listView);
					      }
				      }
				      dashboard.addAll(createDomain);
				      

	//      For Group Mail Form
			        
			        ResultSet gm = stmt.executeQuery("SELECT * FROM form_group_email far "
			                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
			                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
			                + "WHERE far.cito_userid = '" + userid + "' "
			                + "AND (far.isrm_head_status = 'Accepted' "
			                + "AND far.cito_status = 'Pending') ");
			      if (gm != null) {
				      while (gm.next()) {
				      	ListView listView = new ListView();
				
				          long id = gm.getLong("id");
				          String users = gm.getString("user_id");
				          String username = gm.getString("user_name");
				          String formid = gm.getString("form_id");
				          String formname = gm.getString("form_name");
				          String unitheadstatus = gm.getString("unit_head_status");
				          String citostatus = gm.getString("cito_status");
				          Timestamp submittime = gm.getTimestamp("submit_time");
				          
				          listView.setId(id);
				          listView.setUserid(users);
				          listView.setUsername(username);
				          listView.setFormid(formid);
				          listView.setFormname(formname);
				          listView.setUnitheadstatus(unitheadstatus);
				          listView.setCitostatus(citostatus);
				          listView.setSubmittime(submittime);
				          
				          String branchcode = gm.getString("branch_code");
			              listView.setBranchcode(branchcode);
				
				          groupMail.add(listView);
				      }
			      }
			      dashboard.addAll(groupMail);
				       

	//      For Incident Report Form
			        
			        ResultSet ir = stmt.executeQuery("SELECT * FROM form_incident_report far "
			                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
			                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
			                + "WHERE far.cito_userid = '" + userid + "' "
			                + "AND (far.isrm_head_status = 'Accepted' "
			                + "AND far.cito_status = 'Pending') ");
			      if (ir != null) {
				      while (ir.next()) {
				      	ListView listView = new ListView();
				
				          long id = ir.getLong("id");
				          String users = ir.getString("user_id");
				          String username = ir.getString("user_name");
				          String formid = ir.getString("form_id");
				          String formname = ir.getString("form_name");
				          String unitheadstatus = ir.getString("unit_head_status");
				          String citostatus = ir.getString("cito_status");
				          Timestamp submittime = ir.getTimestamp("submit_time");
				          
				          listView.setId(id);
				          listView.setUserid(users);
				          listView.setUsername(username);
				          listView.setFormid(formid);
				          listView.setFormname(formname);
				          listView.setUnitheadstatus(unitheadstatus);
				          listView.setCitostatus(citostatus);
				          listView.setSubmittime(submittime);
				          
				          String branchcode = ir.getString("branch_code");
			              listView.setBranchcode(branchcode);
				
				          incidentReport.add(listView);
				      }
			      }
			      dashboard.addAll(incidentReport);
			      
			      
	//      For Database Access Form
			        
			        ResultSet da = stmt.executeQuery("SELECT * FROM form_database_access far "
			                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
			                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
			                + "WHERE far.cito_userid = '" + userid + "' "
			                + "AND (far.isrm_head_status = 'Accepted' "
			                + "AND far.cito_status = 'Pending') ");
			      if (da != null) {
				      while (da.next()) {
				      	ListView listView = new ListView();
				
				          long id = da.getLong("id");
				          String users = da.getString("user_id");
				          String username = da.getString("user_name");
				          String formid = da.getString("form_id");
				          String formname = da.getString("form_name");
				          String unitheadstatus = da.getString("unit_head_status");
				          String citostatus = da.getString("cito_status");
				          Timestamp submittime = da.getTimestamp("submit_time");
				          
				          listView.setId(id);
				          listView.setUserid(users);
				          listView.setUsername(username);
				          listView.setFormid(formid);
				          listView.setFormname(formname);
				          listView.setUnitheadstatus(unitheadstatus);
				          listView.setCitostatus(citostatus);
				          listView.setSubmittime(submittime);
				          
				          String branchcode = da.getString("branch_code");
			              listView.setBranchcode(branchcode);
				
				          databaseAccess.add(listView);
				      }
			      }
			      dashboard.addAll(databaseAccess);
			       
				      
		        } catch (Exception e) {
		            e.printStackTrace(); 
		        }
				finally {
				    // Close the Statement in the finally block
				    if (stmt != null) {
				        try {
				            stmt.close();
				        } catch (SQLException e) {
				            e.printStackTrace();
				        }
				    }
				}
			}
			else {
			
//		For ICT officer
			
				try {
		//        For Access Controls Form
		        
		        ResultSet ac =  null;
		        
		        if (functionalRole.getFunctionalroleid() == 2) {
		        	ac = stmt.executeQuery("SELECT * FROM form_access_control far "
	                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	                  + "WHERE far.isrm_head_userid = '" + userid + "' "
	                  + "AND (far.unit_head_status = 'Accepted' "
	                  + "AND far.isrm_head_status = 'Pending') ");
	            }
	            else if (functionalRole.getFunctionalroleid() == 6) {
	            	ac = stmt.executeQuery("SELECT * FROM form_access_control far "
	                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	                  + "WHERE far.network_head_userid = '" + userid + "' "
	                  + "AND (far.cito_status = 'Accepted' "
	                  + "AND far.network_head_status = 'Pending')");
	            }
		        
		        if (ac != null) {
			        while (ac.next()) {
			        	ListView listView = new ListView();
			
			            long id = ac.getLong("id");
			            String users = ac.getString("user_id");
			            String username = ac.getString("user_name");
			            String formid = ac.getString("form_id");
			            String formname = ac.getString("form_name");
			            String unitheadstatus = ac.getString("unit_head_status");
			            String citostatus = ac.getString("cito_status");
			            Timestamp submittime = ac.getTimestamp("submit_time");
			
			            listView.setId(id);
			            listView.setUserid(users);
			            listView.setUsername(username);
			            listView.setFormid(formid);
			            listView.setFormname(formname);
			            listView.setUnitheadstatus(unitheadstatus);
			            listView.setCitostatus(citostatus);
			            listView.setSubmittime(submittime);
			            
			            String branchcode = ac.getString("branch_code");
			              listView.setBranchcode(branchcode);
			
			            accessControls.add(listView);
			        }
		        }
		        dashboard.addAll(accessControls);
		 
		//      For Creating Mail Form
				       
		      			ResultSet cm = null; 

				      if (functionalRole.getFunctionalroleid() == 2) {
					         cm = stmt.executeQuery("SELECT * FROM form_create_email far "
					                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
					                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
					                  + "WHERE far.isrm_head_userid = '" + userid + "' "
					                  + "AND (far.unit_head_status = 'Accepted' "
					                  + "AND far.isrm_head_status = 'Pending') ");
					      }
				      else if (functionalRole.getFunctionalroleid() == 4) {
					         cm = stmt.executeQuery("SELECT * FROM form_create_email far "
					                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
					                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
					                  + "WHERE far.impl_by_unithead_userid = '" + userid + "' "
					                  + "AND (far.cito_status = 'Accepted' "
					                  + "AND far.impl_by_unithead_status = 'Pending') ");
					      }
				      
				        if (cm != null) {
					      while (cm.next()) {
					      	ListView listView = new ListView();
					
					          long id = cm.getLong("id");
					          String users = cm.getString("user_id");
					          String username = cm.getString("user_name");
					          String formid = cm.getString("form_id");
					          String formname = cm.getString("form_name");
					          String unitheadstatus = cm.getString("unit_head_status");
					          String citostatus = cm.getString("cito_status");
					          Timestamp submittime = cm.getTimestamp("submit_time");
					          
					          listView.setId(id);
					          listView.setUserid(users);
					          listView.setUsername(username);
					          listView.setFormid(formid);
					          listView.setFormname(formname);
					          listView.setUnitheadstatus(unitheadstatus);
					          listView.setCitostatus(citostatus);
					          listView.setSubmittime(submittime);
					          
					          String branchcode = cm.getString("branch_code");
				              listView.setBranchcode(branchcode);
					
					          createMail.add(listView);
					      }
				        }
				      dashboard.addAll(createMail);

	//      For Create Domain Form
				       
		      			ResultSet cd = null; 

				      if (functionalRole.getFunctionalroleid() == 2) {
				    	  cd = stmt.executeQuery("SELECT * FROM form_create_domain far "
					                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
					                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
					                  + "WHERE far.isrm_head_userid = '" + userid + "' "
					                  + "AND (far.sa_head_status = 'Accepted' "
					                  + "AND far.isrm_head_status = 'Pending') ");
					      }
				      else if (functionalRole.getFunctionalroleid() == 4) {
				    	  cd = stmt.executeQuery("SELECT * FROM form_create_domain far "
					                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
					                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
					                  + "WHERE far.sa_head_userid = '" + userid + "' "
					                  + "AND (far.unit_head_status = 'Accepted' "
					                  + "AND far.sa_head_status = 'Pending') ");
					      }
				      
				        if (cd != null) {
					      while (cd.next()) {
					      	ListView listView = new ListView();
					
					          long id = cd.getLong("id");
					          String users = cd.getString("user_id");
					          String username = cd.getString("user_name");
					          String formid = cd.getString("form_id");
					          String formname = cd.getString("form_name");
					          String unitheadstatus = cd.getString("unit_head_status");
					          String citostatus = cd.getString("cito_status");
					          Timestamp submittime = cd.getTimestamp("submit_time");
					          
					          listView.setId(id);
					          listView.setUserid(users);
					          listView.setUsername(username);
					          listView.setFormid(formid);
					          listView.setFormname(formname);
					          listView.setUnitheadstatus(unitheadstatus);
					          listView.setCitostatus(citostatus);
					          listView.setSubmittime(submittime);
					          
					          String branchcode = cd.getString("branch_code");
				              listView.setBranchcode(branchcode);
					
					          createDomain.add(listView);
					      }
				        }
				      dashboard.addAll(createDomain);

	//      For Group Mail Form
			       
	      			ResultSet gm = null; 

			      if (functionalRole.getFunctionalroleid() == 2) {
			    	  gm = stmt.executeQuery("SELECT * FROM form_group_email far "
				                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
				                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
				                  + "WHERE far.isrm_head_userid = '" + userid + "' "
				                  + "AND (far.unit_head_status = 'Accepted' "
				                  + "AND far.isrm_head_status = 'Pending') ");
				      }
			      else if (functionalRole.getFunctionalroleid() == 4) {
			    	  gm = stmt.executeQuery("SELECT * FROM form_group_email far "
				                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
				                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
				                  + "WHERE far.impl_by_unithead_userid = '" + userid + "' "
				                  + "AND (far.cito_status = 'Accepted' "
				                  + "AND far.impl_by_unithead_status = 'Pending') ");
				      }
			      
			        if (gm != null) {
				      while (gm.next()) {
				      	ListView listView = new ListView();
				
				          long id = gm.getLong("id");
				          String users = gm.getString("user_id");
				          String username = gm.getString("user_name");
				          String formid = gm.getString("form_id");
				          String formname = gm.getString("form_name");
				          String unitheadstatus = gm.getString("unit_head_status");
				          String citostatus = gm.getString("cito_status");
				          Timestamp submittime = gm.getTimestamp("submit_time");
				          
				          listView.setId(id);
				          listView.setUserid(users);
				          listView.setUsername(username);
				          listView.setFormid(formid);
				          listView.setFormname(formname);
				          listView.setUnitheadstatus(unitheadstatus);
				          listView.setCitostatus(citostatus);
				          listView.setSubmittime(submittime);
				          
				          String branchcode = gm.getString("branch_code");
			              listView.setBranchcode(branchcode);
				
				          groupMail.add(listView);
				      }
			        }
			      dashboard.addAll(groupMail);

		//          For Incident Reports Form
		            
		            ResultSet ir = stmt.executeQuery("SELECT * FROM form_incident_report far "
		                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
		                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		                  + "WHERE far.isrm_head_userid = '" + userid + "' "
		                  + "AND (far.unit_head_status = 'Accepted' "
		                  + "AND far.isrm_head_status = 'Pending') ");
		            
		          if (ir != null) {  
			          while (ir.next()) {
			        	  
			          	ListView listView = new ListView();
			
			              long id = ir.getLong("id");
			              String users = ir.getString("user_id");
			              String username = ir.getString("user_name");
			              String formid = ir.getString("form_id");
			              String formname = ir.getString("form_name");
			              String unitheadstatus = ir.getString("unit_head_status");
			              String citostatus = ir.getString("cito_status");
			              Timestamp submittime = ir.getTimestamp("submit_time");
			              
			
			              listView.setId(id);
			              listView.setUserid(users);
			              listView.setUsername(username);
			              listView.setFormid(formid);
			              listView.setFormname(formname);
			              listView.setUnitheadstatus(unitheadstatus);
			              listView.setCitostatus(citostatus);
			              listView.setSubmittime(submittime);
			              
			              String branchcode = ir.getString("branch_code");
			              listView.setBranchcode(branchcode);
			
			              incidentReport.add(listView);
			          }
		          }
		          
		          dashboard.addAll(incidentReport);

	//      For Database Access Form
			       
	      			ResultSet da = null; 

			      if (functionalRole.getFunctionalroleid() == 2) {
			    	  da = stmt.executeQuery("SELECT * FROM form_database_access far "
				                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
				                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
				                  + "WHERE far.isrm_head_userid = '" + userid + "' "
				                  + "AND (far.unit_head_status = 'Accepted' "
				                  + "AND far.isrm_head_status = 'Pending') ");
				      }
			      else if (functionalRole.getFunctionalroleid() == 4) {
			    	  da = stmt.executeQuery("SELECT * FROM form_database_access far "
				                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
				                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
				                  + "WHERE far.impl_by_unithead_userid = '" + userid + "' "
				                  + "AND (far.cito_status = 'Accepted' "
				                  + "AND far.impl_by_unithead_status = 'Pending') ");
				      }
			      
			        if (da != null) {
				      while (da.next()) {
				      	ListView listView = new ListView();
				
				          long id = da.getLong("id");
				          String users = da.getString("user_id");
				          String username = da.getString("user_name");
				          String formid = da.getString("form_id");
				          String formname = da.getString("form_name");
				          String unitheadstatus = da.getString("unit_head_status");
				          String citostatus = da.getString("cito_status");
				          Timestamp submittime = da.getTimestamp("submit_time");
				          
				          listView.setId(id);
				          listView.setUserid(users);
				          listView.setUsername(username);
				          listView.setFormid(formid);
				          listView.setFormname(formname);
				          listView.setUnitheadstatus(unitheadstatus);
				          listView.setCitostatus(citostatus);
				          listView.setSubmittime(submittime);
				          
				          String branchcode = da.getString("branch_code");
			              listView.setBranchcode(branchcode);
				
				          databaseAccess.add(listView);
				      }
			        }
			      dashboard.addAll(databaseAccess);
		          
				      
		        } catch (Exception e) {
		            e.printStackTrace(); 
		        }
				
			}
			
			accessRights.clear();
			accessControls.clear();
			changeRequest.clear();
			createMail.clear();
			incidentReport.clear();
			groupMail.clear();
			createDomain.clear();
			cbsUserPermission.clear();
			databaseAccess.clear();
		}
		if (user.getRoleid() == 2 && flag == 0) {

//			For unit head
			
	        try {
	        	
	//        For Access Controls Form
	        
	        ResultSet ac = stmt.executeQuery("SELECT * FROM form_access_control far "
	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	                + "WHERE far.unit_head_userid = '" + userid + "' "
	                + "AND far.unit_head_status = 'Pending' ");
	        
	        if (ac != null) {
		        while (ac.next()) {
		        	ListView listView = new ListView();
		
		            long id = ac.getLong("id");
		            String users = ac.getString("user_id");
		            String username = ac.getString("user_name");
		            String formid = ac.getString("form_id");
		            String formname = ac.getString("form_name");
		            String unitheadstatus = ac.getString("unit_head_status");
		            String citostatus = ac.getString("cito_status");
		            Timestamp submittime = ac.getTimestamp("submit_time");
		
		            listView.setId(id);
		            listView.setUserid(users);
		            listView.setUsername(username);
		            listView.setFormid(formid);
		            listView.setFormname(formname);
		            listView.setUnitheadstatus(unitheadstatus);
		            listView.setCitostatus(citostatus);
		            listView.setSubmittime(submittime);
		            
		            String branchcode = ac.getString("branch_code");
		              listView.setBranchcode(branchcode);
		
		            accessControls.add(listView);
		        }
	        }
	        dashboard.addAll(accessControls);
	
  	//      For Creating Mail Form
	  	        
	  	        ResultSet cm = stmt.executeQuery("SELECT * FROM form_create_email far "
	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	  	                + "WHERE far.unit_head_userid = '" + userid + "' "
	  	                + "AND far.unit_head_status = 'Pending' ");
	  	      
	  	        if (cm != null) {
	  		      while (cm.next()) {
	  		      	ListView listView = new ListView();
	  		
	  		          long id = cm.getLong("id");
	  		          String users = cm.getString("user_id");
	  		          String username = cm.getString("user_name");
	  		          String formid = cm.getString("form_id");
	  		          String formname = cm.getString("form_name");
	  		          String unitheadstatus = cm.getString("unit_head_status");
	  		          String citostatus = cm.getString("cito_status");
	  		          Timestamp submittime = cm.getTimestamp("submit_time");
	  		          
	  		          listView.setId(id);
	  		          listView.setUserid(users);
	  		          listView.setUsername(username);
	  		          listView.setFormid(formid);
	  		          listView.setFormname(formname);
	  		          listView.setUnitheadstatus(unitheadstatus);
	  		          listView.setCitostatus(citostatus);
	  		          listView.setSubmittime(submittime);
	  		          
	  		          String branchcode = cm.getString("branch_code");
	  	              listView.setBranchcode(branchcode);
	  		
	  		          createMail.add(listView);
	  		      }
	  	        }
	  	      dashboard.addAll(createMail);
	  	      

  	//      For Create Domain Form
	  	        
	  	        ResultSet cd = stmt.executeQuery("SELECT * FROM form_create_domain far "
	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	  	                + "WHERE far.unit_head_userid = '" + userid + "' "
	  	                + "AND far.unit_head_status = 'Pending' ");
	  	      
	  	        if (cd != null) {
	  		      while (cd.next()) {
	  		      	ListView listView = new ListView();
	  		
	  		          long id = cd.getLong("id");
	  		          String users = cd.getString("user_id");
	  		          String username = cd.getString("user_name");
	  		          String formid = cd.getString("form_id");
	  		          String formname = cd.getString("form_name");
	  		          String unitheadstatus = cd.getString("unit_head_status");
	  		          String citostatus = cd.getString("cito_status");
	  		          Timestamp submittime = cd.getTimestamp("submit_time");
	  		          
	  		          listView.setId(id);
	  		          listView.setUserid(users);
	  		          listView.setUsername(username);
	  		          listView.setFormid(formid);
	  		          listView.setFormname(formname);
	  		          listView.setUnitheadstatus(unitheadstatus);
	  		          listView.setCitostatus(citostatus);
	  		          listView.setSubmittime(submittime);
	  		          
	  		          String branchcode = cd.getString("branch_code");
	  	              listView.setBranchcode(branchcode);
	  		
	  		          createDomain.add(listView);
	  		      }
	  	        }
	  	      dashboard.addAll(createDomain);
	  	      

  	//      For Group Mail Form
	  	        
	  	        ResultSet gm = stmt.executeQuery("SELECT * FROM form_group_email far "
	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	  	                + "WHERE far.unit_head_userid = '" + userid + "' "
	  	                + "AND far.unit_head_status = 'Pending' ");
	  	      
	  	        if (gm != null) {
	  		      while (gm.next()) {
	  		      	ListView listView = new ListView();
	  		
	  		          long id = gm.getLong("id");
	  		          String users = gm.getString("user_id");
	  		          String username = gm.getString("user_name");
	  		          String formid = gm.getString("form_id");
	  		          String formname = gm.getString("form_name");
	  		          String unitheadstatus = gm.getString("unit_head_status");
	  		          String citostatus = gm.getString("cito_status");
	  		          Timestamp submittime = gm.getTimestamp("submit_time");
	  		          
	  		          listView.setId(id);
	  		          listView.setUserid(users);
	  		          listView.setUsername(username);
	  		          listView.setFormid(formid);
	  		          listView.setFormname(formname);
	  		          listView.setUnitheadstatus(unitheadstatus);
	  		          listView.setCitostatus(citostatus);
	  		          listView.setSubmittime(submittime);
	  		          
	  		          String branchcode = gm.getString("branch_code");
	  	              listView.setBranchcode(branchcode);
	  		
	  		          groupMail.add(listView);
	  		      }
	  	        }
	  	      dashboard.addAll(groupMail);
	           

	//          For Incident Report Form
	          
	          ResultSet ir = stmt.executeQuery("SELECT * FROM form_incident_report far "
	                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	                  + "WHERE far.unit_head_userid = '" + userid + "' "
	                  + "AND far.unit_head_status = 'Pending' ");
	         
	          if (ir != null) {
		          while (ir.next()) {
		          	ListView listView = new ListView();
		
		              long id = ir.getLong("id");
		              String users = ir.getString("user_id");
		              String username = ir.getString("user_name");
		              String formid = ir.getString("form_id");
		              String formname = ir.getString("form_name");
		              String unitheadstatus = ir.getString("unit_head_status");
		              String citostatus = ir.getString("cito_status");
		              Timestamp submittime = ir.getTimestamp("submit_time");
		              
		
		              listView.setId(id);
		              listView.setUserid(users);
		              listView.setUsername(username);
		              listView.setFormid(formid);
		              listView.setFormname(formname);
		              listView.setUnitheadstatus(unitheadstatus);
		              listView.setCitostatus(citostatus);
		              listView.setSubmittime(submittime);
		              
		              String branchcode = ir.getString("branch_code");
		              listView.setBranchcode(branchcode);
		
		              incidentReport.add(listView);
		          }
	          }
	          
	          dashboard.addAll(incidentReport);
	          

	  	//      For CBS User Permission
	  	       
	          ResultSet cbs = null;
	          ResultSet cbsHead = null;
	          
	          if (user.getBranchcode().equals("0100")) {
	        	  User userBr = profileRepository.findByEmpid(user.getEmpid());
	        	  DivisionName div = divisionNameRepository.findByDivisionname(userBr.getDepartment());
	        	  
	        	  if (div.getId() == 2) {
	        		  cbs = stmt.executeQuery("SELECT * FROM form_cbs_user_permission far "
	  	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	  	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	  	  	                + "WHERE far.bcd_userid = '" + div.getId() + "' "
	  	  	                + "AND (far.unit_head_status = 'Accepted' "
	  	  	                + "AND far.bcd_status = 'Pending')");
	        	  }
	        	  else if (div.getId() == 3) {
	        		  cbs = stmt.executeQuery("SELECT * FROM form_cbs_user_permission far "
		  	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
		  	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		  	  	                + "WHERE far.iad_userid = '" + div.getId() + "' "
		  	  	                + "AND (far.unit_head_status = 'Accepted' "
		  	  	                + "AND far.iad_status = 'Pending')");
	        	  }
	        	  else if (div.getId() == 12) {
	        		  cbs = stmt.executeQuery("SELECT * FROM form_cbs_user_permission far "
		  	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
		  	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		  	  	                + "WHERE far.imrd_userid = '" + div.getId() + "' "
		  	  	                + "AND (far.unit_head_status = 'Accepted' "
		  	  	                + "AND far.imrd_status = 'Pending')");
	        	  }
	        	  else if (div.getId() == 19) {
	        		  cbs = stmt.executeQuery("SELECT * FROM form_cbs_user_permission far "
		  	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
		  	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		  	  	                + "WHERE far.id_userid = '" + div.getId() + "' "
		  	  	                + "AND (far.unit_head_status = 'Accepted' "
		  	  	                + "AND far.id_status = 'Pending')");
	        	  }
	          }
	          else {
	        	  cbs = stmt.executeQuery("SELECT * FROM form_cbs_user_permission far "
		  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
		  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		  	                + "WHERE far.unit_head_userid = '" + userid + "' "
		  	                + "AND far.unit_head_status = 'Pending' ");
	          }
	          
		          if (cbs != null) {
			  	      while (cbs.next()) {
			  	      	ListView listView = new ListView();
			  	
			  	          long id = cbs.getLong("id");
			  	          String users = cbs.getString("user_id");
			  	          String username = cbs.getString("user_name");
			  	          String formid = cbs.getString("form_id");
			  	          String formname = cbs.getString("form_name");
			  	          String unitheadstatus = cbs.getString("unit_head_status");
			  	          Timestamp submittime = cbs.getTimestamp("submit_time");
			  	          
			  	          listView.setId(id);
			  	          listView.setUserid(users);
			  	          listView.setUsername(username);
			  	          listView.setFormid(formid);
			  	          listView.setFormname(formname);
			  	          listView.setUnitheadstatus(unitheadstatus);
			  	          listView.setSubmittime(submittime);
			  	          
			  	          String branchcode = cbs.getString("branch_code");
			                listView.setBranchcode(branchcode);
			  	
			  	          cbsUserPermission.add(listView);
			  	      }
		  	        }
		          
		          dashboard.addAll(cbsUserPermission);
		          
		          List<UnitHead> funcDeg = unitHeadRepository.findByEmpcodeAndStatus(user.getEmpid(), "Active");
	        	  
	        	  if (funcDeg != null && !funcDeg.isEmpty()) {
			          UnitHead unitHead = funcDeg.get(0);
			          
			          if (unitHead.getFuncdescode().equals("FD001") || unitHead.getFuncdescode().equals("FD011") 
			        		  || unitHead.getFuncdescode().equals("FD002") || unitHead.getFuncdescode().equals("FD016")) {
			         
			          cbsHead = stmt.executeQuery("SELECT * FROM form_cbs_user_permission far "
				  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
				  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
				  	                + "WHERE far.unit_head_userid = '" + userid + "' "
				  	                + "AND far.unit_head_status = 'Pending' ");
			          }
			        }
		          
		  	        if (cbsHead != null) {
			  	      while (cbsHead.next()) {
			  	      	ListView listView = new ListView();
			  	
			  	          long id = cbsHead.getLong("id");
			  	          String users = cbsHead.getString("user_id");
			  	          String username = cbsHead.getString("user_name");
			  	          String formid = cbsHead.getString("form_id");
			  	          String formname = cbsHead.getString("form_name");
			  	          String unitheadstatus = cbsHead.getString("unit_head_status");
			  	          Timestamp submittime = cbsHead.getTimestamp("submit_time");
			  	          
			  	          listView.setId(id);
			  	          listView.setUserid(users);
			  	          listView.setUsername(username);
			  	          listView.setFormid(formid);
			  	          listView.setFormname(formname);
			  	          listView.setUnitheadstatus(unitheadstatus);
			  	          listView.setSubmittime(submittime);
			  	          
			  	          String branchcode = cbsHead.getString("branch_code");
			                listView.setBranchcode(branchcode);
			  	
			  	          cbsUserPermission1.add(listView);
			  	      }
		  	        }
		  	      dashboard.addAll(cbsUserPermission1);

  	//      For Database Access Form
  		  	        
  		  	        ResultSet da = stmt.executeQuery("SELECT * FROM form_database_access far "
  		  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
  		  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
  		  	                + "WHERE far.unit_head_userid = '" + userid + "' "
  		  	                + "AND far.unit_head_status = 'Pending' ");
  		  	      
  		  	        if (da != null) {
  		  		      while (da.next()) {
  		  		      	ListView listView = new ListView();
  		  		
  		  		          long id = da.getLong("id");
  		  		          String users = da.getString("user_id");
  		  		          String username = da.getString("user_name");
  		  		          String formid = da.getString("form_id");
  		  		          String formname = da.getString("form_name");
  		  		          String unitheadstatus = da.getString("unit_head_status");
  		  		          String citostatus = da.getString("cito_status");
  		  		          Timestamp submittime = da.getTimestamp("submit_time");
  		  		          
  		  		          listView.setId(id);
  		  		          listView.setUserid(users);
  		  		          listView.setUsername(username);
  		  		          listView.setFormid(formid);
  		  		          listView.setFormname(formname);
  		  		          listView.setUnitheadstatus(unitheadstatus);
  		  		          listView.setCitostatus(citostatus);
  		  		          listView.setSubmittime(submittime);
  		  		          
  		  		          String branchcode = da.getString("branch_code");
  		  	              listView.setBranchcode(branchcode);
  		  		
  		  		          databaseAccess.add(listView);
  		  		      }
  		  	        }
  		  	      dashboard.addAll(databaseAccess);
	  	            
	  	      
	        } catch (Exception e) {
	            e.printStackTrace(); 
	        }
		}
		
		else if (user.getRoleid() == 3) {

//			For Implementers End 
			
			String deptname = user.getUnit();
			Long deptid = null;
			
			AccessControlUser accessControlUser = accessControlUserRepository.findByUserid(userid);
			IctDepartment ictDepartment = ictDepartmentRepository.findByDeptname(deptname);
			
			if (ictDepartment != null) {
				deptid = ictDepartment.getId();
			} else {
				deptname = user.getDepartment();
				IctDepartment ictDept = ictDepartmentRepository.findByDeptname(deptname);
				
				if (ictDept != null) {
					deptid = ictDept.getId();
				}
				else {
					deptid = 0L;
				}
			}
			
	        try {
	//        For Access Controls Form
	          
	          ResultSet ac = null ;
	          
	        if (accessControlUser != null) {
	        	ac = stmt.executeQuery("SELECT * FROM form_access_control far "
	        			+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
	        			+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	        			+ "WHERE (far.network_implemented_by_status = 'Pending' "
	        			+ "AND far.network_head_status = 'Accepted')");
	        }

	        if (ac != null) {
		        while (ac.next()) {
		        	ListView listView = new ListView();
		
		            long id = ac.getLong("id");
		            String users = ac.getString("user_id");
		            String username = ac.getString("user_name");
		            String formid = ac.getString("form_id");
		            String formname = ac.getString("form_name");
		            String unitheadstatus = ac.getString("unit_head_status");
		            String citostatus = ac.getString("cito_status");
		            Timestamp submittime = ac.getTimestamp("submit_time");
		
		            listView.setId(id);
		            listView.setUserid(users);
		            listView.setUsername(username);
		            listView.setFormid(formid);
		            listView.setFormname(formname);
		            listView.setUnitheadstatus(unitheadstatus);
		            listView.setCitostatus(citostatus);
		            listView.setSubmittime(submittime);
		            
		            String branchcode = ac.getString("branch_code");
		              listView.setBranchcode(branchcode);
		
		            accessControls.add(listView);
		        }
	        }
	        dashboard.addAll(accessControls);
	
	  	//      For Creating Mail Form
	  	        
	  	        ResultSet cm = stmt.executeQuery("SELECT * FROM form_create_email far "
	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	  	                + "WHERE far.implemented_by_dept_id = " + deptid + " "
	  	                + "AND (far.implemented_by_status = 'Pending' "
	  	                + "AND far.impl_by_unithead_status = 'Accepted') ");
	  	      
	  	        if (cm != null) {
	  		      while (cm.next()) {
	  		      	ListView listView = new ListView();
	  		
	  		          long id = cm.getLong("id");
	  		          String users = cm.getString("user_id");
	  		          String username = cm.getString("user_name");
	  		          String formid = cm.getString("form_id");
	  		          String formname = cm.getString("form_name");
	  		          String unitheadstatus = cm.getString("unit_head_status");
	  		          String citostatus = cm.getString("cito_status");
	  		          Timestamp submittime = cm.getTimestamp("submit_time");
	  		          
	  		          listView.setId(id);
	  		          listView.setUserid(users);
	  		          listView.setUsername(username);
	  		          listView.setFormid(formid);
	  		          listView.setFormname(formname);
	  		          listView.setUnitheadstatus(unitheadstatus);
	  		          listView.setCitostatus(citostatus);
	  		          listView.setSubmittime(submittime);
	  		          
	  		          String branchcode = cm.getString("branch_code");
	  	              listView.setBranchcode(branchcode);
	  		
	  		          createMail.add(listView);
	  		      }
	  	        }
	  	      dashboard.addAll(createMail);
	  	      
  	//      For Create Domain Form
  	  	        
  	  	        ResultSet cd = stmt.executeQuery("SELECT * FROM form_create_domain far "
  	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
  	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
  	  	                + "WHERE far.implemented_by_dept_id = " + deptid + " "
  	  	                + "AND (far.implemented_by_status = 'Pending' "
  	  	                + "AND far.cito_status = 'Accepted') ");
  	  	      
  	  	        if (cd != null) {
  	  		      while (cd.next()) {
  	  		      	ListView listView = new ListView();
  	  		
  	  		          long id = cd.getLong("id");
  	  		          String users = cd.getString("user_id");
  	  		          String username = cd.getString("user_name");
  	  		          String formid = cd.getString("form_id");
  	  		          String formname = cd.getString("form_name");
  	  		          String unitheadstatus = cd.getString("unit_head_status");
  	  		          String citostatus = cd.getString("cito_status");
  	  		          Timestamp submittime = cd.getTimestamp("submit_time");
  	  		          
  	  		          listView.setId(id);
  	  		          listView.setUserid(users);
  	  		          listView.setUsername(username);
  	  		          listView.setFormid(formid);
  	  		          listView.setFormname(formname);
  	  		          listView.setUnitheadstatus(unitheadstatus);
  	  		          listView.setCitostatus(citostatus);
  	  		          listView.setSubmittime(submittime);
  	  		          
  	  		          String branchcode = cd.getString("branch_code");
  	  	              listView.setBranchcode(branchcode);
  	  		
  	  		          createDomain.add(listView);
  	  		      }
  	  	        }
  	  	      dashboard.addAll(createDomain);
	  	      
  	//      For Group Mail Form
  	        
  	        ResultSet gm = stmt.executeQuery("SELECT * FROM form_group_email far "
  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
  	                + "WHERE far.implemented_by_dept_id = " + deptid + " "
  	                + "AND (far.implemented_by_status = 'Pending' "
  	                + "AND far.impl_by_unithead_status = 'Accepted') ");
  	      
  	        if (gm != null) {
  		      while (gm.next()) {
  		      	ListView listView = new ListView();
  		
  		          long id = gm.getLong("id");
  		          String users = gm.getString("user_id");
  		          String username = gm.getString("user_name");
  		          String formid = gm.getString("form_id");
  		          String formname = gm.getString("form_name");
  		          String unitheadstatus = gm.getString("unit_head_status");
  		          String citostatus = gm.getString("cito_status");
  		          Timestamp submittime = gm.getTimestamp("submit_time");
  		          
  		          listView.setId(id);
  		          listView.setUserid(users);
  		          listView.setUsername(username);
  		          listView.setFormid(formid);
  		          listView.setFormname(formname);
  		          listView.setUnitheadstatus(unitheadstatus);
  		          listView.setCitostatus(citostatus);
  		          listView.setSubmittime(submittime);
  		          
  		          String branchcode = gm.getString("branch_code");
  	              listView.setBranchcode(branchcode);
  		
  		          groupMail.add(listView);
  		      }
  	        }
  	      dashboard.addAll(groupMail);

  	//      For CBS User Permission
  	        
  	        ResultSet cbs = stmt.executeQuery("SELECT * FROM form_cbs_user_permission far "
  	        		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
  	        		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
  	        		+ "WHERE far.implemented_by_dept_id = '" + deptid + "' "
  	        		+ "AND far.implemented_by_status = 'Pending' "
  	        		+ "AND ((far.unit_head_status = 'Accepted' OR far.unit_head_status IS NULL) "
  	        		+ "AND (far.bcd_status = 'Accepted' OR far.bcd_status IS NULL) "
  	        		+ "AND (far.iad_status = 'Accepted' OR far.iad_status IS NULL) "
  	        		+ "AND (far.id_status = 'Accepted' OR far.id_status IS NULL) "
  	        		+ "AND (far.imrd_status = 'Accepted' OR far.imrd_status IS NULL))");
  	      
  	        if (cbs != null) {
	  	      while (cbs.next()) {
	  	      	ListView listView = new ListView();
	  	
	  	          long id = cbs.getLong("id");
	  	          String users = cbs.getString("user_id");
	  	          String username = cbs.getString("user_name");
	  	          String formid = cbs.getString("form_id");
	  	          String formname = cbs.getString("form_name");
	  	          String unitheadstatus = cbs.getString("unit_head_status");
	  	          Timestamp submittime = cbs.getTimestamp("submit_time");
	  	          
	  	          listView.setId(id);
	  	          listView.setUserid(users);
	  	          listView.setUsername(username);
	  	          listView.setFormid(formid);
	  	          listView.setFormname(formname);
	  	          listView.setUnitheadstatus(unitheadstatus);
	  	          listView.setSubmittime(submittime);
	  	          
	  	          String branchcode = cbs.getString("branch_code");
	                listView.setBranchcode(branchcode);
	  	
	  	          cbsUserPermission.add(listView);
	  	      }
  	        }
  	      dashboard.addAll(cbsUserPermission);
  	      
//        For Database Access Form
	        
	        ResultSet da = stmt.executeQuery("SELECT * FROM form_database_access far "
	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	                + "WHERE far.implemented_by_dept_id = " + deptid + " "
	                + "AND (far.implemented_by_status = 'Pending' "
	                + "AND far.impl_by_unithead_status = 'Accepted') ");
	      
	        if (da != null) {
		      while (da.next()) {
		      	ListView listView = new ListView();
		
		          long id = da.getLong("id");
		          String users = da.getString("user_id");
		          String username = da.getString("user_name");
		          String formid = da.getString("form_id");
		          String formname = da.getString("form_name");
		          String unitheadstatus = da.getString("unit_head_status");
		          String citostatus = da.getString("cito_status");
		          Timestamp submittime = da.getTimestamp("submit_time");
		          
		          listView.setId(id);
		          listView.setUserid(users);
		          listView.setUsername(username);
		          listView.setFormid(formid);
		          listView.setFormname(formname);
		          listView.setUnitheadstatus(unitheadstatus);
		          listView.setCitostatus(citostatus);
		          listView.setSubmittime(submittime);
		          
		          String branchcode = da.getString("branch_code");
	              listView.setBranchcode(branchcode);
		
		          databaseAccess.add(listView);
		      }
	        }
	      dashboard.addAll(databaseAccess);
		  	            
	      
	        } catch (Exception e) {
	            e.printStackTrace(); 
	        }
		}
		con.close();
		return dashboard;
	}
	
	@GetMapping("accepted/{id}")
    public List<ListView> acceptedForms(@PathVariable("id") String userid) throws SQLException, ClassNotFoundException{
		
		FunctionalRole functionalRole = functionalRoleRepository.findByUseridAndStatus(userid, "Active");
		User user = profileService.getUserByUserid(userid);
		
		Connection con = null;
		
		List<ListView> dashboard = new ArrayList<>();
		
		List<ListView> accessRights = new ArrayList<>();
		List<ListView> accessControls = new ArrayList<>();
		List<ListView> changeRequest = new ArrayList<>();
		List<ListView> createMail = new ArrayList<>();
		List<ListView> createDomain = new ArrayList<>();
		List<ListView> groupMail = new ArrayList<>();
		List<ListView> incidentReport = new ArrayList<>();
		List<ListView> databaseAccess = new ArrayList<>();
		List<ListView> cbsUserPermission = new ArrayList<>();
		List<ListView> cbsUserPermission1 = new ArrayList<>();
		
		con = PostGRESQLConnUtils.getPostGreSQLConnection();
        con.setAutoCommit(false);
        Statement stmt = con.createStatement();
        
        int flag = 0;
		
//		check the functional role of that user
		
		if (functionalRole!=null) {
		
//			For cito
			
			if (functionalRole.getFunctionalroleid() == 1) {
				flag = 1;
				
				try {
		
		//        For Access Controls Form
		        
		        ResultSet ac = stmt.executeQuery("SELECT * FROM form_access_control far "
		                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
		                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		                + "WHERE far.cito_userid = '" + userid + "' "
		                + "AND far.cito_status = 'Accepted' ");
		        
		        if (ac != null) {  
			        while (ac.next()) {
			        	ListView listView = new ListView();
			
			            long id = ac.getLong("id");
			            String users = ac.getString("user_id");
			            String username = ac.getString("user_name");
			            String formid = ac.getString("form_id");
			            String formname = ac.getString("form_name");
			            String unitheadstatus = ac.getString("unit_head_status");
			            String citostatus = ac.getString("cito_status");
			            Timestamp submittime = ac.getTimestamp("submit_time");
			
			            listView.setId(id);
			            listView.setUserid(users);
			            listView.setUsername(username);
			            listView.setFormid(formid);
			            listView.setFormname(formname);
			            listView.setUnitheadstatus(unitheadstatus);
			            listView.setCitostatus(citostatus);
			            listView.setSubmittime(submittime);
			            
			            String branchcode = ac.getString("branch_code");
			              listView.setBranchcode(branchcode);
			
			            accessControls.add(listView);
			        }
		        }
		        dashboard.addAll(accessControls);
		
		//      For Creating Mail Form
				        
				        ResultSet cm = stmt.executeQuery("SELECT * FROM form_create_email far "
				                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
				                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
				                + "WHERE far.cito_userid = '" + userid + "' "
				                + "AND far.cito_status = 'Accepted' ");
				      
				        if (cm != null) {
					      while (cm.next()) {
					      	ListView listView = new ListView();
					
					          long id = cm.getLong("id");
					          String users = cm.getString("user_id");
					          String username = cm.getString("user_name");
					          String formid = cm.getString("form_id");
					          String formname = cm.getString("form_name");
					          String unitheadstatus = cm.getString("unit_head_status");
					          String citostatus = cm.getString("cito_status");
					          Timestamp submittime = cm.getTimestamp("submit_time");
					          
					          listView.setId(id);
					          listView.setUserid(users);
					          listView.setUsername(username);
					          listView.setFormid(formid);
					          listView.setFormname(formname);
					          listView.setUnitheadstatus(unitheadstatus);
					          listView.setCitostatus(citostatus);
					          listView.setSubmittime(submittime);
					          
					          String branchcode = cm.getString("branch_code");
				              listView.setBranchcode(branchcode);
					
					          createMail.add(listView);
					      }
				        }
				      dashboard.addAll(createMail);
			      
	//		For Create Domain Form
			        
			        ResultSet cd = stmt.executeQuery("SELECT * FROM form_create_domain far "
			                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
			                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
			                + "WHERE far.cito_userid = '" + userid + "' "
			                + "AND far.cito_status = 'Accepted' ");
			      
			        if (cd != null) {
				      while (cd.next()) {
				      	ListView listView = new ListView();
				
				          long id = cd.getLong("id");
				          String users = cd.getString("user_id");
				          String username = cd.getString("user_name");
				          String formid = cd.getString("form_id");
				          String formname = cd.getString("form_name");
				          String unitheadstatus = cd.getString("unit_head_status");
				          String citostatus = cd.getString("cito_status");
				          Timestamp submittime = cd.getTimestamp("submit_time");
				          
				          listView.setId(id);
				          listView.setUserid(users);
				          listView.setUsername(username);
				          listView.setFormid(formid);
				          listView.setFormname(formname);
				          listView.setUnitheadstatus(unitheadstatus);
				          listView.setCitostatus(citostatus);
				          listView.setSubmittime(submittime);
				          
				          String branchcode = cd.getString("branch_code");
			              listView.setBranchcode(branchcode);
				
				          createDomain.add(listView);
				      }
			        }
			      dashboard.addAll(createDomain);
				      

	//      For Group Mail Form
			        
			        ResultSet gm = stmt.executeQuery("SELECT * FROM form_group_email far "
			                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
			                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
			                + "WHERE far.cito_userid = '" + userid + "' "
			                + "AND far.cito_status = 'Accepted' ");
			      
			        if (gm != null) {
				      while (gm.next()) {
				      	ListView listView = new ListView();
				
				          long id = gm.getLong("id");
				          String users = gm.getString("user_id");
				          String username = gm.getString("user_name");
				          String formid = gm.getString("form_id");
				          String formname = gm.getString("form_name");
				          String unitheadstatus = gm.getString("unit_head_status");
				          String citostatus = gm.getString("cito_status");
				          Timestamp submittime = gm.getTimestamp("submit_time");
				          
				          listView.setId(id);
				          listView.setUserid(users);
				          listView.setUsername(username);
				          listView.setFormid(formid);
				          listView.setFormname(formname);
				          listView.setUnitheadstatus(unitheadstatus);
				          listView.setCitostatus(citostatus);
				          listView.setSubmittime(submittime);
				          
				          String branchcode = gm.getString("branch_code");
			              listView.setBranchcode(branchcode);
				
				          groupMail.add(listView);
				      }
			        }
			      dashboard.addAll(groupMail);
				      

      //          For Incident Report Form
			          
			          ResultSet ir = stmt.executeQuery("SELECT * FROM form_incident_report far "
			                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
			                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
			                  + "WHERE far.cito_userid = '" + userid + "' "
			                  + "AND far.cito_status = 'Accepted' ");
			          
			          if (ir != null) {
				          while (ir.next()) {
				          	ListView listView = new ListView();
				
				              long id = ir.getLong("id");
				              String users = ir.getString("user_id");
				              String username = ir.getString("user_name");
				              String formid = ir.getString("form_id");
				              String formname = ir.getString("form_name");
				              String unitheadstatus = ir.getString("unit_head_status");
				              String citostatus = ir.getString("cito_status");
				              Timestamp submittime = ir.getTimestamp("submit_time");
				              
				
				              listView.setId(id);
				              listView.setUserid(users);
				              listView.setUsername(username);
				              listView.setFormid(formid);
				              listView.setFormname(formname);
				              listView.setUnitheadstatus(unitheadstatus);
				              listView.setCitostatus(citostatus);
				              listView.setSubmittime(submittime);
				              
				              String branchcode = ir.getString("branch_code");
				              listView.setBranchcode(branchcode);
				
				              incidentReport.add(listView);
				          }
			          }
			          
			          dashboard.addAll(incidentReport);
			          

	//      For Database Access Form
			        
			        ResultSet da = stmt.executeQuery("SELECT * FROM form_database_access far "
			                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
			                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
			                + "WHERE far.cito_userid = '" + userid + "' "
			                + "AND far.cito_status = 'Accepted' ");
			      
			        if (da != null) {
				      while (da.next()) {
				      	ListView listView = new ListView();
				
				          long id = da.getLong("id");
				          String users = da.getString("user_id");
				          String username = da.getString("user_name");
				          String formid = da.getString("form_id");
				          String formname = da.getString("form_name");
				          String unitheadstatus = da.getString("unit_head_status");
				          String citostatus = da.getString("cito_status");
				          Timestamp submittime = da.getTimestamp("submit_time");
				          
				          listView.setId(id);
				          listView.setUserid(users);
				          listView.setUsername(username);
				          listView.setFormid(formid);
				          listView.setFormname(formname);
				          listView.setUnitheadstatus(unitheadstatus);
				          listView.setCitostatus(citostatus);
				          listView.setSubmittime(submittime);
				          
				          String branchcode = da.getString("branch_code");
			              listView.setBranchcode(branchcode);
				
				          databaseAccess.add(listView);
				      }
			        }
			      dashboard.addAll(databaseAccess);
			        
				      
		        } catch (Exception e) {
		            e.printStackTrace(); 
		        }
				
			}
			else {
				
//				For ICT officer
				
				try {
		
		//        For Access Controls Form
		        
		        ResultSet ac =  null;
		        
		        if (functionalRole.getFunctionalroleid() == 2) {
		        	ac = stmt.executeQuery("SELECT * FROM form_access_control far "
	                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	                  + "WHERE far.isrm_head_userid = '" + userid + "' "
	                  + "AND far.isrm_head_status = 'Accepted' ");
	            }
	            else if (functionalRole.getFunctionalroleid() == 6) {
	            	ac = stmt.executeQuery("SELECT * FROM form_access_control far "
	                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	                  + "WHERE far.network_head_userid = '" + userid + "' "
	                  + "AND far.network_head_status = 'Accepted' ");
	            }
		        
		        if (ac != null) {  
		        while (ac.next()) {
		        	ListView listView = new ListView();
		
		            long id = ac.getLong("id");
		            String users = ac.getString("user_id");
		            String username = ac.getString("user_name");
		            String formid = ac.getString("form_id");
		            String formname = ac.getString("form_name");
		            String unitheadstatus = ac.getString("unit_head_status");
		            String citostatus = ac.getString("cito_status");
		            Timestamp submittime = ac.getTimestamp("submit_time");
		
		            listView.setId(id);
		            listView.setUserid(users);
		            listView.setUsername(username);
		            listView.setFormid(formid);
		            listView.setFormname(formname);
		            listView.setUnitheadstatus(unitheadstatus);
		            listView.setCitostatus(citostatus);
		            listView.setSubmittime(submittime);
		            
		            String branchcode = ac.getString("branch_code");
		              listView.setBranchcode(branchcode);
		
		            accessControls.add(listView);
		        }
		        }
		        dashboard.addAll(accessControls);
		
		//      For Creating Mail Form
		      
		      ResultSet cm = null ;
		      	if (functionalRole.getFunctionalroleid() == 2) {
				         cm = stmt.executeQuery("SELECT * FROM form_create_email far "
				                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
				                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
				                  + "WHERE far.isrm_head_userid = '" + userid + "' "
				                  + "AND far.isrm_head_status = 'Accepted' ");
		      	}
		      	else if (functionalRole.getFunctionalroleid() == 4) {
		      		cm = stmt.executeQuery("SELECT * FROM form_create_email far "
			                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
			                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
			                  + "WHERE far.impl_by_unithead_userid = '" + userid + "' "
			                  + "AND far.impl_by_unithead_status = 'Accepted' ");
		      	}
				      
				        if (cm != null) {
					      while (cm.next()) {
					      	ListView listView = new ListView();
					
					          long id = cm.getLong("id");
					          String users = cm.getString("user_id");
					          String username = cm.getString("user_name");
					          String formid = cm.getString("form_id");
					          String formname = cm.getString("form_name");
					          String unitheadstatus = cm.getString("unit_head_status");
					          String citostatus = cm.getString("cito_status");
					          Timestamp submittime = cm.getTimestamp("submit_time");
					          
					          listView.setId(id);
					          listView.setUserid(users);
					          listView.setUsername(username);
					          listView.setFormid(formid);
					          listView.setFormname(formname);
					          listView.setUnitheadstatus(unitheadstatus);
					          listView.setCitostatus(citostatus);
					          listView.setSubmittime(submittime);
					          
					          String branchcode = cm.getString("branch_code");
				              listView.setBranchcode(branchcode);
					
					          createMail.add(listView);
					      }
				        }
				      dashboard.addAll(createMail);
				      

	//      For Create Domain Form
			      
			      ResultSet cd = null ;
			      	if (functionalRole.getFunctionalroleid() == 2) {
			      		cd = stmt.executeQuery("SELECT * FROM form_create_domain far "
					                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
					                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
					                  + "WHERE far.isrm_head_userid = '" + userid + "' "
					                  + "AND far.isrm_head_status = 'Accepted' ");
			      	}
			      	else if (functionalRole.getFunctionalroleid() == 4) {
			      		cd = stmt.executeQuery("SELECT * FROM form_create_domain far "
				                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
				                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
				                  + "WHERE far.sa_head_userid = '" + userid + "' "
				                  + "AND far.sa_head_status = 'Accepted' ");
			      	}
					      
					        if (cd != null) {
						      while (cd.next()) {
						      	ListView listView = new ListView();
						
						          long id = cd.getLong("id");
						          String users = cd.getString("user_id");
						          String username = cd.getString("user_name");
						          String formid = cd.getString("form_id");
						          String formname = cd.getString("form_name");
						          String unitheadstatus = cd.getString("unit_head_status");
						          String citostatus = cd.getString("cito_status");
						          Timestamp submittime = cd.getTimestamp("submit_time");
						          
						          listView.setId(id);
						          listView.setUserid(users);
						          listView.setUsername(username);
						          listView.setFormid(formid);
						          listView.setFormname(formname);
						          listView.setUnitheadstatus(unitheadstatus);
						          listView.setCitostatus(citostatus);
						          listView.setSubmittime(submittime);
						          
						          String branchcode = cd.getString("branch_code");
					              listView.setBranchcode(branchcode);
						
						          createDomain.add(listView);
						      }
					        }
					      dashboard.addAll(createDomain);
				      
	
		//      For Group Mail Form
			      
			      ResultSet gm = null ;
			      	if (functionalRole.getFunctionalroleid() == 2) {
			      		gm = stmt.executeQuery("SELECT * FROM form_group_email far "
					                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
					                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
					                  + "WHERE far.isrm_head_userid = '" + userid + "' "
					                  + "AND far.isrm_head_status = 'Accepted' ");
			      	}
			      	else if (functionalRole.getFunctionalroleid() == 4) {
			      		gm = stmt.executeQuery("SELECT * FROM form_group_email far "
				                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
				                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
				                  + "WHERE far.impl_by_unithead_userid = '" + userid + "' "
				                  + "AND far.impl_by_unithead_status = 'Accepted' ");
			      	}
					      
					        if (gm != null) {
						      while (gm.next()) {
						      	ListView listView = new ListView();
						
						          long id = gm.getLong("id");
						          String users = gm.getString("user_id");
						          String username = gm.getString("user_name");
						          String formid = gm.getString("form_id");
						          String formname = gm.getString("form_name");
						          String unitheadstatus = gm.getString("unit_head_status");
						          String citostatus = gm.getString("cito_status");
						          Timestamp submittime = gm.getTimestamp("submit_time");
						          
						          listView.setId(id);
						          listView.setUserid(users);
						          listView.setUsername(username);
						          listView.setFormid(formid);
						          listView.setFormname(formname);
						          listView.setUnitheadstatus(unitheadstatus);
						          listView.setCitostatus(citostatus);
						          listView.setSubmittime(submittime);
						          
						          String branchcode = gm.getString("branch_code");
					              listView.setBranchcode(branchcode);
						
						          groupMail.add(listView);
						      }
					        }
					      dashboard.addAll(groupMail);
					      

	//          For Incident Report Form
	            
	            ResultSet ir = stmt.executeQuery("SELECT * FROM form_incident_report far "
	                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	                  + "WHERE far.isrm_head_userid = '" + userid + "' "
	                  + "AND far.isrm_head_status = 'Accepted' ");
	            
	            if (ir != null) {  
		          while (ir.next()) {
		        	  
		          	ListView listView = new ListView();
		
		              long id = ir.getLong("id");
		              String users = ir.getString("user_id");
		              String username = ir.getString("user_name");
		              String formid = ir.getString("form_id");
		              String formname = ir.getString("form_name");
		              String unitheadstatus = ir.getString("unit_head_status");
		              String citostatus = ir.getString("cito_status");
		              Timestamp submittime = ir.getTimestamp("submit_time");
		              
		
		              listView.setId(id);
		              listView.setUserid(users);
		              listView.setUsername(username);
		              listView.setFormid(formid);
		              listView.setFormname(formname);
		              listView.setUnitheadstatus(unitheadstatus);
		              listView.setCitostatus(citostatus);
		              listView.setSubmittime(submittime);
		              
		              String branchcode = ir.getString("branch_code");
		              listView.setBranchcode(branchcode);
		
		              incidentReport.add(listView);
		          }
	            }
	          
	          dashboard.addAll(incidentReport);
	          

	  		//      For Database Access Form
	  		      
	  		      ResultSet da = null ;
	  		      	if (functionalRole.getFunctionalroleid() == 2) {
	  		      	da = stmt.executeQuery("SELECT * FROM form_database_access far "
	  				                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	  				                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	  				                  + "WHERE far.isrm_head_userid = '" + userid + "' "
	  				                  + "AND far.isrm_head_status = 'Accepted' ");
	  		      	}
	  		      	else if (functionalRole.getFunctionalroleid() == 4) {
	  		      	da = stmt.executeQuery("SELECT * FROM form_database_access far "
	  			                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	  			                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	  			                  + "WHERE far.impl_by_unithead_userid = '" + userid + "' "
	  			                  + "AND far.impl_by_unithead_status = 'Accepted' ");
	  		      	}
	  				      
	  				        if (da != null) {
	  					      while (da.next()) {
	  					      	ListView listView = new ListView();
	  					
	  					          long id = da.getLong("id");
	  					          String users = da.getString("user_id");
	  					          String username = da.getString("user_name");
	  					          String formid = da.getString("form_id");
	  					          String formname = da.getString("form_name");
	  					          String unitheadstatus = da.getString("unit_head_status");
	  					          String citostatus = da.getString("cito_status");
	  					          Timestamp submittime = da.getTimestamp("submit_time");
	  					          
	  					          listView.setId(id);
	  					          listView.setUserid(users);
	  					          listView.setUsername(username);
	  					          listView.setFormid(formid);
	  					          listView.setFormname(formname);
	  					          listView.setUnitheadstatus(unitheadstatus);
	  					          listView.setCitostatus(citostatus);
	  					          listView.setSubmittime(submittime);
	  					          
	  					          String branchcode = da.getString("branch_code");
	  				              listView.setBranchcode(branchcode);
	  					
	  					          databaseAccess.add(listView);
	  					      }
	  				        }
	  				      dashboard.addAll(databaseAccess);
      
				            
		        } catch (Exception e) {
		            e.printStackTrace(); 
		        }
				
			}
			accessRights.clear();
			accessControls.clear();
			changeRequest.clear();
			createMail.clear();
			createDomain.clear();
			incidentReport.clear();
			groupMail.clear();
			cbsUserPermission.clear();
			databaseAccess.clear();
		}
			
		if (user.getRoleid() == 2 && flag == 0) {
			
			
//			For unit head
			
	        try {
	
	//        For Access Controls Form
	        
	        ResultSet ac = stmt.executeQuery("SELECT * FROM form_access_control far "
	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	                + "WHERE far.unit_head_userid = '" + userid + "' "
	                + "AND far.unit_head_status = 'Accepted' ");
	        
	        if (ac != null) {  
		        while (ac.next()) {
		        	ListView listView = new ListView();
		
		            long id = ac.getLong("id");
		            String users = ac.getString("user_id");
		            String username = ac.getString("user_name");
		            String formid = ac.getString("form_id");
		            String formname = ac.getString("form_name");
		            String unitheadstatus = ac.getString("unit_head_status");
		            String citostatus = ac.getString("cito_status");
		            Timestamp submittime = ac.getTimestamp("submit_time");
		
		            listView.setId(id);
		            listView.setUserid(users);
		            listView.setUsername(username);
		            listView.setFormid(formid);
		            listView.setFormname(formname);
		            listView.setUnitheadstatus(unitheadstatus);
		            listView.setCitostatus(citostatus);
		            listView.setSubmittime(submittime);
		            
		            String branchcode = ac.getString("branch_code");
		              listView.setBranchcode(branchcode);
		
		            accessControls.add(listView);
		        }
	        }
	        dashboard.addAll(accessControls);

	  	//      For Creating Mail Form
	  	        
	  	        ResultSet cm = stmt.executeQuery("SELECT * FROM form_create_email far "
	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	  	                + "WHERE far.unit_head_userid = '" + userid + "' "
	  	                + "AND far.unit_head_status = 'Accepted' ");
	  	      
	  	        if (cm != null) {
	  		      while (cm.next()) {
	  		      	ListView listView = new ListView();
	  		
	  		          long id = cm.getLong("id");
	  		          String users = cm.getString("user_id");
	  		          String username = cm.getString("user_name");
	  		          String formid = cm.getString("form_id");
	  		          String formname = cm.getString("form_name");
	  		          String unitheadstatus = cm.getString("unit_head_status");
	  		          String citostatus = cm.getString("cito_status");
	  		          Timestamp submittime = cm.getTimestamp("submit_time");
	  		          
	  		          listView.setId(id);
	  		          listView.setUserid(users);
	  		          listView.setUsername(username);
	  		          listView.setFormid(formid);
	  		          listView.setFormname(formname);
	  		          listView.setUnitheadstatus(unitheadstatus);
	  		          listView.setCitostatus(citostatus);
	  		          listView.setSubmittime(submittime);
	  		          
	  		          String branchcode = cm.getString("branch_code");
	  	              listView.setBranchcode(branchcode);
	  		
	  		          createMail.add(listView);
	  		      }
	  	        }
	  	      dashboard.addAll(createMail);
	  	      

	  	  	//      For Create Domain Form
	  	  	        
	  	  	        ResultSet cd = stmt.executeQuery("SELECT * FROM form_create_domain far "
	  	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	  	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	  	  	                + "WHERE far.unit_head_userid = '" + userid + "' "
	  	  	                + "AND far.unit_head_status = 'Accepted' ");
	  	  	      
	  	  	        if (cd != null) {
	  	  		      while (cd.next()) {
	  	  		      	ListView listView = new ListView();
	  	  		
	  	  		          long id = cd.getLong("id");
	  	  		          String users = cd.getString("user_id");
	  	  		          String username = cd.getString("user_name");
	  	  		          String formid = cd.getString("form_id");
	  	  		          String formname = cd.getString("form_name");
	  	  		          String unitheadstatus = cd.getString("unit_head_status");
	  	  		          String citostatus = cd.getString("cito_status");
	  	  		          Timestamp submittime = cd.getTimestamp("submit_time");
	  	  		          
	  	  		          listView.setId(id);
	  	  		          listView.setUserid(users);
	  	  		          listView.setUsername(username);
	  	  		          listView.setFormid(formid);
	  	  		          listView.setFormname(formname);
	  	  		          listView.setUnitheadstatus(unitheadstatus);
	  	  		          listView.setCitostatus(citostatus);
	  	  		          listView.setSubmittime(submittime);
	  	  		          
	  	  		          String branchcode = cd.getString("branch_code");
	  	  	              listView.setBranchcode(branchcode);
	  	  		
	  	  		          createDomain.add(listView);
	  	  		      }
	  	  	        }
	  	  	      dashboard.addAll(createDomain);
	  	      

  	  	//      For Group Mail Form
  	  	        
  	  	        ResultSet gm = stmt.executeQuery("SELECT * FROM form_group_email far "
  	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
  	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
  	  	                + "WHERE far.unit_head_userid = '" + userid + "' "
  	  	                + "AND far.unit_head_status = 'Accepted' ");
  	  	      
  	  	        if (gm != null) {
  	  		      while (gm.next()) {
  	  		      	ListView listView = new ListView();
  	  		
  	  		          long id = gm.getLong("id");
  	  		          String users = gm.getString("user_id");
  	  		          String username = gm.getString("user_name");
  	  		          String formid = gm.getString("form_id");
  	  		          String formname = gm.getString("form_name");
  	  		          String unitheadstatus = gm.getString("unit_head_status");
  	  		          String citostatus = gm.getString("cito_status");
  	  		          Timestamp submittime = gm.getTimestamp("submit_time");
  	  		          
  	  		          listView.setId(id);
  	  		          listView.setUserid(users);
  	  		          listView.setUsername(username);
  	  		          listView.setFormid(formid);
  	  		          listView.setFormname(formname);
  	  		          listView.setUnitheadstatus(unitheadstatus);
  	  		          listView.setCitostatus(citostatus);
  	  		          listView.setSubmittime(submittime);
  	  		          
  	  		          String branchcode = gm.getString("branch_code");
  	  	              listView.setBranchcode(branchcode);
  	  		
  	  		          groupMail.add(listView);
  	  		      }
  	  	        }
  	  	      dashboard.addAll(groupMail);
	  	      

	//          For Incident Report Form
	          
	          ResultSet ir = stmt.executeQuery("SELECT * FROM form_incident_report far "
	                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	                  + "WHERE far.unit_head_userid = '" + userid + "' "
	                  + "AND far.unit_head_status = 'Accepted' ");
	         
	          if (ir != null) {
		          while (ir.next()) {
		          	ListView listView = new ListView();
		
		              long id = ir.getLong("id");
		              String users = ir.getString("user_id");
		              String username = ir.getString("user_name");
		              String formid = ir.getString("form_id");
		              String formname = ir.getString("form_name");
		              String unitheadstatus = ir.getString("unit_head_status");
		              String citostatus = ir.getString("cito_status");
		              Timestamp submittime = ir.getTimestamp("submit_time");
		              
		
		              listView.setId(id);
		              listView.setUserid(users);
		              listView.setUsername(username);
		              listView.setFormid(formid);
		              listView.setFormname(formname);
		              listView.setUnitheadstatus(unitheadstatus);
		              listView.setCitostatus(citostatus);
		              listView.setSubmittime(submittime);
		              
		              String branchcode = ir.getString("branch_code");
		              listView.setBranchcode(branchcode);
		
		              incidentReport.add(listView);
		          }
	          }
	          
	          dashboard.addAll(incidentReport);
	      

	  	//      For CBS User Permission
	          
	          
	          ResultSet cbs = null;
	          ResultSet cbsHead = null;
	          
	          if (user.getBranchcode().equals("0100")) {
	        	  User userBr = profileRepository.findByEmpid(user.getEmpid());
	        	  DivisionName div = divisionNameRepository.findByDivisionname(userBr.getDepartment());
	        	  
	        	  if (div.getId() == 2) {
	        		  cbs = stmt.executeQuery("SELECT * FROM form_cbs_user_permission far "
	  	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	  	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	  	  	                + "WHERE far.bcd_userid = '" + userid + "' "
	  	  	                + "AND far.bcd_status = 'Accepted'");
	        	  }
	        	  else if (div.getId() == 3) {
	        		  cbs = stmt.executeQuery("SELECT * FROM form_cbs_user_permission far "
		  	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
		  	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		  	  	                + "WHERE far.iad_userid = '" + userid + "' "
		  	  	                + "AND far.iad_status = 'Accepted'");
	        	  }
	        	  else if (div.getId() == 12) {
	        		  cbs = stmt.executeQuery("SELECT * FROM form_cbs_user_permission far "
		  	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
		  	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		  	  	                + "WHERE far.imrd_userid = '" + userid + "' "
		  	  	                + "AND far.imrd_status = 'Accepted'");
	        	  }
	        	  else if (div.getId() == 19) {
	        		  cbs = stmt.executeQuery("SELECT * FROM form_cbs_user_permission far "
		  	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
		  	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		  	  	                + "WHERE far.id_userid = '" + userid + "' "
		  	  	                + "AND far.id_status = 'Accepted'");
	        	  }
	        	  
	        	  
	        	  
	          }
	          else {
	        	  cbs = stmt.executeQuery("SELECT * FROM form_cbs_user_permission far "
		  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
		  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		  	                + "WHERE far.unit_head_userid = '" + userid + "' "
		  	                + "AND far.unit_head_status = 'Accepted' ");
	          }
		          
		  	        if (cbs != null) {
			  	      while (cbs.next()) {
			  	      	ListView listView = new ListView();
			  	
			  	          long id = cbs.getLong("id");
			  	          String users = cbs.getString("user_id");
			  	          String username = cbs.getString("user_name");
			  	          String formid = cbs.getString("form_id");
			  	          String formname = cbs.getString("form_name");
			  	          String unitheadstatus = cbs.getString("unit_head_status");
			  	          Timestamp submittime = cbs.getTimestamp("submit_time");
			  	          
			  	          listView.setId(id);
			  	          listView.setUserid(users);
			  	          listView.setUsername(username);
			  	          listView.setFormid(formid);
			  	          listView.setFormname(formname);
			  	          listView.setUnitheadstatus(unitheadstatus);
			  	          listView.setSubmittime(submittime);
			  	          
			  	          String branchcode = cbs.getString("branch_code");
			                listView.setBranchcode(branchcode);
			  	
			  	          cbsUserPermission.add(listView);
			  	      }
		  	        }
		  	      dashboard.addAll(cbsUserPermission);
	          
		  	    List<UnitHead> funcDeg = unitHeadRepository.findByEmpcodeAndStatus(user.getEmpid(), "Active");
	        	  
	        	  if (funcDeg != null && !funcDeg.isEmpty()) {
			          UnitHead unitHead = funcDeg.get(0);
			          
			          if (unitHead.getFuncdescode().equals("FD001") || unitHead.getFuncdescode().equals("FD011") 
			        		  || unitHead.getFuncdescode().equals("FD002") || unitHead.getFuncdescode().equals("FD016")) {
			          
			          cbsHead = stmt.executeQuery("SELECT * FROM form_cbs_user_permission far "
			  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
			  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
			  	                + "WHERE far.unit_head_userid = '" + userid + "' "
			  	                + "AND far.unit_head_status = 'Accepted' ");
			          }
			        }
	        	  
	        	  if (cbsHead != null) {
			  	      while (cbsHead.next()) {
			  	      	ListView listView = new ListView();
			  	
			  	          long id = cbsHead.getLong("id");
			  	          String users = cbsHead.getString("user_id");
			  	          String username = cbsHead.getString("user_name");
			  	          String formid = cbsHead.getString("form_id");
			  	          String formname = cbsHead.getString("form_name");
			  	          String unitheadstatus = cbsHead.getString("unit_head_status");
			  	          Timestamp submittime = cbsHead.getTimestamp("submit_time");
			  	          
			  	          listView.setId(id);
			  	          listView.setUserid(users);
			  	          listView.setUsername(username);
			  	          listView.setFormid(formid);
			  	          listView.setFormname(formname);
			  	          listView.setUnitheadstatus(unitheadstatus);
			  	          listView.setSubmittime(submittime);
			  	          
			  	          String branchcode = cbsHead.getString("branch_code");
			                listView.setBranchcode(branchcode);
			  	
			  	          cbsUserPermission1.add(listView);
			  	      }
		  	        }
		  	      dashboard.addAll(cbsUserPermission1);
	        	  
	        	  
	          
  	//      For Database Access Form
  	  	        
  	  	        ResultSet da = stmt.executeQuery("SELECT * FROM form_database_access far "
  	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
  	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
  	  	                + "WHERE far.unit_head_userid = '" + userid + "' "
  	  	                + "AND far.unit_head_status = 'Accepted' ");
  	  	      
  	  	        if (da != null) {
  	  		      while (da.next()) {
  	  		      	ListView listView = new ListView();
  	  		
  	  		          long id = da.getLong("id");
  	  		          String users = da.getString("user_id");
  	  		          String username = da.getString("user_name");
  	  		          String formid = da.getString("form_id");
  	  		          String formname = da.getString("form_name");
  	  		          String unitheadstatus = da.getString("unit_head_status");
  	  		          String citostatus = da.getString("cito_status");
  	  		          Timestamp submittime = da.getTimestamp("submit_time");
  	  		          
  	  		          listView.setId(id);
  	  		          listView.setUserid(users);
  	  		          listView.setUsername(username);
  	  		          listView.setFormid(formid);
  	  		          listView.setFormname(formname);
  	  		          listView.setUnitheadstatus(unitheadstatus);
  	  		          listView.setCitostatus(citostatus);
  	  		          listView.setSubmittime(submittime);
  	  		          
  	  		          String branchcode = da.getString("branch_code");
  	  	              listView.setBranchcode(branchcode);
  	  		
  	  		          databaseAccess.add(listView);
  	  		      }
  	  	        }
  	  	      dashboard.addAll(databaseAccess);
	            
	        } catch (Exception e) {
	            e.printStackTrace(); 
	        }
		}
		
		else if (user.getRoleid() == 3) {

//			For Implementers End 
			
			String deptname = user.getUnit();
			Long deptid = null;
			
			AccessControlUser accessControlUser = accessControlUserRepository.findByUserid(userid);
			IctDepartment ictDepartment = ictDepartmentRepository.findByDeptname(deptname);
			
			if (ictDepartment != null) {
				deptid = ictDepartment.getId();
			} else {
				
				deptname = user.getDepartment();
				IctDepartment ictDept = ictDepartmentRepository.findByDeptname(deptname);
				
				if (ictDept != null) {
					deptid = ictDept.getId();
				}
				else {
					deptid = 0L;
				}
			}
			
	        try {
	        	
	//        For Access Controls Form
	        
	          ResultSet ac = null;
	        		  
	          if (accessControlUser != null) {
	        	  ac = stmt.executeQuery("SELECT * FROM form_access_control far "
		        			+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
		        			+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		        			+ "WHERE far.network_implemented_by_status = 'Done' ");
		        }
	          
	          if (ac != null) {  
		        while (ac.next()) {
		        	ListView listView = new ListView();
		
		            long id = ac.getLong("id");
		            String users = ac.getString("user_id");
		            String username = ac.getString("user_name");
		            String formid = ac.getString("form_id");
		            String formname = ac.getString("form_name");
		            String unitheadstatus = ac.getString("unit_head_status");
		            String citostatus = ac.getString("cito_status");
		            Timestamp submittime = ac.getTimestamp("submit_time");
		
		            listView.setId(id);
		            listView.setUserid(users);
		            listView.setUsername(username);
		            listView.setFormid(formid);
		            listView.setFormname(formname);
		            listView.setUnitheadstatus(unitheadstatus);
		            listView.setCitostatus(citostatus);
		            listView.setSubmittime(submittime);
		            
		            String branchcode = ac.getString("branch_code");
		              listView.setBranchcode(branchcode);
		
		            accessControls.add(listView);
		        	}
		          }
	        
	        dashboard.addAll(accessControls);
	
	  	//      For Creating Mail Form
	  	        
	  	        ResultSet cm = stmt.executeQuery("SELECT * FROM form_create_email far "
	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	  	                + "WHERE far.implemented_by_dept_id = " + deptid + " "
	  	                + "AND far.implemented_by_status = 'Done' ");
	  	      
	  	        if (cm != null) {
	  		      while (cm.next()) {
	  		      	ListView listView = new ListView();
	  		
	  		          long id = cm.getLong("id");
	  		          String users = cm.getString("user_id");
	  		          String username = cm.getString("user_name");
	  		          String formid = cm.getString("form_id");
	  		          String formname = cm.getString("form_name");
	  		          String unitheadstatus = cm.getString("unit_head_status");
	  		          String citostatus = cm.getString("cito_status");
	  		          Timestamp submittime = cm.getTimestamp("submit_time");
	  		          
	  		          listView.setId(id);
	  		          listView.setUserid(users);
	  		          listView.setUsername(username);
	  		          listView.setFormid(formid);
	  		          listView.setFormname(formname);
	  		          listView.setUnitheadstatus(unitheadstatus);
	  		          listView.setCitostatus(citostatus);
	  		          listView.setSubmittime(submittime);
	  		          
	  		          String branchcode = cm.getString("branch_code");
	  	              listView.setBranchcode(branchcode);
	  		
	  		          createMail.add(listView);
	  		      }
	  	        }
	  	      dashboard.addAll(createMail);
	  	      
//	        For Create Domain Form
	  	        
	  	        ResultSet cd = stmt.executeQuery("SELECT * FROM form_create_domain far "
	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	  	                + "WHERE far.implemented_by_dept_id = " + deptid + " "
	  	                + "AND far.implemented_by_status = 'Done' ");
	  	      
	  	        if (cd != null) {
	  		      while (cd.next()) {
	  		      	ListView listView = new ListView();
	  		
	  		          long id = cd.getLong("id");
	  		          String users = cd.getString("user_id");
	  		          String username = cd.getString("user_name");
	  		          String formid = cd.getString("form_id");
	  		          String formname = cd.getString("form_name");
	  		          String unitheadstatus = cd.getString("unit_head_status");
	  		          String citostatus = cd.getString("cito_status");
	  		          Timestamp submittime = cd.getTimestamp("submit_time");
	  		          
	  		          listView.setId(id);
	  		          listView.setUserid(users);
	  		          listView.setUsername(username);
	  		          listView.setFormid(formid);
	  		          listView.setFormname(formname);
	  		          listView.setUnitheadstatus(unitheadstatus);
	  		          listView.setCitostatus(citostatus);
	  		          listView.setSubmittime(submittime);
	  		          
	  		          String branchcode = cd.getString("branch_code");
	  	              listView.setBranchcode(branchcode);
	  		
	  		          createDomain.add(listView);
	  		      }
	  	        }
	  	      dashboard.addAll(createDomain);
	  	      

  //      For Group Mail Form
  	  	        
  	  	        ResultSet gm = stmt.executeQuery("SELECT * FROM form_group_email far "
  	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
  	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
  	  	                + "WHERE far.implemented_by_dept_id = " + deptid + " "
  	  	                + "AND far.implemented_by_status = 'Done' ");
  	  	      
  	  	        if (gm != null) {
  	  		      while (gm.next()) {
  	  		      	ListView listView = new ListView();
  	  		
  	  		          long id = gm.getLong("id");
  	  		          String users = gm.getString("user_id");
  	  		          String username = gm.getString("user_name");
  	  		          String formid = gm.getString("form_id");
  	  		          String formname = gm.getString("form_name");
  	  		          String unitheadstatus = gm.getString("unit_head_status");
  	  		          String citostatus = gm.getString("cito_status");
  	  		          Timestamp submittime = gm.getTimestamp("submit_time");
  	  		          
  	  		          listView.setId(id);
  	  		          listView.setUserid(users);
  	  		          listView.setUsername(username);
  	  		          listView.setFormid(formid);
  	  		          listView.setFormname(formname);
  	  		          listView.setUnitheadstatus(unitheadstatus);
  	  		          listView.setCitostatus(citostatus);
  	  		          listView.setSubmittime(submittime);
  	  		          
  	  		          String branchcode = gm.getString("branch_code");
  	  	              listView.setBranchcode(branchcode);
  	  		
  	  		          groupMail.add(listView);
  	  		      }
  	  	        }
  	  	      dashboard.addAll(groupMail);
	  	            

	  	//      For CBS User Permission
	  	        
	  	        ResultSet cbs = stmt.executeQuery("SELECT * FROM form_cbs_user_permission far "
	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	  	                + "WHERE far.implemented_by_dept_id = " + deptid + " "
	  	                + "AND far.implemented_by_status = 'Done' ");
	  	      
	  	      if (cbs != null) {
		  	      while (cbs.next()) {
		  	      	ListView listView = new ListView();
		  	
		  	          long id = cbs.getLong("id");
		  	          String users = cbs.getString("user_id");
		  	          String username = cbs.getString("user_name");
		  	          String formid = cbs.getString("form_id");
		  	          String formname = cbs.getString("form_name");
		  	          String unitheadstatus = cbs.getString("unit_head_status");
		  	          Timestamp submittime = cbs.getTimestamp("submit_time");
		  	          
		  	          listView.setId(id);
		  	          listView.setUserid(users);
		  	          listView.setUsername(username);
		  	          listView.setFormid(formid);
		  	          listView.setFormname(formname);
		  	          listView.setUnitheadstatus(unitheadstatus);
		  	          listView.setSubmittime(submittime);
		  	          
		  	          String branchcode = cbs.getString("branch_code");
		                listView.setBranchcode(branchcode);
		  	
		  	          cbsUserPermission.add(listView);
		  	      }
	  	      }
	  	      dashboard.addAll(cbsUserPermission);
	  	      

  	//      For Database Access Form
  	  	        
  	  	        ResultSet da = stmt.executeQuery("SELECT * FROM form_database_access far "
  	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
  	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
  	  	                + "WHERE far.implemented_by_dept_id = " + deptid + " "
  	  	                + "AND far.implemented_by_status = 'Done' ");
  	  	      
  	  	        if (da != null) {
  	  		      while (da.next()) {
  	  		      	ListView listView = new ListView();
  	  		
  	  		          long id = da.getLong("id");
  	  		          String users = da.getString("user_id");
  	  		          String username = da.getString("user_name");
  	  		          String formid = da.getString("form_id");
  	  		          String formname = da.getString("form_name");
  	  		          String unitheadstatus = da.getString("unit_head_status");
  	  		          String citostatus = da.getString("cito_status");
  	  		          Timestamp submittime = da.getTimestamp("submit_time");
  	  		          
  	  		          listView.setId(id);
  	  		          listView.setUserid(users);
  	  		          listView.setUsername(username);
  	  		          listView.setFormid(formid);
  	  		          listView.setFormname(formname);
  	  		          listView.setUnitheadstatus(unitheadstatus);
  	  		          listView.setCitostatus(citostatus);
  	  		          listView.setSubmittime(submittime);
  	  		          
  	  		          String branchcode = da.getString("branch_code");
  	  	              listView.setBranchcode(branchcode);
  	  		
  	  		          databaseAccess.add(listView);
  	  		      }
  	  	        }
  	  	      dashboard.addAll(databaseAccess);
	  	            
	  	      
	        } catch (Exception e) {
	            e.printStackTrace(); 
	        }
		}
		
		con.close();
		return dashboard;
	}
	
	@GetMapping("rejected/{id}")
    public List<ListView> rejectedForms(@PathVariable("id") String userid) throws SQLException, ClassNotFoundException{
		
		FunctionalRole functionalRole = functionalRoleRepository.findByUseridAndStatus(userid, "Active");
		User user = profileService.getUserByUserid(userid);
		
		Connection con = null;
		
		List<ListView> dashboard = new ArrayList<>();
		
		List<ListView> accessRights = new ArrayList<>();
		List<ListView> accessControls = new ArrayList<>();
		List<ListView> changeRequest = new ArrayList<>();
		List<ListView> createMail = new ArrayList<>();
		List<ListView> createDomain = new ArrayList<>();
		List<ListView> groupMail = new ArrayList<>();
		List<ListView> incidentReport = new ArrayList<>();
		List<ListView> databaseAccess = new ArrayList<>();
		List<ListView> cbsUserPermission = new ArrayList<>();
		List<ListView> cbsUserPermission1 = new ArrayList<>();
		
		con = PostGRESQLConnUtils.getPostGreSQLConnection();
        con.setAutoCommit(false);
        Statement stmt = con.createStatement();
        
        int flag = 0;
		
//		Check the functional role of that user
		
		if (functionalRole!=null) {
		
//			For cito
			
			if (functionalRole.getFunctionalroleid() == 1) {
				flag = 1;
				
				try {
		
		//        For Access Controls Form
		        
		        ResultSet ac = stmt.executeQuery("SELECT * FROM form_access_control far "
		                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
		                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		                + "WHERE far.cito_userid = '" + userid + "' "
		                + "AND far.cito_status = 'Rejected' ");
		        
		        if (ac != null) {
			        while (ac.next()) {
			        	ListView listView = new ListView();
			
			            long id = ac.getLong("id");
			            String users = ac.getString("user_id");
			            String username = ac.getString("user_name");
			            String formid = ac.getString("form_id");
			            String formname = ac.getString("form_name");
			            String unitheadstatus = ac.getString("unit_head_status");
			            String citostatus = ac.getString("cito_status");
			            Timestamp submittime = ac.getTimestamp("submit_time");
			
			            listView.setId(id);
			            listView.setUserid(users);
			            listView.setUsername(username);
			            listView.setFormid(formid);
			            listView.setFormname(formname);
			            listView.setUnitheadstatus(unitheadstatus);
			            listView.setCitostatus(citostatus);
			            listView.setSubmittime(submittime);
			            
			            String branchcode = ac.getString("branch_code");
			              listView.setBranchcode(branchcode);
			
			            accessControls.add(listView);
			        }
		        }
		        dashboard.addAll(accessControls);
		
		//      For Creating Mail Form
				        
			        ResultSet cm = stmt.executeQuery("SELECT * FROM form_create_email far "
			                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
			                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
			                + "WHERE far.cito_userid = '" + userid + "' "
			                + "AND far.cito_status = 'Rejected' ");
			      
			        if (cm != null) {
				      while (cm.next()) {
				      	ListView listView = new ListView();
				
				          long id = cm.getLong("id");
				          String users = cm.getString("user_id");
				          String username = cm.getString("user_name");
				          String formid = cm.getString("form_id");
				          String formname = cm.getString("form_name");
				          String unitheadstatus = cm.getString("unit_head_status");
				          String citostatus = cm.getString("cito_status");
				          Timestamp submittime = cm.getTimestamp("submit_time");
				          
				          listView.setId(id);
				          listView.setUserid(users);
				          listView.setUsername(username);
				          listView.setFormid(formid);
				          listView.setFormname(formname);
				          listView.setUnitheadstatus(unitheadstatus);
				          listView.setCitostatus(citostatus);
				          listView.setSubmittime(submittime);
				          
				          String branchcode = cm.getString("branch_code");
			              listView.setBranchcode(branchcode);
				
				          createMail.add(listView);
				      }
			        }
			      dashboard.addAll(createMail);
			      
//			      For Create Domain Form
			        
			        ResultSet cd = stmt.executeQuery("SELECT * FROM form_create_domain far "
			                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
			                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
			                + "WHERE far.cito_userid = '" + userid + "' "
			                + "AND far.cito_status = 'Rejected' ");
			      
			        if (cd != null) {
				      while (cd.next()) {
				      	ListView listView = new ListView();
				
				          long id = cd.getLong("id");
				          String users = cd.getString("user_id");
				          String username = cd.getString("user_name");
				          String formid = cd.getString("form_id");
				          String formname = cd.getString("form_name");
				          String unitheadstatus = cd.getString("unit_head_status");
				          String citostatus = cd.getString("cito_status");
				          Timestamp submittime = cd.getTimestamp("submit_time");
				          
				          listView.setId(id);
				          listView.setUserid(users);
				          listView.setUsername(username);
				          listView.setFormid(formid);
				          listView.setFormname(formname);
				          listView.setUnitheadstatus(unitheadstatus);
				          listView.setCitostatus(citostatus);
				          listView.setSubmittime(submittime);
				          
				          String branchcode = cd.getString("branch_code");
			              listView.setBranchcode(branchcode);
				
				          createDomain.add(listView);
				      }
			        }
			      dashboard.addAll(createDomain);

		//      For Group Mail Form
				        
			        ResultSet gm = stmt.executeQuery("SELECT * FROM form_group_email far "
			                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
			                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
			                + "WHERE far.cito_userid = '" + userid + "' "
			                + "AND far.cito_status = 'Rejected' ");
			      
			        if (gm != null) {
				      while (gm.next()) {
				      	ListView listView = new ListView();
				
				          long id = gm.getLong("id");
				          String users = gm.getString("user_id");
				          String username = gm.getString("user_name");
				          String formid = gm.getString("form_id");
				          String formname = gm.getString("form_name");
				          String unitheadstatus = gm.getString("unit_head_status");
				          String citostatus = gm.getString("cito_status");
				          Timestamp submittime = gm.getTimestamp("submit_time");
				          
				          listView.setId(id);
				          listView.setUserid(users);
				          listView.setUsername(username);
				          listView.setFormid(formid);
				          listView.setFormname(formname);
				          listView.setUnitheadstatus(unitheadstatus);
				          listView.setCitostatus(citostatus);
				          listView.setSubmittime(submittime);
				          
				          String branchcode = gm.getString("branch_code");
			              listView.setBranchcode(branchcode);
				
				          groupMail.add(listView);
				      }
			        }
			      dashboard.addAll(groupMail);

		//          For Incident Report Form
		          
		          ResultSet ir = stmt.executeQuery("SELECT * FROM form_incident_report far "
		                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
		                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		                  + "WHERE far.cito_userid = '" + userid + "' "
		                  + "AND far.cito_status = 'Rejected' ");
		          
		          if (ir != null) {
			          while (ir.next()) {
			          	ListView listView = new ListView();
			
			              long id = ir.getLong("id");
			              String users = ir.getString("user_id");
			              String username = ir.getString("user_name");
			              String formid = ir.getString("form_id");
			              String formname = ir.getString("form_name");
			              String unitheadstatus = ir.getString("unit_head_status");
			              String citostatus = ir.getString("cito_status");
			              Timestamp submittime = ir.getTimestamp("submit_time");
			              
			
			              listView.setId(id);
			              listView.setUserid(users);
			              listView.setUsername(username);
			              listView.setFormid(formid);
			              listView.setFormname(formname);
			              listView.setUnitheadstatus(unitheadstatus);
			              listView.setCitostatus(citostatus);
			              listView.setSubmittime(submittime);
			              
			              String branchcode = ir.getString("branch_code");
			              listView.setBranchcode(branchcode);
			
			              incidentReport.add(listView);
			          }
		          }
		          dashboard.addAll(incidentReport);
		          

  		//      For Database Access Form
  				        
  			        ResultSet da = stmt.executeQuery("SELECT * FROM form_database_access far "
  			                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
  			                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
  			                + "WHERE far.cito_userid = '" + userid + "' "
  			                + "AND far.cito_status = 'Rejected' ");
  			      
  			        if (da != null) {
  				      while (da.next()) {
  				      	ListView listView = new ListView();
  				
  				          long id = da.getLong("id");
  				          String users = da.getString("user_id");
  				          String username = da.getString("user_name");
  				          String formid = da.getString("form_id");
  				          String formname = da.getString("form_name");
  				          String unitheadstatus = da.getString("unit_head_status");
  				          String citostatus = da.getString("cito_status");
  				          Timestamp submittime = da.getTimestamp("submit_time");
  				          
  				          listView.setId(id);
  				          listView.setUserid(users);
  				          listView.setUsername(username);
  				          listView.setFormid(formid);
  				          listView.setFormname(formname);
  				          listView.setUnitheadstatus(unitheadstatus);
  				          listView.setCitostatus(citostatus);
  				          listView.setSubmittime(submittime);
  				          
  				          String branchcode = da.getString("branch_code");
  			              listView.setBranchcode(branchcode);
  				
  				          databaseAccess.add(listView);
  				      }
  			        }
  			      dashboard.addAll(databaseAccess);
		          
				            
		        } catch (Exception e) {
		            e.printStackTrace(); 
		        }
				
			}
			else {
				try {
		    
//					For ICT officer
		
		//        For Access Controls Form
		        
		        ResultSet ac =  null;
		        
		        if (functionalRole.getFunctionalroleid() == 2) {
		        	ac = stmt.executeQuery("SELECT * FROM form_access_control far "
	                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	                  + "WHERE far.isrm_head_userid = '" + userid + "' "
	                  + "AND far.isrm_head_status = 'Rejected' ");
	            }
	            else if (functionalRole.getFunctionalroleid() == 6) {
	            	ac = stmt.executeQuery("SELECT * FROM form_access_control far "
	                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	                  + "WHERE far.network_head_userid = '" + userid + "' "
	                  + "AND far.network_head_status = 'Rejected' ");
	            }
		        
		        if (ac != null) {
			        while (ac.next()) {
			        	ListView listView = new ListView();
			
			            long id = ac.getLong("id");
			            String users = ac.getString("user_id");
			            String username = ac.getString("user_name");
			            String formid = ac.getString("form_id");
			            String formname = ac.getString("form_name");
			            String unitheadstatus = ac.getString("unit_head_status");
			            String citostatus = ac.getString("cito_status");
			            Timestamp submittime = ac.getTimestamp("submit_time");
			
			            listView.setId(id);
			            listView.setUserid(users);
			            listView.setUsername(username);
			            listView.setFormid(formid);
			            listView.setFormname(formname);
			            listView.setUnitheadstatus(unitheadstatus);
			            listView.setCitostatus(citostatus);
			            listView.setSubmittime(submittime);
			            
			            String branchcode = ac.getString("branch_code");
			              listView.setBranchcode(branchcode);
			
			            accessControls.add(listView);
			        }
		        }
		        dashboard.addAll(accessControls);
		
			//      For Creating Mail Form
		      
		      ResultSet cm = null;
		    
			      if (functionalRole.getFunctionalroleid() == 2) {   
				         cm = stmt.executeQuery("SELECT * FROM form_create_email far "
				                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
				                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
				                  + "WHERE far.isrm_head_userid = '" + userid + "' "
				                  + "AND far.isrm_head_status = 'Rejected' ");
			      }
			      else if (functionalRole.getFunctionalroleid() == 4) {   
				         cm = stmt.executeQuery("SELECT * FROM form_create_email far "
				                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
				                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
				                  + "WHERE far.impl_by_unithead_userid = '" + userid + "' "
				                  + "AND far.impl_by_unithead_status = 'Rejected' ");
			      }
			      
			        if (cm != null) {
				      while (cm.next()) {
				      	ListView listView = new ListView();
				
				          long id = cm.getLong("id");
				          String users = cm.getString("user_id");
				          String username = cm.getString("user_name");
				          String formid = cm.getString("form_id");
				          String formname = cm.getString("form_name");
				          String unitheadstatus = cm.getString("unit_head_status");
				          String citostatus = cm.getString("cito_status");
				          Timestamp submittime = cm.getTimestamp("submit_time");
				          
				          listView.setId(id);
				          listView.setUserid(users);
				          listView.setUsername(username);
				          listView.setFormid(formid);
				          listView.setFormname(formname);
				          listView.setUnitheadstatus(unitheadstatus);
				          listView.setCitostatus(citostatus);
				          listView.setSubmittime(submittime);
				          
				          String branchcode = cm.getString("branch_code");
			              listView.setBranchcode(branchcode);
				
				          createMail.add(listView);
				      }
			        }
			      dashboard.addAll(createMail);
			      

	//      For Create Domain Form
			      
			      ResultSet cd = null;
			    
				      if (functionalRole.getFunctionalroleid() == 2) {   
				    	  cd = stmt.executeQuery("SELECT * FROM form_create_domain far "
					                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
					                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
					                  + "WHERE far.isrm_head_userid = '" + userid + "' "
					                  + "AND far.isrm_head_status = 'Rejected' ");
				      }
				      else if (functionalRole.getFunctionalroleid() == 4) {   
				    	  cd = stmt.executeQuery("SELECT * FROM form_create_domain far "
					                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
					                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
					                  + "WHERE far.impl_by_unithead_userid = '" + userid + "' "
					                  + "AND far.impl_by_unithead_status = 'Rejected' ");
				      }
				      
				        if (cd != null) {
					      while (cd.next()) {
					      	ListView listView = new ListView();
					
					          long id = cd.getLong("id");
					          String users = cd.getString("user_id");
					          String username = cd.getString("user_name");
					          String formid = cd.getString("form_id");
					          String formname = cd.getString("form_name");
					          String unitheadstatus = cd.getString("unit_head_status");
					          String citostatus = cd.getString("cito_status");
					          Timestamp submittime = cd.getTimestamp("submit_time");
					          
					          listView.setId(id);
					          listView.setUserid(users);
					          listView.setUsername(username);
					          listView.setFormid(formid);
					          listView.setFormname(formname);
					          listView.setUnitheadstatus(unitheadstatus);
					          listView.setCitostatus(citostatus);
					          listView.setSubmittime(submittime);
					          
					          String branchcode = cd.getString("branch_code");
				              listView.setBranchcode(branchcode);
					
					          createDomain.add(listView);
					      }
				        }
				      dashboard.addAll(createDomain);
			      

      //      For Group Mail Form
			      
			      ResultSet gm = null;
			    
				      if (functionalRole.getFunctionalroleid() == 2) {   
				    	  gm = stmt.executeQuery("SELECT * FROM form_group_email far "
					                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
					                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
					                  + "WHERE far.isrm_head_userid = '" + userid + "' "
					                  + "AND far.isrm_head_status = 'Rejected' ");
				      }
				      else if (functionalRole.getFunctionalroleid() == 4) {   
				    	  gm = stmt.executeQuery("SELECT * FROM form_group_email far "
					                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
					                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
					                  + "WHERE far.impl_by_unithead_userid = '" + userid + "' "
					                  + "AND far.impl_by_unithead_status = 'Rejected' ");
				      }
				      
				        if (gm != null) {
					      while (gm.next()) {
					      	ListView listView = new ListView();
					
					          long id = gm.getLong("id");
					          String users = gm.getString("user_id");
					          String username = gm.getString("user_name");
					          String formid = gm.getString("form_id");
					          String formname = gm.getString("form_name");
					          String unitheadstatus = gm.getString("unit_head_status");
					          String citostatus = gm.getString("cito_status");
					          Timestamp submittime = gm.getTimestamp("submit_time");
					          
					          listView.setId(id);
					          listView.setUserid(users);
					          listView.setUsername(username);
					          listView.setFormid(formid);
					          listView.setFormname(formname);
					          listView.setUnitheadstatus(unitheadstatus);
					          listView.setCitostatus(citostatus);
					          listView.setSubmittime(submittime);
					          
					          String branchcode = gm.getString("branch_code");
				              listView.setBranchcode(branchcode);
					
					          groupMail.add(listView);
					      }
				        }
				      dashboard.addAll(groupMail);
			      

		//          For Incident Report Form
		            
		            ResultSet ir = stmt.executeQuery("SELECT * FROM form_incident_report far "
		                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
		                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		                  + "WHERE far.isrm_head_userid = '" + userid + "' "
		                  + "AND far.isrm_head_status = 'Rejected' ");
		            
		            if (ir != null) { 
			          while (ir.next()) {
			        	  
			          	ListView listView = new ListView();
			
			              long id = ir.getLong("id");
			              String users = ir.getString("user_id");
			              String username = ir.getString("user_name");
			              String formid = ir.getString("form_id");
			              String formname = ir.getString("form_name");
			              String unitheadstatus = ir.getString("unit_head_status");
			              String citostatus = ir.getString("cito_status");
			              Timestamp submittime = ir.getTimestamp("submit_time");
			              
			
			              listView.setId(id);
			              listView.setUserid(users);
			              listView.setUsername(username);
			              listView.setFormid(formid);
			              listView.setFormname(formname);
			              listView.setUnitheadstatus(unitheadstatus);
			              listView.setCitostatus(citostatus);
			              listView.setSubmittime(submittime);
			              
			              String branchcode = ir.getString("branch_code");
			              listView.setBranchcode(branchcode);
			
			              incidentReport.add(listView);
			          }
		            }
		          dashboard.addAll(incidentReport);
		          

	//      For Database Access Form
			      
			      ResultSet da = null;
			    
				      if (functionalRole.getFunctionalroleid() == 2) {   
				    	  da = stmt.executeQuery("SELECT * FROM form_database_access far "
					                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
					                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
					                  + "WHERE far.isrm_head_userid = '" + userid + "' "
					                  + "AND far.isrm_head_status = 'Rejected' ");
				      }
				      else if (functionalRole.getFunctionalroleid() == 4) {   
				    	  da = stmt.executeQuery("SELECT * FROM form_database_access far "
					                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
					                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
					                  + "WHERE far.impl_by_unithead_userid = '" + userid + "' "
					                  + "AND far.impl_by_unithead_status = 'Rejected' ");
				      }
				      
				        if (da != null) {
					      while (da.next()) {
					      	ListView listView = new ListView();
					
					          long id = da.getLong("id");
					          String users = da.getString("user_id");
					          String username = da.getString("user_name");
					          String formid = da.getString("form_id");
					          String formname = da.getString("form_name");
					          String unitheadstatus = da.getString("unit_head_status");
					          String citostatus = da.getString("cito_status");
					          Timestamp submittime = da.getTimestamp("submit_time");
					          
					          listView.setId(id);
					          listView.setUserid(users);
					          listView.setUsername(username);
					          listView.setFormid(formid);
					          listView.setFormname(formname);
					          listView.setUnitheadstatus(unitheadstatus);
					          listView.setCitostatus(citostatus);
					          listView.setSubmittime(submittime);
					          
					          String branchcode = da.getString("branch_code");
				              listView.setBranchcode(branchcode);
					
					          databaseAccess.add(listView);
					      }
				        }
				      dashboard.addAll(databaseAccess);
				            
		        } catch (Exception e) {
		            e.printStackTrace(); 
		        }
				
			}
			accessRights.clear();
			accessControls.clear();
			changeRequest.clear();
			createMail.clear();
			createDomain.clear();
			groupMail.clear();
			incidentReport.clear();
			cbsUserPermission.clear();
			databaseAccess.clear();
		}
			
		if (user.getRoleid() == 2 && flag == 0) {
		
//			For unit head
			
	        try {
	
	//        For Access Controls Form
	        
	        ResultSet ac = stmt.executeQuery("SELECT * FROM form_access_control far "
	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	                + "WHERE far.unit_head_userid = '" + userid + "' "
	                + "AND far.unit_head_status = 'Rejected' ");
	        
	        if (ac != null) {
		        while (ac.next()) {
		        	ListView listView = new ListView();
		
		            long id = ac.getLong("id");
		            String users = ac.getString("user_id");
		            String username = ac.getString("user_name");
		            String formid = ac.getString("form_id");
		            String formname = ac.getString("form_name");
		            String unitheadstatus = ac.getString("unit_head_status");
		            String citostatus = ac.getString("cito_status");
		            Timestamp submittime = ac.getTimestamp("submit_time");
		
		            listView.setId(id);
		            listView.setUserid(users);
		            listView.setUsername(username);
		            listView.setFormid(formid);
		            listView.setFormname(formname);
		            listView.setUnitheadstatus(unitheadstatus);
		            listView.setCitostatus(citostatus);
		            listView.setSubmittime(submittime);
		            
		            String branchcode = ac.getString("branch_code");
		            listView.setBranchcode(branchcode);
		
		            accessControls.add(listView);
		        }
	        }
	        dashboard.addAll(accessControls);
	
	  	//      For Creating Mail Form
	  	        
	  	        ResultSet cm = stmt.executeQuery("SELECT * FROM form_create_email far "
	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	  	                + "WHERE far.unit_head_userid = '" + userid + "' "
	  	                + "AND far.unit_head_status = 'Rejected' ");
	  	      
	  	        if (cm != null) {
	  		      while (cm.next()) {
	  		      	ListView listView = new ListView();
	  		
	  		          long id = cm.getLong("id");
	  		          String users = cm.getString("user_id");
	  		          String username = cm.getString("user_name");
	  		          String formid = cm.getString("form_id");
	  		          String formname = cm.getString("form_name");
	  		          String unitheadstatus = cm.getString("unit_head_status");
	  		          String citostatus = cm.getString("cito_status");
	  		          Timestamp submittime = cm.getTimestamp("submit_time");
	  		          
	  		          listView.setId(id);
	  		          listView.setUserid(users);
	  		          listView.setUsername(username);
	  		          listView.setFormid(formid);
	  		          listView.setFormname(formname);
	  		          listView.setUnitheadstatus(unitheadstatus);
	  		          listView.setCitostatus(citostatus);
	  		          listView.setSubmittime(submittime);
	  		          
	  		          String branchcode = cm.getString("branch_code");
	  	              listView.setBranchcode(branchcode);
	  		
	  		          createMail.add(listView);
	  		      }
	  	        }
	  	      dashboard.addAll(createMail);
	  	      

  	  	//      For Create Domain Form
	  	  	        
	  	  	        ResultSet cd = stmt.executeQuery("SELECT * FROM form_create_domain far "
	  	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	  	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	  	  	                + "WHERE far.unit_head_userid = '" + userid + "' "
	  	  	                + "AND far.unit_head_status = 'Rejected' ");
	  	  	      
	  	  	        if (cd != null) {
	  	  		      while (cd.next()) {
	  	  		      	ListView listView = new ListView();
	  	  		
	  	  		          long id = cd.getLong("id");
	  	  		          String users = cd.getString("user_id");
	  	  		          String username = cd.getString("user_name");
	  	  		          String formid = cd.getString("form_id");
	  	  		          String formname = cd.getString("form_name");
	  	  		          String unitheadstatus = cd.getString("unit_head_status");
	  	  		          String citostatus = cd.getString("cito_status");
	  	  		          Timestamp submittime = cd.getTimestamp("submit_time");
	  	  		          
	  	  		          listView.setId(id);
	  	  		          listView.setUserid(users);
	  	  		          listView.setUsername(username);
	  	  		          listView.setFormid(formid);
	  	  		          listView.setFormname(formname);
	  	  		          listView.setUnitheadstatus(unitheadstatus);
	  	  		          listView.setCitostatus(citostatus);
	  	  		          listView.setSubmittime(submittime);
	  	  		          
	  	  		          String branchcode = cd.getString("branch_code");
	  	  	              listView.setBranchcode(branchcode);
	  	  		
	  	  		          createDomain.add(listView);
	  	  		      }
	  	  	        }
	  	  	      dashboard.addAll(createDomain);

  	  	//      For Group Mail Form
  	  	        
  	  	        ResultSet gm = stmt.executeQuery("SELECT * FROM form_group_email far "
  	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
  	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
  	  	                + "WHERE far.unit_head_userid = '" + userid + "' "
  	  	                + "AND far.unit_head_status = 'Rejected' ");
  	  	      
  	  	        if (gm != null) {
  	  		      while (gm.next()) {
  	  		      	ListView listView = new ListView();
  	  		
  	  		          long id = gm.getLong("id");
  	  		          String users = gm.getString("user_id");
  	  		          String username = gm.getString("user_name");
  	  		          String formid = gm.getString("form_id");
  	  		          String formname = gm.getString("form_name");
  	  		          String unitheadstatus = gm.getString("unit_head_status");
  	  		          String citostatus = gm.getString("cito_status");
  	  		          Timestamp submittime = gm.getTimestamp("submit_time");
  	  		          
  	  		          listView.setId(id);
  	  		          listView.setUserid(users);
  	  		          listView.setUsername(username);
  	  		          listView.setFormid(formid);
  	  		          listView.setFormname(formname);
  	  		          listView.setUnitheadstatus(unitheadstatus);
  	  		          listView.setCitostatus(citostatus);
  	  		          listView.setSubmittime(submittime);
  	  		          
  	  		          String branchcode = gm.getString("branch_code");
  	  	              listView.setBranchcode(branchcode);
  	  		
  	  		          groupMail.add(listView);
  	  		      }
  	  	        }
  	  	      dashboard.addAll(groupMail);
	  	            
	//          For Incident Report Form
	          
	          ResultSet ir = stmt.executeQuery("SELECT * FROM form_incident_report far "
	                  + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	                  + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	                  + "WHERE far.unit_head_userid = '" + userid + "' "
	                  + "AND far.unit_head_status = 'Rejected' ");
	          
	          if (ir != null) {
		          while (ir.next()) {
		          	ListView listView = new ListView();
		
		              long id = ir.getLong("id");
		              String users = ir.getString("user_id");
		              String username = ir.getString("user_name");
		              String formid = ir.getString("form_id");
		              String formname = ir.getString("form_name");
		              String unitheadstatus = ir.getString("unit_head_status");
		              String citostatus = ir.getString("cito_status");
		              Timestamp submittime = ir.getTimestamp("submit_time");
		              
		
		              listView.setId(id);
		              listView.setUserid(users);
		              listView.setUsername(username);
		              listView.setFormid(formid);
		              listView.setFormname(formname);
		              listView.setUnitheadstatus(unitheadstatus);
		              listView.setCitostatus(citostatus);
		              listView.setSubmittime(submittime);
		              
		              String branchcode = ir.getString("branch_code");
		              listView.setBranchcode(branchcode);
		
		              incidentReport.add(listView);
		          }
	          }
	          dashboard.addAll(incidentReport);
	          

  	//      For CBS User Permission
	          
	          ResultSet cbs = null;
	          ResultSet cbsHead = null;
	          
	          if (user.getBranchcode().equals("0100")) {
	        	  User userBr = profileRepository.findByEmpid(user.getEmpid());
	        	  DivisionName div = divisionNameRepository.findByDivisionname(userBr.getDepartment());
	        	  
	        	  if (div.getId() == 2) {
	        		  cbs = stmt.executeQuery("SELECT * FROM form_cbs_user_permission far "
	  	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	  	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	  	  	                + "WHERE far.bcd_userid = '" + userid + "' "
	  	  	                + "AND far.bcd_status = 'Rejected'");
	        	  }
	        	  else if (div.getId() == 3) {
	        		  cbs = stmt.executeQuery("SELECT * FROM form_cbs_user_permission far "
		  	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
		  	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		  	  	                + "WHERE far.iad_userid = '" + userid + "' "
		  	  	                + "AND far.iad_status = 'Rejected'");
	        	  }
	        	  else if (div.getId() == 12) {
	        		  cbs = stmt.executeQuery("SELECT * FROM form_cbs_user_permission far "
		  	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
		  	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		  	  	                + "WHERE far.imrd_userid = '" + userid + "' "
		  	  	                + "AND far.imrd_status = 'Rejected'");
	        	  }
	        	  else if (div.getId() == 19) {
	        		  cbs = stmt.executeQuery("SELECT * FROM form_cbs_user_permission far "
		  	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
		  	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		  	  	                + "WHERE far.id_userid = '" + userid + "' "
		  	  	                + "AND far.id_status = 'Rejected'");
	        	  }
	        	  
	        	  
	        	  
	          }
	          else {
	        	  cbs = stmt.executeQuery("SELECT * FROM form_cbs_user_permission far "
		  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
		  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		  	                + "WHERE far.unit_head_userid = '" + userid + "' "
		  	                + "AND far.unit_head_status = 'Rejected' ");
	          }
		          
		  	        if (cbs != null) {
			  	      while (cbs.next()) {
			  	      	ListView listView = new ListView();
			  	
			  	          long id = cbs.getLong("id");
			  	          String users = cbs.getString("user_id");
			  	          String username = cbs.getString("user_name");
			  	          String formid = cbs.getString("form_id");
			  	          String formname = cbs.getString("form_name");
			  	          String unitheadstatus = cbs.getString("unit_head_status");
			  	          Timestamp submittime = cbs.getTimestamp("submit_time");
			  	          
			  	          listView.setId(id);
			  	          listView.setUserid(users);
			  	          listView.setUsername(username);
			  	          listView.setFormid(formid);
			  	          listView.setFormname(formname);
			  	          listView.setUnitheadstatus(unitheadstatus);
			  	          listView.setSubmittime(submittime);
			  	          
			  	          String branchcode = cbs.getString("branch_code");
			                listView.setBranchcode(branchcode);
			  	
			  	          cbsUserPermission.add(listView);
			  	      }
		  	        }
		  	      dashboard.addAll(cbsUserPermission);
	          
		  	    List<UnitHead> funcDeg = unitHeadRepository.findByEmpcodeAndStatus(user.getEmpid(), "Active");
	        	  
	        	  if (funcDeg != null && !funcDeg.isEmpty()) {
			          UnitHead unitHead = funcDeg.get(0);
			          
			          if (unitHead.getFuncdescode().equals("FD001") || unitHead.getFuncdescode().equals("FD011") 
			        		  || unitHead.getFuncdescode().equals("FD002") || unitHead.getFuncdescode().equals("FD016")) {
			          
			          cbsHead = stmt.executeQuery("SELECT * FROM form_cbs_user_permission far "
			  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
			  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
			  	                + "WHERE far.unit_head_userid = '" + userid + "' "
			  	                + "AND far.unit_head_status = 'Rejected' ");
			          }
			        }
	        	  
	        	  if (cbsHead != null) {
			  	      while (cbsHead.next()) {
			  	      	ListView listView = new ListView();
			  	
			  	          long id = cbsHead.getLong("id");
			  	          String users = cbsHead.getString("user_id");
			  	          String username = cbsHead.getString("user_name");
			  	          String formid = cbsHead.getString("form_id");
			  	          String formname = cbsHead.getString("form_name");
			  	          String unitheadstatus = cbsHead.getString("unit_head_status");
			  	          Timestamp submittime = cbsHead.getTimestamp("submit_time");
			  	          
			  	          listView.setId(id);
			  	          listView.setUserid(users);
			  	          listView.setUsername(username);
			  	          listView.setFormid(formid);
			  	          listView.setFormname(formname);
			  	          listView.setUnitheadstatus(unitheadstatus);
			  	          listView.setSubmittime(submittime);
			  	          
			  	          String branchcode = cbsHead.getString("branch_code");
			                listView.setBranchcode(branchcode);
			  	
			  	          cbsUserPermission1.add(listView);
			  	      }
		  	        }
		  	      dashboard.addAll(cbsUserPermission1);

//      For Database Access Form
  	  	        
  	  	        ResultSet da = stmt.executeQuery("SELECT * FROM form_database_access far "
  	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
  	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
  	  	                + "WHERE far.unit_head_userid = '" + userid + "' "
  	  	                + "AND far.unit_head_status = 'Rejected' ");
  	  	      
  	  	        if (da != null) {
  	  		      while (da.next()) {
  	  		      	ListView listView = new ListView();
  	  		
  	  		          long id = da.getLong("id");
  	  		          String users = da.getString("user_id");
  	  		          String username = da.getString("user_name");
  	  		          String formid = da.getString("form_id");
  	  		          String formname = da.getString("form_name");
  	  		          String unitheadstatus = da.getString("unit_head_status");
  	  		          String citostatus = da.getString("cito_status");
  	  		          Timestamp submittime = da.getTimestamp("submit_time");
  	  		          
  	  		          listView.setId(id);
  	  		          listView.setUserid(users);
  	  		          listView.setUsername(username);
  	  		          listView.setFormid(formid);
  	  		          listView.setFormname(formname);
  	  		          listView.setUnitheadstatus(unitheadstatus);
  	  		          listView.setCitostatus(citostatus);
  	  		          listView.setSubmittime(submittime);
  	  		          
  	  		          String branchcode = da.getString("branch_code");
  	  	              listView.setBranchcode(branchcode);
  	  		
  	  		          databaseAccess.add(listView);
  	  		      }
  	  	        }
  	  	      dashboard.addAll(databaseAccess);
  	            
  	      
	        } catch (Exception e) {
	            e.printStackTrace(); 
	        }
		}
		
		else if (user.getRoleid() == 3) {

//			For Implementers End 
			
			String deptname = user.getUnit();
			Long deptid = null;
			
			AccessControlUser accessControlUser = accessControlUserRepository.findByUserid(userid);
			IctDepartment ictDepartment = ictDepartmentRepository.findByDeptname(deptname);
			if (ictDepartment != null) {
				deptid = ictDepartment.getId();
			} else {
				deptname = user.getDepartment();
				IctDepartment ictDept = ictDepartmentRepository.findByDeptname(deptname);
				if (ictDept != null) {
					deptid = ictDept.getId();
				}
				else {
					deptid = 0L;
				}
			}
			
	        try {
	
	//        For Access Controls Form
	        
	          ResultSet ac = null;
    		  
	          if (accessControlUser != null) {
	        	  ac = stmt.executeQuery("SELECT * FROM form_access_control far "
		        			+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
		        			+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		        			+ "WHERE far.network_implemented_by_status = 'Rejected' ");
		        }
	          
	          if (ac != null) {
		        while (ac.next()) {
		        	ListView listView = new ListView();
		
		            long id = ac.getLong("id");
		            String users = ac.getString("user_id");
		            String username = ac.getString("user_name");
		            String formid = ac.getString("form_id");
		            String formname = ac.getString("form_name");
		            String unitheadstatus = ac.getString("unit_head_status");
		            String citostatus = ac.getString("cito_status");
		            Timestamp submittime = ac.getTimestamp("submit_time");
		
		            listView.setId(id);
		            listView.setUserid(users);
		            listView.setUsername(username);
		            listView.setFormid(formid);
		            listView.setFormname(formname);
		            listView.setUnitheadstatus(unitheadstatus);
		            listView.setCitostatus(citostatus);
		            listView.setSubmittime(submittime);
		            
		            String branchcode = ac.getString("branch_code");
		              listView.setBranchcode(branchcode);
		
		            accessControls.add(listView);
		        }
	          }
	        dashboard.addAll(accessControls);
	
	  	//      For Creating Mail Form
	  	        
	  	        ResultSet cm = stmt.executeQuery("SELECT * FROM form_create_email far "
	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	  	                + "WHERE far.implemented_by_dept_id = " + deptid + " "
	  	                + "AND far.implemented_by_status = 'Rejected' ");
	  	      
	  	        if (cm != null) {
	  		      while (cm.next()) {
	  		      	ListView listView = new ListView();
	  		
	  		          long id = cm.getLong("id");
	  		          String users = cm.getString("user_id");
	  		          String username = cm.getString("user_name");
	  		          String formid = cm.getString("form_id");
	  		          String formname = cm.getString("form_name");
	  		          String unitheadstatus = cm.getString("unit_head_status");
	  		          String citostatus = cm.getString("cito_status");
	  		          Timestamp submittime = cm.getTimestamp("submit_time");
	  		          
	  		          listView.setId(id);
	  		          listView.setUserid(users);
	  		          listView.setUsername(username);
	  		          listView.setFormid(formid);
	  		          listView.setFormname(formname);
	  		          listView.setUnitheadstatus(unitheadstatus);
	  		          listView.setCitostatus(citostatus);
	  		          listView.setSubmittime(submittime);
	  		          
	  		          String branchcode = cm.getString("branch_code");
	  	              listView.setBranchcode(branchcode);
	  		
	  		          createMail.add(listView);
	  		      }
	  	        }
	  	      dashboard.addAll(createMail);
	  	      
 	//      For Create Domain Form
	  	        
	  	        ResultSet cd = stmt.executeQuery("SELECT * FROM form_create_domain far "
	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	  	                + "WHERE far.implemented_by_dept_id = " + deptid + " "
	  	                + "AND far.implemented_by_status = 'Rejected' ");
	  	      
	  	        if (cd != null) {
	  		      while (cd.next()) {
	  		      	ListView listView = new ListView();
	  		
	  		          long id = cd.getLong("id");
	  		          String users = cd.getString("user_id");
	  		          String username = cd.getString("user_name");
	  		          String formid = cd.getString("form_id");
	  		          String formname = cd.getString("form_name");
	  		          String unitheadstatus = cd.getString("unit_head_status");
	  		          String citostatus = cd.getString("cito_status");
	  		          Timestamp submittime = cd.getTimestamp("submit_time");
	  		          
	  		          listView.setId(id);
	  		          listView.setUserid(users);
	  		          listView.setUsername(username);
	  		          listView.setFormid(formid);
	  		          listView.setFormname(formname);
	  		          listView.setUnitheadstatus(unitheadstatus);
	  		          listView.setCitostatus(citostatus);
	  		          listView.setSubmittime(submittime);
	  		          
	  		          String branchcode = cd.getString("branch_code");
	  	              listView.setBranchcode(branchcode);
	  		
	  		          createDomain.add(listView);
	  		      }
	  	        }
	  	      dashboard.addAll(createDomain);

  	//      For Group Mail Form
  	  	        
  	  	        ResultSet gm = stmt.executeQuery("SELECT * FROM form_group_email far "
  	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
  	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
  	  	                + "WHERE far.implemented_by_dept_id = " + deptid + " "
  	  	                + "AND far.implemented_by_status = 'Rejected' ");
  	  	      
  	  	        if (gm != null) {
  	  		      while (gm.next()) {
  	  		      	ListView listView = new ListView();
  	  		
  	  		          long id = gm.getLong("id");
  	  		          String users = gm.getString("user_id");
  	  		          String username = gm.getString("user_name");
  	  		          String formid = gm.getString("form_id");
  	  		          String formname = gm.getString("form_name");
  	  		          String unitheadstatus = gm.getString("unit_head_status");
  	  		          String citostatus = gm.getString("cito_status");
  	  		          Timestamp submittime = gm.getTimestamp("submit_time");
  	  		          
  	  		          listView.setId(id);
  	  		          listView.setUserid(users);
  	  		          listView.setUsername(username);
  	  		          listView.setFormid(formid);
  	  		          listView.setFormname(formname);
  	  		          listView.setUnitheadstatus(unitheadstatus);
  	  		          listView.setCitostatus(citostatus);
  	  		          listView.setSubmittime(submittime);
  	  		          
  	  		          String branchcode = gm.getString("branch_code");
  	  	              listView.setBranchcode(branchcode);
  	  		
  	  		          groupMail.add(listView);
  	  		      }
  	  	        }
  	  	      dashboard.addAll(groupMail);
	  	            

  	//      For CBS User Permission
  	        
  	        ResultSet cbs = stmt.executeQuery("SELECT * FROM form_cbs_user_permission far "
  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
  	                + "WHERE far.implemented_by_dept_id = " + deptid + " "
  	                + "AND far.implemented_by_status = 'Rejected' ");
  	      
  	      if (cbs != null) {
	  	      while (cbs.next()) {
	  	      	ListView listView = new ListView();
	  	
	  	          long id = cbs.getLong("id");
	  	          String users = cbs.getString("user_id");
	  	          String username = cbs.getString("user_name");
	  	          String formid = cbs.getString("form_id");
	  	          String formname = cbs.getString("form_name");
	  	          String unitheadstatus = cbs.getString("unit_head_status");
	  	          Timestamp submittime = cbs.getTimestamp("submit_time");
	  	          
	  	          listView.setId(id);
	  	          listView.setUserid(users);
	  	          listView.setUsername(username);
	  	          listView.setFormid(formid);
	  	          listView.setFormname(formname);
	  	          listView.setUnitheadstatus(unitheadstatus);
	  	          listView.setSubmittime(submittime);
	  	          
	  	          String branchcode = cbs.getString("branch_code");
	                listView.setBranchcode(branchcode);
	  	
	  	          cbsUserPermission.add(listView);
	  	      }
  	      }
  	      dashboard.addAll(cbsUserPermission);
  	      

  	//      For Database Access Form
  	  	        
  	  	        ResultSet da = stmt.executeQuery("SELECT * FROM form_database_access far "
  	  	                + "JOIN stp_forms sf ON far.form_id = sf.form_id "
  	  	                + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
  	  	                + "WHERE far.implemented_by_dept_id = " + deptid + " "
  	  	                + "AND far.implemented_by_status = 'Rejected' ");
  	  	      
  	  	        if (da != null) {
  	  		      while (da.next()) {
  	  		      	ListView listView = new ListView();
  	  		
  	  		          long id = da.getLong("id");
  	  		          String users = da.getString("user_id");
  	  		          String username = da.getString("user_name");
  	  		          String formid = da.getString("form_id");
  	  		          String formname = da.getString("form_name");
  	  		          String unitheadstatus = da.getString("unit_head_status");
  	  		          String citostatus = da.getString("cito_status");
  	  		          Timestamp submittime = da.getTimestamp("submit_time");
  	  		          
  	  		          listView.setId(id);
  	  		          listView.setUserid(users);
  	  		          listView.setUsername(username);
  	  		          listView.setFormid(formid);
  	  		          listView.setFormname(formname);
  	  		          listView.setUnitheadstatus(unitheadstatus);
  	  		          listView.setCitostatus(citostatus);
  	  		          listView.setSubmittime(submittime);
  	  		          
  	  		          String branchcode = da.getString("branch_code");
  	  	              listView.setBranchcode(branchcode);
  	  		
  	  		          databaseAccess.add(listView);
  	  		      }
  	  	        }
  	  	      dashboard.addAll(databaseAccess);
  	            
  	      
	        } catch (Exception e) {
	            e.printStackTrace(); 
	        }
		}
		
		con.close();
		return dashboard;
	}
	
	@GetMapping("allforms/{id}")
    public List<ListView> allForms(@PathVariable("id") Integer deptid){

		Connection con = null;
		List<ListView> accessRights = new ArrayList<>();
		List<ListView> accessControls = new ArrayList<>();
		List<ListView> changeRequest = new ArrayList<>();
		List<ListView> cbsUserPermission = new ArrayList<>();
		List<ListView> createMail = new ArrayList<>();
		List<ListView> createDomain = new ArrayList<>();
		List<ListView> groupMail = new ArrayList<>();
		List<ListView> incidentReport = new ArrayList<>();
		List<ListView> databaseAccess = new ArrayList<>();
		List<ListView> dashboard = new ArrayList<>();
 
        try {
            con = PostGRESQLConnUtils.getPostGreSQLConnection();
            con.setAutoCommit(false);
            Statement stmt = con.createStatement();
            
//            ISRM Unit
            
            if (deptid == 7) {
            	            	
//              For Access Rights Form
                
                ResultSet ar = stmt.executeQuery("SELECT * FROM form_access_right far "
                        + "JOIN stp_forms sf ON far.form_id = sf.form_id "
                        + "JOIN sys_app_user sau ON far.user_id = sau.user_id ");
               
                if (ar != null) {
	                while (ar.next()) {
	                	 ListView listView = new ListView();
	
	                    long id = ar.getLong("id");
	                    String users = ar.getString("user_id");
	                    String username = ar.getString("user_name");
	                    String formid = ar.getString("form_id");
	                    String formname = ar.getString("form_name");
	                    Timestamp submittime = ar.getTimestamp("submit_time");
	                    
	
	                    listView.setId(id);
	                    listView.setUserid(users);
	                    listView.setUsername(username);
	                    listView.setFormid(formid);
	                    listView.setFormname(formname);
	                    listView.setSubmittime(submittime);
	
	                    accessRights.add(listView);
	                }
                }
                dashboard.addAll(accessRights);
                
//              For Change Request Form
                
                ResultSet cr = stmt.executeQuery("SELECT * FROM form_change_request far "
                        + "JOIN stp_forms sf ON far.form_id = sf.form_id "
                        + "JOIN sys_app_user sau ON far.user_id = sau.user_id ");
              
                if (cr != null) {
	              while (cr.next()) {
	              	ListView listView = new ListView();
	
	                  long id = cr.getLong("id");
	                  String users = cr.getString("user_id");
	                  String username = cr.getString("user_name");
	                  String formid = cr.getString("form_id");
	                  String formname = cr.getString("form_name");
	                  Timestamp submittime = cr.getTimestamp("submit_time");
	                  
	                  listView.setId(id);
	                  listView.setUserid(users);
	                  listView.setUsername(username);
	                  listView.setFormid(formid);
	                  listView.setFormname(formname);
	                  listView.setSubmittime(submittime);
	
	                  changeRequest.add(listView);
	              }
                }
              dashboard.addAll(changeRequest);
              
//            For Incident Report Form
              
              ResultSet ir = stmt.executeQuery("SELECT * FROM form_incident_report far "
                      + "JOIN stp_forms sf ON far.form_id = sf.form_id "
                      + "JOIN sys_app_user sau ON far.user_id = sau.user_id ");
            
              if (ir != null) {
	              while (ir.next()) {
	              	ListView listView = new ListView();
	
	                  long id = ir.getLong("id");
	                  String users = ir.getString("user_id");
	                  String username = ir.getString("user_name");
	                  String formid = ir.getString("form_id");
	                  String formname = ir.getString("form_name");
	                  Timestamp submittime = ir.getTimestamp("submit_time");
	                  
	                  listView.setId(id);
	                  listView.setUserid(users);
	                  listView.setUsername(username);
	                  listView.setFormid(formid);
	                  listView.setFormname(formname);
	                  listView.setSubmittime(submittime);
	
	                  incidentReport.add(listView);
	              }
              }
            dashboard.addAll(incidentReport);
           
//              For Database Access form
              
              ResultSet da = stmt.executeQuery("SELECT * FROM form_database_access far "
                      + "JOIN stp_forms sf ON far.form_id = sf.form_id "
                      + "JOIN sys_app_user sau ON far.user_id = sau.user_id ");
              
              if (da != null) {
	              while (da.next()) {
	              	ListView listView = new ListView();
	
	                  long id = da.getLong("id");
	                  String users = da.getString("user_id");
	                  String username = da.getString("user_name");
	                  String formid = da.getString("form_id");
	                  String formname = da.getString("form_name");
	                  Timestamp submittime = da.getTimestamp("submit_time");
	
	                  listView.setId(id);
	                  listView.setUserid(users);
	                  listView.setUsername(username);
	                  listView.setFormid(formid);
	                  listView.setFormname(formname);
	                  listView.setSubmittime(submittime);
	
	                  databaseAccess.add(listView);
	              }
              }
              dashboard.addAll(databaseAccess);
              
            }

//          CBS Unit

            else if (deptid == 2) {
            	
//              For CBS User Permission
              
              ResultSet cbs = stmt.executeQuery("SELECT * FROM form_cbs_user_permission far "
                      + "JOIN stp_forms sf ON far.form_id = sf.form_id "
                      + "JOIN sys_app_user sau ON far.user_id = sau.user_id ");
              
              if (cbs != null) {
	              while (cbs.next()) {
	              	ListView listView = new ListView();
	
	                  long id = cbs.getLong("id");
	                  String users = cbs.getString("user_id");
	                  String username = cbs.getString("user_name");
	                  String formid = cbs.getString("form_id");
	                  String formname = cbs.getString("form_name");
	                  Timestamp submittime = cbs.getTimestamp("submit_time");
	
	                  listView.setId(id);
	                  listView.setUserid(users);
	                  listView.setUsername(username);
	                  listView.setFormid(formid);
	                  listView.setFormname(formname);
	                  listView.setSubmittime(submittime);
	
	                  cbsUserPermission.add(listView);
	              }
              }
              dashboard.addAll(cbsUserPermission);

            }
            
//          Network Unit
            
            else if (deptid == 14) {
//            For Access Controls Form
            
            ResultSet ac = stmt.executeQuery("SELECT * FROM form_access_control far "
                    + "JOIN stp_forms sf ON far.form_id = sf.form_id "
                    + "JOIN sys_app_user sau ON far.user_id = sau.user_id ");
            
            if (ac != null) {
	            while (ac.next()) {
	            	ListView listView = new ListView();
	
	                long id = ac.getLong("id");
	                String users = ac.getString("user_id");
	                String username = ac.getString("user_name");
	                String formid = ac.getString("form_id");
	                String formname = ac.getString("form_name");
	                Timestamp submittime = ac.getTimestamp("submit_time");
	
	                listView.setId(id);
	                listView.setUserid(users);
	                listView.setUsername(username);
	                listView.setFormid(formid);
	                listView.setFormname(formname);
	                listView.setSubmittime(submittime);
	
	                accessControls.add(listView);
	            }
            }
            dashboard.addAll(accessControls);

            }
            
//          System Admin Unit

            else if (deptid == 11) {
	            	
	//              For Create Mail form
	              
	              ResultSet cm = stmt.executeQuery("SELECT * FROM form_create_email far "
	                      + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	                      + "JOIN sys_app_user sau ON far.user_id = sau.user_id ");
	              
	              if (cm != null) {
		              while (cm.next()) {
		              	ListView listView = new ListView();
		
		                  long id = cm.getLong("id");
		                  String users = cm.getString("user_id");
		                  String username = cm.getString("user_name");
		                  String formid = cm.getString("form_id");
		                  String formname = cm.getString("form_name");
		                  Timestamp submittime = cm.getTimestamp("submit_time");
		
		                  listView.setId(id);
		                  listView.setUserid(users);
		                  listView.setUsername(username);
		                  listView.setFormid(formid);
		                  listView.setFormname(formname);
		                  listView.setSubmittime(submittime);
		
		                  createMail.add(listView);
		              }
	              }
	              dashboard.addAll(createMail);
	              

//              For Group Mail form
      	              
      	              ResultSet gm = stmt.executeQuery("SELECT * FROM form_group_email far "
      	                      + "JOIN stp_forms sf ON far.form_id = sf.form_id "
      	                      + "JOIN sys_app_user sau ON far.user_id = sau.user_id ");
      	              
      	              if (gm != null) {
      		              while (gm.next()) {
      		              	ListView listView = new ListView();
      		
      		                  long id = gm.getLong("id");
      		                  String users = gm.getString("user_id");
      		                  String username = gm.getString("user_name");
      		                  String formid = gm.getString("form_id");
      		                  String formname = gm.getString("form_name");
      		                  Timestamp submittime = gm.getTimestamp("submit_time");
      		
      		                  listView.setId(id);
      		                  listView.setUserid(users);
      		                  listView.setUsername(username);
      		                  listView.setFormid(formid);
      		                  listView.setFormname(formname);
      		                  listView.setSubmittime(submittime);
      		
      		                  groupMail.add(listView);
      		              }
      	              }
      	              dashboard.addAll(groupMail);
	

//            For Create Domain form
    	              
    	              ResultSet cd = stmt.executeQuery("SELECT * FROM form_create_domain far "
    	                      + "JOIN stp_forms sf ON far.form_id = sf.form_id "
    	                      + "JOIN sys_app_user sau ON far.user_id = sau.user_id ");
    	              
    	              if (cd != null) {
    		              while (cd.next()) {
    		              	ListView listView = new ListView();
    		
    		                  long id = cd.getLong("id");
    		                  String users = cd.getString("user_id");
    		                  String username = cd.getString("user_name");
    		                  String formid = cd.getString("form_id");
    		                  String formname = cd.getString("form_name");
    		                  Timestamp submittime = cd.getTimestamp("submit_time");
    		
    		                  listView.setId(id);
    		                  listView.setUserid(users);
    		                  listView.setUsername(username);
    		                  listView.setFormid(formid);
    		                  listView.setFormname(formname);
    		                  listView.setSubmittime(submittime);
    		
    		                  createDomain.add(listView);
    		              }
    	              }
    	              dashboard.addAll(createDomain);
	            	
	            }
          
            con.close();
            
            
        } catch (Exception e) {
            e.printStackTrace(); 
        }
		
        return dashboard;
	}
}
