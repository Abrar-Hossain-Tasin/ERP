package com.fsiberp.frms.model;

import jakarta.persistence.*;

@Entity
public class CBSUserProfile {
	
	@Id
	private int ID;
	
	@Column(name = "PFID")
	private String pfid;
	
	@Column(name = "EMPLOYEE_ID")
	private String profileid;
	
	@Column(name = "EMPLOYEE_NM")
	private String employeenm;
	
	@Column(name = "CONTACT_NO")
	private String contactno;
	
	@Column(name = "PROFILE_ID")
	private String uniquserid;
	
	@Column(name = "USER_NM")
	private String usernm;
	
	@Column(name = "USER_DESIG")
	private String userdesig;
	
	@Column(name = "BRANCH_ID")
	private String branchid;
	
	@Column(name = "BRANCH_NM")
	private String branchnm;
	
	@Column(name = "EMAIL_ADDERSS")
	private String email;
	
	public CBSUserProfile() {
		  
	  }

	public CBSUserProfile(int iD, String pfid, String profileid, String employeenm, String contactno, String uniquserid,
			String usernm, String userdesig, String branchid, String branchnm, String email) {
		super();
		ID = iD;
		this.pfid = pfid;
		this.profileid = profileid;
		this.employeenm = employeenm;
		this.contactno = contactno;
		this.uniquserid = uniquserid;
		this.usernm = usernm;
		this.userdesig = userdesig;
		this.branchid = branchid;
		this.branchnm = branchnm;
		this.email = email;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getPfid() {
		return pfid;
	}

	public void setPfid(String pfid) {
		this.pfid = pfid;
	}

	public String getProfileid() {
		return profileid;
	}

	public void setProfileid(String profileid) {
		this.profileid = profileid;
	}

	public String getEmployeenm() {
		return employeenm;
	}

	public void setEmployeenm(String employeenm) {
		this.employeenm = employeenm;
	}

	public String getContactno() {
		return contactno;
	}

	public void setContactno(String contactno) {
		this.contactno = contactno;
	}

	public String getUniquserid() {
		return uniquserid;
	}

	public void setUniquserid(String uniquserid) {
		this.uniquserid = uniquserid;
	}

	public String getUsernm() {
		return usernm;
	}

	public void setUsernm(String usernm) {
		this.usernm = usernm;
	}

	public String getUserdesig() {
		return userdesig;
	}

	public void setUserdesig(String userdesig) {
		this.userdesig = userdesig;
	}

	public String getBranchid() {
		return branchid;
	}

	public void setBranchid(String branchid) {
		this.branchid = branchid;
	}

	public String getBranchnm() {
		return branchnm;
	}

	public void setBranchnm(String branchnm) {
		this.branchnm = branchnm;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	
}

