package com.fsiberp.frms.controller;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fsiberp.bms.model.UnitHead;
import com.fsiberp.bms.repository.UnitHeadRepository;
import com.fsiberp.frms.model.AccessControlUser;
import com.fsiberp.frms.model.CBSUserProfile;
import com.fsiberp.frms.model.CreateDomain;
import com.fsiberp.frms.model.CreateEmail;
import com.fsiberp.frms.model.DivisionName;
import com.fsiberp.frms.model.FunctionalRole;
import com.fsiberp.frms.model.IctDepartment;
import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.AccessControlUserRepository;
import com.fsiberp.frms.repository.AuthRepository;
import com.fsiberp.frms.repository.CreateDomainRepository;
import com.fsiberp.frms.repository.CreateEmailRepository;
import com.fsiberp.frms.repository.DivisionNameRepository;
import com.fsiberp.frms.repository.FunctionalRoleRepository;
import com.fsiberp.frms.repository.IctDepartmentRepository;
import com.fsiberp.frms.security.jwt.JwtUtil;
import com.fsiberp.frms.services.EmailService;
import com.fsiberp.frms.services.ProfileService;
import com.fsiberp.onms.model.OfficeNote;
import com.fsiberp.onms.repository.OfficeNoteRepository;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;


@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/")
public class AuthController {
	
	  @Autowired
	  AuthenticationManager authenticationManager;

	  @Autowired
	  AuthRepository authRepository;
	  

	  @Autowired
	  PasswordEncoder encoder;
	  private JwtUtil jwtUtil = new JwtUtil();
	  private ProfileService profileService;
	  private IctDepartmentRepository ictDepartmentRepository;
	  private FunctionalRoleRepository functionalRoleRepository;
	  private final RestTemplate restTemplate;
	  private DivisionNameRepository divisionNameRepository;
	  private UnitHeadRepository unitHeadRepository;
	  private CreateDomainRepository createDomainRepository;
	  private CreateEmailRepository createEmailRepository;
	  private OfficeNoteRepository officeNoteRepository;
	  private AccessControlUserRepository accessControlUserRepository;
	  private EmailService emailService;
	    
	  public AuthController(ProfileService profileService, IctDepartmentRepository ictDepartmentRepository, UnitHeadRepository unitHeadRepository,
			  FunctionalRoleRepository functionalRoleRepository, RestTemplate restTemplate, DivisionNameRepository divisionNameRepository,
			  CreateDomainRepository createDomainRepository, OfficeNoteRepository officeNoteRepository, EmailService emailService,
			  CreateEmailRepository createEmailRepository, AccessControlUserRepository accessControlUserRepository) {
	        this.profileService = profileService;
	        this.ictDepartmentRepository = ictDepartmentRepository;
	        this.functionalRoleRepository = functionalRoleRepository;
	        this.restTemplate = restTemplate;
	        this.divisionNameRepository = divisionNameRepository;
	        this.unitHeadRepository = unitHeadRepository;
	        this.createDomainRepository = createDomainRepository;
	        this.createEmailRepository =  createEmailRepository;
	        this.officeNoteRepository = officeNoteRepository;
	        this.accessControlUserRepository = accessControlUserRepository;
	        this.emailService = emailService;
	   }
	  
	  @PutMapping("change-default-password")
	  public ResponseEntity<?> changePassword(@RequestBody User user, HttpServletRequest request) {
	      User existingUser = authRepository.findByUserid(user.getUserid()).orElse(null);
	      if (existingUser != null) {
	          if (encoder.matches(user.getPassword(), existingUser.getPassword())) {
	              return ResponseEntity.status(HttpStatus.BAD_REQUEST)
	                      .body(Map.of("msg", "The new password cannot be the same as the current password"));
	          }

	          existingUser.setLastpasschngdate(new Timestamp(System.currentTimeMillis())); // Update the last password change date
	          existingUser.setPassword(encoder.encode(user.getPassword()));
	          existingUser.setChngpassword("Y"); // Set chngpassword to indicate password change

	          // Get the client's IP address
	          String clientIp = request.getRemoteAddr();
	          existingUser.setMachineIp(clientIp); // Set the client IP address in the machine_ip column

	          authRepository.save(existingUser);
	          return ResponseEntity.status(HttpStatus.OK)
	                  .body(Map.of("msg", "Password changed successfully"));
	      } else {
	          return ResponseEntity.status(HttpStatus.NOT_FOUND)
	                  .body(Map.of("msg", "User not found"));
	      }
	  }

	  @PutMapping("change-password")
	  public ResponseEntity<?> changePassword(@RequestBody Map<String, String> requestBody, HttpServletRequest request) {
	      String userId = requestBody.get("userid");
	      String oldPassword = requestBody.get("oldPassword");
	      String newPassword = requestBody.get("password");


	      User existingUser = authRepository.findByUserid(userId).orElse(null);

	      if (existingUser != null) {
	       
	          if (!encoder.matches(oldPassword, existingUser.getPassword())) {
	              return new ResponseEntity<>(createErrorResponse("Old password is incorrect"), HttpStatus.BAD_REQUEST);
	          }

	    
	          if (encoder.matches(newPassword, existingUser.getPassword())) {
	              return new ResponseEntity<>(createErrorResponse("The new password cannot be the same as the current password"), HttpStatus.BAD_REQUEST);
	          }

	
	          existingUser.setLastpasschngdate(new Timestamp(System.currentTimeMillis())); 
	          existingUser.setPassword(encoder.encode(newPassword)); 
	          existingUser.setChngpassword("Y"); 

	          String clientIp = request.getRemoteAddr();
	          existingUser.setMachineIp(clientIp);

	          authRepository.save(existingUser);

	          return new ResponseEntity<>(createErrorResponse("Password changed successfully"), HttpStatus.OK);
	      } else {
	          return new ResponseEntity<>(createErrorResponse("User not found"), HttpStatus.NOT_FOUND);
	      }
	  }

	  private Map<String, String> createErrorResponse(String message) {
	      Map<String, String> response = new HashMap<>();
	      response.put("msg", message);
	      return response;
	  }

	  @PostMapping("signin")
		
	  public ResponseEntity<String> authenticateUser(@Valid @RequestBody User user) throws JSONException {
		  
	    Authentication authentication = authenticationManager
	        .authenticate(new UsernamePasswordAuthenticationToken(user.getUserid(), user.getPassword()));
	    SecurityContextHolder.getContext().setAuthentication(authentication);
	    
	   
	    FunctionalRole citoRole = functionalRoleRepository.findByFunctionalroleAndStatus("cito" , "Active")
                .orElseThrow(NoSuchElementException::new);
	    
	    User userinfo = profileService.getUserByUserid(user.getUserid());
	    
	    String url = "http://localhost:8083/api/cbs/" + user.getUserid();
	    
	    JSONObject resp = new JSONObject();
	    
	    resp.put("userid", user.getUserid());
	    
	    if (userinfo.getBranchcode().equals("0100")) {
	    	DivisionName divisionName = divisionNameRepository.findByDivisionname(userinfo.getDepartment());
	        IctDepartment ictDepartment = ictDepartmentRepository.findByDeptname(userinfo.getUnit());
	       
	        if (ictDepartment != null) {
	            resp.put("log_status", userinfo.getChngpassword());
	            resp.put("user_roleid", userinfo.getRoleid());
	            resp.put("unit", ictDepartment.getId()); 
	            resp.put("department", divisionName.getId());
	            resp.put("cito", citoRole.getUserid()); 
	        } else if (divisionName != null) {
	            // If ictDepartment is null, fall back to the else condition
	            resp.put("log_status", userinfo.getChngpassword());
	            resp.put("user_roleid", userinfo.getRoleid());
	            resp.put("department", divisionName.getId());
	            resp.put("cito", citoRole.getUserid()); 
	        } else {
	        	resp.put("log_status", userinfo.getChngpassword());
	            resp.put("user_roleid", userinfo.getRoleid());
	            resp.put("cito", citoRole.getUserid()); 
	        }
	    } else {
	        resp.put("log_status", userinfo.getChngpassword());
	        resp.put("user_roleid", userinfo.getRoleid());
	        resp.put("cito", citoRole.getUserid()); 
	    }
	    
	    ResponseEntity<List<CBSUserProfile>> response = restTemplate.exchange(
		        url, HttpMethod.GET, null, new ParameterizedTypeReference<List<CBSUserProfile>>() {});

		    if (response.getBody() == null || response.getBody().isEmpty()) {
		    	resp.put("cbsuser" , "new");
		    }
		    else {
		          resp.put("cbsuser", "old");
		      }
		    
		    List<String> unitfuncDesig = Arrays.asList("FD001", "FD003", "FD011", "FD022",
		    		"FD002", "FD016", "FD009");
		    List<UnitHead> unit = unitHeadRepository.findByEmpcodeAndFuncdescode(userinfo.getEmpid(), unitfuncDesig);
		    List<String> funcDesig = Arrays.asList("dmd", "amd", "fadUser");
		    List<FunctionalRole> role = functionalRoleRepository.findByUseridAndFunctionalroleAndStatus(userinfo.getUserid(), funcDesig, "Active");

			    if (unit.size() == 0 && role.size() == 0) {
			    	resp.put("bms", "User");
				  }
			    else {
			    	resp.put("bms", "Admin");
			    }
			    
			    // Check the form_create_domain 
			    List<CreateDomain> domains = createDomainRepository.findByActionAndImplementedbystatusAndUserid("Create", "Done", userinfo.getUserid());
			    if (domains.isEmpty()) {
			        resp.put("domainuser", "0");
			    } else {
			        resp.put("domainuser", "1");
			    }
			    
			    // Check the form_create_email 
			    List<CreateEmail> emails = createEmailRepository.findByActionAndImplementedbystatusAndUserid("Create", "Done", userinfo.getUserid());
			    if (emails.isEmpty()) {
			        resp.put("emailuser", "0");
			    } else {
			        resp.put("emailuser", "1");
			    }
			    
			   List<String> divDesig = Arrays.asList("FD001", "FD003");
			   List<UnitHead> divhead = unitHeadRepository.findByEmpcodeAndFuncdescode(userinfo.getEmpid(), divDesig); 
			   
			    if (divhead.size() != 0) {
			    	resp.put("divhead", "1");
			    }
			    else {
			    	resp.put("divhead", "0");
			    }
			    
			    List<String> unitfunc = Arrays.asList("FD001", "FD003", "FD011", "FD022");
			    List<UnitHead> unitacc = unitHeadRepository.findByEmpcodeAndFuncdescode(userinfo.getEmpid(), unitfunc);

			    List<String> func = Arrays.asList("dmd", "amd", "md");		    
			    List<FunctionalRole> onmsrole = functionalRoleRepository.findByUseridAndFunctionalrole(userinfo.getUserid(), func);

			    if (onmsrole.size() != 0) {
			    	resp.put("official", 1);
			    }
			    else 
			    {
			    	resp.put("official", 0);
			    }
			    String noteuser = userinfo.getUserid(); 
			    List<OfficeNote> officeNote = officeNoteRepository.findByOtherApprovalUserIdNative(noteuser);

			    if (unitacc.size() == 0 && onmsrole.size() == 0 && officeNote.size() == 0) {
			    	resp.put("onms", 0);
				  }
			    else {
			    	resp.put("onms", 1);
			    }
			    
			    AccessControlUser accessControlUser = accessControlUserRepository.findByUserid(user.getUserid());
			    if (accessControlUser != null) {
			        resp.put("AccessControlUser", 1);
			    } else {
			        resp.put("AccessControlUser", 0);
			    }
			    
			    String jwt = jwtUtil.generateToken(resp);
			    JSONObject jwttoken = new JSONObject();
			    jwttoken.put("token", jwt);

	    return new ResponseEntity<String>(jwttoken.toString(), HttpStatus.OK);
	 
	  }

  @PutMapping("forget-password")
	  public ResponseEntity<Map<String, Object>> forgetPassword(
	          @RequestBody Map<String, Object> requestBody, HttpServletRequest request) {

	      Map<String, Object> response = new LinkedHashMap<>();
	      
	      String userid = (String) requestBody.get("userid");
	      String email = (String) requestBody.get("email");
	      User user = profileService.getUserByUserid(userid);
	      
	      if (user == null) {
	          response.put("message", "User not found");
	          return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
	      }

	      if (user.getEmail().equals(email.trim())) {
	          // Update user details
	          user.setPassword(encoder.encode("123456"));
	          user.setChngpassword("N");
	          String clientIp = request.getRemoteAddr();
	          user.setMachineIp(clientIp);
	          user.setLastpasschngdate(new Timestamp(System.currentTimeMillis()));

	          response.put("message", "Default Password sent");

	          // Email content
	          
	          emailService.sendForgetPassEmail(user.getUserid());
	          
	          authRepository.save(user);
	      } else if (user.getEmail().equals("Not Available") || user.getEmail().equals(null)) {
	          response.put("message", "Email is not available");
	      } else {
	          response.put("message", "Wrong Email address");
	      }

	      return new ResponseEntity<>(response, HttpStatus.OK);
	  }
}

