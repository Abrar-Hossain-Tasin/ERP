package com.fsiberp.frms.services;

import java.sql.Timestamp;

import com.fsiberp.frms.model.AccessControl;
import com.fsiberp.frms.model.StatusUpdateRequest;


public interface AccessControlService {
	AccessControl createForm(AccessControl accessControl);
	AccessControl updateStatus(Long id, String userid, StatusUpdateRequest request, Timestamp currentTimestamp);
	AccessControl saveForm(AccessControl form);
}
