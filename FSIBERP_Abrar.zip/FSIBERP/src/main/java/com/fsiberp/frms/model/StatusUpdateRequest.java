package com.fsiberp.frms.model;

import java.util.List;
import java.util.Map;

public class StatusUpdateRequest {
    private String status;
    private String userid;
    private String comment;
    private String comment2;
    private String comment3;
    
    
    private List<Map<String, Object>> formUpdates; // For batch updates

    // Getters and setters
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public List<Map<String, Object>> getFormUpdates() {
        return formUpdates;
    }

    public void setFormUpdates(List<Map<String, Object>> formUpdates) {
        this.formUpdates = formUpdates;
    }

	public String getComment2() {
		return comment2;
	}

	public void setComment2(String comment2) {
		this.comment2 = comment2;
	}

	public String getComment3() {
		return comment3;
	}

	public void setComment3(String comment3) {
		this.comment3 = comment3;
	}
	
    
}