package com.fsiberp.frms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.fsiberp.frms.model.GroupEmail;

@Repository
public interface GroupEmailRepository extends JpaRepository<GroupEmail, Long> {
	
	Optional<GroupEmail> findById(Long id);
	List<GroupEmail> findByUserid(String userid);
	GroupEmail findAllByUseridAndFormidAndId(String userid, String formid, Long id);
	List<GroupEmail> findByImplementedbydeptid(Integer implementedbydeptid);
	List<GroupEmail> findByActionAndImplementedbystatusAndUserid(String action, String implementedbystatus, String userid);

	List<GroupEmail> findByImplementedbystatus(String implementedbystatus);
	List<GroupEmail> findByImplementedbystatusAndDepartment(String implementedbystatus, String department);
	List<GroupEmail> findByImplementedbystatusAndBranchCode(String implementedbystatus, String branchCode);
}
