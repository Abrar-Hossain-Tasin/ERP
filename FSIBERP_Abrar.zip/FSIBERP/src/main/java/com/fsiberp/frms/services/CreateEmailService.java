package com.fsiberp.frms.services;

import java.sql.Timestamp;

import com.fsiberp.frms.model.CreateEmail;
import com.fsiberp.frms.model.StatusUpdateRequest;

public interface CreateEmailService {
	
	CreateEmail createForm(CreateEmail createEmail);
	CreateEmail saveForm(CreateEmail form);
	CreateEmail updateStatus(Long id, String userid, StatusUpdateRequest request, Timestamp currentTimestamp);

}
