package com.fsiberp.frms.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table( name = "stp_branch_info" )
public class BranchInfo {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "branch_code")
	private String branchcode;
	
	@Column(name = "branch_name")
	private String branchname;
	
	@Column(name = "zone_name")
	private String zonename;
	
	@Column(name = "zonal_code")
	private String zonalcode;

	public BranchInfo() {
		  
	  }
	
	public BranchInfo(String branchcode, String branchname, String zonename, String zonalcode) {
		super();
		this.branchcode = branchcode;
		this.branchname = branchname;
		this.zonename = zonename;
		this.zonalcode = zonalcode;
	}

	public String getBranchcode() {
		return branchcode;
	}

	public void setBranchcode(String branchcode) {
		this.branchcode = branchcode;
	}

	public String getBranchname() {
		return branchname;
	}

	public void setBranchname(String branchname) {
		this.branchname = branchname;
	}

	public String getZonename() {
		return zonename;
	}

	public void setZonename(String zonename) {
		this.zonename = zonename;
	}

	public String getZonalcode() {
		return zonalcode;
	}

	public void setZonalcode(String zonalcode) {
		this.zonalcode = zonalcode;
	}

}
