package com.fsiberp.frms.controller;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.fsiberp.frms.services.CBSUserPermissionService;
import com.fsiberp.frms.model.StatusUpdateRequest;
import com.fsiberp.frms.services.AccessControlService;
import com.fsiberp.frms.services.CreateDomainService;
import com.fsiberp.frms.services.CreateEmailService;
import com.fsiberp.frms.services.DatabaseAccessService;
import com.fsiberp.frms.services.GroupEmailService;
import com.fsiberp.frms.services.IncidentReportService;

@RestController
@RequestMapping("/api/approval/")
@CrossOrigin(origins = "*", maxAge = 3600)
public class ApprovalController {

	private final AccessControlService accessControlService;
	private final CBSUserPermissionService cbsUserPermissionService;
	private final IncidentReportService incidentReportService;
	private final CreateEmailService createEmailService;
	private final CreateDomainService createDomainService;
	private final GroupEmailService groupEmailService;
	private final DatabaseAccessService databaseAccessService;
	
	public ApprovalController(AccessControlService accessControlService, CBSUserPermissionService cbsUserPermissionService,
			IncidentReportService incidentReportService, CreateEmailService createEmailService,
			CreateDomainService createDomainService, GroupEmailService groupEmailService, DatabaseAccessService databaseAccessService) {
		this.accessControlService = accessControlService;
		this.cbsUserPermissionService = cbsUserPermissionService;
		this.incidentReportService = incidentReportService;
		this.createEmailService = createEmailService;
		this.createDomainService = createDomainService;
		this.groupEmailService = groupEmailService;
		this.databaseAccessService = databaseAccessService;

	}

	@PutMapping("{userid}/{formId}/{id}")
	public ResponseEntity<?> updateStatus(@PathVariable("userid") String userid, @PathVariable("formId") String formId,
			@PathVariable("id") Long id, @RequestBody StatusUpdateRequest request) {

		Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());

		if (request.getFormUpdates() != null && !request.getFormUpdates().isEmpty()) {
			
			Map<String, Object> results = new HashMap<>();
			
			// Batch update case
			for (Map<String, Object> formUpdate : request.getFormUpdates()) {
				
				Long batchId = Long.valueOf(formUpdate.get("id").toString());
				String batchFormId = formUpdate.get("formId").toString();

				switch (batchFormId) {
				case "1002": // AccessControl
					results.put("AccessControl", accessControlService.updateStatus(batchId, userid, request, currentTimestamp));
			        break;
				case "1004": // CreateEmail
			        results.put("CreateEmail", createEmailService.updateStatus(batchId, userid, request, currentTimestamp));
			        break;
			    case "1005": // GroupEmail
			        results.put("GroupEmail", groupEmailService.updateStatus(batchId, userid, request, currentTimestamp));
			        break;
			    case "1006": // IncidentReport
			        results.put("IncidentReport", incidentReportService.updateStatus(batchId, userid, request, currentTimestamp));
			        break;
			    case "1010": // CreateDomain
			        results.put("CreateDomain", createDomainService.updateStatus(batchId, userid, request, currentTimestamp));
			        break;
			    case "1015": // DatabaseAccess
			        results.put("DatabaseAccess", databaseAccessService.updateStatus(batchId, userid, request, currentTimestamp));
			        break;
			    case "2001": // CBSUserPermission
			        results.put("CBSUserPermission", cbsUserPermissionService.updateStatus(batchId, userid, request, currentTimestamp));
			        break;
				default:
					return new ResponseEntity<>("Invalid form ID: " + batchFormId, HttpStatus.BAD_REQUEST);
				}
			}
			return new ResponseEntity<>(results, HttpStatus.OK);
		} else {
			// Single update case
			switch (formId) {
			case "1002": // AccessControl
				return new ResponseEntity<>(accessControlService.updateStatus(id, userid, request, currentTimestamp),
						HttpStatus.OK);
			case "1004": // CreateEmail
				return new ResponseEntity<>(createEmailService.updateStatus(id, userid, request, currentTimestamp),
						HttpStatus.OK);
			case "1005": // GroupEmail
				return new ResponseEntity<>(groupEmailService.updateStatus(id, userid, request, currentTimestamp),
						HttpStatus.OK);
			case "1006": // IncidentReport
				return new ResponseEntity<>(incidentReportService.updateStatus(id, userid, request, currentTimestamp),
						HttpStatus.OK);
			case "1010": // CreateDomain
				return new ResponseEntity<>(createDomainService.updateStatus(id, userid, request, currentTimestamp),
						HttpStatus.OK);
			case "1015": // DatabaseAccess
				return new ResponseEntity<>(databaseAccessService.updateStatus(id, userid, request, currentTimestamp),
						HttpStatus.OK);
			case "2001": // CBSUserPermission
				return new ResponseEntity<>(
						cbsUserPermissionService.updateStatus(id, userid, request, currentTimestamp), HttpStatus.OK);
			default:
				return new ResponseEntity<>("Invalid form ID", HttpStatus.BAD_REQUEST);
			}
		}
	}
}
