package com.fsiberp.frms.services.impl;

import com.fsiberp.frms.model.CBSUserPermission;
import com.fsiberp.frms.model.IctDepartment;
import com.fsiberp.frms.model.Notification;
import com.fsiberp.frms.model.StatusUpdateRequest;
import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.AuthRepository;
import com.fsiberp.frms.repository.BranchInfoRepository;
import com.fsiberp.frms.repository.CBSUserPermissionRepository;
import com.fsiberp.frms.repository.IctDepartmentRepository;
import com.fsiberp.frms.repository.NotificationRepository;
import com.fsiberp.frms.repository.ProfileRepository;
import com.fsiberp.frms.services.CBSUserPermissionService;
import com.fsiberp.frms.services.EmailService;
import com.fsiberp.frms.services.NotificationService;
import com.fsiberp.frms.services.ProfileService;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import org.springframework.stereotype.Service;

@Service
public class CBSUserPermissionServiceImpl implements CBSUserPermissionService {

	private final BranchInfoRepository branchInfoRepository;
	private final CBSUserPermissionRepository cbsUserPermissionRepository;
	private final AuthRepository authRepository;
	private final ProfileRepository profileRepository;
	private final ProfileService profileService; // Add ProfileService
	private final NotificationService notificationService; 
	private final IctDepartmentRepository ictDepartmentRepository;
	private NotificationRepository notificationRepository;
	private EmailService emailService;

	public CBSUserPermissionServiceImpl(BranchInfoRepository branchInfoRepository,
			CBSUserPermissionRepository cbsUserPermissionRepository, AuthRepository authRepository,
			ProfileRepository profileRepository, IctDepartmentRepository ictDepartmentRepository,
			ProfileService profileService, NotificationRepository notificationRepository,
			NotificationService notificationService, EmailService emailService) { // Inject NotificationService
		this.branchInfoRepository = branchInfoRepository;
		this.cbsUserPermissionRepository = cbsUserPermissionRepository;
		this.authRepository = authRepository;
		this.profileRepository = profileRepository;
		this.profileService = profileService;
		this.notificationService = notificationService;
		this.ictDepartmentRepository = ictDepartmentRepository;
		this.notificationRepository = notificationRepository;
		this.emailService = emailService;
	}

	@Override
	public String getBranchCode(String branchName) {
		return branchInfoRepository.findBranchCodeByBranchName(branchName);
	}

	@Override
	public List<User> getDivisionalHeads(String userid) {

	    User user = profileRepository.findByUserid(userid).orElseThrow(() -> new RuntimeException("User not found"));

	    String branchCode = user.getBranchcode();

	    List<Long> divisionIds = Arrays.asList(2L, 3L, 12L, 14L); 


	    if ("0100".equals(branchCode)) {
	        return profileRepository.findDivisionalHeadsForBranchCode0100(divisionIds);
	    } else {
	        return profileRepository.findDivisionalHeadsForOtherBranchCodes(userid, divisionIds);
	    }
	}


	@Override
	public CBSUserPermission save(CBSUserPermission userPermission) {
	
		CBSUserPermission savedUserPermission = cbsUserPermissionRepository.save(userPermission);

	
		if (userPermission.getUnitheaduserid() != null) {
			User user = profileRepository.findByUserid(userPermission.getUserid())
					.orElseThrow(() -> new RuntimeException("User not found"));

			String username = user.getUsername() != null ? user.getUsername() : "Unknown User";

			notificationService.createNotification(userPermission.getUnitheaduserid(),
					"A new CBS User Permission form has been submitted by " + username + " ("
							+ userPermission.getUserid() + ")",
					userPermission.getUserid(), userPermission.getFormid(), savedUserPermission.getId(), // Pass the
																											// saved
																											// entity ID
					false // Assuming false means the notification hasn't been viewed yet
			);

//          unit head email
			 emailService.sendNotificationEmail(user,userPermission.getUnitheaduserid(),1);
		}

		return savedUserPermission;
	}

	@Override
	public CBSUserPermission update(Long id, CBSUserPermission userPermission) {
		// Fetch the existing permission
		Optional<CBSUserPermission> existingUserPermissionOpt = cbsUserPermissionRepository.findById(id);

		if (existingUserPermissionOpt.isPresent()) {
			CBSUserPermission existingUserPermission = existingUserPermissionOpt.get();

			// Update fields
			existingUserPermission.setNewBranchName(userPermission.getNewBranchName());
			existingUserPermission.setNewBranchCode(userPermission.getNewBranchCode());
			existingUserPermission.setPreviousBranchName(userPermission.getPreviousBranchName());
			existingUserPermission.setPreviousBranchCode(userPermission.getPreviousBranchCode());
			existingUserPermission.setTransferDate(userPermission.getTransferDate());
			existingUserPermission.setTransactionType(userPermission.getTransactionType());
			existingUserPermission.setTransactionLimit(userPermission.getTransactionLimit());
			existingUserPermission.setAuthorizationType(userPermission.getAuthorizationType());
			existingUserPermission.setAuthorizationLimit(userPermission.getAuthorizationLimit());
			existingUserPermission.setCashTellerLimit(userPermission.getCashTellerLimit());
			existingUserPermission.setTellerType(userPermission.getTellerType());
			existingUserPermission.setGeneralBankingManagement(userPermission.getGeneralBankingManagement());
			existingUserPermission.setInvestmentManagement(userPermission.getInvestmentManagement());
			existingUserPermission.setTradeFinanceManagement(userPermission.getTradeFinanceManagement());
			existingUserPermission.setReports(userPermission.getReports());
			existingUserPermission.setFsibCloudAdminPanel(userPermission.getFsibCloudAdminPanel());
			existingUserPermission.setBranchDayClose(userPermission.getBranchDayClose());
			existingUserPermission.setAgentBankingModule(userPermission.getAgentBankingModule());
			existingUserPermission.setSubmitdate(userPermission.getSubmitdate());
			existingUserPermission.setSubmittime(userPermission.getSubmittime());
	
			existingUserPermission.setUnitheadstatus("Pending");
			
			for (String bcd : userPermission.getGeneralBankingManagement()) {
	            if (bcd != null) {
	            	existingUserPermission.setBcduserid("2");
	            	existingUserPermission.setBcdstatus("Pending");
	                break;  // Stop after the first non-null value
	            }
	            else {
	            	existingUserPermission.setBcduserid(null);
	            	existingUserPermission.setBcdstatus(null);
	            }
	        }
			
	        for (String iad : userPermission.getInvestmentManagement()) {
        	if (iad != null) {
        		existingUserPermission.setIaduserid("3");
        		existingUserPermission.setIadstatus("Pending");
        		
        		existingUserPermission.setImrduserid("12");
        		existingUserPermission.setImrdstatus("Pending");
            	break;
        	}
        }
        
        for (String finid : userPermission.getTradeFinanceManagement()) {
        	if (finid != null) {
        		existingUserPermission.setIduserid("19");
        		existingUserPermission.setIdstatus("Pending");
            	break;
        	}
        }
        
        
        if (!userPermission.getUnitheaduserid().equals(existingUserPermission.getUnitheaduserid())) {
	          String newUnitHeadUserId = userPermission.getUnitheaduserid();
	          User newUnitHeadUser = profileService.getUserByUserid(newUnitHeadUserId);
	          String newUnitHeadUsername = newUnitHeadUser != null ? newUnitHeadUser.getUsername() : "Unknown User";

	  
	          List<Notification> existingNotifications = notificationRepository.findByUseridAndFormidAndSubmissionId(
	        		  existingUserPermission.getUnitheaduserid(),
	        		  existingUserPermission.getFormid(),
	        		  existingUserPermission.getId()
	          );

	   
	          User user = profileService.getUserByUserid(existingUserPermission.getUserid());
	          String username = user != null ? user.getUsername() : "Unknown User";
	          for (Notification notification : existingNotifications) {
	              notification.setUserid(newUnitHeadUserId);
	              notification.setViewed(false);
	              notification.setMessage(
	                  "A new CBS User Permission form has been submitted by " + username + " (" + existingUserPermission.getUserid() + ")."
	              );
	              notificationRepository.save(notification);
	          }
//	          unit head email
	          emailService.sendNotificationEmail(user,userPermission.getUnitheaduserid(),1);
		            
	          existingUserPermission.setUnitheaduserid(newUnitHeadUserId);
	          existingUserPermission.setUnitheadusername(newUnitHeadUsername);
	         
	          
	      }
			existingUserPermission.setSubmitdate(new Date(System.currentTimeMillis()));
			existingUserPermission.setSubmittime(new Timestamp(System.currentTimeMillis()));

		
			return cbsUserPermissionRepository.save(existingUserPermission);
		}

		return null;
	}
	
	@Override
	public CBSUserPermission updateStatus(Long id, String userid, StatusUpdateRequest request, Timestamp currentTimestamp) {
	    CBSUserPermission userPermission = cbsUserPermissionRepository.findById(id)
	            .orElseThrow(() -> new NoSuchElementException("User permission not found for id: " + id));
	    
	    User user = profileService.getUserByUserid(userid);
	    String currentStatus = userPermission.getUnitheadstatus();
	    
	    if (isPendingOrRejected(currentStatus)) {
	        handlePendingOrRejectedStatus(userPermission, request, currentTimestamp, user);
	    } else if ("Accepted".equalsIgnoreCase(currentStatus)) {
	        handleAcceptedStatus(userPermission, request, currentTimestamp, user);
	    } else {
	        throw new IllegalArgumentException("Invalid status update for implementation");
	    }

	    return cbsUserPermissionRepository.save(userPermission);
	}

	private boolean isPendingOrRejected(String status) {
	    return "Pending".equals(status) || "Rejected".equals(status) || status == null;
	}

	private void handlePendingOrRejectedStatus(CBSUserPermission userPermission, StatusUpdateRequest request, 
	                                            Timestamp currentTimestamp, User user) {
	    userPermission.setUnitheadstatus(request.getStatus());
	    userPermission.setUnitheadcmnt(request.getComment());
	    userPermission.setUnitheadsubdate(currentTimestamp);

	    createUnitHeadNotification(userPermission, request);

	    if ("Accepted".equalsIgnoreCase(request.getStatus())) {
	        if (areAllUserIdsNull(userPermission)) {
	            notifyCBSUnitMembers(userPermission);
	            sendDepartmentEmailNotification(userPermission);
	        }
	        sendNotificationsToSpecificUsers(userPermission);
	    }
	}

	private boolean areAllUserIdsNull(CBSUserPermission userPermission) {
	    return userPermission.getBcduserid() == null &&
	           userPermission.getIaduserid() == null &&
	           userPermission.getImrduserid() == null &&
	           userPermission.getIduserid() == null;
	}

	private void createUnitHeadNotification(CBSUserPermission userPermission, StatusUpdateRequest request) {
	    notificationService.createNotification(userPermission.getUserid(),
	            "Your CBS User Permission form has been " + request.getStatus().toLowerCase() + " by Unit Head "
	                    + userPermission.getUnitheadusername() + ".",
	            userPermission.getUserid(), userPermission.getFormid(), userPermission.getId(), false);
	}

	private void notifyCBSUnitMembers(CBSUserPermission userPermission) {
	    List<User> cbsUsers = profileService.getAllUnitUsers("Core Banking Solution Unit (CBS)");
	    User formSubmitter = profileService.getUserByUserid(userPermission.getUserid());
	    String deptName = formSubmitter != null ? formSubmitter.getDepartment() : "Unknown Branch";
	    
	    for (User cbsUser : cbsUsers) {
	        String submitterName = formSubmitter != null ? formSubmitter.getUsername() : "Unknown User";
	        String branchCode = formSubmitter != null ? formSubmitter.getBranchcode() : "Unknown Code";

	        notificationService.createNotification(cbsUser.getUserid(),
	                "A new CBS User Permission request from " + submitterName + " (" + formSubmitter.getUserid() + "), " 
	                        + deptName + " (" + branchCode + ") requires your approval.",
	                userPermission.getUserid(), userPermission.getFormid(), userPermission.getId(), false);
	    }
	}

	private void sendDepartmentEmailNotification(CBSUserPermission userPermission) {
	    User formSubmitter = profileService.getUserByUserid(userPermission.getUserid());
	    User userinfo = authRepository.findByUserid(formSubmitter.getUserid()).orElse(null);
	    IctDepartment existingUser = ictDepartmentRepository.findById(userPermission.getImplementedbydeptid()).orElse(null);
	    
	    if (userinfo != null && existingUser != null) {
	        emailService.sendNotificationEmailForDept(userinfo, existingUser.getDeptmail(), 1);
	    }
	}

	private void sendNotificationsToSpecificUsers(CBSUserPermission userPermission) {
	    sendNotificationToProfiles(userPermission.getBcduserid(), userPermission);
	    sendNotificationToProfiles(userPermission.getIaduserid(), userPermission);
	    sendNotificationToProfiles(userPermission.getImrduserid(), userPermission);
	    sendNotificationToProfiles(userPermission.getIduserid(), userPermission);
	}

	private void handleAcceptedStatus(CBSUserPermission userPermission, StatusUpdateRequest request, 
	                                   Timestamp currentTimestamp, User user) {
	    String department = user.getDepartment();
	    
	    if ("Accepted".equalsIgnoreCase(request.getStatus())) {
	        updateUserPermissionStatus(userPermission, request, currentTimestamp, department, user);
	    }

	    if (areAllStatusesAccepted(userPermission)) {
	        notifyCBSUnitMembers(userPermission);
	        sendDepartmentEmailNotification(userPermission);
	    }

	    if ("Done".equalsIgnoreCase(request.getStatus())) {
	        finalizeUserPermission(userPermission, currentTimestamp, user);
	    }
	}

	private void updateUserPermissionStatus(CBSUserPermission userPermission, StatusUpdateRequest request, 
	                                         Timestamp currentTimestamp, String department, User user) {
	    if ("B C D, Head Office, Dhaka".equals(department)) {
	        updateBcdStatus(userPermission, request, currentTimestamp, user);
	    } else if ("I A D, Head Office, Dhaka".equals(department)) {
	        updateIadStatus(userPermission, request, currentTimestamp, user);
	    } else if ("I M R D, Head Office, Dhaka".equals(department)) {
	        updateImrdStatus(userPermission, request, currentTimestamp, user);
	    } else if ("I D, Head Office, Dhaka".equals(department)) {
	        updateIdStatus(userPermission, request, currentTimestamp, user);
	    }
	}

	private void updateBcdStatus(CBSUserPermission userPermission, StatusUpdateRequest request, 
	                              Timestamp currentTimestamp, User user) {
	    userPermission.setBcdstatus(request.getStatus());
	    userPermission.setBcdcmnt(request.getComment());
	    userPermission.setBcdsubdate(currentTimestamp);
	    userPermission.setBcduserid(user.getUserid());
	    userPermission.setBcdusername(user.getUsername());

	    markNotificationsAsViewed(profileRepository.findBcdUsersForDivision(), userPermission);
	    createNotificationForStatusUpdate(userPermission, request, "BCD");
	}

	private void updateIadStatus(CBSUserPermission userPermission, StatusUpdateRequest request, 
	                              Timestamp currentTimestamp, User user) {
	    userPermission.setIadstatus(request.getStatus());
	    userPermission.setIadcmnt(request.getComment());
	    userPermission.setIadsubdate(currentTimestamp);
	    userPermission.setIaduserid(user.getUserid());
	    userPermission.setIadusername(user.getUsername());

	    markNotificationsAsViewed(profileRepository.findIadUsersForDivision(), userPermission);
	    createNotificationForStatusUpdate(userPermission, request, "IAD");
	}

	private void updateImrdStatus(CBSUserPermission userPermission, StatusUpdateRequest request, 
	                               Timestamp currentTimestamp, User user) {
	    userPermission.setImrdstatus(request.getStatus());
	    userPermission.setImrdcmnt(request.getComment());
	    userPermission.setImrdsubdate(currentTimestamp);
	    userPermission.setImrduserid(user.getUserid());
	    userPermission.setImrdusername(user.getUsername());

	    markNotificationsAsViewed(profileRepository.findImrdUsersForDivision(), userPermission);
	    createNotificationForStatusUpdate(userPermission, request, "IMRD");
	}

	private void updateIdStatus(CBSUserPermission userPermission, StatusUpdateRequest request, 
	                             Timestamp currentTimestamp, User user) {
	    userPermission.setIdstatus(request.getStatus());
	    userPermission.setIdcmnt(request.getComment());
	    userPermission.setIdsubdate(currentTimestamp);
	    userPermission.setIduserid(user.getUserid());
	    userPermission.setIdusername(user.getUsername());

	    markNotificationsAsViewed(profileRepository.findIdUsersForDivision(), userPermission);
	    createNotificationForStatusUpdate(userPermission, request, "ID");
	}

	private void markNotificationsAsViewed(List<User> users, CBSUserPermission userPermission) {
	    for (User user : users) {
	        notificationService.markNotificationsAsViewedForUserAndForm(user.getUserid(), userPermission.getFormid());
	    }
	}

	private void createNotificationForStatusUpdate(CBSUserPermission userPermission, StatusUpdateRequest request, String department) {
	    String username = "";
	    String userid = "";
	    
	    switch (department) {
	        case "BCD":
	            username = userPermission.getBcdusername();
	            userid = userPermission.getBcduserid();
	            break;
	        case "IAD":
	            username = userPermission.getIadusername();
	            userid = userPermission.getIaduserid();
	            break;
	        case "IMRD":
	            username = userPermission.getImrdusername();
	            userid = userPermission.getImrduserid();
	            break;
	        case "ID":
	            username = userPermission.getIdusername();
	            userid = userPermission.getIduserid();
	            break;
	        default:
	            throw new IllegalArgumentException("Invalid department: " + department);
	    }

	    notificationService.createNotification(userPermission.getUserid(),
	            "Your CBS User Permission form has been " + request.getStatus().toLowerCase() + " by "
	                    + username + " (" + userid + ") from the " + department + " Department.",
	            userPermission.getUserid(), userPermission.getFormid(), userPermission.getId(), false);
	}


	private boolean areAllStatusesAccepted(CBSUserPermission userPermission) {
	    return ("Accepted".equalsIgnoreCase(userPermission.getBcdstatus()) || userPermission.getBcdstatus() == null) &&
	           ("Accepted".equalsIgnoreCase(userPermission.getIadstatus()) || userPermission.getIadstatus() == null) &&
	           ("Accepted".equalsIgnoreCase(userPermission.getImrdstatus()) || userPermission.getImrdstatus() == null) &&
	           ("Accepted".equalsIgnoreCase(userPermission.getIdstatus()) || userPermission.getIdstatus() == null);
	}

	private void finalizeUserPermission(CBSUserPermission userPermission, Timestamp currentTimestamp, User user) {
	    userPermission.setImplementedbystatus("Done");
	    userPermission.setImplementedbysubdate(currentTimestamp);
	    userPermission.setImplementedbyuserid(user.getUserid());
	    userPermission.setImplementedbyusername(user.getUsername());

	    markNotificationsAsViewed(profileService.getAllUnitUsers("Core Banking Solution Unit (CBS)"), userPermission);
	    
	    notificationService.createNotification(userPermission.getUserid(),
	            "Your CBS User Permission request form has been fully granted by "
	                    + userPermission.getImplementedbyusername() + " (" + userPermission.getImplementedbyuserid() + ").",
	            userPermission.getUserid(), userPermission.getFormid(), userPermission.getId(), false);
	    
	    sendUserEmailNotification(userPermission);
	}

	private void sendUserEmailNotification(CBSUserPermission userPermission) {
	    User userinfo = authRepository.findByUserid(userPermission.getUserid()).orElse(null);
	    if (userinfo != null) {
	        emailService.sendNotificationEmailForUser(userinfo, userinfo.getUserid(), 1);
	    }
	}

	private void sendNotificationToProfiles(String divisionId, CBSUserPermission userPermission) {
	    List<User> profiles = profileRepository.findProfilesByDivisionIdAndActiveStatus(divisionId);
	    User subUser = profileService.getUserByUserid(userPermission.getUserid());

	    for (User user : profiles) {
	        notificationService.createNotification(user.getUserid(),
	                "A CBS User Permission request requires your approval.",
	                userPermission.getUserid(), userPermission.getFormid(), userPermission.getId(), false);
	        emailService.sendNotificationEmail(subUser, user.getUserid(), 1);
	    }
	}
}