package com.fsiberp.frms.security;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class DatabaseBackupScheduler {

    private static final String PORT = "5432";
    private static final String DB_NAME = "fsiberp_test";
    private static final String USERNAME = "postgres";
    private static final String PASSWORD = "postgres";
    private static final String BACKUP_DIR = "D:/Abrar/Project/Database_Backup";
    private static final String PG_DUMP_PATH = "D:/Database/bin/pg_dump.exe";

    @Scheduled(cron = "0 7 11 * * ?")
    public void backupDatabase() {
        String timestamp = new java.text.SimpleDateFormat("yyyyMMdd_HHmmss").format(new java.util.Date());
        String backupFile = BACKUP_DIR + "/" + DB_NAME + "_" + timestamp + ".sql";

        String command = String.format(
            "\"%s\" -h localhost -p %s -U %s -F c -b -v -f \"%s\" %s",
            PG_DUMP_PATH, PORT, USERNAME, backupFile, DB_NAME
        );

        ProcessBuilder processBuilder = new ProcessBuilder(command.split(" "));
        processBuilder.environment().put("PGPASSWORD", PASSWORD);

        try {
            Process process = processBuilder.start();

            // Use an executor service to handle the output and error streams
            ExecutorService executorService = Executors.newFixedThreadPool(2);

            // Handle standard output
            executorService.submit(() -> {
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(process.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        System.out.println("STDOUT: " + line);
                    }
                } catch (IOException e) {
                    System.err.println("Error reading STDOUT: " + e.getMessage());
                }
            });

            // Handle error output
            executorService.submit(() -> {
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(process.getErrorStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        System.err.println("STDERR: " + line);
                    }
                } catch (IOException e) {
                    System.err.println("Error reading STDERR: " + e.getMessage());
                }
            });

            // Wait for the process to complete
            if (!process.waitFor(180000, TimeUnit.MILLISECONDS)) {  // 3 minutes timeout
                process.destroy();  // Destroy process if it exceeds timeout
                System.err.println("Process timeout occurred.");
            } else if (process.exitValue() == 0) {
                System.out.println("Database backup completed successfully.");
            } else {
                System.err.println("Database backup failed. Exit code: " + process.exitValue());
            }

            executorService.shutdown();
        } catch (IOException e) {
            System.err.println("IOException occurred: " + e.getMessage());
            e.printStackTrace();
        } catch (InterruptedException e) {
            System.err.println("Process interrupted: " + e.getMessage());
            e.printStackTrace();
        }
    }
}




//package com.fsiberp.frms.security;
//
//import java.io.IOException;
//import java.util.concurrent.TimeUnit;
//
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.stereotype.Component;
//
//
//
//@Component
//public class DatabaseBackupScheduler {
//
//    private static final String PORT = "5432";
//    private static final String DB_NAME = "fsiberp_test";
//    private static final String USERNAME = "postgres";
//    private static final String PASSWORD = "postgres";
////    private static final String BACKUP_DIR = "E:/Office_Purpose/eclipse-workspace";
//    private static final String BACKUP_DIR = "D:/Abrar/Project/Database_Backup";
////    private static final String PG_DUMP_PATH = "E:/PostgreSQL/bin/pg_dump.exe";
//    private static final String PG_DUMP_PATH = "D:/Database/bin/pg_dump.exe";
//
//    @Scheduled(cron = "0 37 10 * * ?")
//    public void backupDatabase() {
//        String timestamp = new java.text.SimpleDateFormat("yyyyMMdd_HHmmss").format(new java.util.Date());
//        String backupFile = BACKUP_DIR + "/" + DB_NAME + "_" + timestamp + ".sql";
//
//        String command = String.format(
//        	    "\"%s\" -h localhost -p %s -U %s -F c -b -v -f \"%s\" %s",
//        	    PG_DUMP_PATH, PORT, USERNAME, backupFile, DB_NAME
//        	);
//
//
//
//        ProcessBuilder processBuilder = new ProcessBuilder(command.split(" "));
//        processBuilder.environment().put("PGPASSWORD", PASSWORD);
//        
//
//        try {
//            Process process = processBuilder.start();
//            if (!process.waitFor(180000, TimeUnit.MILLISECONDS)) {  // 60 seconds timeout
//                process.destroy();  // Destroy process if it exceeds timeout
//                System.err.println("Process timeout occurred.");
//            } else if (process.exitValue() == 0) {
//                System.out.println("Database backup completed successfully.");
//            } else {
//                System.err.println("Database backup failed. Exit code: " + process.exitValue());
//            }
//        } catch (IOException e) {
//            System.err.println("IOException occurred: " + e.getMessage());
//            e.printStackTrace();
//        } catch (InterruptedException e) {
//            System.err.println("Process interrupted: " + e.getMessage());
//            e.printStackTrace();
//        } finally {
//            processBuilder.environment().remove("PGPASSWORD");
//        }
//    }
//}








//package com.fsiberp.frms.security;
//
//import java.io.IOException;
//
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.stereotype.Component;
//
//@Component
//public class DatabaseBackupScheduler {
//
//    private static final String HOST = "10.20.46.26";
//    private static final String PORT = "5432";
//    private static final String DB_NAME = "fsiberp_test";
//    private static final String USERNAME = "postgres";
//    private static final String PASSWORD = "postgres";
//    private static final String BACKUP_DIR = "E:/Office_Purpose/eclipse-workspace";
//    private static final String PG_DUMP_PATH = "E:/PostgreSQL/bin/pg_dump.exe";
//
//    // @Scheduled(cron = "0 0 2 * * ?")
//    @Scheduled(cron = "0 57 1 * * ?")
//    public void backupDatabase() {
//        String timestamp = new java.text.SimpleDateFormat("yyyyMMdd_HHmmss").format(new java.util.Date());
//        String backupFile = BACKUP_DIR + "/" + DB_NAME + "_" + timestamp + ".sql";
//
//        // Command with the full path to pg_dump
//        String command = String.format(
//            "%s -h %s -p %s -U %s -F c -b -v -f %s %s",
//            PG_DUMP_PATH, HOST, PORT, USERNAME, backupFile, DB_NAME
//        );
//
//        ProcessBuilder processBuilder = new ProcessBuilder(command.split(" "));
//        processBuilder.environment().put("PGPASSWORD", PASSWORD);
//
//        try {
//            Process process = processBuilder.start();
//            int exitCode = process.waitFor();
//
//            if (exitCode == 0) {
//                System.out.println("Database backup completed successfully.");
//            } else {
//                System.err.println("Database backup failed. Exit code: " + exitCode);
//            }
//        } catch (IOException | InterruptedException e) {
//            e.printStackTrace();
//        } finally {
//            // Cleanup
//            processBuilder.environment().remove("PGPASSWORD");
//        }
//    }
//}
//
//
//
//
////import java.io.IOException;
////
////import org.springframework.scheduling.annotation.Scheduled;
////import org.springframework.stereotype.Component;
////
////@Component
////public class DatabaseBackupScheduler {
////
////    private static final String HOST = "10.20.46.26";
////    private static final String PORT = "5432";
////    private static final String DB_NAME = "fsiberp_test";
////    private static final String USERNAME = "postgres";
////    private static final String PASSWORD = "postgres";
////    private static final String BACKUP_DIR = "E:/Office_Purpose/eclipse-workspace";
////
////    @Scheduled(cron = "0 39 23 * * ?")
////    public void backupDatabase() {
////        String timestamp = new java.text.SimpleDateFormat("yyyyMMdd_HHmmss").format(new java.util.Date());
////        String backupFile = BACKUP_DIR + "/" + DB_NAME + "_" + timestamp + ".sql";
////
////        String command = String.format(
////            "pg_dump -h %s -p %s -U %s -F c -b -v -f %s %s",
////            HOST, PORT, USERNAME, backupFile, DB_NAME
////        );
////
////        ProcessBuilder processBuilder = new ProcessBuilder(command.split(" "));
////        processBuilder.environment().put("PGPASSWORD", PASSWORD);
////
////        try {
////            Process process = processBuilder.start();
////            int exitCode = process.waitFor();
////
////            if (exitCode == 0) {
////                System.out.println("Database backup completed successfully.");
////            } else {
////                System.err.println("Database backup failed. Exit code: " + exitCode);
////            }
////        } catch (IOException | InterruptedException e) {
////            e.printStackTrace();
////        } finally {
////            processBuilder.environment().remove("PGPASSWORD");
////        }
////    }
////}
