package com.fsiberp.frms.controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fsiberp.frms.model.AccessControl;
import com.fsiberp.frms.model.BranchInfo;
import com.fsiberp.frms.model.CBSUserPermission;
import com.fsiberp.frms.model.CreateDomain;
import com.fsiberp.frms.model.CreateEmail;
import com.fsiberp.frms.model.DatabaseAccess;
import com.fsiberp.frms.model.GroupEmail;
import com.fsiberp.frms.model.IncidentReport;
import com.fsiberp.frms.model.ListView;
import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.AccessControlRepository;
import com.fsiberp.frms.repository.AuthRepository;
import com.fsiberp.frms.repository.BranchInfoRepository;
import com.fsiberp.frms.repository.CBSUserPermissionRepository;
import com.fsiberp.frms.repository.CreateDomainRepository;
import com.fsiberp.frms.repository.CreateEmailRepository;
import com.fsiberp.frms.repository.DatabaseAccessRepository;
import com.fsiberp.frms.repository.GroupEmailRepository;
import com.fsiberp.frms.repository.IncidentReportRepository;
import com.fsiberp.frms.services.ProfileService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/user/")
public class UserDashBoardController {
	
	private AccessControlRepository accessControlRepository;
	private AuthRepository authRepository;
	private BranchInfoRepository branchInfoRepository;
	private ProfileService profileService;
	private CBSUserPermissionRepository cbsUserPermissionRepository;
	private CreateEmailRepository createEmailRepository;
	private IncidentReportRepository incidentReportRepository;
	private GroupEmailRepository groupEmailRepository;
	private CreateDomainRepository createDomainRepository;
	private DatabaseAccessRepository databaseAccessRepository;
	
	public UserDashBoardController(AuthRepository authRepository, AccessControlRepository accessControlRepository,CreateEmailRepository createEmailRepository,
			ProfileService profileService, BranchInfoRepository branchInfoRepository, 
			CBSUserPermissionRepository cbsUserPermissionRepository, IncidentReportRepository incidentReportRepository,
			GroupEmailRepository groupEmailRepository,CreateDomainRepository createDomainRepository, DatabaseAccessRepository databaseAccessRepository) {
		
	        this.accessControlRepository = accessControlRepository;
	        this.authRepository = authRepository;
	        this.profileService = profileService;
	        this.branchInfoRepository = branchInfoRepository;
	        this.cbsUserPermissionRepository = cbsUserPermissionRepository;
	        this.createEmailRepository = createEmailRepository;
	        this.incidentReportRepository = incidentReportRepository;
	        this.groupEmailRepository = groupEmailRepository;
	        this.createDomainRepository = createDomainRepository;
	        this.databaseAccessRepository = databaseAccessRepository;
	    }
	
	@GetMapping("emplist/{id}")
	public List<User>  emplist(@PathVariable(name = "id") String userid) {
		User user = profileService.getUserByUserid(userid);
		
		if (user.getBranchcode().equals("0100")) {
			if (user.getDepartment().equals("I C T Div., Head Office, Dhaka")) {
				
				List<String> unitfuncDesig = null;
				
				if (user.getRoleid() == 3) {
					unitfuncDesig = Arrays.asList("FD002", "FD010");
				}
				else {
					unitfuncDesig = Arrays.asList("FD002", "FD001");
				}
				return authRepository.findAllByDepartmentAndFuncdescode(user.getDepartment(), unitfuncDesig);
			}
			else {
				return authRepository.findAllByDepartmentAndRoleid(user.getDepartment(), 2);
			}
		}
		else {
			if (user.getRoleid() == 3) {
				return authRepository.findAllByBranchcodeAndRoleidAndUseridNot(user.getBranchcode(), 2, userid);
			}
			else {
				BranchInfo branchInfo = branchInfoRepository.findByBranchcode(user.getBranchcode());
				
				List<String> branchcode = null;
				
				if (user.getUsergrp().equals("Manager")) {
					if (branchInfo.getZonalcode().equals("0100")) {
						branchcode = Arrays.asList("0506", "0507");
					}
					else {
						branchcode = Arrays.asList(branchInfo.getZonalcode());
					}
				}
				else {
					branchcode = Arrays.asList(user.getBranchcode());
				}
				return authRepository.findAllByBranchcodeAndRoleid(branchcode, 2);
			}
		}
	}
	
	@GetMapping("implist/{id}")
	public List<User>  implist(@PathVariable(name = "id") String userid) {
		
		String dept = "I C T Div., Head Office, Dhaka";
		List<String> unitfuncDesig = Arrays.asList("FD002", "FD010");
				
		return authRepository.findAllByDepartmentAndFuncdescode(dept, unitfuncDesig);
	}
	
	@GetMapping("viewform/{userid}/{formid}/{id}")
    public ResponseEntity<?> viewForms(@PathVariable("userid") String userid, @PathVariable("formid") String formid,
    		@PathVariable("id") Long id){
		
			if (formid.equals("1002")) {
			   AccessControl accessControl = accessControlRepository.findAllByUseridAndFormidAndId(userid, formid, id);
		        if (accessControl == null) {
		            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		        }

		        // Set download URLs if paths are not null
		        if (accessControl.getEmployeeIdCardPath() != null) {
		            String idCardDownloadUrl = "/api/accesscontrol/download/idCard/" + accessControl.getId();
		            accessControl.setEmployeeIdCardDownloadUrl(idCardDownloadUrl);
		        }
		        if (accessControl.getJoiningLetterPath() != null) {
		            String joiningLetterDownloadUrl = "/api/accesscontrol/download/joiningLetter/" + accessControl.getId();
		            accessControl.setJoiningLetterDownloadUrl(joiningLetterDownloadUrl);
		        }

		        return new ResponseEntity<>(accessControl, HttpStatus.OK);
			
		}
		else if (formid.equals("1004")) {
		    CreateEmail createEmail = createEmailRepository.findAllByUseridAndFormidAndId(userid, formid, id);
		    return new ResponseEntity<>(createEmail, HttpStatus.OK);
		}
		else if (formid.equals("1005")) {
		    GroupEmail groupEmail = groupEmailRepository.findAllByUseridAndFormidAndId(userid, formid, id);
		    return new ResponseEntity<>(groupEmail, HttpStatus.OK);
		}
		else if (formid.equals("1010")) {
			   
		    CreateDomain createDomain = createDomainRepository.findAllByUseridAndFormidAndId(userid, formid, id);
	        if (createDomain == null) {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        }

	        // Set download URLs if paths are not null
	        
	        if (createDomain.getJoiningLetterPath() != null) {
	            String joiningLetterDownloadUrl = "/api/domain/download/joiningLetter/" + createDomain.getId();
	            createDomain.setJoiningLetterDownloadUrl(joiningLetterDownloadUrl);
	        }

	        return new ResponseEntity<>(createDomain, HttpStatus.OK);
	
		}
		else if (formid.equals("2001")) {
			Pageable pageable = PageRequest.of(0, 1);
			List<CBSUserPermission> viewforms = new ArrayList<>();
			List<CBSUserPermission> prevforms = new ArrayList<>();
			
			CBSUserPermission newforms  = cbsUserPermissionRepository.findAllByUseridAndFormidAndId(userid, formid, id);
			viewforms.add(newforms);
			if (newforms != null) {
			 prevforms = cbsUserPermissionRepository.findRecordsBeforeId(userid, id, pageable);
			viewforms.addAll(prevforms);
			}
			if (viewforms.isEmpty()) {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No records found.");
	        } else {
	            return ResponseEntity.ok(viewforms);
	        }
		}
		
		else if (formid.equals("1006")) {
			System.out.println("userid " +userid + " formid " +formid+ " id " + id);
	        IncidentReport incidentReport = incidentReportRepository.findAllByUseridAndFormidAndId(userid, formid, id);

	        if (incidentReport == null) {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        }
	        
	        System.out.println("userid1 " +userid + " formid " +formid+ " id " + id);

	        // Set download URLs if paths are not null
	        if (incidentReport.getIncidentHandlingDocumentsPath() != null) {
	            String incidentHandlingDocumentsDownloadUrl = "/api/incidentreport/download/incidentHandlingDocuments/" + incidentReport.getId();
	            incidentReport.setIncidentHandlingDocumentsDownloadUrl(incidentHandlingDocumentsDownloadUrl);
	        }
	        if (incidentReport.getImpactAnalysisDocumentPath() != null) {
	            String impactAnalysisDocumentDownloadUrl = "/api/incidentreport/download/impactAnalysisDocument/" + incidentReport.getId();
	            incidentReport.setImpactAnalysisDocumentDownloadUrl(impactAnalysisDocumentDownloadUrl);
	        }
	        if (incidentReport.getDowntimeDocumentationPath() != null) {
	            String downtimeDocumentationDownloadUrl = "/api/incidentreport/download/downtimeDocumentation/" + incidentReport.getId();
	            incidentReport.setDowntimeDocumentationDownloadUrl(downtimeDocumentationDownloadUrl);
	        }
	        if (incidentReport.getRootCauseAnalysisDocumentsPath() != null) {
	            String rootCauseAnalysisDocumentsDownloadUrl = "/api/incidentreport/download/rootCauseAnalysisDocuments/" + incidentReport.getId();
	            incidentReport.setRootCauseAnalysisDocumentsDownloadUrl(rootCauseAnalysisDocumentsDownloadUrl);
	        }
	        if (incidentReport.getWorkCompletionDocumentPath() != null) {
	            String workCompletionDocumentDownloadUrl = "/api/incidentreport/download/workCompletionDocument/" + incidentReport.getId();
	            incidentReport.setWorkCompletionDocumentDownloadUrl(workCompletionDocumentDownloadUrl);
	        }

	        return new ResponseEntity<>(incidentReport, HttpStatus.OK);
	    }
		else if (formid.equals("1015")) {
		    DatabaseAccess databaseAccess = databaseAccessRepository.findAllByUseridAndFormidAndId(userid, formid, id);
		    return new ResponseEntity<>(databaseAccess, HttpStatus.OK);
		}
	else {
	    return new ResponseEntity<>("Invalid formid", HttpStatus.BAD_REQUEST);
	}
}

	@GetMapping("pending/{id}")
    public List<ListView> pendingForms(@PathVariable("id") String userid){

		Connection con = null;
		List<ListView> accessRights = new ArrayList<>();
		List<ListView> accessControls = new ArrayList<>();
		List<ListView> createMail = new ArrayList<>();
		List<ListView> incidentReport = new ArrayList<>();
		List<ListView> groupMail = new ArrayList<>();
		List<ListView> createDomain = new ArrayList<>();
		List<ListView> cbsUserPermission = new ArrayList<>();
		List<ListView> databaseAccess = new ArrayList<>();

        try {
            con = PostGRESQLConnUtils.getPostGreSQLConnection();
            con.setAutoCommit(false);
            Statement stmt = con.createStatement();

//            For Access Controls Form
            
            ResultSet ac = stmt.executeQuery("SELECT * FROM form_access_control far "
            		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
            		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
            		+ "WHERE far.user_id = '" + userid + "' "
            		+ "AND (far.unit_head_status = 'Pending' "
            		+ "OR far.network_head_status = 'Pending' "
            		+ "OR far.isrm_head_status = 'Pending' "
            		+ "OR far.cito_status = 'Pending' "
            		+ "OR far.network_implemented_by_status = 'Pending') "
            		+ "AND NOT (far.unit_head_status = 'Rejected' "
            		+ "OR far.network_head_status = 'Rejected' "
            		+ "OR far.isrm_head_status = 'Rejected' "
            		+ "OR far.cito_status = 'Rejected' "
            		+ "OR far.network_implemented_by_status = 'Rejected')");
            
            if (ac != null) {
	            while (ac.next()) {
	            	ListView listView = new ListView();
	
	                long id = ac.getLong("id");
	                String users = ac.getString("user_id");
	                String username = ac.getString("user_name");
	                String formid = ac.getString("form_id");
	                String formname = ac.getString("form_name");
	                String unitheadstatus = ac.getString("unit_head_status");
	                String citostatus = ac.getString("cito_status");
	                Timestamp submittime = ac.getTimestamp("submit_time");
	
	                listView.setId(id);
	                listView.setUserid(users);
	                listView.setUsername(username);
	                listView.setFormid(formid);
	                listView.setFormname(formname);
	                listView.setUnitheadstatus(unitheadstatus);
	                listView.setCitostatus(citostatus);
	                listView.setSubmittime(submittime);
	
	                accessControls.add(listView);
	            }
            }
            accessRights.addAll(accessControls);

//        For Creating Domain Form
          
          ResultSet cd = stmt.executeQuery("SELECT * FROM form_create_domain far "
          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
          		+ "WHERE far.user_id = '" + userid + "' "
          		+ "AND (far.unit_head_status = 'Pending' "
          		+ "OR far.sa_head_status = 'Pending' "
          		+ "OR far.isrm_head_status = 'Pending' "
          		+ "OR far.cito_status = 'Pending' "
          		+ "OR far.implemented_by_status = 'Pending') "
          		+ "AND NOT (far.unit_head_status = 'Rejected' "
          		+ "OR far.sa_head_status = 'Rejected' "
          		+ "OR far.isrm_head_status = 'Rejected' "
          		+ "OR far.cito_status = 'Rejected' "
          		+ "OR far.implemented_by_status = 'Rejected')");
        
          if (cd != null) {
	          while (cd.next()) {
	          	ListView listView = new ListView();
	
	              long id = cd.getLong("id");
	              String users = cd.getString("user_id");
	              String username = cd.getString("user_name");
	              String formid = cd.getString("form_id");
	              String formname = cd.getString("form_name");
	              String unitheadstatus = cd.getString("unit_head_status");
	              String citostatus = cd.getString("cito_status");
	              Timestamp submittime = cd.getTimestamp("submit_time");
	              
	              listView.setId(id);
	              listView.setUserid(users);
	              listView.setUsername(username);
	              listView.setFormid(formid);
	              listView.setFormname(formname);
	              listView.setUnitheadstatus(unitheadstatus);
	              listView.setCitostatus(citostatus);
	              listView.setSubmittime(submittime);
	
	              createDomain.add(listView);
	          }
          }
        accessRights.addAll(createDomain);

//        For Creating mail Form
          
          ResultSet cm = stmt.executeQuery("SELECT * FROM form_create_email far "
          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
          		+ "WHERE far.user_id = '" + userid + "' "
          		+ "AND (far.unit_head_status = 'Pending' "
          		+ "OR far.isrm_head_status = 'Pending' "
          		+ "OR far.cito_status = 'Pending' "
          		+ "OR far.impl_by_unithead_status = 'Pending' "
          		+ "OR far.implemented_by_status = 'Pending') "
          		+ "AND NOT (far.unit_head_status = 'Rejected' "
          		+ "OR far.isrm_head_status = 'Rejected' "
          		+ "OR far.cito_status = 'Rejected' "
          		+ "OR far.impl_by_unithead_status = 'Rejected' "
          		+ "OR far.implemented_by_status = 'Rejected')");
        
          if (cm != null) {
	          while (cm.next()) {
	          	ListView listView = new ListView();
	
	              long id = cm.getLong("id");
	              String users = cm.getString("user_id");
	              String username = cm.getString("user_name");
	              String formid = cm.getString("form_id");
	              String formname = cm.getString("form_name");
	              String unitheadstatus = cm.getString("unit_head_status");
	              String citostatus = cm.getString("cito_status");
	              Timestamp submittime = cm.getTimestamp("submit_time");
	              
	              listView.setId(id);
	              listView.setUserid(users);
	              listView.setUsername(username);
	              listView.setFormid(formid);
	              listView.setFormname(formname);
	              listView.setUnitheadstatus(unitheadstatus);
	              listView.setCitostatus(citostatus);
	              listView.setSubmittime(submittime);
	
	              createMail.add(listView);
	          }
          }
        accessRights.addAll(createMail);
        
//      For Group mail Form
        
        ResultSet gm = stmt.executeQuery("SELECT * FROM form_group_email far "
        		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
        		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
        		+ "WHERE far.user_id = '" + userid + "' "
        		+ "AND (far.unit_head_status = 'Pending' "
        		+ "OR far.isrm_head_status = 'Pending' "
        		+ "OR far.cito_status = 'Pending' "
        		+ "OR far.impl_by_unithead_status = 'Pending' "
        		+ "OR far.implemented_by_status = 'Pending') "
        		+ "AND NOT (far.unit_head_status = 'Rejected' "
        		+ "OR far.isrm_head_status = 'Rejected' "
        		+ "OR far.cito_status = 'Rejected' "
        		+ "OR far.impl_by_unithead_status = 'Rejected' "
        		+ "OR far.implemented_by_status = 'Rejected')");
      
        if (gm != null) {
	          while (gm.next()) {
	          	ListView listView = new ListView();
	
	              long id = gm.getLong("id");
	              String users = gm.getString("user_id");
	              String username = gm.getString("user_name");
	              String formid = gm.getString("form_id");
	              String formname = gm.getString("form_name");
	              String unitheadstatus = gm.getString("unit_head_status");
	              String citostatus = gm.getString("cito_status");
	              Timestamp submittime = gm.getTimestamp("submit_time");
	              
	              listView.setId(id);
	              listView.setUserid(users);
	              listView.setUsername(username);
	              listView.setFormid(formid);
	              listView.setFormname(formname);
	              listView.setUnitheadstatus(unitheadstatus);
	              listView.setCitostatus(citostatus);
	              listView.setSubmittime(submittime);
	
	              groupMail.add(listView);
	          }
        }
      accessRights.addAll(groupMail);
        

//      For Incident Report Form
        
        ResultSet ir = stmt.executeQuery("SELECT * FROM form_incident_report far "
        		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
        		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
        		+ "WHERE far.user_id = '" + userid + "' "
        		+ "AND (far.unit_head_status = 'Pending' "
        		+ "OR far.isrm_head_status = 'Pending' "
        		+ "OR far.cito_status = 'Pending') "
        		+ "AND NOT (far.unit_head_status = 'Rejected' "
        		+ "OR far.isrm_head_status = 'Rejected' "
        		+ "OR far.cito_status = 'Rejected')");
      
        if (ir != null) {
	          while (ir.next()) {
	          	ListView listView = new ListView();
	
	              long id = ir.getLong("id");
	              String users = ir.getString("user_id");
	              String username = ir.getString("user_name");
	              String formid = ir.getString("form_id");
	              String formname = ir.getString("form_name");
	              String unitheadstatus = ir.getString("unit_head_status");
	              String citostatus = ir.getString("cito_status");
	              Timestamp submittime = ir.getTimestamp("submit_time");
	              
	              listView.setId(id);
	              listView.setUserid(users);
	              listView.setUsername(username);
	              listView.setFormid(formid);
	              listView.setFormname(formname);
	              listView.setUnitheadstatus(unitheadstatus);
	              listView.setCitostatus(citostatus);
	              listView.setSubmittime(submittime);
	
	              incidentReport.add(listView);
	          }
        }
      accessRights.addAll(incidentReport);
          
//        For CBS User Permission
        
        ResultSet cbs = stmt.executeQuery("SELECT * FROM form_cbs_user_permission far "
        		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
        		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
        		+ "WHERE far.user_id = '" + userid + "' "
        		+ "AND NOT ((far.unit_head_status IS NOT NULL AND far.unit_head_status = 'Rejected') "
        		+ "OR (far.bcd_status IS NOT NULL AND far.bcd_status = 'Rejected') "
        		+ "OR (far.iad_status IS NOT NULL AND far.iad_status = 'Rejected') "
        		+ "OR (far.id_status IS NOT NULL AND far.id_status = 'Rejected') "
        		+ "OR (far.implemented_by_status IS NOT NULL AND far.implemented_by_status = 'Done') "
        		+ "OR (far.imrd_status IS NOT NULL AND far.imrd_status = 'Rejected')) "
        		+ "AND (far.unit_head_status = 'Pending' OR far.bcd_status = 'Pending' "
        		+ "OR far.iad_status = 'Pending' OR far.id_status = 'Pending' "
        		+ "OR far.implemented_by_status = 'Pending' OR far.imrd_status = 'Pending')");
        
        if (cbs != null) {
	        while (cbs.next()) {
	        	ListView listView = new ListView();
	
	            long id = cbs.getLong("id");
	            String users = cbs.getString("user_id");
	            String username = cbs.getString("user_name");
	            String formid = cbs.getString("form_id");
	            String formname = cbs.getString("form_name");
	            String unitheadstatus = cbs.getString("unit_head_status");
	            Timestamp submittime = cbs.getTimestamp("submit_time");
	
	            listView.setId(id);
	            listView.setUserid(users);
	            listView.setUsername(username);
	            listView.setFormid(formid);
	            listView.setFormname(formname);
	            listView.setUnitheadstatus(unitheadstatus);
	            listView.setSubmittime(submittime);
	
	            cbsUserPermission.add(listView);
	        }
        }
        accessRights.addAll(cbsUserPermission);
        
//      For Database Access Form
        
        ResultSet da = stmt.executeQuery("SELECT * FROM form_database_access far "
        		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
        		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
        		+ "WHERE far.user_id = '" + userid + "' "
        		+ "AND (far.unit_head_status = 'Pending' "
        		+ "OR far.isrm_head_status = 'Pending' "
        		+ "OR far.cito_status = 'Pending' "
        		+ "OR far.impl_by_unithead_status = 'Pending' "
        		+ "OR far.implemented_by_status = 'Pending') "
        		+ "AND NOT (far.unit_head_status = 'Rejected' "
        		+ "OR far.isrm_head_status = 'Rejected' "
        		+ "OR far.cito_status = 'Rejected' "
        		+ "OR far.impl_by_unithead_status = 'Rejected' "
        		+ "OR far.implemented_by_status = 'Rejected')");
      
        if (da != null) {
	          while (da.next()) {
	          	ListView listView = new ListView();
	
	              long id = da.getLong("id");
	              String users = da.getString("user_id");
	              String username = da.getString("user_name");
	              String formid = da.getString("form_id");
	              String formname = da.getString("form_name");
	              String unitheadstatus = da.getString("unit_head_status");
	              String citostatus = da.getString("cito_status");
	              Timestamp submittime = da.getTimestamp("submit_time");
	              
	              listView.setId(id);
	              listView.setUserid(users);
	              listView.setUsername(username);
	              listView.setFormid(formid);
	              listView.setFormname(formname);
	              listView.setUnitheadstatus(unitheadstatus);
	              listView.setCitostatus(citostatus);
	              listView.setSubmittime(submittime);
	
	              databaseAccess.add(listView);
	          }
        }
      accessRights.addAll(databaseAccess);

          
            con.close();
            
            
        } catch (Exception e) {
            e.printStackTrace(); 
        }
		
        return accessRights;
	}
	
	@GetMapping("accepted/{id}")
    public List<ListView> acceptedForms(@PathVariable("id") String userid){
		
			Connection con = null;
			List<ListView> accessRights = new ArrayList<>();
			List<ListView> accessControls = new ArrayList<>();
			List<ListView> createMail = new ArrayList<>();
			List<ListView> incidentReport = new ArrayList<>();
			List<ListView> groupMail = new ArrayList<>();
			List<ListView> createDomain = new ArrayList<>();
			List<ListView> cbsUserPermission = new ArrayList<>();
			List<ListView> databaseAccess = new ArrayList<>();

	        try {
	            con = PostGRESQLConnUtils.getPostGreSQLConnection();
	            con.setAutoCommit(false);
	            Statement stmt = con.createStatement();
	            
//	            For Access Controls Form
	            
	            ResultSet ac = stmt.executeQuery("SELECT * FROM form_access_control far "
	                    + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	                    + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	                    + "WHERE far.user_id = '" + userid + "' "
	                    + "AND far.network_implemented_by_status = 'Done'");
	            
	            if (ac != null) {
		            while (ac.next()) {
		            	ListView listView = new ListView();
	
		                long id = ac.getLong("id");
		                String users = ac.getString("user_id");
		                String username = ac.getString("user_name");
		                String formid = ac.getString("form_id");
		                String formname = ac.getString("form_name");
		                String unitheadstatus = ac.getString("unit_head_status");
		                String citostatus = ac.getString("cito_status");
		                Timestamp submittime = ac.getTimestamp("submit_time");
	
		                listView.setId(id);
		                listView.setUserid(users);
		                listView.setUsername(username);
		                listView.setFormid(formid);
		                listView.setFormname(formname);
		                listView.setUnitheadstatus(unitheadstatus);
		                listView.setCitostatus(citostatus);
		                listView.setSubmittime(submittime);
	
		                accessControls.add(listView);
		            }
	            }
	            accessRights.addAll(accessControls);

//	          For Creating Mail Form
	            
	            ResultSet cm = stmt.executeQuery("SELECT * FROM form_create_email far "
	                    + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	                    + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	                    + "WHERE far.user_id = '" + userid + "' "
	                    + "AND (far.implemented_by_status = 'Done')");
	          
	            if (cm != null) {
		          while (cm.next()) {
		          	ListView listView = new ListView();
	
		              long id = cm.getLong("id");
		              String users = cm.getString("user_id");
		              String username = cm.getString("user_name");
		              String formid = cm.getString("form_id");
		              String formname = cm.getString("form_name");
		              String unitheadstatus = cm.getString("unit_head_status");
		              String citostatus = cm.getString("cito_status");
		              Timestamp submittime = cm.getTimestamp("submit_time");
		              
		              listView.setId(id);
		              listView.setUserid(users);
		              listView.setUsername(username);
		              listView.setFormid(formid);
		              listView.setFormname(formname);
		              listView.setUnitheadstatus(unitheadstatus);
		              listView.setCitostatus(citostatus);
		              listView.setSubmittime(submittime);
	
		              createMail.add(listView);
		          }
	            }
	          accessRights.addAll(createMail);
	          

//	          For Create Domain Form
	            
	            ResultSet cd = stmt.executeQuery("SELECT * FROM form_create_domain far "
	                    + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	                    + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	                    + "WHERE far.user_id = '" + userid + "' "
	                    + "AND (far.implemented_by_status = 'Done')");
	          
	            if (cd != null) {
		          while (cd.next()) {
		          	ListView listView = new ListView();
	
		              long id = cd.getLong("id");
		              String users = cd.getString("user_id");
		              String username = cd.getString("user_name");
		              String formid = cd.getString("form_id");
		              String formname = cd.getString("form_name");
		              String unitheadstatus = cd.getString("unit_head_status");
		              String citostatus = cd.getString("cito_status");
		              Timestamp submittime = cd.getTimestamp("submit_time");
		              
		              listView.setId(id);
		              listView.setUserid(users);
		              listView.setUsername(username);
		              listView.setFormid(formid);
		              listView.setFormname(formname);
		              listView.setUnitheadstatus(unitheadstatus);
		              listView.setCitostatus(citostatus);
		              listView.setSubmittime(submittime);
	
		              createDomain.add(listView);
		          }
	            }
	          accessRights.addAll(createDomain);
	          

//	          For Group Mail Form
	            
	            ResultSet gm = stmt.executeQuery("SELECT * FROM form_group_email far "
	                    + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	                    + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	                    + "WHERE far.user_id = '" + userid + "' "
	                    + "AND (far.implemented_by_status = 'Done')");
	          
	            if (gm != null) {
		          while (gm.next()) {
		          	ListView listView = new ListView();
	
		              long id = gm.getLong("id");
		              String users = gm.getString("user_id");
		              String username = gm.getString("user_name");
		              String formid = gm.getString("form_id");
		              String formname = gm.getString("form_name");
		              String unitheadstatus = gm.getString("unit_head_status");
		              String citostatus = gm.getString("cito_status");
		              Timestamp submittime = gm.getTimestamp("submit_time");
		              
		              listView.setId(id);
		              listView.setUserid(users);
		              listView.setUsername(username);
		              listView.setFormid(formid);
		              listView.setFormname(formname);
		              listView.setUnitheadstatus(unitheadstatus);
		              listView.setCitostatus(citostatus);
		              listView.setSubmittime(submittime);
	
		              groupMail.add(listView);
		          }
	            }
	          accessRights.addAll(groupMail);

//	          For Incident Report Form
	            
	            ResultSet ir = stmt.executeQuery("SELECT * FROM form_incident_report far "
	                    + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	                    + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	                    + "WHERE far.user_id = '" + userid + "' "
	                    + "AND (far.cito_status = 'Accepted')");
	          
	            if (ir != null) {
		          while (ir.next()) {
		          	ListView listView = new ListView();
	
		              long id = ir.getLong("id");
		              String users = ir.getString("user_id");
		              String username = ir.getString("user_name");
		              String formid = ir.getString("form_id");
		              String formname = ir.getString("form_name");
		              String unitheadstatus = ir.getString("unit_head_status");
		              String citostatus = ir.getString("cito_status");
		              Timestamp submittime = ir.getTimestamp("submit_time");
		              
		              listView.setId(id);
		              listView.setUserid(users);
		              listView.setUsername(username);
		              listView.setFormid(formid);
		              listView.setFormname(formname);
		              listView.setUnitheadstatus(unitheadstatus);
		              listView.setCitostatus(citostatus);
		              listView.setSubmittime(submittime);
	
		              incidentReport.add(listView);
		          }
	            }
	          accessRights.addAll(incidentReport);
	          

//	            For CBS User Permission
	            
	            ResultSet cbs = stmt.executeQuery("SELECT * FROM form_cbs_user_permission far "
	                    + "JOIN stp_forms sf ON far.form_id = sf.form_id "
	                    + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
	                    + "WHERE far.user_id = '" + userid + "' "
	                    + "AND (far.implemented_by_status = 'Done')");
	            
	            if (cbs != null) {
		            while (cbs.next()) {
		            	ListView listView = new ListView();
	
		                long id = cbs.getLong("id");
		                String users = cbs.getString("user_id");
		                String username = cbs.getString("user_name");
		                String formid = cbs.getString("form_id");
		                String formname = cbs.getString("form_name");
		                String unitheadstatus = cbs.getString("unit_head_status");
		                Timestamp submittime = cbs.getTimestamp("submit_time");
	
		                listView.setId(id);
		                listView.setUserid(users);
		                listView.setUsername(username);
		                listView.setFormid(formid);
		                listView.setFormname(formname);
		                listView.setUnitheadstatus(unitheadstatus);
		                listView.setSubmittime(submittime);
	
		                cbsUserPermission.add(listView);
		            }
	            }
	            accessRights.addAll(cbsUserPermission);
	            

//		          For Database Access Form
		            
		            ResultSet da = stmt.executeQuery("SELECT * FROM form_database_access far "
		                    + "JOIN stp_forms sf ON far.form_id = sf.form_id "
		                    + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		                    + "WHERE far.user_id = '" + userid + "' "
		                    + "AND (far.implemented_by_status = 'Done')");
		          
		            if (da != null) {
			          while (da.next()) {
			          	ListView listView = new ListView();
		
			              long id = da.getLong("id");
			              String users = da.getString("user_id");
			              String username = da.getString("user_name");
			              String formid = da.getString("form_id");
			              String formname = da.getString("form_name");
			              String unitheadstatus = da.getString("unit_head_status");
			              String citostatus = da.getString("cito_status");
			              Timestamp submittime = da.getTimestamp("submit_time");
			              
			              listView.setId(id);
			              listView.setUserid(users);
			              listView.setUsername(username);
			              listView.setFormid(formid);
			              listView.setFormname(formname);
			              listView.setUnitheadstatus(unitheadstatus);
			              listView.setCitostatus(citostatus);
			              listView.setSubmittime(submittime);
		
			              databaseAccess.add(listView);
			          }
		            }
		          accessRights.addAll(databaseAccess);

	            con.close();
	            
	        } catch (Exception e) {
	            e.printStackTrace(); 
	        }
			
		return accessRights;
	}
	
	@GetMapping("rejected/{id}")
    public List<ListView> rejectedForms(@PathVariable("id") String userid){

			Connection con = null;
			List<ListView> accessRights = new ArrayList<>();
			List<ListView> accessControls = new ArrayList<>();
			List<ListView> createMail = new ArrayList<>();
			List<ListView> groupMail = new ArrayList<>();
			List<ListView> createDomain = new ArrayList<>();
			List<ListView> incidentReport = new ArrayList<>();
			List<ListView> databaseAccess = new ArrayList<>();
			List<ListView> cbsUserPermission = new ArrayList<>();

			 try {
		            con = PostGRESQLConnUtils.getPostGreSQLConnection();
		            con.setAutoCommit(false);
		            Statement stmt = con.createStatement();

//		            For Access Controls Form
		            
		            ResultSet ac = stmt.executeQuery("SELECT * FROM form_access_control far "
		                    + "JOIN stp_forms sf ON far.form_id = sf.form_id "
		                    + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		                    + "WHERE far.user_id = '" + userid + "' "
		                    + "AND (far.unit_head_status = 'Rejected' "
		                    + "OR far.isrm_head_status = 'Rejected' "
		                    + "OR far.cito_status = 'Rejected' "
		                    + "OR far.network_head_status = 'Rejected' )");
		            
		            if (ac != null) {
			            while (ac.next()) {
			            	ListView listView = new ListView();
	
			                long id = ac.getLong("id");
			                String users = ac.getString("user_id");
			                String username = ac.getString("user_name");
			                String formid = ac.getString("form_id");
			                String formname = ac.getString("form_name");
			                String unitheadstatus = ac.getString("unit_head_status");
			                String citostatus = ac.getString("cito_status");
			                Timestamp submittime = ac.getTimestamp("submit_time");
	
			                listView.setId(id);
			                listView.setUserid(users);
			                listView.setUsername(username);
			                listView.setFormid(formid);
			                listView.setFormname(formname);
			                listView.setUnitheadstatus(unitheadstatus);
			                listView.setCitostatus(citostatus);
			                listView.setSubmittime(submittime);
	
			                accessControls.add(listView);
			            }
		            }
		            accessRights.addAll(accessControls);

//		          For Creating Mail Form
		            
		            ResultSet cm = stmt.executeQuery("SELECT * FROM form_create_email far "
		                    + "JOIN stp_forms sf ON far.form_id = sf.form_id "
		                    + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		                    + "WHERE far.user_id = '" + userid + "' "
		                    + "AND (far.unit_head_status = 'Rejected' "
		                    + "OR far.isrm_head_status = 'Rejected' "
		                    + "OR far.cito_status = 'Rejected' "
		                    + "OR far.impl_by_unithead_status = 'Rejected' )");
		          
		            if (cm != null) {
			          while (cm.next()) {
			          	ListView listView = new ListView();
	
			              long id = cm.getLong("id");
			              String users = cm.getString("user_id");
			              String username = cm.getString("user_name");
			              String formid = cm.getString("form_id");
			              String formname = cm.getString("form_name");
			              String unitheadstatus = cm.getString("unit_head_status");
			              String citostatus = cm.getString("cito_status");
			              Timestamp submittime = cm.getTimestamp("submit_time");
			              
			              listView.setId(id);
			              listView.setUserid(users);
			              listView.setUsername(username);
			              listView.setFormid(formid);
			              listView.setFormname(formname);
			              listView.setUnitheadstatus(unitheadstatus);
			              listView.setCitostatus(citostatus);
			              listView.setSubmittime(submittime);
	
			              createMail.add(listView);
			          }
		            }
		          accessRights.addAll(createMail);
		          
//		          For Create Domain Form
		            
		            ResultSet cd = stmt.executeQuery("SELECT * FROM form_create_domain far "
		                    + "JOIN stp_forms sf ON far.form_id = sf.form_id "
		                    + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		                    + "WHERE far.user_id = '" + userid + "' "
		                    + "AND (far.unit_head_status = 'Rejected' "
		                    + "OR far.sa_head_status = 'Rejected' "
		                    + "OR far.isrm_head_status = 'Rejected' "
		                    + "OR far.cito_status = 'Rejected' )");
		          
		            if (cd != null) {
			          while (cd.next()) {
			          	ListView listView = new ListView();
	
			              long id = cd.getLong("id");
			              String users = cd.getString("user_id");
			              String username = cd.getString("user_name");
			              String formid = cd.getString("form_id");
			              String formname = cd.getString("form_name");
			              String unitheadstatus = cd.getString("unit_head_status");
			              String citostatus = cd.getString("cito_status");
			              Timestamp submittime = cd.getTimestamp("submit_time");
			              
			              listView.setId(id);
			              listView.setUserid(users);
			              listView.setUsername(username);
			              listView.setFormid(formid);
			              listView.setFormname(formname);
			              listView.setUnitheadstatus(unitheadstatus);
			              listView.setCitostatus(citostatus);
			              listView.setSubmittime(submittime);
	
			              createDomain.add(listView);
			          }
		            }
		          accessRights.addAll(createDomain);

//		          For Group Mail Form
		            
		            ResultSet gm = stmt.executeQuery("SELECT * FROM form_group_email far "
		                    + "JOIN stp_forms sf ON far.form_id = sf.form_id "
		                    + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		                    + "WHERE far.user_id = '" + userid + "' "
		                    + "AND (far.unit_head_status = 'Rejected' "
		                    + "OR far.isrm_head_status = 'Rejected' "
		                    + "OR far.cito_status = 'Rejected' "
		                    + "OR far.impl_by_unithead_status = 'Rejected' )");
		          
		            if (gm != null) {
			          while (gm.next()) {
			          	ListView listView = new ListView();
	
			              long id = gm.getLong("id");
			              String users = gm.getString("user_id");
			              String username = gm.getString("user_name");
			              String formid = gm.getString("form_id");
			              String formname = gm.getString("form_name");
			              String unitheadstatus = gm.getString("unit_head_status");
			              String citostatus = gm.getString("cito_status");
			              Timestamp submittime = gm.getTimestamp("submit_time");
			              
			              listView.setId(id);
			              listView.setUserid(users);
			              listView.setUsername(username);
			              listView.setFormid(formid);
			              listView.setFormname(formname);
			              listView.setUnitheadstatus(unitheadstatus);
			              listView.setCitostatus(citostatus);
			              listView.setSubmittime(submittime);
	
			              groupMail.add(listView);
			          }
		            }
		          accessRights.addAll(groupMail);

//		          For Incident Report Form
		            
		            ResultSet ir = stmt.executeQuery("SELECT * FROM form_incident_report far "
		                    + "JOIN stp_forms sf ON far.form_id = sf.form_id "
		                    + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		                    + "WHERE far.user_id = '" + userid + "' "
		                    + "AND (far.unit_head_status = 'Rejected' "
		                    + "OR far.isrm_head_status = 'Rejected' "
		                    + "OR far.cito_status = 'Rejected' )");
		          
		            if (ir != null) {
			          while (ir.next()) {
			          	ListView listView = new ListView();
	
			              long id = ir.getLong("id");
			              String users = ir.getString("user_id");
			              String username = ir.getString("user_name");
			              String formid = ir.getString("form_id");
			              String formname = ir.getString("form_name");
			              String unitheadstatus = ir.getString("unit_head_status");
			              String citostatus = ir.getString("cito_status");
			              Timestamp submittime = ir.getTimestamp("submit_time");
			              
			              listView.setId(id);
			              listView.setUserid(users);
			              listView.setUsername(username);
			              listView.setFormid(formid);
			              listView.setFormname(formname);
			              listView.setUnitheadstatus(unitheadstatus);
			              listView.setCitostatus(citostatus);
			              listView.setSubmittime(submittime);
	
			              incidentReport.add(listView);
			          }
		            }
		          accessRights.addAll(incidentReport);
		          
//		            For CBS User Permission
		            
		            ResultSet cbs = stmt.executeQuery("SELECT * FROM form_cbs_user_permission far "
		                    + "JOIN stp_forms sf ON far.form_id = sf.form_id "
		                    + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
		                    + "WHERE far.user_id = '" + userid + "' "
		                    + "AND (far.unit_head_status = 'Rejected' "
		                    + "OR far.implemented_by_status = 'Rejected' "
				            + "OR far.bcd_status = 'Rejected'"
			        		+ "OR far.iad_status = 'Rejected'"
			        		+ "OR far.id_status = 'Rejected'"
			        		+ "OR far.imrd_status = 'Rejected')");
		            
		            if (cbs != null) {
			            while (cbs.next()) {
			            	ListView listView = new ListView();
	
			                long id = cbs.getLong("id");
			                String users = cbs.getString("user_id");
			                String username = cbs.getString("user_name");
			                String formid = cbs.getString("form_id");
			                String formname = cbs.getString("form_name");
			                String unitheadstatus = cbs.getString("unit_head_status");
			                Timestamp submittime = cbs.getTimestamp("submit_time");
	
			                listView.setId(id);
			                listView.setUserid(users);
			                listView.setUsername(username);
			                listView.setFormid(formid);
			                listView.setFormname(formname);
			                listView.setUnitheadstatus(unitheadstatus);
			                listView.setSubmittime(submittime);
	
			                cbsUserPermission.add(listView);
			            }
		            }
		            accessRights.addAll(cbsUserPermission);
		            

//			          For Database Access Form
			            
			            ResultSet da = stmt.executeQuery("SELECT * FROM form_database_access far "
			                    + "JOIN stp_forms sf ON far.form_id = sf.form_id "
			                    + "JOIN sys_app_user sau ON far.user_id = sau.user_id "
			                    + "WHERE far.user_id = '" + userid + "' "
			                    + "AND (far.unit_head_status = 'Rejected' "
			                    + "OR far.isrm_head_status = 'Rejected' "
			                    + "OR far.cito_status = 'Rejected' "
			                    + "OR far.impl_by_unithead_status = 'Rejected' )");
			          
			            if (da != null) {
				          while (da.next()) {
				          	ListView listView = new ListView();
		
				              long id = da.getLong("id");
				              String users = da.getString("user_id");
				              String username = da.getString("user_name");
				              String formid = da.getString("form_id");
				              String formname = da.getString("form_name");
				              String unitheadstatus = da.getString("unit_head_status");
				              String citostatus = da.getString("cito_status");
				              Timestamp submittime = da.getTimestamp("submit_time");
				              
				              listView.setId(id);
				              listView.setUserid(users);
				              listView.setUsername(username);
				              listView.setFormid(formid);
				              listView.setFormname(formname);
				              listView.setUnitheadstatus(unitheadstatus);
				              listView.setCitostatus(citostatus);
				              listView.setSubmittime(submittime);
		
				              databaseAccess.add(listView);
				          }
			            }
			          accessRights.addAll(databaseAccess);

		            con.close();
		            
		        } catch (Exception e) {
		            e.printStackTrace(); 
		        }
			
		return accessRights;
	}
}
