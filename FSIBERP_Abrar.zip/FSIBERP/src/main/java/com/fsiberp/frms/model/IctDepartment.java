package com.fsiberp.frms.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table( name = "stp_ict_department" )
public class IctDepartment {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	
	@Column(name = "dept_name")
	private String deptname;
	
	@Column(name = "dept_mail")
	private String deptmail;
	
	public IctDepartment() {
		  
	  }

	public IctDepartment(Long id, String deptname, String deptmail) {
		super();
		this.id = id;
		this.deptname = deptname;
		this.deptmail = deptmail;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}

	public String getDeptmail() {
		return deptmail;
	}

	public void setDeptmail(String deptmail) {
		this.deptmail = deptmail;
	}

}
