package com.fsiberp.frms.services;

import java.util.List;
import com.fsiberp.frms.model.Notification;

public interface NotificationService {
	Notification createNotification(String userid, String message, String fuserid, String formid, Long submissionId,
			boolean viewed);

	List<Notification> getNotifications(String userid);
	void markAsViewed(Long id);
	boolean areNotificationsViewed(String formId);
	void markNotificationsAsViewedForUserAndForm(String userid, String formId);
	void markNotificationsAsViewedForUserAndForm(String userid, String formid, Long submissionId);
	void archiveOldNotifications();
}
