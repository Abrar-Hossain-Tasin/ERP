package com.fsiberp.frms.services;

import java.util.List;
import java.util.Optional;

import com.fsiberp.frms.model.FunctionalRole;


public interface SystemAdminService {
    
    // Add a new member
    FunctionalRole addMember(FunctionalRole functionalRole);
    
    // Update an existing member
    FunctionalRole updateMember(String userid, FunctionalRole updatedRole);
    
    // Get all members
    List<FunctionalRole> getAllMembers();
    
    // Get a member by ID
    Optional<FunctionalRole> getMemberByUserId(String userid);
    
    // Temporarily update role and revert after specified hours
    boolean temporarilyUpdateRole(String userid, Integer newRoleId, Integer hours);
}
