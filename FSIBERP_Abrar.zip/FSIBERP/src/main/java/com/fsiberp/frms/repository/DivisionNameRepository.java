package com.fsiberp.frms.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.fsiberp.frms.model.DivisionName;

@Repository
public interface DivisionNameRepository extends JpaRepository<DivisionName, Long>  {
	DivisionName findByDivisionname(String divisionname);
}
