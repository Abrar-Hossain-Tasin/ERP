package com.fsiberp.frms.controller;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fsiberp.frms.model.CreateEmail;
import com.fsiberp.frms.model.FunctionalRole;
import com.fsiberp.frms.model.Notification;
import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.CreateEmailRepository;
import com.fsiberp.frms.repository.FunctionalRoleRepository;
import com.fsiberp.frms.repository.NotificationRepository;
import com.fsiberp.frms.services.CreateEmailService;
import com.fsiberp.frms.services.EmailService;
import com.fsiberp.frms.services.ProfileService;
import jakarta.validation.Valid;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/email/")
public class CreateEmailController {
	
	private ProfileService profileService;
	private FunctionalRoleRepository functionalRoleRepository;
	private CreateEmailService createEmailService;
	private CreateEmailRepository createEmailRepository;
	private NotificationRepository notificationRepository;
    private EmailService emailService;
	
	public CreateEmailController(ProfileService profileService, NotificationRepository notificationRepository,
			FunctionalRoleRepository functionalRoleRepository, CreateEmailService createEmailService,
			CreateEmailRepository createEmailRepository, EmailService emailService) {
			
	        this.profileService = profileService;
	        this.functionalRoleRepository = functionalRoleRepository;
	        this.createEmailService = createEmailService;
	        this.createEmailRepository = createEmailRepository;
	        this.notificationRepository = notificationRepository;
	        this.emailService = emailService;
	    }
	
	@GetMapping("view/{id}")
    public ResponseEntity<User> showForms(@PathVariable("id") String userid){
        User user = profileService.getUserByUserid(userid);
        
        FunctionalRole citoRole = functionalRoleRepository.findByFunctionalroleAndStatus("cito" , "Active")
                .orElseThrow(NoSuchElementException::new);
        User citoinfo = profileService.getUserByUserid(citoRole.getUserid());
        
        FunctionalRole isrmRole = functionalRoleRepository.findByFunctionalroleAndStatus("isrm" , "Active")
                .orElseThrow(NoSuchElementException::new);
        User isrminfo = profileService.getUserByUserid(isrmRole.getUserid());
        
        FunctionalRole saRole = functionalRoleRepository.findByFunctionalroleAndStatus("sa" , "Active")
                .orElseThrow(NoSuchElementException::new);
        User sainfo = profileService.getUserByUserid(saRole.getUserid());
		
		user.setCreatedby(citoinfo.getUsername());
		user.setUsergrp(isrminfo.getUsername());
		user.setChngpassword(sainfo.getConfirmPassword());
		user.setPassword("Pending");
	
        return new ResponseEntity<>(user, HttpStatus.OK);
    }
	
	@PostMapping("save/{id}")
	public ResponseEntity<?> createForm(@PathVariable("id") String userid, @RequestBody @Valid CreateEmail createEmail, BindingResult bindingResult) {
		
		
		 if (bindingResult.hasErrors()) {
		        // Handle validation errors
		        return ResponseEntity.badRequest().body("Validation failed: " + bindingResult.getAllErrors());
		    }
		
	    User user = profileService.getUserByUserid(userid);

	    // Fetch CITO role and user information
	    FunctionalRole citoRole = functionalRoleRepository.findByFunctionalroleAndStatus("cito", "Active")
	            .orElseThrow(NoSuchElementException::new);
	    User citoinfo = profileService.getUserByUserid(citoRole.getUserid());

	    // Fetch ISRM role and user information
	    FunctionalRole isrmRole = functionalRoleRepository.findByFunctionalroleAndStatus("isrm", "Active")
	            .orElseThrow(NoSuchElementException::new);
	    User isrminfo = profileService.getUserByUserid(isrmRole.getUserid());
	    
	 // Fetch SA role and user information
	    FunctionalRole saRole = functionalRoleRepository.findByFunctionalroleAndStatus("sa", "Active")
	            .orElseThrow(NoSuchElementException::new);
	    User sainfo = profileService.getUserByUserid(saRole.getUserid());

	    // Set necessary fields in AccessRights
	    createEmail.setFormid("1004"); // Set form ID (might be generated differently)
	    createEmail.setUserid(user.getUserid());
	    
	    createEmail.setCitouserid(citoinfo.getUserid());
	    createEmail.setCitousername(citoinfo.getUsername());
	    createEmail.setCitostatus("Pending");
	    
	    createEmail.setIsrmheaduserid(isrminfo.getUserid());
	    createEmail.setIsrmheadusername(isrminfo.getUsername());
	    createEmail.setIsrmheadstatus("Pending");
	    
	    createEmail.setImplbyunitheaduserid(sainfo.getUserid());
	    createEmail.setImplbyunitheadusername(sainfo.getUsername());
	    createEmail.setImplbyunitheadstatus("Pending");
	    
	    createEmail.setUnitheadstatus("Pending");
	    createEmail.setImplementedbystatus("Pending");
	    createEmail.setImplementedbydeptid(11); // Set department ID
	    
	    createEmail.setSubmitdate(new Date(System.currentTimeMillis()));
	    createEmail.setSubmittime(new Timestamp(System.currentTimeMillis()));
	    createEmail.setBranchCode(user.getBranchcode());
	    
	    if (user.getDepartment().equals("I C T Div., Head Office, Dhaka")) {
	    	createEmail.setDepartment(user.getUnit());
        }
        else {        	
        	createEmail.setDepartment(user.getDepartment());
        }
	    
	    // Save the form using the updated saveForm method in the service
	    CreateEmail savedForm = createEmailService.saveForm(createEmail);

	    return new ResponseEntity<>(savedForm, HttpStatus.CREATED);
	}
	
	@PutMapping("update/{id}")
	public ResponseEntity<CreateEmail> updateCreateEmail(@PathVariable("id") Long id, @RequestBody @Valid CreateEmail upcreateEmail) {
	
	CreateEmail createEmail = createEmailRepository.findById(id)
            .orElseThrow(NoSuchElementException::new);
 
	createEmail.setAction(upcreateEmail.getAction());
	createEmail.setGrpemail(upcreateEmail.getGrpemail());
	createEmail.setDisplayname(upcreateEmail.getDisplayname());
	createEmail.setEmailadd(upcreateEmail.getEmailadd());
	createEmail.setPurpose(upcreateEmail.getPurpose());
	createEmail.setUnitheadstatus("Pending");
	
	
    createEmail.setSubmittime(new Timestamp(System.currentTimeMillis()));
    createEmail.setSubmitdate(new Date(System.currentTimeMillis())); 
    
    
    if (!upcreateEmail.getUnitheaduserid().equals(createEmail.getUnitheaduserid())) {
          String newUnitHeadUserId = upcreateEmail.getUnitheaduserid();
          User newUnitHeadUser = profileService.getUserByUserid(newUnitHeadUserId);
          String newUnitHeadUsername = newUnitHeadUser != null ? newUnitHeadUser.getUsername() : "Unknown User";

  
          List<Notification> existingNotifications = notificationRepository.findByUseridAndFormidAndSubmissionId(
        		  createEmail.getUnitheaduserid(),
        		  createEmail.getFormid(),
        		  createEmail.getId()
          );

   
          User user = profileService.getUserByUserid(upcreateEmail.getUnitheaduserid());
          User submittingUser = profileService.getUserByUserid(createEmail.getUserid());
          String submittingUsername = submittingUser != null ? submittingUser.getUsername() : "Unknown User";
          
          for (Notification notification : existingNotifications) {
              notification.setUserid(newUnitHeadUserId);
              notification.setViewed(false);
              notification.setMessage(
                  "A new Email request has been submitted by " + submittingUsername +
                  " (" + createEmail.getUserid() + ")."
              );
              notificationRepository.save(notification);
          }
          
          
//          unit head email
          emailService.sendNotificationEmail(user,upcreateEmail.getUserid(),1);
       
          createEmail.setUnitheaduserid(newUnitHeadUserId);
          createEmail.setUnitheadusername(newUnitHeadUsername);
      }

    
    CreateEmail updatedForm = createEmailRepository.save(createEmail);
    return new ResponseEntity<>(updatedForm, HttpStatus.OK);
}


}
