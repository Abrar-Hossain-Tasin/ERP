package com.fsiberp.frms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.fsiberp.frms.model.IncidentReport;

import org.springframework.stereotype.Repository;

@Repository
public interface IncidentReportRepository extends JpaRepository<IncidentReport, Long> {
	IncidentReport findTopByUseridOrderByIdDesc(String userid);
	List<IncidentReport> findByUserid(String userid);
	IncidentReport findAllByUseridAndFormidAndId(String userid, String formid, Long id);
//	List<IncidentReport> findByImplementedbydeptid(Integer implementedbydeptid);
	
	List<IncidentReport> findByCitostatus(String citostatus);
	List<IncidentReport> findByCitostatusAndDepartment(String implementedbystatus, String department);
	List<IncidentReport> findByCitostatusAndBranchCode(String implementedbystatus, String branchCode);
} 