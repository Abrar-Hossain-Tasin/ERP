package com.fsiberp.frms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.fsiberp.frms.model.DatabaseAccess;

@Repository
public interface DatabaseAccessRepository extends JpaRepository<DatabaseAccess, Long>{ 

	Optional<DatabaseAccess> findById(Long id);
	List<DatabaseAccess> findByUserid(String userid);
	DatabaseAccess findAllByUseridAndFormidAndId(String userid, String formid, Long id);
	List<DatabaseAccess> findByImplementedbydeptid(Integer implementedbydeptid);
	
	List<DatabaseAccess> findByImplementedbystatus(String implementedbystatus);
	List<DatabaseAccess> findByImplementedbystatusAndDepartment(String implementedbystatus, String department);
	List<DatabaseAccess> findByImplementedbystatusAndBranchCode(String implementedbystatus, String branchCode);
}
