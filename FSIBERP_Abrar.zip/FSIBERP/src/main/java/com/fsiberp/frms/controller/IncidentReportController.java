package com.fsiberp.frms.controller;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.apache.tika.Tika;
import org.apache.tika.exception.TikaException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import com.fsiberp.frms.model.FunctionalRole;
import com.fsiberp.frms.model.IncidentReport;
import com.fsiberp.frms.model.Notification;
import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.AuthRepository;
import com.fsiberp.frms.repository.FunctionalRoleRepository;
import com.fsiberp.frms.repository.IncidentReportRepository;
import com.fsiberp.frms.repository.NotificationRepository;
import com.fsiberp.frms.services.EmailService;
import com.fsiberp.frms.services.IncidentReportService;
import com.fsiberp.frms.services.ProfileService;

import jakarta.validation.Valid;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;


@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/incidentreport/")
public class IncidentReportController {

	    private IncidentReportService incidentReportService;
	    private ProfileService profileService;
	    private FunctionalRoleRepository functionalRoleRepository;
	    private IncidentReportRepository incidentReportRepository;
	    private AuthRepository authRepository;
	    private NotificationRepository notificationRepository;
	    private EmailService emailService;
	    
	    @Value("${file.upload-dir}")
	    private String uploadDir;

	    public IncidentReportController(AuthRepository authRepository, IncidentReportService incidentReportService, ProfileService profileService,
	    		NotificationRepository notificationRepository, FunctionalRoleRepository functionalRoleRepository, IncidentReportRepository incidentReportRepository,
	    		EmailService emailService) {
	        this.authRepository = authRepository;
	        this.incidentReportService = incidentReportService;
	        this.profileService = profileService;
	        this.functionalRoleRepository = functionalRoleRepository;
	        this.incidentReportRepository = incidentReportRepository;
	        this.notificationRepository = notificationRepository;
	        this.emailService = emailService;
	    }

	    @GetMapping("view/{id}")
	    public ResponseEntity<User> showForms(@PathVariable("id") String userid) {
	        User user = profileService.getUserByUserid(userid);
	       
	        FunctionalRole citoRole = functionalRoleRepository.findByFunctionalroleAndStatus("cito" , "Active")
	                .orElseThrow(NoSuchElementException::new);
	        User citoinfo = profileService.getUserByUserid(citoRole.getUserid());
	        

	        FunctionalRole isrmRole = functionalRoleRepository.findByFunctionalroleAndStatus("isrm" , "Active")
	                .orElseThrow(NoSuchElementException::new);
	        User isrminfo = profileService.getUserByUserid(isrmRole.getUserid());

	        user.setCreatedby(citoinfo.getUsername());
	        user.setUsergrp(isrminfo.getUsername());
	        user.setPassword("Pending");

	        return new ResponseEntity<>(user, HttpStatus.OK);
	    }

	    @PostMapping("save/{id}")
	    public ResponseEntity<?> createForm(@PathVariable("id") String userid,
            @ModelAttribute @Valid IncidentReport incidentReport,
            @RequestParam(value = "typeOfIncident", required = false) String typeOfIncidentJson,
            @RequestParam(value = "potentialImpact", required = false) String potentialImpactJson,
            @RequestParam(value = "incidentHandlingDocuments", required = false) MultipartFile incidentHandlingDocuments,
            @RequestParam(value = "impactAnalysisDocument", required = false) MultipartFile impactAnalysisDocument,
            @RequestParam(value = "downtimeDocumentation", required = false) MultipartFile downtimeDocumentation,
            @RequestParam(value = "rootCauseAnalysisDocuments", required = false) MultipartFile rootCauseAnalysisDocuments,
            @RequestParam(value = "workCompletionDocument", required = false) MultipartFile workCompletionDocument) {

	        // Get user and functional role info
	        User user = profileService.getUserByUserid(userid);

	        FunctionalRole citoRole = functionalRoleRepository.findByFunctionalroleAndStatus("cito", "Active")
	                .orElseThrow(NoSuchElementException::new);
	        User citoinfo = profileService.getUserByUserid(citoRole.getUserid());

	        FunctionalRole isrmRole = functionalRoleRepository.findByFunctionalroleAndStatus("isrm", "Active")
	                .orElseThrow(NoSuchElementException::new);
	        User isrminfo = profileService.getUserByUserid(isrmRole.getUserid());

	        // Set basic incident report details
	        incidentReport.setUserid(user.getUserid());
	        incidentReport.setFormid("1006");
	        incidentReport.setUnitheadstatus("Pending");

	        incidentReport.setCitouserid(citoinfo.getUserid());
	        incidentReport.setCitousername(citoinfo.getUsername());
	        incidentReport.setCitostatus("Pending");

	        incidentReport.setIsrmheaduserid(isrminfo.getUserid());
	        incidentReport.setIsrmheadusername(isrminfo.getUsername());
	        incidentReport.setIsrmheadstatus("Pending");

	        incidentReport.setSubmitdate(new Date(System.currentTimeMillis()));
	        incidentReport.setSubmittime(new Timestamp(System.currentTimeMillis()));
	        incidentReport.setBranchCode(user.getBranchcode());

	        if (user.getDepartment().equals("I C T Div., Head Office, Dhaka")) {
	            incidentReport.setDepartment(user.getUnit());
	        } else {
	            incidentReport.setDepartment(user.getDepartment());
	        }

	        if (incidentReport.getTypeOfIncident() == null) {
	            incidentReport.setTypeOfIncident(new String[]{});
	        }

	        if (incidentReport.getPotentialImpact() == null) {
	            incidentReport.setPotentialImpact(new String[]{});
	        }

	        if (incidentReport.getWitness() == null) {
	            incidentReport.setWitness(new String[]{});
	        }

	        // Validate files
	        Map<String, String> errors = new HashMap<>();
	        final long FILE_SIZE_LIMIT = 250 * 1024;

	        MultipartFile[] files = {
	                incidentHandlingDocuments,
	                impactAnalysisDocument,
	                downtimeDocumentation,
	                rootCauseAnalysisDocuments,
	                workCompletionDocument
	        };

	        String[] fileNames = {
	                "incidentHandlingDocuments",
	                "impactAnalysisDocument",
	                "downtimeDocumentation",
	                "rootCauseAnalysisDocuments",
	                "workCompletionDocument"
	        };

	        // Validate each file
	        for (int i = 0; i < files.length; i++) {
	            MultipartFile file = files[i];
	            if (file != null && !file.isEmpty()) {
	                try {
	                    // Check file size
	                    if (file.getSize() > FILE_SIZE_LIMIT) {
	                        errors.put(fileNames[i], "File size exceeds the limit of 250 KB.");
	                        continue;
	                    }

	                    // Check content type using Tika
	                    String fileType = getFileTypeFromTika(file);
	                    if (!"application/pdf".equals(fileType) &&
	                            !"image/jpeg".equals(fileType) &&
	                            !"image/png".equals(fileType)) {
	                        errors.put(fileNames[i], "Invalid file type. Only PDF, JPEG, and PNG files are allowed.");
	                        continue;
	                    }

	                    // Check file extension
	                    String fileExtension = getFileExtension(file.getOriginalFilename());
	                    if (!"pdf".equalsIgnoreCase(fileExtension) &&
	                            !"jpg".equalsIgnoreCase(fileExtension) &&
	                            !"jpeg".equalsIgnoreCase(fileExtension) &&
	                            !"png".equalsIgnoreCase(fileExtension)) {
	                        errors.put(fileNames[i], "Invalid file extension. Only PDF, JPG, JPEG, and PNG files are allowed.");
	                    }
	                } catch (IOException e) {
	                    errors.put(fileNames[i], "Error checking file content type: " + e.getMessage());
	                } catch (TikaException e) {
	                    errors.put(fileNames[i], "Error detecting file type: " + e.getMessage());
	                }
	            }
	        }

	        if (!errors.isEmpty()) {
	            return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
	        }

	        // Handle file uploads
	        try {
	            if (incidentHandlingDocuments != null && !incidentHandlingDocuments.isEmpty()) {
	                String path = saveFile(userid, incidentHandlingDocuments);
	                incidentReport.setIncidentHandlingDocumentsPath(path);
	            }
	            if (impactAnalysisDocument != null && !impactAnalysisDocument.isEmpty()) {
	                String path = saveFile(userid, impactAnalysisDocument);
	                incidentReport.setImpactAnalysisDocumentPath(path);
	            }
	            if (downtimeDocumentation != null && !downtimeDocumentation.isEmpty()) {
	                String path = saveFile(userid, downtimeDocumentation);
	                incidentReport.setDowntimeDocumentationPath(path);
	            }
	            if (rootCauseAnalysisDocuments != null && !rootCauseAnalysisDocuments.isEmpty()) {
	                String path = saveFile(userid, rootCauseAnalysisDocuments);
	                incidentReport.setRootCauseAnalysisDocumentsPath(path);
	            }
	            if (workCompletionDocument != null && !workCompletionDocument.isEmpty()) {
	                String path = saveFile(userid, workCompletionDocument);
	                incidentReport.setWorkCompletionDocumentPath(path);
	            }
	        } catch (IOException e) {
	            errors.put("fileUpload", "An error occurred while saving the file(s).");
	            return new ResponseEntity<>(errors, HttpStatus.INTERNAL_SERVER_ERROR);
	        }

	        // Save the incident report
	        IncidentReport savedForm = incidentReportService.saveForm(incidentReport);
	        return new ResponseEntity<>(savedForm, HttpStatus.CREATED);
	    }

	    // Save file to disk
	    private String saveFile(String userid, MultipartFile file) throws IOException {
	        String originalFilename = file.getOriginalFilename();
	        String sanitizedFilename = sanitizeFileName(originalFilename);
	        String filename = userid + "_" + 1006 + "_" + System.currentTimeMillis() + "~" + sanitizedFilename;

	        Path filePath = Paths.get(uploadDir, filename);

	        try (InputStream inputStream = file.getInputStream()) {
	            Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
	        }

	        return filePath.toString();
	    }

	    // Sanitize file name
	    private String sanitizeFileName(String originalFilename) {
	        return originalFilename.replaceAll("[^a-zA-Z0-9.-]", "_");
	    }

	    // Extract file extension
	    private String getFileExtension(String filename) {
	        if (filename == null || filename.isEmpty()) {
	            return "";
	        }
	        int dotIndex = filename.lastIndexOf(".");
	        if (dotIndex == -1) {
	            return "";
	        }
	        return filename.substring(dotIndex + 1);
	    }

	    // Use Tika to detect file type
	    private String getFileTypeFromTika(MultipartFile file) throws IOException, TikaException {
	        Tika tika = new Tika();
	        try (InputStream inputStream = file.getInputStream()) {
	            return tika.detect(inputStream);
	        }
	    }

	    
	    @GetMapping("viewform/{id}")
	    public ResponseEntity<IncidentReport> viewForms(@PathVariable("id") String userid) {
	        IncidentReport incidentReport = incidentReportRepository.findTopByUseridOrderByIdDesc(userid);

	        if (incidentReport == null) {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        }

	        // Set download URLs if paths are not null
	        if (incidentReport.getIncidentHandlingDocumentsPath() != null) {
	            String incidentHandlingDocumentsDownloadUrl = "/api/incidentreport/download/incidentHandlingDocuments/" + incidentReport.getId();
	            incidentReport.setIncidentHandlingDocumentsDownloadUrl(incidentHandlingDocumentsDownloadUrl);
	        }
	        if (incidentReport.getImpactAnalysisDocumentPath() != null) {
	            String impactAnalysisDocumentDownloadUrl = "/api/incidentreport/download/impactAnalysisDocument/" + incidentReport.getId();
	            incidentReport.setImpactAnalysisDocumentDownloadUrl(impactAnalysisDocumentDownloadUrl);
	        }
	        if (incidentReport.getDowntimeDocumentationPath() != null) {
	            String downtimeDocumentationDownloadUrl = "/api/incidentreport/download/downtimeDocumentation/" + incidentReport.getId();
	            incidentReport.setDowntimeDocumentationDownloadUrl(downtimeDocumentationDownloadUrl);
	        }
	        if (incidentReport.getRootCauseAnalysisDocumentsPath() != null) {
	            String rootCauseAnalysisDocumentsDownloadUrl = "/api/incidentreport/download/rootCauseAnalysisDocuments/" + incidentReport.getId();
	            incidentReport.setRootCauseAnalysisDocumentsDownloadUrl(rootCauseAnalysisDocumentsDownloadUrl);
	        }
	        if (incidentReport.getWorkCompletionDocumentPath() != null) {
	            String workCompletionDocumentDownloadUrl = "/api/incidentreport/download/workCompletionDocument/" + incidentReport.getId();
	            incidentReport.setWorkCompletionDocumentDownloadUrl(workCompletionDocumentDownloadUrl);
	        }

	        return new ResponseEntity<>(incidentReport, HttpStatus.OK);
	    }
	    
	    @GetMapping("download/incidentHandlingDocuments/{id}")
	    public ResponseEntity<Resource> downloadIncidentHandlingDocuments(@PathVariable("id") Long id) {
	        return downloadFile(id, "incidentHandlingDocumentsPath");
	    }

	    @GetMapping("download/impactAnalysisDocument/{id}")
	    public ResponseEntity<Resource> downloadImpactAnalysisDocument(@PathVariable("id") Long id) {
	        return downloadFile(id, "impactAnalysisDocumentPath");
	    }

	    @GetMapping("download/downtimeDocumentation/{id}")
	    public ResponseEntity<Resource> downloadDowntimeDocumentation(@PathVariable("id") Long id) {
	        return downloadFile(id, "downtimeDocumentationPath");
	    }

	    @GetMapping("download/rootCauseAnalysisDocuments/{id}")
	    public ResponseEntity<Resource> downloadRootCauseAnalysisDocuments(@PathVariable("id") Long id) {
	        return downloadFile(id, "rootCauseAnalysisDocumentsPath");
	    }

	    @GetMapping("download/workCompletionDocument/{id}")
	    public ResponseEntity<Resource> downloadWorkCompletionDocument(@PathVariable("id") Long id) {
	        return downloadFile(id, "workCompletionDocumentPath");
	    }

	    private ResponseEntity<Resource> downloadFile(Long id, String filePathField) {
	        IncidentReport incidentReport = incidentReportRepository.findById(id).orElse(null);
	        if (incidentReport == null) {
	            return ResponseEntity.notFound().build();
	        }
	        
	        String filePathString;
	        switch (filePathField) {
	            case "incidentHandlingDocumentsPath":
	                filePathString = incidentReport.getIncidentHandlingDocumentsPath();
	                break;
	            case "impactAnalysisDocumentPath":
	                filePathString = incidentReport.getImpactAnalysisDocumentPath();
	                break;
	            case "downtimeDocumentationPath":
	                filePathString = incidentReport.getDowntimeDocumentationPath();
	                break;
	            case "rootCauseAnalysisDocumentsPath":
	                filePathString = incidentReport.getRootCauseAnalysisDocumentsPath();
	                break;
	            case "workCompletionDocumentPath":
	                filePathString = incidentReport.getWorkCompletionDocumentPath();
	                break;
	            default:
	                return ResponseEntity.badRequest().build();
	        }

	        if (filePathString == null) {
	            return ResponseEntity.notFound().build();
	        }

	        try {
	            Path filePath = Paths.get(filePathString);
	            Resource resource = new UrlResource(filePath.toUri());

	            String originalFilename = filePath.getFileName().toString();
	            String contentType = Files.probeContentType(filePath);
	            if (contentType == null) {
	                contentType = MediaType.APPLICATION_OCTET_STREAM_VALUE; // Default for unknown content types
	            }

	            return ResponseEntity.ok()
	                    .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + originalFilename + "\"")
	                    .contentType(MediaType.parseMediaType(contentType))
	                    .body(resource);
	        } catch (IOException e) {
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
	        }
	    }
	    
	    @PutMapping("update/{id}")
	    public ResponseEntity<?> updateIncidentReport(
	            @PathVariable("id") Long id,
	            @ModelAttribute @Valid IncidentReport updatedIncidentReport,
	            @RequestParam(value = "incidentHandlingDocuments", required = false) MultipartFile incidentHandlingDocuments,
	            @RequestParam(value = "impactAnalysisDocument", required = false) MultipartFile impactAnalysisDocument,
	            @RequestParam(value = "downtimeDocumentation", required = false) MultipartFile downtimeDocumentation,
	            @RequestParam(value = "rootCauseAnalysisDocuments", required = false) MultipartFile rootCauseAnalysisDocuments,
	            @RequestParam(value = "workCompletionDocument", required = false) MultipartFile workCompletionDocument,
	            @RequestParam(value = "typeOfIncident", required = false) String typeOfIncidentJson,
	            @RequestParam(value = "potentialImpact", required = false) String potentialImpactJson) {

	        IncidentReport existingIncidentReport = incidentReportRepository.findById(id)
	                .orElseThrow(NoSuchElementException::new);
	        
	        

	        existingIncidentReport.setPriority(updatedIncidentReport.getPriority());
	        existingIncidentReport.setIncidentOccurred(updatedIncidentReport.getIncidentOccurred());
	        existingIncidentReport.setIncidentResolved(updatedIncidentReport.getIncidentResolved());
	        existingIncidentReport.setLocationOfIncident(updatedIncidentReport.getLocationOfIncident());
	        existingIncidentReport.setIncidentReportedBy(updatedIncidentReport.getIncidentReportedBy());
	        existingIncidentReport.setIncidentHandledBy(updatedIncidentReport.getIncidentHandledBy());
	      
	        existingIncidentReport.setNameOfTheIncident(updatedIncidentReport.getNameOfTheIncident());
	        existingIncidentReport.setRootCauseOfIncident(updatedIncidentReport.getRootCauseOfIncident());
	        existingIncidentReport.setPotentialImpactDescription(updatedIncidentReport.getPotentialImpactDescription());
	        existingIncidentReport.setActionTaken(updatedIncidentReport.getActionTaken());
	        existingIncidentReport.setPrevention(updatedIncidentReport.getPrevention());
	        existingIncidentReport.setProposedSolution(updatedIncidentReport.getProposedSolution());
	        existingIncidentReport.setLessonLearned(updatedIncidentReport.getLessonLearned());
	        existingIncidentReport.setUnitheadstatus("Pending");

	        Map<String, String> errors = new HashMap<>();
	        Tika tika = new Tika(); // Instantiate Apache Tika
	        final long FILE_SIZE_LIMIT = 250 * 1024;

	        // Validate each file
	        MultipartFile[] files = {
	            incidentHandlingDocuments,
	            impactAnalysisDocument,
	            downtimeDocumentation,
	            rootCauseAnalysisDocuments,
	            workCompletionDocument
	        };
	        String[] fileNames = {
	            "incidentHandlingDocuments",
	            "impactAnalysisDocument",
	            "downtimeDocumentation",
	            "rootCauseAnalysisDocuments",
	            "workCompletionDocument"
	        };

	        for (int i = 0; i < files.length; i++) {
	            MultipartFile file = files[i];
	            if (file != null && !file.isEmpty()) {
	                try {
	                    // Check file size
	                    if (file.getSize() > FILE_SIZE_LIMIT) {
	                        errors.put(fileNames[i], "File size exceeds the limit of 250 KB.");
	                        continue;
	                    }

	                    // Check content type
	                    String fileType = tika.detect(file.getInputStream());
	                    if (!"application/pdf".equals(fileType) &&
	                            !"image/jpeg".equals(fileType) &&
	                            !"image/png".equals(fileType)) {
	                        errors.put(fileNames[i], "Invalid file type. Only PDF, JPEG, and PNG files are allowed.");
	                        continue;
	                    }

	                    // Check file extension
	                    String fileExtension = getFileExtension(file.getOriginalFilename());
	                    if (!"pdf".equalsIgnoreCase(fileExtension) &&
	                            !"jpg".equalsIgnoreCase(fileExtension) &&
	                            !"jpeg".equalsIgnoreCase(fileExtension) &&
	                            !"png".equalsIgnoreCase(fileExtension)) {
	                        errors.put(fileNames[i], "Invalid file extension. Only PDF, JPG, JPEG, and PNG files are allowed.");
	                    }
	                } catch (IOException e) {
	                    errors.put(fileNames[i], "Error checking file content type: " + e.getMessage());
	                }
	            }
	        }


	        // If there are errors, return immediately
	        if (!errors.isEmpty()) {
	            return ResponseEntity.badRequest().body(errors);
	        }

	        try {
	            // Save the files
	            if (incidentHandlingDocuments != null && !incidentHandlingDocuments.isEmpty()) {
	                String path = saveFile(updatedIncidentReport.getUserid(), incidentHandlingDocuments);
	                existingIncidentReport.setIncidentHandlingDocumentsPath(path);
	            }
	            if (impactAnalysisDocument != null && !impactAnalysisDocument.isEmpty()) {
	                String path = saveFile(updatedIncidentReport.getUserid(), impactAnalysisDocument);
	                existingIncidentReport.setImpactAnalysisDocumentPath(path);
	            }
	            if (downtimeDocumentation != null && !downtimeDocumentation.isEmpty()) {
	                String path = saveFile(updatedIncidentReport.getUserid(), downtimeDocumentation);
	                existingIncidentReport.setDowntimeDocumentationPath(path);
	            }
	            if (rootCauseAnalysisDocuments != null && !rootCauseAnalysisDocuments.isEmpty()) {
	                String path = saveFile(updatedIncidentReport.getUserid(), rootCauseAnalysisDocuments);
	                existingIncidentReport.setRootCauseAnalysisDocumentsPath(path);
	            }
	            if (workCompletionDocument != null && !workCompletionDocument.isEmpty()) {
	                String path = saveFile(updatedIncidentReport.getUserid(), workCompletionDocument);
	                existingIncidentReport.setWorkCompletionDocumentPath(path);
	            }
	        } catch (IOException e) {
	            errors.put("fileUpload", "An error occurred while saving the file(s).");
	            return new ResponseEntity<>(errors, HttpStatus.INTERNAL_SERVER_ERROR);
	        }
	        
	        if (!updatedIncidentReport.getUnitheaduserid().equals(existingIncidentReport.getUnitheaduserid())) {
		          String newUnitHeadUserId = updatedIncidentReport.getUnitheaduserid();
		          User newUnitHeadUser = profileService.getUserByUserid(newUnitHeadUserId);
		          String newUnitHeadUsername = newUnitHeadUser != null ? newUnitHeadUser.getUsername() : "Unknown User";

		  
		          List<Notification> existingNotifications = notificationRepository.findByUseridAndFormidAndSubmissionId(
		        		  existingIncidentReport.getUnitheaduserid(),
		        		  existingIncidentReport.getFormid(),
		        		  existingIncidentReport.getId()
		          );

		   
		          User user = profileService.getUserByUserid(updatedIncidentReport.getUnitheaduserid());
		          
		          User submittingUser = profileService.getUserByUserid(existingIncidentReport.getUserid());
		          String submittingUsername = submittingUser != null ? submittingUser.getUsername() : "Unknown User";

		          
		          for (Notification notification : existingNotifications) {
		              notification.setUserid(newUnitHeadUserId);
		              notification.setViewed(false);
		              notification.setMessage(
		                  "A new Incident Report has been submitted by " + submittingUsername +
                          " (" + existingIncidentReport.getUserid() + ")."
		              );
		              notificationRepository.save(notification);
		          }
		          
//		          unit head email
		          emailService.sendNotificationEmail(user,updatedIncidentReport.getUserid(),1);
		       
		          existingIncidentReport.setUnitheaduserid(newUnitHeadUserId);
		          existingIncidentReport.setUnitheadusername(newUnitHeadUsername);
		          existingIncidentReport.setSubmittime(new Timestamp(System.currentTimeMillis()));
		          existingIncidentReport.setSubmitdate(new Date(System.currentTimeMillis())); 
		      }

	
	        IncidentReport updatedIncidentReportResult = incidentReportRepository.save(existingIncidentReport);
	        return new ResponseEntity<>(updatedIncidentReportResult, HttpStatus.OK);
	    }

	    @DeleteMapping("removefile/{id}/{fileType}")
	    public ResponseEntity<String> removeFile(
	            @PathVariable("id") Long id,
	            @PathVariable("fileType") String fileType) {


	        IncidentReport existingIncidentReport = incidentReportRepository.findById(id)
	                .orElseThrow(() -> new NoSuchElementException("Incident Report not found with ID: " + id));

	        String filePath = null;


	        switch (fileType.toLowerCase()) {
	            case "incidenthandlingdocuments":
	                filePath = existingIncidentReport.getIncidentHandlingDocumentsPath();
	                existingIncidentReport.setIncidentHandlingDocumentsPath(null);
	                break;
	            case "impactanalysisdocument":
	                filePath = existingIncidentReport.getImpactAnalysisDocumentPath();
	                existingIncidentReport.setImpactAnalysisDocumentPath(null);
	                break;
	            case "downtimedocumentation":
	                filePath = existingIncidentReport.getDowntimeDocumentationPath();
	                existingIncidentReport.setDowntimeDocumentationPath(null);
	                break;
	            case "rootcauseanalysisdocuments":
	                filePath = existingIncidentReport.getRootCauseAnalysisDocumentsPath();
	                existingIncidentReport.setRootCauseAnalysisDocumentsPath(null);
	                break;
	            case "workcompletiondocument":
	                filePath = existingIncidentReport.getWorkCompletionDocumentPath();
	                existingIncidentReport.setWorkCompletionDocumentPath(null);
	                break;
	            default:
	                return new ResponseEntity<>("Invalid file type specified", HttpStatus.BAD_REQUEST);
	        }


	        if (filePath != null) {
	            File fileToDelete = new File(filePath);
	            if (fileToDelete.exists() && fileToDelete.delete()) {
	                incidentReportRepository.save(existingIncidentReport);
	                return new ResponseEntity<>("File removed successfully", HttpStatus.OK);
	            } else {
	                return new ResponseEntity<>("File not found or could not be deleted", HttpStatus.INTERNAL_SERVER_ERROR);
	            }
	        } else {
	            return new ResponseEntity<>("No file associated with the specified file type", HttpStatus.NOT_FOUND);
	        }
	    }

	    
	    @GetMapping("emplist/{id}")
	    public List<User> emplist(@PathVariable(name = "id") String userid) {
	        User user = profileService.getUserByUserid(userid);
	        
	        if (user.getBranchcode().equals("0100")) {
	            // Filter by department for branch code "0100"
	            return authRepository.findAllByDepartment(user.getDepartment());
	        } else {
	            // Show all members of the user's branch code, excluding the specified user
	            return authRepository.findAllByBranchcode(user.getBranchcode());
	        }
	    }
	    
	}