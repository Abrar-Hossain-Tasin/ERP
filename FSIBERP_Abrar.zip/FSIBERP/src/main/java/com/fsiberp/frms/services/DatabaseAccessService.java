package com.fsiberp.frms.services;

import java.sql.Timestamp;


import com.fsiberp.frms.model.DatabaseAccess;
import com.fsiberp.frms.model.StatusUpdateRequest;

public interface DatabaseAccessService {
	
	DatabaseAccess createForm(DatabaseAccess databaseAccess);
	DatabaseAccess saveForm(DatabaseAccess form);
	DatabaseAccess updateStatus(Long id, String userid, StatusUpdateRequest request, Timestamp currentTimestamp);

}
