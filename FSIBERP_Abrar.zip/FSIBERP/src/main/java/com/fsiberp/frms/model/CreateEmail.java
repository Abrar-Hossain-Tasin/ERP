package com.fsiberp.frms.model;

import java.sql.*;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "form_create_email")
public class CreateEmail {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "form_id")
    private String formid;
    
  
    @Size(max = 50)
    @Column(name = "user_id")
    private String userid;
    
    @Size(max = 50)
    @Column(name = "ref")
	private String referenceValue;
    
    @Size(max = 50)
    @Column(name = "action")
	private String action;
    
    @Size(max = 50)
    @Column(name = "grp_email")
	private String grpemail;
    
    @Size(max = 50)
    @Column(name = "des_disp_name")
	private String displayname;
    
    @Size(max = 50)
    @Column(name = "des_email")
	private String emailadd;
    
    @Size(max = 50)
    @Column(name = "purpose")
	private String purpose;
    
    @Size(max = 50)
    @Column(name = "conf_email_add")
	private String confemail;
    
    @Size(max = 50)
    @Column(name = "grp_allot")
	private String grpallot;
    
    @Column(name = "submit_date")
	private Date submitdate;
    
    @Column(name = "submit_time")
	private Timestamp submittime;
    
    @Size(max = 50)
	@Column(name = "unit_head_userid")
	private String unitheaduserid;
	
	@Size(max = 50)
	@Column(name = "unit_head_username")
	private String unitheadusername;
	
	@Size(max = 50)
	@Column(name = "unit_head_status")
	private String unitheadstatus;
	
	@Column(name = "unit_head_sub_date")
	private Timestamp unitheadsubdate;
	
	@Size(max = 255)
	@Column(name = "unit_head_cmnt")
	private String unitheadcmnt;
	
	@Size(max = 50)
	@Column(name = "isrm_head_userid")
	private String isrmheaduserid;
	
	@Size(max = 50)
	@Column(name = "isrm_head_username")
	private String isrmheadusername;
	
	@Size(max = 50)
	@Column(name = "isrm_head_status")
	private String isrmheadstatus;
	
	@Column(name = "isrm_head_sub_date")
	private Timestamp isrmheadsubdate;
	
	@Size(max = 255)
	@Column(name = "isrm_head_cmnt")
	private String isrmheadcmnt;
	
	@Size(max = 50)
	@Column(name = "cito_userid")
	private String citouserid;
	
	@Size(max = 50)
	@Column(name = "cito_username")
	private String citousername;
	
	@Size(max = 50)
	@Column(name = "cito_status")
	private String citostatus;
	
	@Column(name = "cito_sub_date")
	private Timestamp citosubdate;
	
	@Size(max = 255)
	@Column(name = "cito_cmnt")
	private String citocmnt;
	
	@Size(max = 50)
	@Column(name = "impl_by_unithead_userid")
	private String implbyunitheaduserid;
	
	@Size(max = 50)
	@Column(name = "impl_by_unithead_username")
	private String implbyunitheadusername;
	
	@Size(max = 50)
	@Column(name = "impl_by_unithead_status")
	private String implbyunitheadstatus;
	
	@Size(max = 255)
	@Column(name = "impl_by_unithead_cmnt")
	private String implbyunitheadcmnt;
	
	@Column(name = "impl_by_unithead_sub_date")
	private Timestamp implbyunitheadsubdate;
	
	@Size(max = 50)
	@Column(name = "implemented_by_userid")
	private String implementedbyuserid;
	
	@Size(max = 50)
	@Column(name = "implemented_by_username")
	private String implementedbyusername;
	
	@Size(max = 50)
	@Column(name = "implemented_by_status")
	private String implementedbystatus;
	
	@Column(name = "implemented_by_sub_date")
	private Timestamp implementedbysubdate;
	
	@Column(name = "implemented_by_dept_id")
	private Integer implementedbydeptid;
	
	@Column(name = "branch_code")
	private String branchCode;
	
	@Column(name = "department")
	private String department;

	public CreateEmail() {
		
	}

	public CreateEmail(Long id, String formid, String userid, String referenceValue, String action, String grpemail, String branchCode,
			String displayname, String emailadd, String purpose, String confemail, String grpallot, Date submitdate, String department,
			Timestamp submittime, String unitheaduserid, String unitheadusername, String unitheadstatus, Timestamp unitheadsubdate, 
			String unitheadcmnt,String isrmheaduserid, String isrmheadusername, String isrmheadstatus, Timestamp isrmheadsubdate, String isrmheadcmnt,
			String citouserid, String citousername, String citostatus, Timestamp citosubdate, String citocmnt, String implbyunitheaduserid,
			String implbyunitheadusername, String implbyunitheadstatus, String implbyunitheadcmnt, Timestamp implbyunitheadsubdate,
			String implementedbyuserid, String implementedbyusername, String implementedbystatus, Timestamp implementedbysubdate, Integer implementedbydeptid) {
		super();
		this.id = id;
		this.formid = formid;
		this.userid = userid;
		this.referenceValue = referenceValue;
		this.action = action;
		this.grpemail = grpemail;
		this.displayname = displayname;
		this.emailadd = emailadd;
		this.purpose = purpose;
		this.confemail = confemail;
		this.grpallot = grpallot;
		this.submitdate = submitdate;
		this.submittime = submittime;
		this.unitheaduserid = unitheaduserid;
		this.unitheadusername = unitheadusername;
		this.unitheadstatus = unitheadstatus;
		this.unitheadsubdate = unitheadsubdate;
		this.unitheadcmnt = unitheadcmnt;
		this.isrmheaduserid = isrmheaduserid;
		this.isrmheadusername = isrmheadusername;
		this.isrmheadstatus = isrmheadstatus;
		this.isrmheadsubdate = isrmheadsubdate;
		this.isrmheadcmnt = isrmheadcmnt;
		this.citouserid = citouserid;
		this.citousername = citousername;
		this.citostatus = citostatus;
		this.citosubdate = citosubdate;
		this.citocmnt = citocmnt;
		this.implbyunitheaduserid = implbyunitheaduserid;
		this.implbyunitheadusername = implbyunitheadusername;
		this.implbyunitheadstatus = implbyunitheadstatus;
		this.implbyunitheadcmnt = implbyunitheadcmnt;
		this.implbyunitheadsubdate = implbyunitheadsubdate;
		this.implementedbyuserid = implementedbyuserid;
		this.implementedbyusername = implementedbyusername;
		this.implementedbystatus = implementedbystatus;
		this.implementedbysubdate = implementedbysubdate;
		this.implementedbydeptid = implementedbydeptid;
		this.branchCode = branchCode;
		this.department = department;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFormid() {
		return formid;
	}

	public void setFormid(String formid) {
		this.formid = formid;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}



	public String getReferenceValue() {
		return referenceValue;
	}

	public void setReferenceValue(String referenceValue) {
		this.referenceValue = referenceValue;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getGrpemail() {
		return grpemail;
	}

	public void setGrpemail(String grpemail) {
		this.grpemail = grpemail;
	}

	public String getDisplayname() {
		return displayname;
	}

	public void setDisplayname(String displayname) {
		this.displayname = displayname;
	}

	public String getEmailadd() {
		return emailadd;
	}

	public void setEmailadd(String emailadd) {
		this.emailadd = emailadd;
	}

	public String getPurpose() {
		return purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public String getConfemail() {
		return confemail;
	}

	public void setConfemail(String confemail) {
		this.confemail = confemail;
	}

	public String getGrpallot() {
		return grpallot;
	}

	public void setGrpallot(String grpallot) {
		this.grpallot = grpallot;
	}

	public Date getSubmitdate() {
		return submitdate;
	}

	public void setSubmitdate(Date submitdate) {
		this.submitdate = submitdate;
	}

	public Timestamp getSubmittime() {
		return submittime;
	}

	public void setSubmittime(Timestamp submittime) {
		this.submittime = submittime;
	}

	public String getUnitheaduserid() {
		return unitheaduserid;
	}

	public void setUnitheaduserid(String unitheaduserid) {
		this.unitheaduserid = unitheaduserid;
	}

	public String getUnitheadusername() {
		return unitheadusername;
	}

	public void setUnitheadusername(String unitheadusername) {
		this.unitheadusername = unitheadusername;
	}

	public String getUnitheadstatus() {
		return unitheadstatus;
	}

	public void setUnitheadstatus(String unitheadstatus) {
		this.unitheadstatus = unitheadstatus;
	}

	public Timestamp getUnitheadsubdate() {
		return unitheadsubdate;
	}

	public void setUnitheadsubdate(Timestamp unitheadsubdate) {
		this.unitheadsubdate = unitheadsubdate;
	}

	public String getUnitheadcmnt() {
		return unitheadcmnt;
	}

	public void setUnitheadcmnt(String unitheadcmnt) {
		this.unitheadcmnt = unitheadcmnt;
	}

	public String getIsrmheaduserid() {
		return isrmheaduserid;
	}

	public void setIsrmheaduserid(String isrmheaduserid) {
		this.isrmheaduserid = isrmheaduserid;
	}

	public String getIsrmheadusername() {
		return isrmheadusername;
	}

	public void setIsrmheadusername(String isrmheadusername) {
		this.isrmheadusername = isrmheadusername;
	}

	public String getIsrmheadstatus() {
		return isrmheadstatus;
	}

	public void setIsrmheadstatus(String isrmheadstatus) {
		this.isrmheadstatus = isrmheadstatus;
	}

	public Timestamp getIsrmheadsubdate() {
		return isrmheadsubdate;
	}

	public void setIsrmheadsubdate(Timestamp isrmheadsubdate) {
		this.isrmheadsubdate = isrmheadsubdate;
	}

	public String getIsrmheadcmnt() {
		return isrmheadcmnt;
	}

	public void setIsrmheadcmnt(String isrmheadcmnt) {
		this.isrmheadcmnt = isrmheadcmnt;
	}

	public String getCitouserid() {
		return citouserid;
	}

	public void setCitouserid(String citouserid) {
		this.citouserid = citouserid;
	}

	public String getCitousername() {
		return citousername;
	}

	public void setCitousername(String citousername) {
		this.citousername = citousername;
	}

	public String getCitostatus() {
		return citostatus;
	}

	public void setCitostatus(String citostatus) {
		this.citostatus = citostatus;
	}

	public Timestamp getCitosubdate() {
		return citosubdate;
	}

	public void setCitosubdate(Timestamp citosubdate) {
		this.citosubdate = citosubdate;
	}

	public String getCitocmnt() {
		return citocmnt;
	}

	public void setCitocmnt(String citocmnt) {
		this.citocmnt = citocmnt;
	}

	public String getImplbyunitheaduserid() {
		return implbyunitheaduserid;
	}

	public void setImplbyunitheaduserid(String implbyunitheaduserid) {
		this.implbyunitheaduserid = implbyunitheaduserid;
	}

	public String getImplbyunitheadusername() {
		return implbyunitheadusername;
	}

	public void setImplbyunitheadusername(String implbyunitheadusername) {
		this.implbyunitheadusername = implbyunitheadusername;
	}

	public String getImplbyunitheadstatus() {
		return implbyunitheadstatus;
	}

	public void setImplbyunitheadstatus(String implbyunitheadstatus) {
		this.implbyunitheadstatus = implbyunitheadstatus;
	}

	public String getImplbyunitheadcmnt() {
		return implbyunitheadcmnt;
	}

	public void setImplbyunitheadcmnt(String implbyunitheadcmnt) {
		this.implbyunitheadcmnt = implbyunitheadcmnt;
	}

	public Timestamp getImplbyunitheadsubdate() {
		return implbyunitheadsubdate;
	}

	public void setImplbyunitheadsubdate(Timestamp implbyunitheadsubdate) {
		this.implbyunitheadsubdate = implbyunitheadsubdate;
	}

	public String getImplementedbyuserid() {
		return implementedbyuserid;
	}

	public void setImplementedbyuserid(String implementedbyuserid) {
		this.implementedbyuserid = implementedbyuserid;
	}

	public String getImplementedbyusername() {
		return implementedbyusername;
	}

	public void setImplementedbyusername(String implementedbyusername) {
		this.implementedbyusername = implementedbyusername;
	}

	public String getImplementedbystatus() {
		return implementedbystatus;
	}

	public void setImplementedbystatus(String implementedbystatus) {
		this.implementedbystatus = implementedbystatus;
	}

	public Timestamp getImplementedbysubdate() {
		return implementedbysubdate;
	}

	public void setImplementedbysubdate(Timestamp implementedbysubdate) {
		this.implementedbysubdate = implementedbysubdate;
	}

	public Integer getImplementedbydeptid() {
		return implementedbydeptid;
	}

	public void setImplementedbydeptid(Integer implementedbydeptid) {
		this.implementedbydeptid = implementedbydeptid;
	}
	
	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	
	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

}
