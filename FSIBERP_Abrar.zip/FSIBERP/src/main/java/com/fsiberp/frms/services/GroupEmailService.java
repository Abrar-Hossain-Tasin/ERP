package com.fsiberp.frms.services;

import java.sql.Timestamp;

import com.fsiberp.frms.model.GroupEmail;
import com.fsiberp.frms.model.StatusUpdateRequest;

public interface GroupEmailService {
	
	GroupEmail createForm(GroupEmail groupEmail);
	GroupEmail saveForm(GroupEmail form);
	GroupEmail updateStatus(Long id, String userid, StatusUpdateRequest request, Timestamp currentTimestamp);

}
