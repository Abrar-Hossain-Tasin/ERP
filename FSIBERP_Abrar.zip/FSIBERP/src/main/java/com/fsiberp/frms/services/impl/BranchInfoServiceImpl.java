package com.fsiberp.frms.services.impl;

import com.fsiberp.frms.model.BranchInfo;
import com.fsiberp.frms.repository.BranchInfoRepository;
import com.fsiberp.frms.services.BranchInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BranchInfoServiceImpl implements BranchInfoService {

    @Autowired
    private BranchInfoRepository branchInfoRepository;

    @Override
    public List<BranchInfo> getAllBranches() {
        return branchInfoRepository.findAll();
    }
}
