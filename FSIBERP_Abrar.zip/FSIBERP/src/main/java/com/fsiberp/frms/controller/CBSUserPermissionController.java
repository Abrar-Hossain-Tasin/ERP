package com.fsiberp.frms.controller;

import com.fsiberp.frms.model.BranchInfo;
import com.fsiberp.frms.model.CBSUserPermission;
import com.fsiberp.frms.model.CBSUserProfile;
import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.CBSUserPermissionRepository;
import com.fsiberp.frms.services.BranchInfoService;
import com.fsiberp.frms.services.CBSUserPermissionService;
import com.fsiberp.frms.services.ProfileService;

import jakarta.validation.Valid;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/cbs-user-permission/")
public class CBSUserPermissionController {

    private final CBSUserPermissionService cbsUserPermissionService;
    private ProfileService profileService;
    private CBSUserPermissionRepository cbsUserPermissionRepository;
    private final RestTemplate restTemplate;
    private final BranchInfoService branchInfoService;


    public CBSUserPermissionController(CBSUserPermissionService cbsUserPermissionService, ProfileService profileService,
            CBSUserPermissionRepository cbsUserPermissionRepository, RestTemplate restTemplate, BranchInfoService branchInfoService) {
        this.cbsUserPermissionService = cbsUserPermissionService;
        this.profileService = profileService;
        this.cbsUserPermissionRepository = cbsUserPermissionRepository;
        this.restTemplate = restTemplate;
        this.branchInfoService = branchInfoService;
    }
    
	@GetMapping("view/{id}")
    public ResponseEntity<User> showForms(@PathVariable("id") String userid){
        User user = profileService.getUserByUserid(userid);
        return new ResponseEntity<>(user, HttpStatus.OK);
    }
	
	@GetMapping("profileid/{id}")
	public ResponseEntity<List<CBSUserProfile>> viewProfile(@PathVariable("id") String userid) {
		
	    String url = "http://localhost:8083/api/cbs/" + userid;
	    User user = profileService.getUserByUserid(userid);
	    
	    ResponseEntity<List<CBSUserProfile>> response = restTemplate.exchange(
	        url, HttpMethod.GET, null, new ParameterizedTypeReference<List<CBSUserProfile>>() {});

	    if (response.getBody() == null || response.getBody().isEmpty()) {
	        return new ResponseEntity<>(null, HttpStatus.OK);
	    }
	    
	    List<CBSUserProfile> profiles = response.getBody();
	    for (CBSUserProfile profile : profiles) {
	    		profile.setBranchid(user.getBranchcode());
	    		profile.setUserdesig(user.getDesignation());
	    }
	    
	    return new ResponseEntity<>(response.getBody(), response.getStatusCode());
	}
	
	@GetMapping("userview/{id}")
    public List<CBSUserPermission> viewForms(@PathVariable("id") String userid){
		return cbsUserPermissionRepository.findByUseridAndIdIsMax(userid);
    }
	
	 @GetMapping("branches")
	    public ResponseEntity<List<BranchInfo>> getAllBranches() {
	        List<BranchInfo> branches = branchInfoService.getAllBranches();
	        
	        if (branches != null && !branches.isEmpty()) {
	            return ResponseEntity.ok(branches);
	        } else {
	            return ResponseEntity.noContent().build(); // Return HTTP 204 No Content if no branches are found
	        }
	    }
    
	 @GetMapping("divhead/{userid}")
	 public ResponseEntity<List<User>> getDivisionalHeads(@PathVariable String userid) {
	     List<User> divisionalHeads = cbsUserPermissionService.getDivisionalHeads(userid);
	     return ResponseEntity.ok(divisionalHeads);
	 }
    
    @PostMapping("save/{id}")
    public ResponseEntity<CBSUserPermission> saveUserPermission(@PathVariable("id") String userid, @RequestBody @Valid CBSUserPermission userPermission) {
        // Retrieve the user by ID
        User user = profileService.getUserByUserid(userid);

        userPermission.setFormid("2001");
        userPermission.setUserid(user.getUserid());

        userPermission.setUnitheadstatus("Pending");
        
        userPermission.setImplementedbystatus("Pending");
        userPermission.setImplementedbydeptid(2); 
        userPermission.setBranchCode(user.getBranchcode());
        
        if (user.getDepartment().equals("I C T Div., Head Office, Dhaka")) {
        	userPermission.setDepartment(user.getUnit());
        }
        else {        	
        	userPermission.setDepartment(user.getDepartment());
        }

        // Set submission date and time
        userPermission.setSubmitdate(new Date(System.currentTimeMillis()));
        userPermission.setSubmittime(new Timestamp(System.currentTimeMillis()));
        
        for (String bcd : userPermission.getGeneralBankingManagement()) {
        	if (bcd != null) {
        		userPermission.setBcduserid("2");
        		userPermission.setBcdstatus("Pending");
            	break;
        	}
        }
        
        for (String iad : userPermission.getInvestmentManagement()) {
        	if (iad != null) {
        		userPermission.setIaduserid("3");
        		userPermission.setIadstatus("Pending");
        		
        		userPermission.setImrduserid("12");
        		userPermission.setImrdstatus("Pending");
            	break;
        	}
        }
        
        for (String id : userPermission.getTradeFinanceManagement()) {
        	if (id != null) {
        		userPermission.setIduserid("19");
        		userPermission.setIdstatus("Pending");
            	break;
        	}
        }
        // Save the permission using the service
        CBSUserPermission savedUserPermission = cbsUserPermissionService.save(userPermission);

        return ResponseEntity.ok(savedUserPermission);
    }
    
    @PutMapping("update/{id}")
    public ResponseEntity<CBSUserPermission> updateUserPermission(
            @PathVariable("id") Long id,
            @RequestBody @Valid CBSUserPermission userPermission) {
        CBSUserPermission updatedPermission = cbsUserPermissionService.update(id, userPermission);
        
        if (updatedPermission != null) {
            return ResponseEntity.ok(updatedPermission);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                                 .body(null); 
        }
    }
    
}
