package com.fsiberp.frms.services;

import java.util.List;

import com.fsiberp.frms.model.User;

public interface ProfileService {
	
    User createUser(User user);
    User getUserByUserid(String userid);
    List<User> getAllUnitUsers(String unit);    
    List<User> getAllUsers();
    User updateUser(User user);
    void deleteUser(Long userId);
}
