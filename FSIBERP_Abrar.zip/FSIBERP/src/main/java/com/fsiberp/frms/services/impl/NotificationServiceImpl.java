package com.fsiberp.frms.services.impl;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.fsiberp.frms.model.Notification;
import com.fsiberp.frms.repository.NotificationRepository;
import com.fsiberp.frms.services.NotificationService;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.transaction.Transactional;

@Service
public class NotificationServiceImpl implements NotificationService {

    private final NotificationRepository notificationRepository;
    private final EntityManager entityManager;

    public NotificationServiceImpl(NotificationRepository notificationRepository, EntityManager entityManager ) {
        this.notificationRepository = notificationRepository;
        this.entityManager = entityManager;
    }

    @Override
    public Notification createNotification(String userid, String message, String fuserid, String formid, Long submissionId, boolean viewed) {
        Notification notification = new Notification();
        notification.setUserid(userid);
        notification.setMessage(message);
        notification.setFuserid(fuserid);
        notification.setFormid(formid);
        notification.setSubmissionId(submissionId);
        notification.setViewed(viewed);
        return notificationRepository.save(notification);
    }

    
    @Override
    public List<Notification> getNotifications(String userid) {
        // Fetch all notifications for the user, regardless of viewed status
        return notificationRepository.findByUserid(userid);
    }
    
    @Override
    public void markAsViewed(Long id) {
        Notification notification = notificationRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Notification not found"));
        notification.setViewed(true);
        notificationRepository.save(notification);
    }

    @Override
    public boolean areNotificationsViewed(String formId) {
        List<Notification> notifications = notificationRepository.findByFormid(formId);
        return notifications.stream().allMatch(Notification::isViewed);
    }
    
    public void markNotificationsAsViewedForUserAndForm(String userid, String formId) {
        List<Notification> notifications = notificationRepository.findByUseridAndFormid(userid, formId);
        for (Notification notification : notifications) {
            notification.setViewed(true);
            notificationRepository.save(notification);
        }
    }
    
    @Override
    public void markNotificationsAsViewedForUserAndForm(String userid, String formid, Long submissionId) {
        List<Notification> notifications = notificationRepository.findByUseridAndFormidAndSubmissionId(userid, formid, submissionId);
        for (Notification notification : notifications) {
            notification.setViewed(true); // Mark notification as viewed
        }
        notificationRepository.saveAll(notifications); // Save changes to the notifications
    }
    
    @Override
    @Transactional
    @Scheduled(cron = "0 0 0 */30 * ?") // Runs at midnight every 30 days
    
    public void archiveOldNotifications() {
        // Move notifications older than 30 days to archived_notifications
        String moveQuery = "INSERT INTO sys_notifications_archive (id, created_at, message, userid, viewed, formid, fuserid, submission_id) " +
                           "SELECT id, created_at, message, userid, viewed, formid, fuserid, submission_id " +
                           "FROM sys_notifications " +
                           "WHERE created_at < NOW() - INTERVAL '30 days'";

        // Execute the move operation
        Query moveToArchive = entityManager.createNativeQuery(moveQuery);
        int movedRows = moveToArchive.executeUpdate();
        System.out.println("Moved " + movedRows + " notifications to archived_notifications.");

        // Delete old notifications after moving them
        String deleteQuery = "DELETE FROM sys_notifications WHERE created_at < NOW() - INTERVAL '30 days'";
        Query deleteOldNotifications = entityManager.createNativeQuery(deleteQuery);
        int deletedRows = deleteOldNotifications.executeUpdate();
        System.out.println("Deleted " + deletedRows + " old notifications from sys_notifications.");
    }
}


