package com.fsiberp.frms.model;

import java.sql.Timestamp;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class ListView {
	
	@Id
	private Long id;
	private String formid;
	private String formname;
	private String userid;
	private String username;
	private String unitheadstatus;
	private String gsdheadstatus;
	private String isrmheadstatus;
	private String citostatus;
	private Timestamp submittime;
	private String branchcode;
	private String networkheadstatus;
	

	public ListView(Long id, String formid, String formname, String userid, String username, String unitheadstatus, String networkheadstatus,
			String gsdheadstatus, String isrmheadstatus, String citostatus, Timestamp submittime,String branchcode) {
		super();
		this.id = id;
		this.formid = formid;
		this.formname = formname;
		this.userid = userid;
		this.username = username;
		this.unitheadstatus = unitheadstatus;
		this.gsdheadstatus = gsdheadstatus;
		this.isrmheadstatus = isrmheadstatus;
		this.citostatus = citostatus;
		this.submittime = submittime;
		this.branchcode = branchcode;
		this.networkheadstatus = networkheadstatus;
	}

	public ListView() {
		
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFormid() {
		return formid;
	}

	public void setFormid(String formid) {
		this.formid = formid;
	}

	public String getFormname() {
		return formname;
	}

	public void setFormname(String formname) {
		this.formname = formname;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUnitheadstatus() {
		return unitheadstatus;
	}

	public void setUnitheadstatus(String unitheadstatus) {
		this.unitheadstatus = unitheadstatus;
	}

	public String getGsdheadstatus() {
		return gsdheadstatus;
	}

	public void setGsdheadstatus(String gsdheadstatus) {
		this.gsdheadstatus = gsdheadstatus;
	}

	public String getIsrmheadstatus() {
		return isrmheadstatus;
	}

	public void setIsrmheadstatus(String isrmheadstatus) {
		this.isrmheadstatus = isrmheadstatus;
	}

	public String getCitostatus() {
		return citostatus;
	}

	public void setCitostatus(String citostatus) {
		this.citostatus = citostatus;
	}

	public Timestamp getSubmittime() {
		return submittime;
	}

	public void setSubmittime(Timestamp submittime) {
		this.submittime = submittime;
	}

	public String getBranchcode() {
		return branchcode;
	}

	public void setBranchcode(String branchcode) {
		this.branchcode = branchcode;
	}

	public String getNetworkheadstatus() {
		return networkheadstatus;
	}

	public void setNetworkheadstatus(String networkheadstatus) {
		this.networkheadstatus = networkheadstatus;
	}

}
