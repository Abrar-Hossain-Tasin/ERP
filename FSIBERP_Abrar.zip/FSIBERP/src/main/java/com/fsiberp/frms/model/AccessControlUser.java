package com.fsiberp.frms.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "sys_access_control_user")
public class AccessControlUser {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "user_id")
    private String userid;
    
    @Column(name = "user_name")
    private String username;
    
    @Column(name = "branch_code")
    private String branchcode;
    
    @Column(name = "department")
    private String department;
    
    @Column(name = "unit")
    private String unit;

	public AccessControlUser() {
		super();
	}

	public AccessControlUser(Long id, String userid, String username, String branchcode, String department,
			String unit) {
		super();
		this.id = id;
		this.userid = userid;
		this.username = username;
		this.branchcode = branchcode;
		this.department = department;
		this.unit = unit;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getBranchcode() {
		return branchcode;
	}

	public void setBranchcode(String branchcode) {
		this.branchcode = branchcode;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

}
