package com.fsiberp.frms.services.impl;

public class FunctionalRoleServiceImpl {

}
