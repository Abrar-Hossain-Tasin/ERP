package com.fsiberp.frms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fsiberp.frms.model.IctDepartment;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface IctDepartmentRepository extends JpaRepository<IctDepartment, Long>{
	IctDepartment findByDeptname(String deptname);
	Optional<IctDepartment> findById(Integer integer);
}
