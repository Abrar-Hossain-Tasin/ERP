package com.fsiberp.frms.services.impl;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.stereotype.Service;

import com.fsiberp.frms.model.CreateEmail;
import com.fsiberp.frms.model.FunctionalRole;
import com.fsiberp.frms.model.IctDepartment;
import com.fsiberp.frms.model.StatusUpdateRequest;
import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.AuthRepository;
import com.fsiberp.frms.repository.CreateEmailRepository;
import com.fsiberp.frms.repository.FunctionalRoleRepository;
import com.fsiberp.frms.repository.IctDepartmentRepository;
import com.fsiberp.frms.repository.ProfileRepository;
import com.fsiberp.frms.services.CreateEmailService;
import com.fsiberp.frms.services.EmailService;
import com.fsiberp.frms.services.NotificationService;
import com.fsiberp.frms.services.ProfileService;

import jakarta.transaction.Transactional;

@Service
public class CreateEmailServiceImpl implements CreateEmailService {
	
    private final FunctionalRoleRepository functionalRoleRepository;
    private final NotificationService notificationService; // Added NotificationService
    private final ProfileRepository profileRepository;
    private final ProfileService profileService;
    private final CreateEmailRepository createEmailRepository;
    private final AuthRepository authRepository;
    private final IctDepartmentRepository ictDepartmentRepository;
    private final EmailService emailService;
    
    // Constructor updated to include NotificationService
    public CreateEmailServiceImpl(FunctionalRoleRepository functionalRoleRepository,CreateEmailRepository createEmailRepository,
        NotificationService notificationService, ProfileRepository profileRepository, ProfileService profileService,
        AuthRepository authRepository, IctDepartmentRepository ictDepartmentRepository, EmailService emailService) {
        this.functionalRoleRepository = functionalRoleRepository;
        this.notificationService = notificationService;
        this.profileRepository = profileRepository;
        this.profileService = profileService;
        this.createEmailRepository = createEmailRepository;
        this.authRepository = authRepository;
        this.ictDepartmentRepository = ictDepartmentRepository;
        this.emailService = emailService;
    }
    
    @Override
    public CreateEmail createForm(CreateEmail createEmail) {
    	CreateEmail savedForm = createEmailRepository.save(createEmail);
        if (createEmail.getUnitheaduserid() != null) {
           
        	User user = profileService.getUserByUserid(createEmail.getUserid());
            String username = user != null ? user.getUsername() : "Unknown User";

    
            notificationService.createNotification(createEmail.getUnitheaduserid(),
					"A new Email request has been submitted by " + username + " (" + createEmail.getUserid() + ").",
					createEmail.getUserid(),
                createEmail.getFormid(), 
                createEmail.getId(),     
                false                    
            );
        }
        return savedForm;
    }

    @Transactional
    public CreateEmail saveForm(CreateEmail form) {
        // Save the form temporarily to generate the ID
    	CreateEmail savedForm = createEmailRepository.save(form);

        // Generate the reference value using the generated ID
        String currentYear = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        String paddedSubmissionId = String.format("%05d", savedForm.getId()); // Padded with zeros
        String referenceValue = currentYear + "-1004/" + paddedSubmissionId;

        // Set the reference value
        savedForm.setReferenceValue(referenceValue);

        // Save the form again with the reference value
        savedForm = createEmailRepository.save(savedForm);

        // Trigger notification for the unit head if the userid is set
        if (savedForm.getUnitheaduserid() != null) {
            User user = profileService.getUserByUserid(savedForm.getUserid());
            String username = user != null ? user.getUsername() : "Unknown User";

            
            notificationService.createNotification(savedForm.getUnitheaduserid(),
					"A new Email request has been submitted by " + username + " (" + savedForm.getUserid() + ").",
					savedForm.getUserid(),
                savedForm.getFormid(), 
                savedForm.getId(),     
                false                    
            );
            
//            unit head email
		          emailService.sendNotificationEmail(user,savedForm.getUnitheaduserid(),1);
        }

        return savedForm;
    }
    
    @Override
    public CreateEmail updateStatus(Long id, String userid, StatusUpdateRequest request, Timestamp currentTimestamp) {
        // Find the form by ID
        CreateEmail createEmail = createEmailRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Form not found"));

     

        // Unit Head status update logic
        if ("Pending".equals(createEmail.getUnitheadstatus()) || 
            "Rejected".equals(createEmail.getUnitheadstatus()) || 
            createEmail.getUnitheadstatus() == null) {


			// Fetch the user's information
			User user = profileService.getUserByUserid(userid);
//			String username = user != null ? user.getUsername() : "Unknown User";
			
        	
            createEmail.setUnitheadstatus(request.getStatus());
            createEmail.setUnitheadcmnt(request.getComment());
            createEmail.setUnitheadsubdate(currentTimestamp);

            notificationService.createNotification(
                createEmail.getUserid(),
                "Your Email request was " + request.getStatus().toLowerCase() + 
                " by Unit Head " + createEmail.getUnitheadusername() + " (" + createEmail.getUnitheaduserid() + ")",
                createEmail.getUserid(),
                createEmail.getFormid(),
                createEmail.getId(),
                false // Not viewed by default
            );

            if ("Accepted".equalsIgnoreCase(request.getStatus())) {
            	User formSubmitter = profileService.getUserByUserid(createEmail.getUserid());
				String deptName = formSubmitter != null ? formSubmitter.getDepartment() : "Unknown Branch";
				String branchCode = formSubmitter != null ? formSubmitter.getBranchcode() : "Unknown Code";

                notificationService.createNotification(
                    createEmail.getIsrmheaduserid(),
                    "A new Email request from " + formSubmitter.getUsername() + "(" + formSubmitter.getUserid()  + "), " + deptName + " (" + branchCode + ") requires your approval.",
                    createEmail.getUserid(),
                    createEmail.getFormid(),
                    createEmail.getId(),
                    false
                );
                
//                isrm head email
                emailService.sendNotificationEmail(user,createEmail.getIsrmheaduserid(),1);
            }

        // ISRM status update logic
        } else if ("Accepted".equalsIgnoreCase(createEmail.getUnitheadstatus()) && 
                   "Pending".equalsIgnoreCase(createEmail.getIsrmheadstatus())) {
            FunctionalRole functionalRole = functionalRoleRepository.findByUserid(userid)
                    .orElseThrow(() -> new NoSuchElementException("No such user role found"));

            if ("isrm".equalsIgnoreCase(functionalRole.getFunctionalrole())) {
                createEmail.setIsrmheadstatus(request.getStatus());
                createEmail.setIsrmheadcmnt(request.getComment());
                createEmail.setIsrmheadsubdate(currentTimestamp);

                notificationService.createNotification(
                    createEmail.getUserid(),
                    "Your Email request was " + request.getStatus().toLowerCase() + 
                    " by ISRM Head " + createEmail.getIsrmheadusername() + " (" + createEmail.getIsrmheaduserid() + ").",
                    createEmail.getUserid(),
                    createEmail.getFormid(),
                    createEmail.getId(),
                    false // Not viewed by default
                );

                if ("Accepted".equalsIgnoreCase(request.getStatus())) {
                    User user = profileService.getUserByUserid(createEmail.getUserid());
//                    String username = user != null ? user.getUsername() : "Unknown User";

            		User formSubmitter = profileService.getUserByUserid(createEmail.getUserid());
    				String deptName = formSubmitter != null ? formSubmitter.getDepartment() : "Unknown Branch";
    				String branchCode = formSubmitter != null ? formSubmitter.getBranchcode() : "Unknown Code";
                    
                    notificationService.createNotification(
                        createEmail.getCitouserid(),
                        "A new Email request from " + formSubmitter.getUsername() + "(" + formSubmitter.getUserid()  + "), " + deptName + " (" + branchCode + ") requires your approval.",
                        createEmail.getUserid(),
                        createEmail.getFormid(),
                        createEmail.getId(),
                        false
                    );
                    
//                    cito email
                    emailService.sendNotificationEmail(user,createEmail.getCitouserid(),1);
                }
            }

        // CITO status update logic
        } else if ("Accepted".equalsIgnoreCase(createEmail.getIsrmheadstatus()) && 
                   "Pending".equalsIgnoreCase(createEmail.getCitostatus())) {
            FunctionalRole functionalRole = functionalRoleRepository.findByUserid(userid)
                    .orElseThrow(() -> new NoSuchElementException("No such user role found"));

            if ("cito".equalsIgnoreCase(functionalRole.getFunctionalrole())) {
                createEmail.setCitostatus(request.getStatus());
                createEmail.setCitocmnt(request.getComment());
                createEmail.setCitosubdate(currentTimestamp);

                notificationService.createNotification(
                    createEmail.getUserid(),
                    "Your Email request was " + request.getStatus().toLowerCase() + 
                    " by CITO " + createEmail.getCitousername() + " (" + createEmail.getCitouserid() + ").",
                    createEmail.getUserid(),
                    createEmail.getFormid(),
                    createEmail.getId(),
                    false // Not viewed by default
                );

                if ("Accepted".equalsIgnoreCase(request.getStatus())) {
                    User user = profileService.getUserByUserid(createEmail.getUserid());
//                    String username = user != null ? user.getUsername() : "Unknown User";

            		User formSubmitter = profileService.getUserByUserid(createEmail.getUserid());
    				String deptName = formSubmitter != null ? formSubmitter.getDepartment() : "Unknown Branch";
    				String branchCode = formSubmitter != null ? formSubmitter.getBranchcode() : "Unknown Code";
                    
                    notificationService.createNotification(
                        createEmail.getImplbyunitheaduserid(),
                        "A new Email request from " + formSubmitter.getUsername() + "(" + formSubmitter.getUserid()  + "), " + deptName + " (" + branchCode + ") requires your approval.",
                        createEmail.getUserid(),
                        createEmail.getFormid(),
                        createEmail.getId(),
                        false // Not viewed by default
                    );
                    
//                    impl unit head email
                    emailService.sendNotificationEmail(user,createEmail.getImplbyunitheaduserid(),1);
                }
            }

        // Implementation Head status update logic
        } else if ("Accepted".equalsIgnoreCase(createEmail.getCitostatus()) && 
                   "Pending".equalsIgnoreCase(createEmail.getImplbyunitheadstatus())) {
            createEmail.setImplbyunitheadstatus(request.getStatus());
            createEmail.setImplbyunitheadcmnt(request.getComment());
            createEmail.setImplbyunitheadsubdate(currentTimestamp);

            notificationService.createNotification(
                createEmail.getUserid(),
                "Your Email request was " + request.getStatus().toLowerCase() + 
                " by the head of the implementers unit " + createEmail.getImplbyunitheadusername() + " (" + createEmail.getImplbyunitheaduserid() + ").",
                createEmail.getUserid(),
                createEmail.getFormid(),
                createEmail.getId(),
                false // Not viewed by default
            );

            if ("Accepted".equalsIgnoreCase(request.getStatus())) {
            	
            	User formSubmitter = profileService.getUserByUserid(createEmail.getUserid());
				String deptName = formSubmitter != null ? formSubmitter.getDepartment() : "Unknown Branch";
				String branchCode = formSubmitter != null ? formSubmitter.getBranchcode() : "Unknown Code";

            	
                // Notify the System Administration Unit
                List<User> systemAdmins = profileRepository.findByUnitAndRoleid("System Administration Unit", 3);
                for (User sysAdmin : systemAdmins) {
                    notificationService.createNotification(
                        sysAdmin.getUserid(),
                        "A new Email request from " + formSubmitter.getUsername() + "(" + formSubmitter.getUserid()  + "), " + deptName + " (" + branchCode + ") requires your approval.",
                        createEmail.getUserid(),
                        createEmail.getFormid(),
                        createEmail.getId(),
                        false
                    );
                }
                
//                dept email
                
                    User userinfo = authRepository.findByUserid(createEmail.getUserid()).orElse(null);
	                IctDepartment existingUser = ictDepartmentRepository.findById(createEmail.getImplementedbydeptid()).orElse(null);
	                emailService.sendNotificationEmailForDept(userinfo, existingUser.getDeptmail(),1);
            }

        // Final implementation step
        } else if ("Done".equalsIgnoreCase(request.getStatus())) {
            User user = profileRepository.findByUserid(userid)
                    .orElseThrow(() -> new NoSuchElementException("No such user found"));

            createEmail.setImplementedbystatus(request.getStatus());
            createEmail.setConfemail(request.getComment());
            createEmail.setGrpallot(request.getComment2());
            createEmail.setImplementedbyuserid(userid);
            createEmail.setImplementedbyusername(user.getUsername());
            createEmail.setImplementedbysubdate(currentTimestamp);

            notificationService.createNotification(
                createEmail.getUserid(),
                "Your Email request has been fully completed by " + 
                createEmail.getImplementedbyusername() + " (" + createEmail.getImplementedbyuserid() + ").",
                createEmail.getUserid(),
                createEmail.getFormid(),
                createEmail.getId(),
                false // Not viewed (false)
            );

            if ("Accepted".equalsIgnoreCase(createEmail.getImplbyunitheadstatus())) {
                List<User> systemAdmins = profileRepository.findByUnitAndRoleid("System Administration Unit", 3);

                for (User sysAdmin : systemAdmins) {
                    notificationService.markNotificationsAsViewedForUserAndForm(
                        sysAdmin.getUserid(), createEmail.getFormid(), createEmail.getId() 
                    );
                }
            }
            
//            user email
            
	            User userinfo = authRepository.findByUserid(createEmail.getUserid()).orElse(null);
	            emailService.sendNotificationEmailForUser(userinfo, createEmail.getUserid(),1);   	
        }

        // Save the updated createEmail object and return it
        return createEmailRepository.save(createEmail);
    }
}