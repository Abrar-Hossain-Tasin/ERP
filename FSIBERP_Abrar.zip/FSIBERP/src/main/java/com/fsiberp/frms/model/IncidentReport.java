package com.fsiberp.frms.model;

import java.sql.Date;
import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

	@Entity
	@Table(name = "form_incident_report")
	public class IncidentReport {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	    
	    @Column(name = "form_id")
	    private String formid;
	    
	    @NotBlank
	    @Size(max = 50)
	    @Column(name = "user_id")
	    private String userid;
	    

	    @Column(name = "priority")
	    private String priority;
    
	    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	    @Column(name = "incident_occurred")
	    private Timestamp incidentOccurred;
    
	    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	    @Column(name = "incident_resolved")
	    private Timestamp incidentResolved;
	    
	    @Column(name = "location_of_incident")
	    private String locationOfIncident;
	   
	    @Column(name = "incident_reported_by")
	    private String incidentReportedBy;
	    
	    @Column(name = "incident_handled_by")
	    private String[] incidentHandledBy;
	    
	    @Size(max = 50)
	    @Column(name = "unit_head_userid")
	    private String unitheaduserid;
	    
	    @Size(max = 50)
	    @Column(name = "unit_head_username")
	    private String unitheadusername;
	    
	    @Size(max = 50)
	    @Column(name = "unit_head_status")
	    private String unitheadstatus;
	    
	   
	    @Column(name = "unit_head_sub_date")
	    private Timestamp unitheadsubdate;
	    
	    @Size(max = 255)
	    @Column(name = "unit_head_cmnt")
	    private String unitheadcmnt;
	    
	    @Column(name = "witness")
	    private String[] witness;
	
	   
	    @Column(name = "name_of_the_incident")
	    private String nameOfTheIncident;
	    
	    @Column(name = "root_cause_of_incident")
	    private String rootCauseOfIncident;
    
	    @Column(name = "type_of_incident")
	    private String[] typeOfIncident;
	    
	    @Column(name = "potential_impact")
	    private String[] potentialImpact;
	  
	    @Column(name = "potential_impact_description")
	    private String potentialImpactDescription;
	    
	    @Column(name = "action_taken")
	    private String actionTaken;
	  
	    @Column(name = "prevention")
	    private String prevention;
	    
	    @Column(name = "proposed_solution")
	    private String proposedSolution;
	  
	    @Column(name = "lesson_learned")
	    private String lessonLearned;
	  
	  
	    @Column(name = "submit_date")
	    private Date submitdate;
	   
	    
	    @Size(max = 50)
	    @Column(name = "isrm_head_userid")
	    private String isrmheaduserid;
	    
	    @Size(max = 50)
	    @Column(name = "isrm_head_username")
	    private String isrmheadusername;
	    
	    @Size(max = 50)
	    @Column(name = "isrm_head_status")
	    private String isrmheadstatus;
	    
	  
	    @Column(name = "isrm_head_sub_date")
	    private Timestamp isrmheadsubdate;
	    
	    @Size(max = 255)
	    @Column(name = "isrm_head_cmnt")
	    private String isrmheadcmnt;
	    
	    @Size(max = 50)
	    @Column(name = "cito_userid")
	    private String citouserid;
	    
	    @Size(max = 50)
	    @Column(name = "cito_username")
	    private String citousername;
	    
	    @Size(max = 50)
	    @Column(name = "cito_status")
	    private String citostatus;
	    
	   
	    @Column(name = "cito_sub_date")
	    private Timestamp citosubdate;
	    
	    @Size(max = 255)
	    @Column(name = "cito_cmnt")
	    private String citocmnt;
	    
	    @Column(name = "submit_time")
		private Timestamp submittime;
	    
	    @Column(name = "incident_handling_documents_path")
	    private String incidentHandlingDocumentsPath;
	    
	    @Column(name = "impact_analysis_document_path")
	    private String  impactAnalysisDocumentPath;
	    
	    @Column(name = "downtime_documentation_path")
	    private String  downtimeDocumentationPath;
	    
	    @Column(name = "root_cause_analysis_documents_path")
	    private String rootCauseAnalysisDocumentsPath;
	    
	    @Column(name = "work_completion_document_path")
	    private String workCompletionDocumentPath;
	   
	    
	    @Transient
	    private String incidentHandlingDocumentsDownloadUrl;
	    
	    @Transient
	    private String impactAnalysisDocumentDownloadUrl;
	    
	    @Transient
	    private String downtimeDocumentationDownloadUrl;
	    
	    @Transient
	    private String rootCauseAnalysisDocumentsDownloadUrl;
		
	    @Transient
	    private String workCompletionDocumentDownloadUrl;
	    
		@Column(name = "ref")
		private String referenceValue; 
		
		@Column(name = "branch_code")
		private String branchCode;
		
		@Column(name = "department")
		private String department;
		
		public IncidentReport() {
			  
		  }

		public IncidentReport(Long id, String formid, @NotBlank @Size(max = 50) String userid, String priority,
				Timestamp incidentOccurred, Timestamp incidentResolved, String locationOfIncident,
				String incidentReportedBy, String[] incidentHandledBy, @Size(max = 50) String unitheaduserid,
				@Size(max = 50) String unitheadusername, @Size(max = 50) String unitheadstatus,
				Timestamp unitheadsubdate, @Size(max = 255) String unitheadcmnt, String[] witness,
				String nameOfTheIncident, String rootCauseOfIncident, String[] typeOfIncident, String[] potentialImpact,
				String potentialImpactDescription, String actionTaken, String prevention, String proposedSolution,
				String lessonLearned, Date submitdate, @Size(max = 50) String isrmheaduserid,
				@Size(max = 50) String isrmheadusername, @Size(max = 50) String isrmheadstatus,
				Timestamp isrmheadsubdate, @Size(max = 255) String isrmheadcmnt, @Size(max = 50) String citouserid,
				@Size(max = 50) String citousername, @Size(max = 50) String citostatus, Timestamp citosubdate,
				@Size(max = 255) String citocmnt, Timestamp submittime,
				String incidentHandlingDocumentsPath, String impactAnalysisDocumentPath,
				String downtimeDocumentationPath, String rootCauseAnalysisDocumentsPath,
				String workCompletionDocumentPath, String incidentHandlingDocumentsDownloadUrl,
				String impactAnalysisDocumentDownloadUrl, String downtimeDocumentationDownloadUrl,
				String rootCauseAnalysisDocumentsDownloadUrl, String workCompletionDocumentDownloadUrl,
				String referenceValue, String branchCode, String department) {
			super();
			this.id = id;
			this.formid = formid;
			this.userid = userid;
			this.priority = priority;
			this.incidentOccurred = incidentOccurred;
			this.incidentResolved = incidentResolved;
			this.locationOfIncident = locationOfIncident;
			this.incidentReportedBy = incidentReportedBy;
			this.incidentHandledBy = incidentHandledBy;
			this.unitheaduserid = unitheaduserid;
			this.unitheadusername = unitheadusername;
			this.unitheadstatus = unitheadstatus;
			this.unitheadsubdate = unitheadsubdate;
			this.unitheadcmnt = unitheadcmnt;
			this.witness = witness;
			this.nameOfTheIncident = nameOfTheIncident;
			this.rootCauseOfIncident = rootCauseOfIncident;
			this.typeOfIncident = typeOfIncident;
			this.potentialImpact = potentialImpact;
			this.potentialImpactDescription = potentialImpactDescription;
			this.actionTaken = actionTaken;
			this.prevention = prevention;
			this.proposedSolution = proposedSolution;
			this.lessonLearned = lessonLearned;
			this.submitdate = submitdate;
			this.isrmheaduserid = isrmheaduserid;
			this.isrmheadusername = isrmheadusername;
			this.isrmheadstatus = isrmheadstatus;
			this.isrmheadsubdate = isrmheadsubdate;
			this.isrmheadcmnt = isrmheadcmnt;
			this.citouserid = citouserid;
			this.citousername = citousername;
			this.citostatus = citostatus;
			this.citosubdate = citosubdate;
			this.citocmnt = citocmnt;
			this.submittime = submittime;
			this.incidentHandlingDocumentsPath = incidentHandlingDocumentsPath;
			this.impactAnalysisDocumentPath = impactAnalysisDocumentPath;
			this.downtimeDocumentationPath = downtimeDocumentationPath;
			this.rootCauseAnalysisDocumentsPath = rootCauseAnalysisDocumentsPath;
			this.workCompletionDocumentPath = workCompletionDocumentPath;
			this.incidentHandlingDocumentsDownloadUrl = incidentHandlingDocumentsDownloadUrl;
			this.impactAnalysisDocumentDownloadUrl = impactAnalysisDocumentDownloadUrl;
			this.downtimeDocumentationDownloadUrl = downtimeDocumentationDownloadUrl;
			this.rootCauseAnalysisDocumentsDownloadUrl = rootCauseAnalysisDocumentsDownloadUrl;
			this.workCompletionDocumentDownloadUrl = workCompletionDocumentDownloadUrl;
			this.referenceValue = referenceValue;
			this.branchCode = branchCode;
			this.department = department;
		}

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getFormid() {
			return formid;
		}

		public void setFormid(String formid) {
			this.formid = formid;
		}

		public String getUserid() {
			return userid;
		}

		public void setUserid(String userid) {
			this.userid = userid;
		}

		public String getPriority() {
			return priority;
		}

		public void setPriority(String priority) {
			this.priority = priority;
		}

		public Timestamp getIncidentOccurred() {
			return incidentOccurred;
		}

		public void setIncidentOccurred(Timestamp incidentOccurred) {
			this.incidentOccurred = incidentOccurred;
		}

		public Timestamp getIncidentResolved() {
			return incidentResolved;
		}

		public void setIncidentResolved(Timestamp incidentResolved) {
			this.incidentResolved = incidentResolved;
		}

		public String getLocationOfIncident() {
			return locationOfIncident;
		}

		public void setLocationOfIncident(String locationOfIncident) {
			this.locationOfIncident = locationOfIncident;
		}

		public String getIncidentReportedBy() {
			return incidentReportedBy;
		}

		public void setIncidentReportedBy(String incidentReportedBy) {
			this.incidentReportedBy = incidentReportedBy;
		}

		public String[] getIncidentHandledBy() {
			return incidentHandledBy;
		}

		public void setIncidentHandledBy(String[] incidentHandledBy) {
			this.incidentHandledBy = incidentHandledBy;
		}

		public String getUnitheaduserid() {
			return unitheaduserid;
		}

		public void setUnitheaduserid(String unitheaduserid) {
			this.unitheaduserid = unitheaduserid;
		}

		public String getUnitheadusername() {
			return unitheadusername;
		}

		public void setUnitheadusername(String unitheadusername) {
			this.unitheadusername = unitheadusername;
		}

		public String getUnitheadstatus() {
			return unitheadstatus;
		}

		public void setUnitheadstatus(String unitheadstatus) {
			this.unitheadstatus = unitheadstatus;
		}

		public Timestamp getUnitheadsubdate() {
			return unitheadsubdate;
		}

		public void setUnitheadsubdate(Timestamp unitheadsubdate) {
			this.unitheadsubdate = unitheadsubdate;
		}

		public String getUnitheadcmnt() {
			return unitheadcmnt;
		}

		public void setUnitheadcmnt(String unitheadcmnt) {
			this.unitheadcmnt = unitheadcmnt;
		}

		public String[] getWitness() {
			return witness;
		}

		public void setWitness(String[] witness) {
			this.witness = witness;
		}

		public String getNameOfTheIncident() {
			return nameOfTheIncident;
		}

		public void setNameOfTheIncident(String nameOfTheIncident) {
			this.nameOfTheIncident = nameOfTheIncident;
		}

		public String getRootCauseOfIncident() {
			return rootCauseOfIncident;
		}

		public void setRootCauseOfIncident(String rootCauseOfIncident) {
			this.rootCauseOfIncident = rootCauseOfIncident;
		}

		public String[] getTypeOfIncident() {
			return typeOfIncident;
		}

		public void setTypeOfIncident(String[] typeOfIncident) {
			this.typeOfIncident = typeOfIncident;
		}

		public String[] getPotentialImpact() {
			return potentialImpact;
		}

		public void setPotentialImpact(String[] potentialImpact) {
			this.potentialImpact = potentialImpact;
		}

		public String getPotentialImpactDescription() {
			return potentialImpactDescription;
		}

		public void setPotentialImpactDescription(String potentialImpactDescription) {
			this.potentialImpactDescription = potentialImpactDescription;
		}

		public String getActionTaken() {
			return actionTaken;
		}

		public void setActionTaken(String actionTaken) {
			this.actionTaken = actionTaken;
		}

		public String getPrevention() {
			return prevention;
		}

		public void setPrevention(String prevention) {
			this.prevention = prevention;
		}

		public String getProposedSolution() {
			return proposedSolution;
		}

		public void setProposedSolution(String proposedSolution) {
			this.proposedSolution = proposedSolution;
		}

		public String getLessonLearned() {
			return lessonLearned;
		}

		public void setLessonLearned(String lessonLearned) {
			this.lessonLearned = lessonLearned;
		}

		public Date getSubmitdate() {
			return submitdate;
		}

		public void setSubmitdate(Date submitdate) {
			this.submitdate = submitdate;
		}

		public String getIsrmheaduserid() {
			return isrmheaduserid;
		}

		public void setIsrmheaduserid(String isrmheaduserid) {
			this.isrmheaduserid = isrmheaduserid;
		}

		public String getIsrmheadusername() {
			return isrmheadusername;
		}

		public void setIsrmheadusername(String isrmheadusername) {
			this.isrmheadusername = isrmheadusername;
		}

		public String getIsrmheadstatus() {
			return isrmheadstatus;
		}

		public void setIsrmheadstatus(String isrmheadstatus) {
			this.isrmheadstatus = isrmheadstatus;
		}

		public Timestamp getIsrmheadsubdate() {
			return isrmheadsubdate;
		}

		public void setIsrmheadsubdate(Timestamp isrmheadsubdate) {
			this.isrmheadsubdate = isrmheadsubdate;
		}

		public String getIsrmheadcmnt() {
			return isrmheadcmnt;
		}

		public void setIsrmheadcmnt(String isrmheadcmnt) {
			this.isrmheadcmnt = isrmheadcmnt;
		}

		public String getCitouserid() {
			return citouserid;
		}

		public void setCitouserid(String citouserid) {
			this.citouserid = citouserid;
		}

		public String getCitousername() {
			return citousername;
		}

		public void setCitousername(String citousername) {
			this.citousername = citousername;
		}

		public String getCitostatus() {
			return citostatus;
		}

		public void setCitostatus(String citostatus) {
			this.citostatus = citostatus;
		}

		public Timestamp getCitosubdate() {
			return citosubdate;
		}

		public void setCitosubdate(Timestamp citosubdate) {
			this.citosubdate = citosubdate;
		}

		public String getCitocmnt() {
			return citocmnt;
		}

		public void setCitocmnt(String citocmnt) {
			this.citocmnt = citocmnt;
		}

		public Timestamp getSubmittime() {
			return submittime;
		}

		public void setSubmittime(Timestamp submittime) {
			this.submittime = submittime;
		}

		public String getIncidentHandlingDocumentsPath() {
			return incidentHandlingDocumentsPath;
		}

		public void setIncidentHandlingDocumentsPath(String incidentHandlingDocumentsPath) {
			this.incidentHandlingDocumentsPath = incidentHandlingDocumentsPath;
		}

		public String getImpactAnalysisDocumentPath() {
			return impactAnalysisDocumentPath;
		}

		public void setImpactAnalysisDocumentPath(String impactAnalysisDocumentPath) {
			this.impactAnalysisDocumentPath = impactAnalysisDocumentPath;
		}

		public String getDowntimeDocumentationPath() {
			return downtimeDocumentationPath;
		}

		public void setDowntimeDocumentationPath(String downtimeDocumentationPath) {
			this.downtimeDocumentationPath = downtimeDocumentationPath;
		}

		public String getRootCauseAnalysisDocumentsPath() {
			return rootCauseAnalysisDocumentsPath;
		}

		public void setRootCauseAnalysisDocumentsPath(String rootCauseAnalysisDocumentsPath) {
			this.rootCauseAnalysisDocumentsPath = rootCauseAnalysisDocumentsPath;
		}

		public String getWorkCompletionDocumentPath() {
			return workCompletionDocumentPath;
		}

		public void setWorkCompletionDocumentPath(String workCompletionDocumentPath) {
			this.workCompletionDocumentPath = workCompletionDocumentPath;
		}

		public String getIncidentHandlingDocumentsDownloadUrl() {
			return incidentHandlingDocumentsDownloadUrl;
		}

		public void setIncidentHandlingDocumentsDownloadUrl(String incidentHandlingDocumentsDownloadUrl) {
			this.incidentHandlingDocumentsDownloadUrl = incidentHandlingDocumentsDownloadUrl;
		}

		public String getImpactAnalysisDocumentDownloadUrl() {
			return impactAnalysisDocumentDownloadUrl;
		}

		public void setImpactAnalysisDocumentDownloadUrl(String impactAnalysisDocumentDownloadUrl) {
			this.impactAnalysisDocumentDownloadUrl = impactAnalysisDocumentDownloadUrl;
		}

		public String getDowntimeDocumentationDownloadUrl() {
			return downtimeDocumentationDownloadUrl;
		}

		public void setDowntimeDocumentationDownloadUrl(String downtimeDocumentationDownloadUrl) {
			this.downtimeDocumentationDownloadUrl = downtimeDocumentationDownloadUrl;
		}

		public String getRootCauseAnalysisDocumentsDownloadUrl() {
			return rootCauseAnalysisDocumentsDownloadUrl;
		}

		public void setRootCauseAnalysisDocumentsDownloadUrl(String rootCauseAnalysisDocumentsDownloadUrl) {
			this.rootCauseAnalysisDocumentsDownloadUrl = rootCauseAnalysisDocumentsDownloadUrl;
		}

		public String getWorkCompletionDocumentDownloadUrl() {
			return workCompletionDocumentDownloadUrl;
		}

		public void setWorkCompletionDocumentDownloadUrl(String workCompletionDocumentDownloadUrl) {
			this.workCompletionDocumentDownloadUrl = workCompletionDocumentDownloadUrl;
		}

		public String getReferenceValue() {
			return referenceValue;
		}

		public void setReferenceValue(String referenceValue) {
			this.referenceValue = referenceValue;
		}	
		
		public String getBranchCode() {
			return branchCode;
		}

		public void setBranchCode(String branchCode) {
			this.branchCode = branchCode;
		}

		public String getDepartment() {
			return department;
		}

		public void setDepartment(String department) {
			this.department = department;
		}
		
}
