package com.fsiberp.frms.services;

import java.sql.Timestamp;

import com.fsiberp.frms.model.IncidentReport;
import com.fsiberp.frms.model.StatusUpdateRequest;

public interface IncidentReportService {
	
	IncidentReport createForm(IncidentReport accessControl);
	IncidentReport updateStatus(Long id, String userid, StatusUpdateRequest request, Timestamp currentTimestamp);
	IncidentReport saveForm(IncidentReport form);
	}


