package com.fsiberp.frms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fsiberp.frms.model.AccessControl;

@Repository
public interface AccessControlRepository extends JpaRepository<AccessControl, Long> {
	AccessControl findTopByUseridOrderByIdDesc(String userid);
	List<AccessControl> findByUserid(String userid);
	AccessControl findAllByUseridAndFormidAndId(String userid, String formid, Long id);
	List<AccessControl> findByImplementedbydeptid(Integer implementedbydeptid);
	
	List<AccessControl> findByNetworkimplementedbystatusAndBranchCode(String networkimplementedbystatus, String branchCode);
	List<AccessControl> findByNetworkimplementedbystatus(String networkimplementedbystatus);
	List<AccessControl> findByNetworkimplementedbystatusAndDepartment(String networkimplementedbystatus, String department);
	
	@Query("SELECT sf FROM AccessControl sf "
		       + "WHERE sf.userid = :userid "
		       + "AND sf.networkimplementedbystatus = :networkimplementedbystatus")
	List<AccessControl> findByUseridAndNetworkimplementedbystatus(String userid, String networkimplementedbystatus);
} 

