package com.fsiberp.frms.controller;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fsiberp.frms.model.AccessControlUser;
import com.fsiberp.frms.model.IctDepartment;
import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.AccessControlRepository;
import com.fsiberp.frms.repository.AccessControlUserRepository;
import com.fsiberp.frms.repository.CBSUserPermissionRepository;
import com.fsiberp.frms.repository.CreateDomainRepository;
import com.fsiberp.frms.repository.CreateEmailRepository;
import com.fsiberp.frms.repository.DatabaseAccessRepository;
import com.fsiberp.frms.repository.GroupEmailRepository;
import com.fsiberp.frms.repository.IctDepartmentRepository;
import com.fsiberp.frms.repository.IncidentReportRepository;
import com.fsiberp.frms.services.ProfileService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/report/")
public class ReportController {
	
	private IncidentReportRepository incidentReportRepository;
	private CBSUserPermissionRepository cbsUserPermissionRepository ;
	private AccessControlRepository accessControlRepository;
	private CreateDomainRepository createDomainRepository ;
	private CreateEmailRepository createEmailRepository;
	private GroupEmailRepository groupEmailRepository;
	private DatabaseAccessRepository databaseAccessRepository;
	private ProfileService profileService;
	private IctDepartmentRepository ictDepartmentRepository;
	private AccessControlUserRepository accessControlUserRepository;
	
	public ReportController ( IncidentReportRepository incidentReportRepository, CreateDomainRepository createDomainRepository,IctDepartmentRepository ictDepartmentRepository,
			CBSUserPermissionRepository cbsUserPermissionRepository, AccessControlRepository accessControlRepository, ProfileService profileService,
			CreateEmailRepository createEmailRepository, GroupEmailRepository groupEmailRepository, DatabaseAccessRepository databaseAccessRepository,
			AccessControlUserRepository accessControlUserRepository) {
		this.incidentReportRepository = incidentReportRepository;
		this.cbsUserPermissionRepository = cbsUserPermissionRepository;
		this.accessControlRepository = accessControlRepository;
		this.createDomainRepository = createDomainRepository;
		this.createEmailRepository = createEmailRepository;
		this.groupEmailRepository = groupEmailRepository;
		this.databaseAccessRepository = databaseAccessRepository;
		this.profileService = profileService;
		this.ictDepartmentRepository = ictDepartmentRepository;
		this.accessControlUserRepository = accessControlUserRepository;
	}
	
	@GetMapping("view/{id}/{userid}")
    public List<?> report(@PathVariable("id") String formid, @PathVariable("userid") String userid){
		
		User user = profileService.getUserByUserid(userid);
		AccessControlUser accessControlUser = accessControlUserRepository.findByUserid(userid);

		if (formid.equals("1002")) {
			if (user.getBranchcode().equals("0100")) {
				if (user.getDepartment().equals("I C T Div., Head Office, Dhaka")) {

					IctDepartment ictDepartment = ictDepartmentRepository.findByDeptname(user.getUnit()) ;
					if (ictDepartment.getId() == 7 || accessControlUser != null || ictDepartment.getId() == 12) {
						return accessControlRepository.findByNetworkimplementedbystatus("Done");
					}
					else {
						return accessControlRepository.findByNetworkimplementedbystatusAndDepartment("Done", user.getUnit());
					}
				}
				else {
					return accessControlRepository.findByNetworkimplementedbystatusAndDepartment("Done", user.getDepartment());
				}
			}
			else {
				return accessControlRepository.findByNetworkimplementedbystatusAndBranchCode("Done", user.getBranchcode());
			}
		}
		
		else if (formid.equals("1004")) {
			if (user.getBranchcode().equals("0100")) {
				if (user.getDepartment().equals("I C T Div., Head Office, Dhaka")) {
					IctDepartment ictDepartment = ictDepartmentRepository.findByDeptname(user.getUnit()) ;

					if (ictDepartment.getId() == 7 || ictDepartment.getId() == 11 || ictDepartment.getId() == 12) {
						return createEmailRepository.findByImplementedbystatus("Done");
					}
					else {
						return createEmailRepository.findByImplementedbystatusAndDepartment("Done", user.getUnit());
					}
				}
				else {
					return createEmailRepository.findByImplementedbystatusAndDepartment("Done", user.getDepartment());
				}
			}
			else {
				return createEmailRepository.findByImplementedbystatusAndBranchCode("Done", user.getBranchcode());
			}
		}
		
		else if (formid.equals("1005")) {
			if (user.getBranchcode().equals("0100")) {
				if (user.getDepartment().equals("I C T Div., Head Office, Dhaka")) {
					IctDepartment ictDepartment = ictDepartmentRepository.findByDeptname(user.getUnit()) ;

					if (ictDepartment.getId() == 7 || ictDepartment.getId() == 11 || ictDepartment.getId() == 12) {
						return groupEmailRepository.findByImplementedbystatus("Done");
					}
					else {
						return groupEmailRepository.findByImplementedbystatusAndDepartment("Done", user.getUnit());
					}
				}
				else {
					return groupEmailRepository.findByImplementedbystatusAndDepartment("Done", user.getDepartment());
				}
			}
			else {
				return groupEmailRepository.findByImplementedbystatusAndBranchCode("Done", user.getBranchcode());
			}
		}
		else if (formid.equals("1006")) {
			if (user.getBranchcode().equals("0100")) {
				if (user.getDepartment().equals("I C T Div., Head Office, Dhaka")) {
					IctDepartment ictDepartment = ictDepartmentRepository.findByDeptname(user.getUnit()) ;

					if (ictDepartment.getId() == 7 || ictDepartment.getId() == 12) {
						return incidentReportRepository.findByCitostatus("Accepted");
					}
					else {
						return incidentReportRepository.findByCitostatusAndDepartment("Accepted", user.getUnit());
					}
				}
				else {
					return incidentReportRepository.findByCitostatusAndDepartment("Accepted", user.getDepartment());
				}
			}
			else {
				return incidentReportRepository.findByCitostatusAndBranchCode("Accepted", user.getBranchcode());
			}
		}
		else if (formid.equals("1010")) {
			if (user.getBranchcode().equals("0100")) {
				if (user.getDepartment().equals("I C T Div., Head Office, Dhaka")) {
					IctDepartment ictDepartment = ictDepartmentRepository.findByDeptname(user.getUnit()) ;

					if (ictDepartment.getId() == 7 || ictDepartment.getId() == 11 || ictDepartment.getId() == 12) {
						return createDomainRepository.findByImplementedbystatus("Done");
					}
					else {
						return createDomainRepository.findByImplementedbystatusAndDepartment("Done", user.getUnit());
					}
				}
				else {
					return createDomainRepository.findByImplementedbystatusAndDepartment("Done", user.getDepartment());
				}
			}
			else {
				return createDomainRepository.findByImplementedbystatusAndBranchCode("Done", user.getBranchcode());
			}
		}
		else if (formid.equals("1015")) {
			if (user.getBranchcode().equals("0100")) {
				if (user.getDepartment().equals("I C T Div., Head Office, Dhaka")) {
					IctDepartment ictDepartment = ictDepartmentRepository.findByDeptname(user.getUnit()) ;

					if (ictDepartment.getId() == 7 || ictDepartment.getId() == 12) {
						return databaseAccessRepository.findByImplementedbystatus("Done");
					}
					else {
						return databaseAccessRepository.findByImplementedbystatusAndDepartment("Done", user.getUnit());
					}
				}
				else {
					return databaseAccessRepository.findByImplementedbystatusAndDepartment("Done", user.getDepartment());
				}
			}
			else {
				return databaseAccessRepository.findByImplementedbystatusAndBranchCode("Done", user.getBranchcode());
			}
		}
		else if (formid.equals("2001")) {
			if (user.getBranchcode().equals("0100")) {
				if (user.getDepartment().equals("I C T Div., Head Office, Dhaka")) {
					IctDepartment ictDepartment = ictDepartmentRepository.findByDeptname(user.getUnit()) ;

					if (ictDepartment.getId() == 7 || ictDepartment.getId() == 2 || ictDepartment.getId() == 12) {
						return cbsUserPermissionRepository.findByImplementedbystatus("Done");
					}
					else {
						return cbsUserPermissionRepository.findByImplementedbystatusAndDepartment("Done", user.getUnit());
					}
				}
				else {
					return cbsUserPermissionRepository.findByImplementedbystatusAndDepartment("Done", user.getDepartment());
				}
			}
			else {
				return cbsUserPermissionRepository.findByImplementedbystatusAndBranchCode("Done", user.getBranchcode());
			}
		}
		return null;
	}

}
