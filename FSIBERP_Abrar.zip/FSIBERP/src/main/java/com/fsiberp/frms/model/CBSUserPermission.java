package com.fsiberp.frms.model;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.Calendar;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PostPersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "form_cbs_user_permission")
public class CBSUserPermission {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Size(max = 50)
    @Column(name = "user_id")
    private String userid;

    @Column(name = "form_id")
    private String formid;
    
    @Size(max = 50)
    @Column(name = "ref")
    private String referenceValue;

    @PostPersist
    public void generateRefNo() {
        if (id != null) {
            String currentYear = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
            String paddedSubmissionId = String.format("%05d", id);
            this.referenceValue = currentYear + "-2001/" + paddedSubmissionId;
        }
    }

    @Column(name = "new_branch_name")
    private String newBranchName;

    @Column(name = "new_branch_code")
    private String newBranchCode;

    @Column(name = "previous_branch_name")
    private String previousBranchName;

    @Column(name = "previous_branch_code")
    private String previousBranchCode;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column(name = "transfer_date")
    private Date transferDate;

    @Column(name = "transaction_type")
    private String[] transactionType;

    @Column(name = "transaction_limit")
    private Integer[] transactionLimit;

    @Column(name = "authorization_type")
    private String[] authorizationType;

    @Column(name = "authorization_limit")
    private Integer[] authorizationLimit;

    @Column(name = "cash_teller_limit")
    private String cashTellerLimit;

    @Column(name = "teller_type")
    private String[] tellerType;

    @Column(name = "general_banking_management")
    private String[] generalBankingManagement;

    @Column(name = "investment_management")
    private String[] investmentManagement;

    @Column(name = "trade_finance_management")
    private String[] tradeFinanceManagement;

    @Column(name = "reports")
    private String[] reports;

    @Column(name = "fsib_cloud_admin_panel")
    private String[] fsibCloudAdminPanel;

    @Column(name = "branch_day_close")
    private String[] branchDayClose;

    @Column(name = "agent_banking_module")
    private String[] agentBankingModule;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column(name = "submit_date")
    private Date submitdate;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "submit_time")
    private Timestamp submittime;

    @Size(max = 50)
    @Column(name = "unit_head_userid")
    private String unitheaduserid;

    @Size(max = 50)
    @Column(name = "unit_head_username")
    private String unitheadusername;

    @Size(max = 50)
    @Column(name = "unit_head_status")
    private String unitheadstatus;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "unit_head_sub_date")
    private Timestamp unitheadsubdate;

    @Size(max = 255)
    @Column(name = "unit_head_cmnt")
    private String unitheadcmnt;

    @Size(max = 50)
    @Column(name = "implemented_by_userid")
    private String implementedbyuserid;

    @Size(max = 50)
    @Column(name = "implemented_by_username")
    private String implementedbyusername;

    @Size(max = 50)
    @Column(name = "implemented_by_status")
    private String implementedbystatus;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "implemented_by_sub_date")
    private Timestamp implementedbysubdate;
    
	@Column(name = "implemented_by_dept_id")
	private Integer implementedbydeptid;
    
    @Size(max = 50)
    @Column(name = "proposed_unique_user_id")
    private String proposedUniqueUserId;
    
    @Size(max = 50)
    @Column(name = "bcd_userid")
    private String bcduserid;

    @Size(max = 50)
    @Column(name = "bcd_username")
    private String bcdusername;

    @Size(max = 50)
    @Column(name = "bcd_status")
    private String bcdstatus;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "bcd_sub_date")
    private Timestamp bcdsubdate;

    @Size(max = 255)
    @Column(name = "bcd_cmnt")
    private String bcdcmnt;
    
    @Size(max = 50)
    @Column(name = "iad_userid")
    private String iaduserid;

    @Size(max = 50)
    @Column(name = "iad_username")
    private String iadusername;

    @Size(max = 50)
    @Column(name = "iad_status")
    private String iadstatus;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "iad_sub_date")
    private Timestamp iadsubdate;

    @Size(max = 255)
    @Column(name = "iad_cmnt")
    private String iadcmnt;
    
    @Size(max = 50)
    @Column(name = "imrd_userid")
    private String imrduserid;

    @Size(max = 50)
    @Column(name = "imrd_username")
    private String imrdusername;

    @Size(max = 50)
    @Column(name = "imrd_status")
    private String imrdstatus;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "imrd_sub_date")
    private Timestamp imrdsubdate;

    @Size(max = 255)
    @Column(name = "imrd_cmnt")
    private String imrdcmnt;
    
    @Size(max = 50)
    @Column(name = "id_userid")
    private String iduserid;

    @Size(max = 50)
    @Column(name = "id_username")
    private String idusername;

    @Size(max = 50)
    @Column(name = "id_status")
    private String idstatus;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "id_sub_date")
    private Timestamp idsubdate;

    @Size(max = 255)
    @Column(name = "id_cmnt")
    private String idcmnt;
    
    @Column(name = "branch_code")
	private String branchCode;
    
    @Column(name = "department")
	private String department;

    public CBSUserPermission() {}

    
	public CBSUserPermission(Long id, String userid, String formid, String newBranchName,
			String newBranchCode, String previousBranchName, String previousBranchCode, Date transferDate,
			String[] transactionType, Integer[] transactionLimit, String[] authorizationType,
			Integer[] authorizationLimit, String cashTellerLimit, String[] tellerType,
			String[] generalBankingManagement, String[] investmentManagement, String[] tradeFinanceManagement,
			String[] reports, String[] fsibCloudAdminPanel, String[] branchDayClose, String[] agentBankingModule,
			Date submitdate, Timestamp submittime, String unitheaduserid, String department,
			String unitheadusername, String unitheadstatus, Timestamp unitheadsubdate,
			String unitheadcmnt, String implementedbyuserid, String branchCode,
			String implementedbyusername, String implementedbystatus,
			Timestamp implementedbysubdate, Integer implementedbydeptid, String proposedUniqueUserId,
			String bcduserid, String bcdusername, String bcdstatus,
			Timestamp bcdsubdate, String bcdcmnt, String iaduserid,
			String iadusername, String iadstatus, Timestamp iadsubdate,
			String iadcmnt, String imrduserid, String imrdusername,
			String imrdstatus, Timestamp imrdsubdate, String imrdcmnt,
			String iduserid, String idusername, String idstatus,
			Timestamp idsubdate, String idcmnt, String referenceValue) {
		
		super();
		this.id = id;
		this.userid = userid;
		this.formid = formid;
		this.newBranchName = newBranchName;
		this.newBranchCode = newBranchCode;
		this.previousBranchName = previousBranchName;
		this.previousBranchCode = previousBranchCode;
		this.transferDate = transferDate;
		this.transactionType = transactionType;
		this.transactionLimit = transactionLimit;
		this.authorizationType = authorizationType;
		this.authorizationLimit = authorizationLimit;
		this.cashTellerLimit = cashTellerLimit;
		this.tellerType = tellerType;
		this.generalBankingManagement = generalBankingManagement;
		this.investmentManagement = investmentManagement;
		this.tradeFinanceManagement = tradeFinanceManagement;
		this.reports = reports;
		this.fsibCloudAdminPanel = fsibCloudAdminPanel;
		this.branchDayClose = branchDayClose;
		this.agentBankingModule = agentBankingModule;
		this.submitdate = submitdate;
		this.submittime = submittime;
		this.unitheaduserid = unitheaduserid;
		this.unitheadusername = unitheadusername;
		this.unitheadstatus = unitheadstatus;
		this.unitheadsubdate = unitheadsubdate;
		this.unitheadcmnt = unitheadcmnt;
		this.implementedbyuserid = implementedbyuserid;
		this.implementedbyusername = implementedbyusername;
		this.implementedbystatus = implementedbystatus;
		this.implementedbysubdate = implementedbysubdate;
		this.implementedbydeptid = implementedbydeptid;
		this.proposedUniqueUserId = proposedUniqueUserId;
		this.bcduserid = bcduserid;
		this.bcdusername = bcdusername;
		this.bcdstatus = bcdstatus;
		this.bcdsubdate = bcdsubdate;
		this.bcdcmnt = bcdcmnt;
		this.iaduserid = iaduserid;
		this.iadusername = iadusername;
		this.iadstatus = iadstatus;
		this.iadsubdate = iadsubdate;
		this.iadcmnt = iadcmnt;
		this.imrduserid = imrduserid;
		this.imrdusername = imrdusername;
		this.imrdstatus = imrdstatus;
		this.imrdsubdate = imrdsubdate;
		this.imrdcmnt = imrdcmnt;
		this.iduserid = iduserid;
		this.idusername = idusername;
		this.idstatus = idstatus;
		this.idsubdate = idsubdate;
		this.idcmnt = idcmnt;
		this.branchCode = branchCode;
		this.department = department;
		this.referenceValue = referenceValue;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getFormid() {
		return formid;
	}

	public void setFormid(String formid) {
		this.formid = formid;
	}

	public String getNewBranchName() {
		return newBranchName;
	}

	public void setNewBranchName(String newBranchName) {
		this.newBranchName = newBranchName;
	}

	public String getNewBranchCode() {
		return newBranchCode;
	}

	public void setNewBranchCode(String newBranchCode) {
		this.newBranchCode = newBranchCode;
	}

	public String getPreviousBranchName() {
		return previousBranchName;
	}

	public void setPreviousBranchName(String previousBranchName) {
		this.previousBranchName = previousBranchName;
	}

	public String getPreviousBranchCode() {
		return previousBranchCode;
	}

	public void setPreviousBranchCode(String previousBranchCode) {
		this.previousBranchCode = previousBranchCode;
	}

	public Date getTransferDate() {
		return transferDate;
	}

	public void setTransferDate(Date transferDate) {
		this.transferDate = transferDate;
	}

	public String[] getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String[] transactionType) {
		this.transactionType = transactionType;
	}

	public Integer[] getTransactionLimit() {
		return transactionLimit;
	}

	public void setTransactionLimit(Integer[] transactionLimit) {
		this.transactionLimit = transactionLimit;
	}

	public String[] getAuthorizationType() {
		return authorizationType;
	}

	public void setAuthorizationType(String[] authorizationType) {
		this.authorizationType = authorizationType;
	}

	public Integer[] getAuthorizationLimit() {
		return authorizationLimit;
	}

	public void setAuthorizationLimit(Integer[] authorizationLimit) {
		this.authorizationLimit = authorizationLimit;
	}

	public String getCashTellerLimit() {
		return cashTellerLimit;
	}

	public void setCashTellerLimit(String cashTellerLimit) {
		this.cashTellerLimit = cashTellerLimit;
	}

	public String[] getTellerType() {
		return tellerType;
	}

	public void setTellerType(String[] tellerType) {
		this.tellerType = tellerType;
	}

	public String[] getGeneralBankingManagement() {
		return generalBankingManagement;
	}

	public void setGeneralBankingManagement(String[] generalBankingManagement) {
		this.generalBankingManagement = generalBankingManagement;
	}

	public String[] getInvestmentManagement() {
		return investmentManagement;
	}

	public void setInvestmentManagement(String[] investmentManagement) {
		this.investmentManagement = investmentManagement;
	}

	public String[] getTradeFinanceManagement() {
		return tradeFinanceManagement;
	}

	public void setTradeFinanceManagement(String[] tradeFinanceManagement) {
		this.tradeFinanceManagement = tradeFinanceManagement;
	}

	public String[] getReports() {
		return reports;
	}

	public void setReports(String[] reports) {
		this.reports = reports;
	}

	public String[] getFsibCloudAdminPanel() {
		return fsibCloudAdminPanel;
	}

	public void setFsibCloudAdminPanel(String[] fsibCloudAdminPanel) {
		this.fsibCloudAdminPanel = fsibCloudAdminPanel;
	}

	public String[] getBranchDayClose() {
		return branchDayClose;
	}

	public void setBranchDayClose(String[] branchDayClose) {
		this.branchDayClose = branchDayClose;
	}

	public String[] getAgentBankingModule() {
		return agentBankingModule;
	}

	public void setAgentBankingModule(String[] agentBankingModule) {
		this.agentBankingModule = agentBankingModule;
	}

	public Date getSubmitdate() {
		return submitdate;
	}

	public void setSubmitdate(Date submitdate) {
		this.submitdate = submitdate;
	}

	public Timestamp getSubmittime() {
		return submittime;
	}

	public void setSubmittime(Timestamp submittime) {
		this.submittime = submittime;
	}

	public String getUnitheaduserid() {
		return unitheaduserid;
	}

	public void setUnitheaduserid(String unitheaduserid) {
		this.unitheaduserid = unitheaduserid;
	}

	public String getUnitheadusername() {
		return unitheadusername;
	}

	public void setUnitheadusername(String unitheadusername) {
		this.unitheadusername = unitheadusername;
	}

	public String getUnitheadstatus() {
		return unitheadstatus;
	}

	public void setUnitheadstatus(String unitheadstatus) {
		this.unitheadstatus = unitheadstatus;
	}

	public Timestamp getUnitheadsubdate() {
		return unitheadsubdate;
	}

	public void setUnitheadsubdate(Timestamp unitheadsubdate) {
		this.unitheadsubdate = unitheadsubdate;
	}

	public String getUnitheadcmnt() {
		return unitheadcmnt;
	}

	public void setUnitheadcmnt(String unitheadcmnt) {
		this.unitheadcmnt = unitheadcmnt;
	}

	public String getImplementedbyuserid() {
		return implementedbyuserid;
	}

	public void setImplementedbyuserid(String implementedbyuserid) {
		this.implementedbyuserid = implementedbyuserid;
	}

	public String getImplementedbyusername() {
		return implementedbyusername;
	}

	public void setImplementedbyusername(String implementedbyusername) {
		this.implementedbyusername = implementedbyusername;
	}

	public String getImplementedbystatus() {
		return implementedbystatus;
	}

	public void setImplementedbystatus(String implementedbystatus) {
		this.implementedbystatus = implementedbystatus;
	}

	public Timestamp getImplementedbysubdate() {
		return implementedbysubdate;
	}

	public void setImplementedbysubdate(Timestamp implementedbysubdate) {
		this.implementedbysubdate = implementedbysubdate;
	}

	public Integer getImplementedbydeptid() {
		return implementedbydeptid;
	}

	public void setImplementedbydeptid(Integer implementedbydeptid) {
		this.implementedbydeptid = implementedbydeptid;
	}

	public String getProposedUniqueUserId() {
		return proposedUniqueUserId;
	}

	public void setProposedUniqueUserId(String proposedUniqueUserId) {
		this.proposedUniqueUserId = proposedUniqueUserId;
	}

	public String getBcduserid() {
		return bcduserid;
	}

	public void setBcduserid(String bcduserid) {
		this.bcduserid = bcduserid;
	}

	public String getBcdusername() {
		return bcdusername;
	}

	public void setBcdusername(String bcdusername) {
		this.bcdusername = bcdusername;
	}

	public String getBcdstatus() {
		return bcdstatus;
	}

	public void setBcdstatus(String bcdstatus) {
		this.bcdstatus = bcdstatus;
	}

	public Timestamp getBcdsubdate() {
		return bcdsubdate;
	}

	public void setBcdsubdate(Timestamp bcdsubdate) {
		this.bcdsubdate = bcdsubdate;
	}

	public String getBcdcmnt() {
		return bcdcmnt;
	}

	public void setBcdcmnt(String bcdcmnt) {
		this.bcdcmnt = bcdcmnt;
	}

	public String getIaduserid() {
		return iaduserid;
	}

	public void setIaduserid(String iaduserid) {
		this.iaduserid = iaduserid;
	}

	public String getIadusername() {
		return iadusername;
	}

	public void setIadusername(String iadusername) {
		this.iadusername = iadusername;
	}

	public String getIadstatus() {
		return iadstatus;
	}

	public void setIadstatus(String iadstatus) {
		this.iadstatus = iadstatus;
	}

	public Timestamp getIadsubdate() {
		return iadsubdate;
	}

	public void setIadsubdate(Timestamp iadsubdate) {
		this.iadsubdate = iadsubdate;
	}

	public String getIadcmnt() {
		return iadcmnt;
	}

	public void setIadcmnt(String iadcmnt) {
		this.iadcmnt = iadcmnt;
	}

	public String getImrduserid() {
		return imrduserid;
	}

	public void setImrduserid(String imrduserid) {
		this.imrduserid = imrduserid;
	}

	public String getImrdusername() {
		return imrdusername;
	}

	public void setImrdusername(String imrdusername) {
		this.imrdusername = imrdusername;
	}

	public String getImrdstatus() {
		return imrdstatus;
	}

	public void setImrdstatus(String imrdstatus) {
		this.imrdstatus = imrdstatus;
	}

	public Timestamp getImrdsubdate() {
		return imrdsubdate;
	}

	public void setImrdsubdate(Timestamp imrdsubdate) {
		this.imrdsubdate = imrdsubdate;
	}

	public String getImrdcmnt() {
		return imrdcmnt;
	}

	public void setImrdcmnt(String imrdcmnt) {
		this.imrdcmnt = imrdcmnt;
	}

	public String getIduserid() {
		return iduserid;
	}

	public void setIduserid(String iduserid) {
		this.iduserid = iduserid;
	}

	public String getIdusername() {
		return idusername;
	}

	public void setIdusername(String idusername) {
		this.idusername = idusername;
	}

	public String getIdstatus() {
		return idstatus;
	}

	public void setIdstatus(String idstatus) {
		this.idstatus = idstatus;
	}

	public Timestamp getIdsubdate() {
		return idsubdate;
	}

	public void setIdsubdate(Timestamp idsubdate) {
		this.idsubdate = idsubdate;
	}

	public String getIdcmnt() {
		return idcmnt;
	}

	public void setIdcmnt(String idcmnt) {
		this.idcmnt = idcmnt;
	}
	
	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	
	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}


	public String getReferenceValue() {
		return referenceValue;
	}


	public void setReferenceValue(String referenceValue) {
		this.referenceValue = referenceValue;
	}


	

	
	
	
	
}

