package com.fsiberp.frms.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.AuthRepository;
import com.fsiberp.frms.services.AuthService;

@Service
public class AuthServiceImpl implements UserDetailsService {
	
  @Autowired
  AuthRepository authRepository;

  @Override
  @Transactional
  public UserDetails loadUserByUsername(String userid) throws UsernameNotFoundException {
    User user = authRepository.findByUserid(userid)
        .orElseThrow(() -> new UsernameNotFoundException("User Not Found with username: " + userid));

    return (UserDetails) AuthService.build(user);
  }
  
}
