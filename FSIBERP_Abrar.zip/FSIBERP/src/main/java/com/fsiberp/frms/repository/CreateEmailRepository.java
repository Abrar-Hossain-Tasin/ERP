package com.fsiberp.frms.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

import com.fsiberp.frms.model.CreateEmail;
import org.springframework.stereotype.Repository;

@Repository
public interface CreateEmailRepository extends JpaRepository<CreateEmail, Long>{
	
	Optional<CreateEmail> findById(Long id);
	List<CreateEmail> findByUserid(String userid);
	CreateEmail findAllByUseridAndFormidAndId(String userid, String formid, Long id);
	List<CreateEmail> findByImplementedbydeptid(Integer implementedbydeptid);
	List<CreateEmail> findByActionAndImplementedbystatusAndUserid(String action, String implementedbystatus, String userid);

	List<CreateEmail> findByImplementedbystatus(String implementedbystatus);
	List<CreateEmail> findByImplementedbystatusAndDepartment(String implementedbystatus, String department);
	List<CreateEmail> findByImplementedbystatusAndBranchCode(String implementedbystatus, String branchCode);
}
