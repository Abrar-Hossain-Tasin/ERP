package com.fsiberp.frms.services;

import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.AuthRepository;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    private JavaMailSender emailSender;

    private final AuthRepository authRepository; 
   
    public EmailService(AuthRepository authRepository, JavaMailSender emailSender) {
    	this.authRepository = authRepository;
    	this.emailSender = emailSender;
    }

    public void sendNotificationEmail(User user, String userid,Integer flag) {
        User existingUser = authRepository.findByUserid(userid).orElse(null);
        
        if (existingUser == null) {
            System.out.println("User not found");
            return;
        }

        String subject = null;
        String ebody = null;
        
        if (flag == 1) {
         subject = "New Notification Alert from Form Requisition Application";
         ebody = "Muhtaram/Muhtarama,<br>"
                + "Assalamu Alaikum,<br><br><br>"
                + "A new notification awaits in your Form Requisition Application "
                + "from <b>" + user.getUsername() + "( " + user.getUserid() + " )" + " </b>, " + user.getDepartment() + " ( " + user.getBranchcode() + " ) .<br><br>"
                + "Please visit <b><a href='http://localhost:5175/'>http://localhost:5175/</a></b> <br><br>"
                + "Ma-assalam, <br><br>"
                + "ICT Division <br>"
                + "First Security Islami Bank PLC <br><br><br>";
        }
        else if (flag == 2) {
        	subject = "New Notification Alert from Billing Application";
        	ebody = "Muhtaram/Muhtarama,<br>"
                    + "Assalamu Alaikum,<br><br><br>"
                    + "A new notification awaits in your Billing Application "
                    + "from <b>" + user.getUsername() + "( " + user.getUserid() + " )" + " </b>, " + user.getDepartment() + " ( " + user.getBranchcode() + " ) .<br><br>"
                    + "Please visit <b><a href='http://localhost:5175/'>http://localhost:5175/</a></b> <br><br>"
                    + "Ma-assalam, <br><br>"
                    + "ICT Division <br>"
                    + "First Security Islami Bank PLC <br><br><br>";
        }
        else if (flag == 3) {
        	subject = "New Notification Alert from Office Note Application";
        	ebody = "Muhtaram/Muhtarama,<br>"
                    + "Assalamu Alaikum,<br><br><br>"
                    + "A new notification awaits in your Office Note Application "
                    + "from <b>" + user.getUsername() + "( " + user.getUserid() + " )" + " </b>, " + user.getDepartment() + " ( " + user.getBranchcode() + " ) .<br><br>"
                    + "Please visit <b><a href='http://localhost:5175/'>http://localhost:5175/</a></b> <br><br>"
                    + "Ma-assalam, <br><br>"
                    + "ICT Division <br>"
                    + "First Security Islami Bank PLC <br><br><br>";
        }

        try {
            // Create the email message
            
        	MimeMessage message = emailSender.createMimeMessage();
            
            message.setFrom("frms@fsiblbd.com");
            message.setRecipient(jakarta.mail.Message.RecipientType.TO, new InternetAddress("fariya06070@fsiblbd.com"));
//            message.setRecipient(jakarta.mail.Message.RecipientType.TO, new InternetAddress(existingUser.getEmail()));
            message.setSubject(subject);
            message.setContent(ebody, "text/html");

            // Send the email
//            emailSender.send(message);
            System.out.println("Email sent successfully!");
        } catch (MessagingException e) {
            e.printStackTrace();
            System.out.println("Failed to send email.");
        }
    }
    
    
    public void sendNotificationEmailForUser(User user, String userid, Integer flag) {
        User existingUser = authRepository.findByUserid(userid).orElse(null);
        
        if (existingUser == null) {
            System.out.println("User not found");
            return;
        }

        String subject = null;
        String ebody = null;
        
        if (flag == 1) {
         subject = "New Notification Alert from Form Requisition Application";
         ebody = "Muhtaram/Muhtarama,<br>"
                + "Assalamu Alaikum,<br><br><br>"
                + "A new notification awaits in your Form Requisition Application.<br><br> "
                + "Please visit <b><a href='http://localhost:5175/'>http://localhost:5175/</a></b> <br><br>"
                + "Ma-assalam, <br><br>"
                + "ICT Division <br>"
                + "First Security Islami Bank PLC <br><br><br>";
        }
        else if (flag == 2) {
        	subject = "New Notification Alert from Billing Application";
        	ebody = "Muhtaram/Muhtarama,<br>"
                    + "Assalamu Alaikum,<br><br><br>"
                    + "A new notification awaits in your Billing Application.<br><br> "
                    + "Please visit <b><a href='http://localhost:5175/'>http://localhost:5175/</a></b> <br><br>"
                    + "Ma-assalam, <br><br>"
                    + "ICT Division <br>"
                    + "First Security Islami Bank PLC <br><br><br>";
        }
        else if (flag == 3) {
        	subject = "New Notification Alert from Office Note Application";
        	ebody = "Muhtaram/Muhtarama,<br>"
                    + "Assalamu Alaikum,<br><br><br>"
                    + "A new notification awaits in your Office Note Application.<br><br> "
                    + "Please visit <b><a href='http://localhost:5175/'>http://localhost:5175/</a></b> <br><br>"
                    + "Ma-assalam, <br><br>"
                    + "ICT Division <br>"
                    + "First Security Islami Bank PLC <br><br><br>";
        }

        try {
            // Create the email message
            MimeMessage message = emailSender.createMimeMessage();
            message.setFrom("frms@fsiblbd.com");
            message.setRecipient(jakarta.mail.Message.RecipientType.TO, new InternetAddress("fariya06070@fsiblbd.com"));
//            message.setRecipient(jakarta.mail.Message.RecipientType.TO, new InternetAddress(existingUser.getEmail()));
            message.setSubject(subject);
            message.setContent(ebody, "text/html");

            // Send the email
//            emailSender.send(message);
            System.out.println("Email sent successfully!");
        } catch (MessagingException e) {
            e.printStackTrace();
            System.out.println("Failed to send email.");
        }
    }
    
    public void sendNotificationEmailForDept(User user, String email, Integer flag) {
   
        String subject = null;
        String ebody = null;
        
        if (flag == 1) {
         subject = "New Notification Alert from Form Requisition Application";
         ebody = "Muhtaram/Muhtarama,<br>"
                + "Assalamu Alaikum,<br><br><br>"
                + "A new notification awaits in your Form Requisition Application "
                + "from <b>" + user.getUsername() + "( " + user.getUserid() + " )" + " </b>, " + user.getDepartment() + " ( " + user.getBranchcode() + " ) .<br><br>"
                + "Please visit <b><a href='http://localhost:5175/'>http://localhost:5175/</a></b> <br><br>"
                + "Ma-assalam, <br><br>"
                + "ICT Division <br>"
                + "First Security Islami Bank PLC <br><br><br>";
        }
        else if (flag == 2) {
        	subject = "New Notification Alert from Billing Application";
        	ebody = "Muhtaram/Muhtarama,<br>"
                    + "Assalamu Alaikum,<br><br><br>"
                    + "A new notification awaits in your Billing Application "
                    + "from <b>" + user.getUsername() + "( " + user.getUserid() + " )" + " </b>, " + user.getDepartment() + " ( " + user.getBranchcode() + " ) .<br><br>"
                    + "Please visit <b><a href='http://localhost:5175/'>http://localhost:5175/</a></b> <br><br>"
                    + "Ma-assalam, <br><br>"
                    + "ICT Division <br>"
                    + "First Security Islami Bank PLC <br><br><br>";
        }
        else if (flag == 3) {
        	subject = "New Notification Alert from Office Note Application";
        	ebody = "Muhtaram/Muhtarama,<br>"
                    + "Assalamu Alaikum,<br><br><br>"
                    + "A new notification awaits in your Office Note Application "
                    + "from <b>" + user.getUsername() + "( " + user.getUserid() + " )" + " </b>, " + user.getDepartment() + " ( " + user.getBranchcode() + " ) .<br><br>"
                    + "Please visit <b><a href='http://localhost:5175/'>http://localhost:5175/</a></b> <br><br>"
                    + "Ma-assalam, <br><br>"
                    + "ICT Division <br>"
                    + "First Security Islami Bank PLC <br><br><br>";
        }

        try {
            // Create the email message
            MimeMessage message = emailSender.createMimeMessage();
            message.setFrom("frms@fsiblbd.com");
            message.setRecipient(jakarta.mail.Message.RecipientType.TO, new InternetAddress("fariya06070@fsiblbd.com"));
//            message.setRecipient(jakarta.mail.Message.RecipientType.TO, new InternetAddress(email));
            message.setSubject(subject);
            message.setContent(ebody, "text/html");

            // Send the email
//            emailSender.send(message);
            System.out.println("Email sent successfully!");
        } catch (MessagingException e) {
            e.printStackTrace();
            System.out.println("Failed to send email.");
        }
    }
    
    public void sendForgetPassEmail(String userid) {
        User existingUser = authRepository.findByUserid(userid).orElse(null);
        
        if (existingUser == null) {
            System.out.println("User not found");
            return;
        }
        
        String subject = "Reset your password for your FSIB-ERP account.";
        String ebody = "Muhtaram/Muhtarama,<br>"
                + "Assalamu Alaikum,<br><br><br>"
                + "Your password has been reset as per your request. "
                + "Your new password is <b>123456</b>. "
                + "Please remember to change this password upon your first login.<br><br>"
                + "Please visit <b><a href='http://localhost:5175/'>http://localhost:5175/</a></b> <br><br>"
                + "Ma-assalam, <br><br>"
                + "ICT Division <br>"
                + "First Security Islami Bank PLC <br><br><br>";

        try {
            // Create the email message
            
        	MimeMessage message = emailSender.createMimeMessage();
            
            message.setFrom("frms@fsiblbd.com");
            message.setRecipient(jakarta.mail.Message.RecipientType.TO, new InternetAddress("fariya06070@fsiblbd.com"));
//            message.setRecipient(jakarta.mail.Message.RecipientType.TO, new InternetAddress(existingUser.getEmail()));
            message.setSubject(subject);
            message.setContent(ebody, "text/html");

            // Send the email
//            emailSender.send(message);
            System.out.println("Email sent successfully!");
        } catch (MessagingException e) {
            e.printStackTrace();
            System.out.println("Failed to send email.");
        }
    }
}
