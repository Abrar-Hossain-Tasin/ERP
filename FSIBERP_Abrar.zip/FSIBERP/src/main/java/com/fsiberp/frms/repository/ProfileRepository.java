package com.fsiberp.frms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.fsiberp.frms.model.User;
import org.springframework.stereotype.Repository;

@Repository
public interface ProfileRepository extends JpaRepository<User, Long> {
	Optional<User> findByUserid(String userid);
	User findByEmpid(String empid);
	List<User> findByUnit(String unit);
	List<User> findByDepartmentAndRoleid(String department, int roleid);
	List<User> findByUnitAndRoleid(String unit, int roleid);
	User findByDepartmentAndUsergrp(String department, String usergrp);
	
	  // Find active divisional heads with specific function codes and status
    @Query("SELECT u FROM User u JOIN UnitHead uh ON u.empid = uh.empcode " +
           "WHERE uh.funcdescode IN :funcDesCodes AND uh.status = :status")
    List<User> findActiveDivHead(@Param("funcDesCodes") List<String> funcDesCodes, 
                                 @Param("status") String status);

    @Query("SELECT u FROM User u JOIN UnitHead uh ON u.empid = uh.empcode " +
    	       "JOIN DivisionName dn ON u.department = dn.divisionname " +
    	       "WHERE dn.id IN :divisionIds AND uh.funcdescode = 'FD001'")
    	List<User> findDivisionalHeadsForBranchCode0100(@Param("divisionIds") List<Long> divisionIds);	
    
    @Query(value = "SELECT u.* FROM sys_app_user u " + 
            "JOIN sys_unit_head uh ON u.emp_id = uh.emp_code " +
            "JOIN stp_def_division dn ON u.department = dn.division_name " +
            "WHERE dn.id IN :divisionIds AND uh.func_des_code = 'FD001' AND uh.status = 'Active' " + 
            "UNION ALL " +
            "SELECT u.* FROM sys_app_user u " +
            "WHERE u.emp_id = ( SELECT uh.emp_code FROM sys_unit_head uh " +
            "WHERE uh.branch = ( SELECT bi.zonal_code FROM stp_branch_info bi " +
            "JOIN sys_app_user u2 ON u2.branch_code = bi.branch_code " +
            "WHERE u2.user_id = :userid ) " +
            "AND uh.func_des_code = 'FD011' AND uh.status = 'Active' )", 
    nativeQuery = true)
    List<User> findDivisionalHeadsForOtherBranchCodes(@Param("userid") String userid, @Param("divisionIds") List<Long> divisionIds);

    
	@Query(value = "SELECT u.* FROM sys_app_user u " + "JOIN sys_unit_head uh ON u.emp_id = uh.emp_code "
			+ "JOIN stp_def_division dn ON u.department = dn.division_name "
			+ "WHERE dn.id ='2' AND uh.func_des_code IN ('FD001', 'FD002') "
			+ "AND uh.status = 'Active'", nativeQuery = true)
	List<User> findBcdUsersForDivision();

	@Query(value = "SELECT u.* FROM sys_app_user u " + "JOIN sys_unit_head uh ON u.emp_id = uh.emp_code "
			+ "JOIN stp_def_division dn ON u.department = dn.division_name "
			+ "WHERE dn.id ='3' AND uh.func_des_code IN ('FD001', 'FD002') "
			+ "AND uh.status = 'Active'", nativeQuery = true)
	List<User> findIadUsersForDivision();

	@Query(value = "SELECT u.* FROM sys_app_user u " + "JOIN sys_unit_head uh ON u.emp_id = uh.emp_code "
			+ "JOIN stp_def_division dn ON u.department = dn.division_name "
			+ "WHERE dn.id ='12' AND uh.func_des_code IN ('FD001', 'FD002') "
			+ "AND uh.status = 'Active'", nativeQuery = true)
	List<User> findImrdUsersForDivision();

	@Query(value = "SELECT u.* FROM sys_app_user u " + "JOIN sys_unit_head uh ON u.emp_id = uh.emp_code "
			+ "JOIN stp_def_division dn ON u.department = dn.division_name "
			+ "WHERE dn.id ='19' AND uh.func_des_code IN ('FD001', 'FD002') "
			+ "AND uh.status = 'Active'", nativeQuery = true)
	List<User> findIdUsersForDivision();
	
	@Query("SELECT p FROM User p " + "JOIN UnitHead uh ON p.empid = uh.empcode "
			+ "JOIN DivisionName dn ON p.department = dn.divisionname " + "WHERE dn.id = :divisionId "
			+ "AND uh.funcdescode IN ('FD001', 'FD002') " + "AND uh.status = 'Active'")
	List<User> findProfilesByDivisionIdAndActiveStatus(@Param("divisionId") String divisionId);

}
