package com.fsiberp.frms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fsiberp.frms.model.User;


@Repository
public interface AuthRepository extends JpaRepository<User, Long> {
	
  Optional<User> findByUserid(String userid);

  List<User> findAllByBranchcodeAndRoleidAndUseridNot(String branchcode,  Integer roleid, String userid);
  List<User> findAllByDepartmentAndRoleid(String department, int roleid);
  List<User> findAllByDepartment(String department);
  List<User> findAllByDepartmentAndUseridNot(String department, String userid);
  List<User> findAllByBranchcodeAndUseridNot(String branchcode, String userid);
  List<User> findAllByBranchcode(String branchcode);
  
  @Query("SELECT u FROM User u JOIN UnitHead uh ON u.empid = uh.empcode " +
	       "WHERE u.department = :department AND uh.funcdescode IN :funcDesCodes")
	List<User> findAllByDepartmentAndFuncdescode(String department, List<String> funcDesCodes);
 
  @Query("SELECT u FROM User u " +
	       "WHERE u.branchcode IN :branchcode AND u.roleid = :roleid")
 	List<User> findAllByBranchcodeAndRoleid(List<String> branchcode, Integer roleid);

}
