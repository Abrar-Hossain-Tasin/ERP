package com.fsiberp.frms.services;

public class FunctionalRoleService {

}
