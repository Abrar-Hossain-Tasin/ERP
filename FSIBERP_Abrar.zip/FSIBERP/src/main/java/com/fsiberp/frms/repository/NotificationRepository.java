package com.fsiberp.frms.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.fsiberp.frms.model.Notification;
import org.springframework.stereotype.Repository;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> {
    List<Notification> findByFormid(String formId);
    List<Notification> findByUserid(String userid); 
    List<Notification> findByUseridAndFormid(String userid, String formId);
    List<Notification> findByUseridAndFormidAndSubmissionId(String userid, String formid, Long submissionId);

}
