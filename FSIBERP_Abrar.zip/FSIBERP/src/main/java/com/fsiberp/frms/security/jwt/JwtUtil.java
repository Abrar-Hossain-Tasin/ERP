package com.fsiberp.frms.security.jwt;

import io.jsonwebtoken.Jwts;
import java.util.Iterator;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import org.json.JSONObject;

public class JwtUtil {

	private static SecretKey SECRET_KEY;

    static {
        try {
            // Generate a 256-bit key for HS256
            KeyGenerator keyGenerator = KeyGenerator.getInstance("HmacSHA256");
            keyGenerator.init(256); 
            SECRET_KEY = keyGenerator.generateKey();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public String generateToken(JSONObject data) {
        try {
            // Create JWT builder
            var jwtBuilder = Jwts.builder();

            // Iterate through the keys of the JSONObject
            for (Iterator<String> it = data.keys(); it.hasNext(); ) {
                String key = it.next();
                Object value = data.get(key);
                jwtBuilder.claim(key, value);
            }
            
            // Sign the JWT with the SECRET_KEY
            return jwtBuilder.signWith(SECRET_KEY).compact();

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    
    public static SecretKey getSecretKey() {
        return SECRET_KEY;
    }
}
