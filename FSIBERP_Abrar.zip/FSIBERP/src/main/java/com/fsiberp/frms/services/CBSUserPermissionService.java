package com.fsiberp.frms.services;

import java.sql.Timestamp;
import java.util.List;

import com.fsiberp.frms.model.CBSUserPermission;
import com.fsiberp.frms.model.StatusUpdateRequest;
import com.fsiberp.frms.model.User;

public interface CBSUserPermissionService {
    String getBranchCode(String branchName);
    CBSUserPermission save(CBSUserPermission userPermission);
    CBSUserPermission update(Long id, CBSUserPermission userPermission);
    
    CBSUserPermission updateStatus(Long id, String userid, StatusUpdateRequest request, Timestamp currentTimestamp);
    List<User> getDivisionalHeads(String userid);
}
