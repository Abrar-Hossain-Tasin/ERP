package com.fsiberp.frms.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "stp_def_division")
public class DivisionName {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "division_name")
	private String divisionname;
	
	@Column(name = "full_div_name")
	private String fulldivname;
	
	@Column(name = "dmd_id")
	private String dmdid;
	
	@Column(name = "amd_id")
	private String amdid;

	public DivisionName() {
		super();
	}

	public DivisionName(Long id, String divisionname, String fulldivname, String dmdid, String amdid) {
		super();
		this.id = id;
		this.divisionname = divisionname;
		this.fulldivname = fulldivname;
		this.dmdid = dmdid;
		this.amdid = amdid;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDivisionname() {
		return divisionname;
	}

	public void setDivisionname(String divisionname) {
		this.divisionname = divisionname;
	}

	public String getFulldivname() {
		return fulldivname;
	}

	public void setFulldivname(String fulldivname) {
		this.fulldivname = fulldivname;
	}

	public String getDmdid() {
		return dmdid;
	}

	public void setDmdid(String dmdid) {
		this.dmdid = dmdid;
	}

	public String getAmdid() {
		return amdid;
	}

	public void setAmdid(String amdid) {
		this.amdid = amdid;
	}

}
