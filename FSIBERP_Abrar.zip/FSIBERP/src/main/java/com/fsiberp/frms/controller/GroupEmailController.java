package com.fsiberp.frms.controller;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fsiberp.frms.model.FunctionalRole;
import com.fsiberp.frms.model.GroupEmail;
import com.fsiberp.frms.model.Notification;
import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.FunctionalRoleRepository;
import com.fsiberp.frms.repository.GroupEmailRepository;
import com.fsiberp.frms.repository.NotificationRepository;
import com.fsiberp.frms.services.EmailService;
import com.fsiberp.frms.services.GroupEmailService;
import com.fsiberp.frms.services.ProfileService;
import jakarta.validation.Valid;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/grp_email/")
public class GroupEmailController {
	
	private ProfileService profileService;
	private FunctionalRoleRepository functionalRoleRepository;
	private GroupEmailService groupEmailService;
	private GroupEmailRepository groupEmailRepository;
	private NotificationRepository notificationRepository;
    private EmailService emailService;
	
	public GroupEmailController(ProfileService profileService, GroupEmailRepository groupEmailRepository,
			FunctionalRoleRepository functionalRoleRepository, GroupEmailService groupEmailService,
			NotificationRepository notificationRepository, EmailService emailService) {
			
	        this.profileService = profileService;
	        this.functionalRoleRepository = functionalRoleRepository;
	        this.groupEmailService = groupEmailService;
	        this.groupEmailRepository = groupEmailRepository;
	        this.notificationRepository = notificationRepository;
	        this.emailService = emailService;
	    }
	
	@GetMapping("view/{id}")
    public ResponseEntity<User> showForms(@PathVariable("id") String userid){
		
        User user = profileService.getUserByUserid(userid);
        
        FunctionalRole citoRole = functionalRoleRepository.findByFunctionalroleAndStatus("cito" , "Active")
                .orElseThrow(NoSuchElementException::new);
        User citoinfo = profileService.getUserByUserid(citoRole.getUserid());
        
        FunctionalRole isrmRole = functionalRoleRepository.findByFunctionalroleAndStatus("isrm" , "Active")
                .orElseThrow(NoSuchElementException::new);
        User isrminfo = profileService.getUserByUserid(isrmRole.getUserid());
        
        FunctionalRole saRole = functionalRoleRepository.findByFunctionalroleAndStatus("sa" , "Active")
                .orElseThrow(NoSuchElementException::new);
        User sainfo = profileService.getUserByUserid(saRole.getUserid());
		
		user.setCreatedby(citoinfo.getUsername());
		user.setUsergrp(isrminfo.getUsername());
		user.setChngpassword(sainfo.getConfirmPassword());
		user.setPassword("Pending");
	
        return new ResponseEntity<>(user, HttpStatus.OK);
    }
	
	@PostMapping("save/{id}")
	public ResponseEntity<GroupEmail> createForm(@PathVariable("id") String userid, @RequestBody @Valid GroupEmail groupEmail) {
		
	    User user = profileService.getUserByUserid(userid);

	    // Fetch CITO role and user information
	    FunctionalRole citoRole = functionalRoleRepository.findByFunctionalroleAndStatus("cito", "Active")
	            .orElseThrow(NoSuchElementException::new);
	    User citoinfo = profileService.getUserByUserid(citoRole.getUserid());

	    // Fetch ISRM role and user information
	    FunctionalRole isrmRole = functionalRoleRepository.findByFunctionalroleAndStatus("isrm", "Active")
	            .orElseThrow(NoSuchElementException::new);
	    User isrminfo = profileService.getUserByUserid(isrmRole.getUserid());
	    
	 // Fetch SA role and user information
	    FunctionalRole saRole = functionalRoleRepository.findByFunctionalroleAndStatus("sa", "Active")
	            .orElseThrow(NoSuchElementException::new);
	    User sainfo = profileService.getUserByUserid(saRole.getUserid());

	    // Set necessary fields in AccessRights
	    groupEmail.setFormid("1005"); // Set form ID (might be generated differently)
	    groupEmail.setUserid(user.getUserid());
	    
	    groupEmail.setCitouserid(citoinfo.getUserid());
	    groupEmail.setCitousername(citoinfo.getUsername());
	    groupEmail.setCitostatus("Pending");
	    
	    groupEmail.setIsrmheaduserid(isrminfo.getUserid());
	    groupEmail.setIsrmheadusername(isrminfo.getUsername());
	    groupEmail.setIsrmheadstatus("Pending");
	    
	    groupEmail.setImplbyunitheaduserid(sainfo.getUserid());
	    groupEmail.setImplbyunitheadusername(sainfo.getUsername());
	    groupEmail.setImplbyunitheadstatus("Pending");
	    
	    groupEmail.setUnitheadstatus("Pending");
	    groupEmail.setImplementedbystatus("Pending");
	    groupEmail.setImplementedbydeptid(11); // Set department ID
	    
	    groupEmail.setSubmitdate(new Date(System.currentTimeMillis()));
	    groupEmail.setSubmittime(new Timestamp(System.currentTimeMillis()));
	    groupEmail.setBranchCode(user.getBranchcode());
	    
	    if (user.getDepartment().equals("I C T Div., Head Office, Dhaka")) {
	    	groupEmail.setDepartment(user.getUnit());
        }
        else {        	
        	groupEmail.setDepartment(user.getDepartment());
        }
	    
	    // Save the form using the updated saveForm method in the service
	    GroupEmail savedForm = groupEmailService.saveForm(groupEmail);

	    return new ResponseEntity<>(savedForm, HttpStatus.CREATED);
	}
	
	
	@PutMapping("update/{id}")
	public ResponseEntity<GroupEmail> updateGroupEmail(@PathVariable("id") Long id, @RequestBody @Valid GroupEmail upgroupEmail) {
		
		GroupEmail groupEmail = groupEmailRepository.findById(id)
	            .orElseThrow(NoSuchElementException::new);
		
		groupEmail.setGrpname(upgroupEmail.getGrpname());
		groupEmail.setGrpowner(upgroupEmail.getGrpowner());
		groupEmail.setAction(upgroupEmail.getAction());
		groupEmail.setPurpose(upgroupEmail.getPurpose());
		groupEmail.setGrpmember(upgroupEmail.getGrpmember());
		groupEmail.setMememail(upgroupEmail.getMememail());

	
		groupEmail.setUnitheadstatus("Pending");
	
		groupEmail.setSubmittime(new Timestamp(System.currentTimeMillis()));
		groupEmail.setSubmitdate(new Date(System.currentTimeMillis()));
		
		  if (!upgroupEmail.getUnitheaduserid().equals(groupEmail.getUnitheaduserid())) {
	          String newUnitHeadUserId = upgroupEmail.getUnitheaduserid();
	          User newUnitHeadUser = profileService.getUserByUserid(newUnitHeadUserId);
	          String newUnitHeadUsername = newUnitHeadUser != null ? newUnitHeadUser.getUsername() : "Unknown User";

	  
	          List<Notification> existingNotifications = notificationRepository.findByUseridAndFormidAndSubmissionId(
	        		  groupEmail.getUnitheaduserid(),
	        		  groupEmail.getFormid(),
	        		  groupEmail.getId()
	          );

	   
	          User user = profileService.getUserByUserid(upgroupEmail.getUnitheaduserid());
	          
	          User submittingUser = profileService.getUserByUserid(groupEmail.getUserid());
	          String submittingUsername = submittingUser != null ? submittingUser.getUsername() : "Unknown User";
	          
	          
	          for (Notification notification : existingNotifications) {
	              notification.setUserid(newUnitHeadUserId);
	              notification.setMessage(
	                  "A new Group Email request has been submitted by " + submittingUsername +
	                  " (" + groupEmail.getUserid() + ")."
	              );
	              notificationRepository.save(notification);
	          }
	          

//	          unit head email
	          emailService.sendNotificationEmail(user,upgroupEmail.getUserid(),1);
	          groupEmail.setUnitheaduserid(newUnitHeadUserId);
	          groupEmail.setUnitheadusername(newUnitHeadUsername);
	      }

		
		
		GroupEmail updatedForm = groupEmailRepository.save(groupEmail);
	    return new ResponseEntity<>(updatedForm, HttpStatus.OK);
	}
}
