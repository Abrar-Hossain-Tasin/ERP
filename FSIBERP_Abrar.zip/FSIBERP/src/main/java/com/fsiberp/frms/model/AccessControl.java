package com.fsiberp.frms.model;

import java.sql.Date;
import java.sql.Timestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "form_access_control")
public class AccessControl {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "form_id")
    private String formid;
    
  
    @Size(max = 50)
    @Column(name = "user_id")
    private String userid;
    
    @Size(max = 50)
    @Column(name = "card_number")
    private String cardnumber;
    
    @Size(max = 50)
    @Column(name = "door_access")
    private String[] dooraccess;
    
    @Size(max = 255)
    @Column(name = "existing_access_info")
    private String existingaccessinfo;
    
  
    @Column(name = "submit_date")
    private Date submitdate;
    
    @Size(max = 50)
    @Column(name = "unit_head_userid")
    private String unitheaduserid;
    
    @Size(max = 50)
    @Column(name = "unit_head_username")
    private String unitheadusername;
    
    @Size(max = 50)
    @Column(name = "unit_head_status")
    private String unitheadstatus;
    
   
    @Column(name = "unit_head_sub_date")
    private Timestamp unitheadsubdate;
    
    @Size(max = 255)
    @Column(name = "unit_head_cmnt")
    private String unitheadcmnt;
    
    @Size(max = 50)
    @Column(name = "isrm_head_userid")
    private String isrmheaduserid;
    
    @Size(max = 50)
    @Column(name = "isrm_head_username")
    private String isrmheadusername;
    
    @Size(max = 50)
    @Column(name = "isrm_head_status")
    private String isrmheadstatus;
    
  
    @Column(name = "isrm_head_sub_date")
    private Timestamp isrmheadsubdate;
    
    @Size(max = 255)
    @Column(name = "isrm_head_cmnt")
    private String isrmheadcmnt;
    
    @Size(max = 50)
    @Column(name = "cito_userid")
    private String citouserid;
    
    @Size(max = 50)
    @Column(name = "cito_username")
    private String citousername;
    
    @Size(max = 50)
    @Column(name = "cito_status")
    private String citostatus;
    
   
    @Column(name = "cito_sub_date")
    private Timestamp citosubdate;
    
    @Size(max = 255)
    @Column(name = "cito_cmnt")
    private String citocmnt;
    
 
    
    @Column(name = "submit_time")
	private Timestamp submittime;
    
    @Column(name = "implemented_by_dept_id")
	private Integer implementedbydeptid;
    
    @Column(name = "employee_id_card_path")
    private String employeeIdCardPath;
    
    @Column(name = "joining_letter_path")
    private String joiningLetterPath;
    
    @Transient
    private String employeeIdCardDownloadUrl;
    
    @Transient
    private String joiningLetterDownloadUrl;
	
	@Column(name = "ref")
	private String referenceValue; 
	
	@Column(name = "branch_code")
	private String branchCode;
	
	@Column(name = "department")
	private String department;
	  
	  @Size(max = 50)
	  @Column(name = "network_head_userid")
	  private String networkheaduserid;
	  
	  @Size(max = 50)
	  @Column(name = "network_head_username")
	  private String networkheadusername;
	  
	  @Size(max = 50)
	  @Column(name = "network_head_status")
	  private String networkheadstatus;
	  
	
	  @Column(name = "network_head_sub_date")
	  private Timestamp networkheadsubdate;
	  
	  @Size(max = 255)
	  @Column(name = "network_head_cmnt")
	  private String networkheadcmnt;
	  
	  @Size(max = 50)
	@Column(name = "network_implemented_by_userid")
	private String networkimplementedbyuserid;
	
	@Size(max = 50)
	@Column(name = "network_implemented_by_username")
	private String networkimplementedbyusername;
	
	@Size(max = 50)
	@Column(name = "network_implemented_by_status")
	private String networkimplementedbystatus;
	
	
	@Column(name = "network_implemented_by_sub_date")
	private Timestamp networkimplementedbysubdate;
	
	@Size(max = 255)
    @Column(name = "network_implemented_by_cmnt")
    private String networkimplementedbycmnt;
 
    public AccessControl() { }

    public AccessControl(Long id, String formid, String userid, String cardnumber, String[] dooraccess, 
                         String existingaccessinfo, Date submitdate, String unitheaduserid, 
                         String unitheadusername, String unitheadstatus, Timestamp unitheadsubdate, 
                         String unitheadcmnt, String isrmheaduserid, String isrmheadusername, 
                         String isrmheadstatus, Timestamp isrmheadsubdate, String isrmheadcmnt, 
                         String drheaduserid, String drheadusername, String drheadstatus, 
                         Timestamp drheadsubdate, String drheadcmnt, String citouserid, 
                         String citousername, String citostatus, Timestamp citosubdate, String networkimplementedbycmnt,
                         String citocmnt, String implementedbyuserid, String implementedbyusername, 
                         String implementedbystatus, Timestamp implementedbysubdate, String department,
                         Timestamp submittime, Integer implementedbydeptid, String employeeIdCardPath,String joiningLetterPath, String referenceValue,
                         String networkheaduserid, String networkheadusername, String networkheadstatus, Timestamp networkheadsubdate, String networkheadcmnt,
                         String networkimplementedbyuserid, String networkimplementedbyusername, String networkimplementedbystatus,Timestamp networkimplementedbysubdate,String branchCode
    		) 
    {
        super();
        this.id = id;
        this.formid = formid;
        this.userid = userid;
        this.cardnumber = cardnumber;
        this.dooraccess = dooraccess;
        this.existingaccessinfo = existingaccessinfo;
        this.submitdate = submitdate;
        this.branchCode = branchCode;
        this.department = department;
        
        this.unitheaduserid = unitheaduserid;
        this.unitheadusername = unitheadusername;
        this.unitheadstatus = unitheadstatus;
        this.unitheadsubdate = unitheadsubdate;
        this.unitheadcmnt = unitheadcmnt;
        this.isrmheaduserid = isrmheaduserid;
        this.isrmheadusername = isrmheadusername;
        this.isrmheadstatus = isrmheadstatus;
        this.isrmheadsubdate = isrmheadsubdate;
        this.isrmheadcmnt = isrmheadcmnt;
       
        this.citouserid = citouserid;
        this.citousername = citousername;
        this.citostatus = citostatus;
        this.citosubdate = citosubdate;
        this.citocmnt = citocmnt;
      
        this.submittime = submittime;
        this.implementedbydeptid = implementedbydeptid;
        this.employeeIdCardPath = employeeIdCardPath;
        this.joiningLetterPath = joiningLetterPath;
        this.referenceValue = referenceValue;
        
        this.networkimplementedbystatus = networkimplementedbystatus;
        this.networkimplementedbysubdate = networkimplementedbysubdate;
        this.networkimplementedbyuserid = networkimplementedbyuserid;
        this.networkimplementedbyusername = networkimplementedbyusername;
        this.networkimplementedbycmnt = networkimplementedbycmnt;
    }

    // Getters and Setters for each field
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFormid() {
        return formid;
    }

    public void setFormid(String formid) {
        this.formid = formid;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getCardnumber() {
        return cardnumber;
    }

    public void setCardnumber(String cardnumber) {
        this.cardnumber = cardnumber;
    }

    public String[] getDooraccess() {
        return dooraccess;
    }

    public void setDooraccess(String[] dooraccess) {
        this.dooraccess = dooraccess;
    }

    public String getExistingaccessinfo() {
        return existingaccessinfo;
    }

    public void setExistingaccessinfo(String existingaccessinfo) {
        this.existingaccessinfo = existingaccessinfo;
    }

    public Date getSubmitdate() {
        return submitdate;
    }

    public void setSubmitdate(Date submitdate) {
        this.submitdate = submitdate;
    }

    public String getUnitheaduserid() {
        return unitheaduserid;
    }

    public void setUnitheaduserid(String unitheaduserid) {
        this.unitheaduserid = unitheaduserid;
    }

    public String getUnitheadusername() {
        return unitheadusername;
    }

    public void setUnitheadusername(String unitheadusername) {
        this.unitheadusername = unitheadusername;
    }

    public String getUnitheadstatus() {
        return unitheadstatus;
    }

    public void setUnitheadstatus(String unitheadstatus) {
        this.unitheadstatus = unitheadstatus;
    }

    public Timestamp getUnitheadsubdate() {
        return unitheadsubdate;
    }

    public void setUnitheadsubdate(Timestamp unitheadsubdate) {
        this.unitheadsubdate = unitheadsubdate;
    }

    public String getUnitheadcmnt() {
        return unitheadcmnt;
    }

    public void setUnitheadcmnt(String unitheadcmnt) {
        this.unitheadcmnt = unitheadcmnt;
    }

    public String getIsrmheaduserid() {
        return isrmheaduserid;
    }

    public void setIsrmheaduserid(String isrmheaduserid) {
        this.isrmheaduserid = isrmheaduserid;
    }

    public String getIsrmheadusername() {
        return isrmheadusername;
    }

    public void setIsrmheadusername(String isrmheadusername) {
        this.isrmheadusername = isrmheadusername;
    }

    public String getIsrmheadstatus() {
        return isrmheadstatus;
    }

    public void setIsrmheadstatus(String isrmheadstatus) {
        this.isrmheadstatus = isrmheadstatus;
    }

    public Timestamp getIsrmheadsubdate() {
        return isrmheadsubdate;
    }

    public void setIsrmheadsubdate(Timestamp isrmheadsubdate) {
        this.isrmheadsubdate = isrmheadsubdate;
    }

    public String getIsrmheadcmnt() {
        return isrmheadcmnt;
    }

    public void setIsrmheadcmnt(String isrmheadcmnt) {
        this.isrmheadcmnt = isrmheadcmnt;
    }

  
    public String getCitouserid() {
        return citouserid;
    }

    public void setCitouserid(String citouserid) {
        this.citouserid = citouserid;
    }

    public String getCitousername() {
        return citousername;
    }

    public void setCitousername(String citousername) {
        this.citousername = citousername;
    }

    public String getCitostatus() {
        return citostatus;
    }

    public void setCitostatus(String citostatus) {
        this.citostatus = citostatus;
    }

    public Timestamp getCitosubdate() {
        return citosubdate;
    }

    public void setCitosubdate(Timestamp citosubdate) {
        this.citosubdate = citosubdate;
    }

    public String getCitocmnt() {
        return citocmnt;
    }

    public void setCitocmnt(String citocmnt) {
        this.citocmnt = citocmnt;
    }

    

    public Timestamp getSubmittime() {
        return submittime;
    }

    public void setSubmittime(Timestamp submittime) {
        this.submittime = submittime;
    }

	public Integer getImplementedbydeptid() {
		return implementedbydeptid;
	}

	public void setImplementedbydeptid(Integer implementedbydeptid) {
		this.implementedbydeptid = implementedbydeptid;
	}

	public String getEmployeeIdCardPath() {
		return employeeIdCardPath;
	}

	public void setEmployeeIdCardPath(String employeeIdCardPath) {
		this.employeeIdCardPath = employeeIdCardPath;
	}

	public String getJoiningLetterPath() {
		return joiningLetterPath;
	}

	public void setJoiningLetterPath(String joiningLetterPath) {
		this.joiningLetterPath = joiningLetterPath;
	}
	public String getEmployeeIdCardDownloadUrl() {
        return employeeIdCardDownloadUrl;
    }

    public void setEmployeeIdCardDownloadUrl(String employeeIdCardDownloadUrl) {
        this.employeeIdCardDownloadUrl = employeeIdCardDownloadUrl;
    }

    public String getJoiningLetterDownloadUrl() {
        return joiningLetterDownloadUrl;
    }

    public void setJoiningLetterDownloadUrl(String joiningLetterDownloadUrl) {
        this.joiningLetterDownloadUrl = joiningLetterDownloadUrl;
    }
    public String getReferenceValue() {
		return referenceValue;
	}

	public void setReferenceValue(String referenceValue) {
		this.referenceValue = referenceValue;
	}

	public String getNetworkheaduserid() {
		return networkheaduserid;
	}

	public void setNetworkheaduserid(String networkheaduserid) {
		this.networkheaduserid = networkheaduserid;
	}

	public String getNetworkheadusername() {
		return networkheadusername;
	}

	public void setNetworkheadusername(String networkheadusername) {
		this.networkheadusername = networkheadusername;
	}

	public String getNetworkheadstatus() {
		return networkheadstatus;
	}

	public void setNetworkheadstatus(String networkheadstatus) {
		this.networkheadstatus = networkheadstatus;
	}

	public Timestamp getNetworkheadsubdate() {
		return networkheadsubdate;
	}

	public void setNetworkheadsubdate(Timestamp networkheadsubdate) {
		this.networkheadsubdate = networkheadsubdate;
	}

	public String getNetworkheadcmnt() {
		return networkheadcmnt;
	}

	public void setNetworkheadcmnt(String networkheadcmnt) {
		this.networkheadcmnt = networkheadcmnt;
	}

	public String getNetworkimplementedbyuserid() {
		return networkimplementedbyuserid;
	}

	public void setNetworkimplementedbyuserid(String networkimplementedbyuserid) {
		this.networkimplementedbyuserid = networkimplementedbyuserid;
	}

	public String getNetworkimplementedbyusername() {
		return networkimplementedbyusername;
	}

	public void setNetworkimplementedbyusername(String networkimplementedbyusername) {
		this.networkimplementedbyusername = networkimplementedbyusername;
	}

	public String getNetworkimplementedbystatus() {
		return networkimplementedbystatus;
	}

	public void setNetworkimplementedbystatus(String networkimplementedbystatus) {
		this.networkimplementedbystatus = networkimplementedbystatus;
	}

	public Timestamp getNetworkimplementedbysubdate() {
		return networkimplementedbysubdate;
	}

	public void setNetworkimplementedbysubdate(Timestamp networkimplementedbysubdate) {
		this.networkimplementedbysubdate = networkimplementedbysubdate;
	}

	public String getNetworkimplementedbycmnt() {
		return networkimplementedbycmnt;
	}

	public void setNetworkimplementedbycmnt(String networkimplementedbycmnt) {
		this.networkimplementedbycmnt = networkimplementedbycmnt;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}
    
}



