package com.fsiberp.frms.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class PostGRESQLConnUtils {

    public static Connection getPostGreSQLConnection() throws ClassNotFoundException, SQLException {
        String hostName = "localhost";
        String dbName = "fsiberp_test";
        String userName = "postgres";
        String password = "postgres";

        return getMySQLConnection(hostName, dbName, userName, password);
    }

    public static Connection getMySQLConnection(String hostName, String dbName,
            String userName, String password) throws SQLException, ClassNotFoundException {

        String connectionURL = "jdbc:postgresql://" + hostName + ":5432/" + dbName + "?useUnicode=yes&characterEncoding=UTF-8";
        Connection conn = DriverManager.getConnection(connectionURL, userName, password);
        return conn;
    }

    public static void main(String[] args) {
        System.out.println("Get connection ... ");

        // Using try-with-resources to ensure the connection is closed automatically
        try (Connection conn = PostGRESQLConnUtils.getPostGreSQLConnection()) {
            System.out.println("database " + conn);
            // Perform database operations here

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
}
