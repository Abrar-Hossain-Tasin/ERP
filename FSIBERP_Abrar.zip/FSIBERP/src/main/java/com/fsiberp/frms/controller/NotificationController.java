package com.fsiberp.frms.controller;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fsiberp.frms.model.Notification;
import com.fsiberp.frms.services.NotificationService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/notifications/")
public class NotificationController {

    private final NotificationService notificationService;

    public NotificationController(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @GetMapping("{userid}")
    public List<Notification> getUserNotifications(@PathVariable("userid") String userid) {
        return notificationService.getNotifications(userid);
    }

    @PutMapping("view/{id}")
    public void markNotificationAsViewed(@PathVariable("id") Long id) {
        notificationService.markAsViewed(id);
    }
}