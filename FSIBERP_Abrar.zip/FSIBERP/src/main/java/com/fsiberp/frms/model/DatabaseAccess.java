//package com.fsiberp.frms.model;
//
//import java.sql.Date;
//import java.sql.Time;
//import java.sql.Timestamp;
//
//import org.springframework.format.annotation.DateTimeFormat;
//
//import com.fasterxml.jackson.annotation.JsonFormat;
//
//import jakarta.persistence.Column;
//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//import jakarta.persistence.Table;
//import jakarta.persistence.Transient;
//import jakarta.validation.constraints.NotBlank;
//import jakarta.validation.constraints.Size;
//
//@Entity
//@Table(name = "form_database_access_right")
//public class DatabaseAccess {
//
//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	private Long id;
//
//	@Column(name = "form_id")
//	private String formid;
//
//	@NotBlank
//	@Size(max = 50)
//	@Column(name = "user_id")
//	private String userid;
//
//	@Column(name = "ref")
//	private String referenceValue;
//
////		@NotBlank
//	@Size(max = 50)
//	@Column(name = "ac_type")
//	private String actype;
//
//	// @NotBlank
//	@Size(max = 50)
//	@Column(name = "action")
//	private String action;
//
//	@DateTimeFormat(pattern = "yyyy-MM-dd")
//	@Column(name = "temp_date_from")
//	private Date tempdatefrom;
//
//	@DateTimeFormat(pattern = "yyyy-MM-dd")
//	@Column(name = "temp_date_to")
//	private Date tempdateto;
//
//	@JsonFormat(pattern = "HH:mm:ss")
//	@Column(name = "temp_time_from")
//	private Time temptimefrom;
//
//	@JsonFormat(pattern = "HH:mm:ss")
//	@Column(name = "temp_time_to")
//	private Time temptimeto;
//
//	// @NotBlank
//	@Size(max = 50)
//	@Column(name = "access_to_db")
//	private String[] accesstodb;
//
//	@Column(name = "submit_date")
//	private Date submitdate;
//
//	@Column(name = "submit_time")
//	private Timestamp submittime;
//
//	@Size(max = 50)
//	@Column(name = "unit_head_userid")
//	private String unitheaduserid;
//
//	@Size(max = 50)
//	@Column(name = "unit_head_username")
//	private String unitheadusername;
//
//	@Size(max = 50)
//	@Column(name = "unit_head_status")
//	private String unitheadstatus;
//
//	@Column(name = "unit_head_sub_date")
//	private Timestamp unitheadsubdate;
//
//	@Size(max = 255)
//	@Column(name = "unit_head_cmnt")
//	private String unitheadcmnt;
//
//	@Size(max = 50)
//	@Column(name = "isrm_head_userid")
//	private String isrmheaduserid;
//
//	@Size(max = 50)
//	@Column(name = "isrm_head_username")
//	private String isrmheadusername;
//
//	@Size(max = 50)
//	@Column(name = "isrm_head_status")
//	private String isrmheadstatus;
//
//	@Column(name = "isrm_head_sub_date")
//	private Timestamp isrmheadsubdate;
//
//	@Size(max = 255)
//	@Column(name = "isrm_head_cmnt")
//	private String isrmheadcmnt;
//
//	@Size(max = 50)
//	@Column(name = "cito_userid")
//	private String citouserid;
//
//	@Size(max = 50)
//	@Column(name = "cito_username")
//	private String citousername;
//
//	@Size(max = 50)
//	@Column(name = "cito_status")
//	private String citostatus;
//
//	@Column(name = "cito_sub_date")
//	private Timestamp citosubdate;
//
//	@Size(max = 255)
//	@Column(name = "cito_cmnt")
//	private String citocmnt;
//
//	@Size(max = 50)
//	@Column(name = "impl_by_unithead_userid")
//	private String implbyunitheaduserid;
//
//	@Size(max = 50)
//	@Column(name = "impl_by_unithead_username")
//	private String implbyunitheadusername;
//
//	@Size(max = 50)
//	@Column(name = "impl_by_unithead_status")
//	private String implbyunitheadstatus;
//
//	@Size(max = 255)
//	@Column(name = "impl_by_unithead_cmnt")
//	private String implbyunitheadcmnt;
//
//	@Column(name = "impl_by_unithead_sub_date")
//	private Timestamp implbyunitheadsubdate;
//
//	@Size(max = 50)
//	@Column(name = "implemented_by_userid")
//	private String implementedbyuserid;
//
//	@Size(max = 50)
//	@Column(name = "implemented_by_username")
//	private String implementedbyusername;
//
//	@Size(max = 50)
//	@Column(name = "implemented_by_status")
//	private String implementedbystatus;
//
//	@Column(name = "implemented_by_sub_date")
//	private Timestamp implementedbysubdate;
//
//	@Column(name = "implemented_by_dept_id")
//	private Long implementedbydeptid;
//
//	public DatabaseAccess() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
//
//	public DatabaseAccess(Long id, String formid, @NotBlank @Size(max = 50) String userid, String referenceValue,
//			@Size(max = 50) String actype, @Size(max = 50) String action, Date tempdatefrom, Date tempdateto,
//			Time temptimefrom, Time temptimeto, @Size(max = 50) String[] accesstodb, Date submitdate,
//			Timestamp submittime, @Size(max = 50) String unitheaduserid, @Size(max = 50) String unitheadusername,
//			@Size(max = 50) String unitheadstatus, Timestamp unitheadsubdate, @Size(max = 255) String unitheadcmnt,
//			@Size(max = 50) String isrmheaduserid, @Size(max = 50) String isrmheadusername,
//			@Size(max = 50) String isrmheadstatus, Timestamp isrmheadsubdate, @Size(max = 255) String isrmheadcmnt,
//			@Size(max = 50) String citouserid, @Size(max = 50) String citousername, @Size(max = 50) String citostatus,
//			Timestamp citosubdate, @Size(max = 255) String citocmnt, @Size(max = 50) String implbyunitheaduserid,
//			@Size(max = 50) String implbyunitheadusername, @Size(max = 50) String implbyunitheadstatus,
//			@Size(max = 255) String implbyunitheadcmnt, Timestamp implbyunitheadsubdate,
//			@Size(max = 50) String implementedbyuserid, @Size(max = 50) String implementedbyusername,
//			@Size(max = 50) String implementedbystatus, Timestamp implementedbysubdate, Long implementedbydeptid) {
//		super();
//		this.id = id;
//		this.formid = formid;
//		this.userid = userid;
//		this.referenceValue = referenceValue;
//		this.actype = actype;
//		this.action = action;
//		this.tempdatefrom = tempdatefrom;
//		this.tempdateto = tempdateto;
//		this.temptimefrom = temptimefrom;
//		this.temptimeto = temptimeto;
//		this.accesstodb = accesstodb;
//		this.submitdate = submitdate;
//		this.submittime = submittime;
//		this.unitheaduserid = unitheaduserid;
//		this.unitheadusername = unitheadusername;
//		this.unitheadstatus = unitheadstatus;
//		this.unitheadsubdate = unitheadsubdate;
//		this.unitheadcmnt = unitheadcmnt;
//		this.isrmheaduserid = isrmheaduserid;
//		this.isrmheadusername = isrmheadusername;
//		this.isrmheadstatus = isrmheadstatus;
//		this.isrmheadsubdate = isrmheadsubdate;
//		this.isrmheadcmnt = isrmheadcmnt;
//		this.citouserid = citouserid;
//		this.citousername = citousername;
//		this.citostatus = citostatus;
//		this.citosubdate = citosubdate;
//		this.citocmnt = citocmnt;
//		this.implbyunitheaduserid = implbyunitheaduserid;
//		this.implbyunitheadusername = implbyunitheadusername;
//		this.implbyunitheadstatus = implbyunitheadstatus;
//		this.implbyunitheadcmnt = implbyunitheadcmnt;
//		this.implbyunitheadsubdate = implbyunitheadsubdate;
//		this.implementedbyuserid = implementedbyuserid;
//		this.implementedbyusername = implementedbyusername;
//		this.implementedbystatus = implementedbystatus;
//		this.implementedbysubdate = implementedbysubdate;
//		this.implementedbydeptid = implementedbydeptid;
//	}
//
//	public Long getId() {
//		return id;
//	}
//
//	public void setId(Long id) {
//		this.id = id;
//	}
//
//	public String getFormid() {
//		return formid;
//	}
//
//	public void setFormid(String formid) {
//		this.formid = formid;
//	}
//
//	public String getUserid() {
//		return userid;
//	}
//
//	public void setUserid(String userid) {
//		this.userid = userid;
//	}
//
//	public String getReferenceValue() {
//		return referenceValue;
//	}
//
//	public void setReferenceValue(String referenceValue) {
//		this.referenceValue = referenceValue;
//	}
//
//	public String getActype() {
//		return actype;
//	}
//
//	public void setActype(String actype) {
//		this.actype = actype;
//	}
//
//	public String getAction() {
//		return action;
//	}
//
//	public void setAction(String acpurpose) {
//		this.action = acpurpose;
//	}
//
//	public Date getTempdatefrom() {
//		return tempdatefrom;
//	}
//
//	public void setTempdatefrom(Date tempdatefrom) {
//		this.tempdatefrom = tempdatefrom;
//	}
//
//	public Date getTempdateto() {
//		return tempdateto;
//	}
//
//	public void setTempdateto(Date tempdateto) {
//		this.tempdateto = tempdateto;
//	}
//
//	public Time getTemptimefrom() {
//		return temptimefrom;
//	}
//
//	public void setTemptimefrom(Time temptimefrom) {
//		this.temptimefrom = temptimefrom;
//	}
//
//	public Time getTemptimeto() {
//		return temptimeto;
//	}
//
//	public void setTemptimeto(Time temptimeto) {
//		this.temptimeto = temptimeto;
//	}
//
//	public String[] getAccesstodb() {
//		return accesstodb;
//	}
//
//	public void setAccesstodb(String[] accesstodb) {
//		this.accesstodb = accesstodb;
//	}
//
//	public Date getSubmitdate() {
//		return submitdate;
//	}
//
//	public void setSubmitdate(Date submitdate) {
//		this.submitdate = submitdate;
//	}
//
//	public Timestamp getSubmittime() {
//		return submittime;
//	}
//
//	public void setSubmittime(Timestamp submittime) {
//		this.submittime = submittime;
//	}
//
//	public String getUnitheaduserid() {
//		return unitheaduserid;
//	}
//
//	public void setUnitheaduserid(String unitheaduserid) {
//		this.unitheaduserid = unitheaduserid;
//	}
//
//	public String getUnitheadusername() {
//		return unitheadusername;
//	}
//
//	public void setUnitheadusername(String unitheadusername) {
//		this.unitheadusername = unitheadusername;
//	}
//
//	public String getUnitheadstatus() {
//		return unitheadstatus;
//	}
//
//	public void setUnitheadstatus(String unitheadstatus) {
//		this.unitheadstatus = unitheadstatus;
//	}
//
//	public Timestamp getUnitheadsubdate() {
//		return unitheadsubdate;
//	}
//
//	public void setUnitheadsubdate(Timestamp unitheadsubdate) {
//		this.unitheadsubdate = unitheadsubdate;
//	}
//
//	public String getUnitheadcmnt() {
//		return unitheadcmnt;
//	}
//
//	public void setUnitheadcmnt(String unitheadcmnt) {
//		this.unitheadcmnt = unitheadcmnt;
//	}
//
//	public String getIsrmheaduserid() {
//		return isrmheaduserid;
//	}
//
//	public void setIsrmheaduserid(String isrmheaduserid) {
//		this.isrmheaduserid = isrmheaduserid;
//	}
//
//	public String getIsrmheadusername() {
//		return isrmheadusername;
//	}
//
//	public void setIsrmheadusername(String isrmheadusername) {
//		this.isrmheadusername = isrmheadusername;
//	}
//
//	public String getIsrmheadstatus() {
//		return isrmheadstatus;
//	}
//
//	public void setIsrmheadstatus(String isrmheadstatus) {
//		this.isrmheadstatus = isrmheadstatus;
//	}
//
//	public Timestamp getIsrmheadsubdate() {
//		return isrmheadsubdate;
//	}
//
//	public void setIsrmheadsubdate(Timestamp isrmheadsubdate) {
//		this.isrmheadsubdate = isrmheadsubdate;
//	}
//
//	public String getIsrmheadcmnt() {
//		return isrmheadcmnt;
//	}
//
//	public void setIsrmheadcmnt(String isrmheadcmnt) {
//		this.isrmheadcmnt = isrmheadcmnt;
//	}
//
//	public String getCitouserid() {
//		return citouserid;
//	}
//
//	public void setCitouserid(String citouserid) {
//		this.citouserid = citouserid;
//	}
//
//	public String getCitousername() {
//		return citousername;
//	}
//
//	public void setCitousername(String citousername) {
//		this.citousername = citousername;
//	}
//
//	public String getCitostatus() {
//		return citostatus;
//	}
//
//	public void setCitostatus(String citostatus) {
//		this.citostatus = citostatus;
//	}
//
//	public Timestamp getCitosubdate() {
//		return citosubdate;
//	}
//
//	public void setCitosubdate(Timestamp citosubdate) {
//		this.citosubdate = citosubdate;
//	}
//
//	public String getCitocmnt() {
//		return citocmnt;
//	}
//
//	public void setCitocmnt(String citocmnt) {
//		this.citocmnt = citocmnt;
//	}
//
//	public String getImplbyunitheaduserid() {
//		return implbyunitheaduserid;
//	}
//
//	public void setImplbyunitheaduserid(String implbyunitheaduserid) {
//		this.implbyunitheaduserid = implbyunitheaduserid;
//	}
//
//	public String getImplbyunitheadusername() {
//		return implbyunitheadusername;
//	}
//
//	public void setImplbyunitheadusername(String implbyunitheadusername) {
//		this.implbyunitheadusername = implbyunitheadusername;
//	}
//
//	public String getImplbyunitheadstatus() {
//		return implbyunitheadstatus;
//	}
//
//	public void setImplbyunitheadstatus(String implbyunitheadstatus) {
//		this.implbyunitheadstatus = implbyunitheadstatus;
//	}
//
//	public String getImplbyunitheadcmnt() {
//		return implbyunitheadcmnt;
//	}
//
//	public void setImplbyunitheadcmnt(String implbyunitheadcmnt) {
//		this.implbyunitheadcmnt = implbyunitheadcmnt;
//	}
//
//	public Timestamp getImplbyunitheadsubdate() {
//		return implbyunitheadsubdate;
//	}
//
//	public void setImplbyunitheadsubdate(Timestamp implbyunitheadsubdate) {
//		this.implbyunitheadsubdate = implbyunitheadsubdate;
//	}
//
//	public String getImplementedbyuserid() {
//		return implementedbyuserid;
//	}
//
//	public void setImplementedbyuserid(String implementedbyuserid) {
//		this.implementedbyuserid = implementedbyuserid;
//	}
//
//	public String getImplementedbyusername() {
//		return implementedbyusername;
//	}
//
//	public void setImplementedbyusername(String implementedbyusername) {
//		this.implementedbyusername = implementedbyusername;
//	}
//
//	public String getImplementedbystatus() {
//		return implementedbystatus;
//	}
//
//	public void setImplementedbystatus(String implementedbystatus) {
//		this.implementedbystatus = implementedbystatus;
//	}
//
//	public Timestamp getImplementedbysubdate() {
//		return implementedbysubdate;
//	}
//
//	public void setImplementedbysubdate(Timestamp implementedbysubdate) {
//		this.implementedbysubdate = implementedbysubdate;
//	}
//
//	public Long getImplementedbydeptid() {
//		return implementedbydeptid;
//	}
//
//	public void setImplementedbydeptid(Long implementedbydeptid) {
//		this.implementedbydeptid = implementedbydeptid;
//	}
//
//}
package com.fsiberp.frms.model;

import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "form_database_access")
public class DatabaseAccess {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "form_id")
	private String formid;

	
	@Size(max = 50)
	@Column(name = "user_id")
	private String userid;

	@Size(max = 50)
	@Column(name = "ref")
	private String referencevalue;

	@Size(max = 50)
	@Column(name = "action")
	private String[] action;

	@Size(max = 50)
	@Column(name = "ac_type")
	private String actype;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(name = "temp_date_from")
	private Date tempdatefrom;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(name = "temp_date_to")
	private Date tempdateto;

	@JsonFormat(pattern = "HH:mm:ss")
	@Column(name = "temp_time_from")
	private Time temptimefrom;

	@JsonFormat(pattern = "HH:mm:ss")
	@Column(name = "temp_time_to")
	private Time temptimeto;

	@Column(name = "access_to_database")
	private String[] accesstodatabase;

	@Column(name = "submit_date")
	private Date submitdate;

	@Column(name = "submit_time")
	private Timestamp submittime;

	@Size(max = 50)
	@Column(name = "unit_head_userid")
	private String unitheaduserid;

	@Size(max = 50)
	@Column(name = "unit_head_username")
	private String unitheadusername;

	@Size(max = 50)
	@Column(name = "unit_head_status")
	private String unitheadstatus;

	@Column(name = "unit_head_sub_date")
	private Timestamp unitheadsubdate;

	@Size(max = 255)
	@Column(name = "unit_head_cmnt")
	private String unitheadcmnt;

	@Size(max = 50)
	@Column(name = "isrm_head_userid")
	private String isrmheaduserid;

	@Size(max = 50)
	@Column(name = "isrm_head_username")
	private String isrmheadusername;

	@Size(max = 50)
	@Column(name = "isrm_head_status")
	private String isrmheadstatus;

	@Column(name = "isrm_head_sub_date")
	private Timestamp isrmheadsubdate;

	@Size(max = 255)
	@Column(name = "isrm_head_cmnt")
	private String isrmheadcmnt;

	@Size(max = 50)
	@Column(name = "cito_userid")
	private String citouserid;

	@Size(max = 50)
	@Column(name = "cito_username")
	private String citousername;

	@Size(max = 50)
	@Column(name = "cito_status")
	private String citostatus;

	@Column(name = "cito_sub_date")
	private Timestamp citosubdate;

	@Size(max = 255)
	@Column(name = "cito_cmnt")
	private String citocmnt;

	@Size(max = 50)
	@Column(name = "impl_by_unithead_userid")
	private String implbyunitheaduserid;

	@Size(max = 50)
	@Column(name = "impl_by_unithead_username")
	private String implbyunitheadusername;

	@Size(max = 50)
	@Column(name = "impl_by_unithead_status")
	private String implbyunitheadstatus;

	@Size(max = 255)
	@Column(name = "impl_by_unithead_cmnt")
	private String implbyunitheadcmnt;

	@Column(name = "impl_by_unithead_sub_date")
	private Timestamp implbyunitheadsubdate;

	@Size(max = 50)
	@Column(name = "implemented_by_userid")
	private String implementedbyuserid;

	@Size(max = 50)
	@Column(name = "implemented_by_username")
	private String implementedbyusername;

	@Size(max = 50)
	@Column(name = "implemented_by_status")
	private String implementedbystatus;

	@Column(name = "implemented_by_sub_date")
	private Timestamp implementedbysubdate;

	@Column(name = "implemented_by_dept_id")
	private Long implementedbydeptid;
	
	@Size(max = 50)
	@Column(name = "other")
	private String other;
	
	@Column(name = "branch_code")
	private String branchCode;
	
	@Column(name = "department")
	private String department;

	public DatabaseAccess() {
		super();
	}

	public DatabaseAccess(Long id, String formid, @NotBlank @Size(max = 50) String userid, String branchCode,
			@Size(max = 50) String referencevalue, @Size(max = 50) String[] action, @Size(max = 50) String actype,
			Date tempdatefrom, Date tempdateto, Time temptimefrom, Time temptimeto, String[] accesstodatabase,
			Date submitdate, Timestamp submittime, @Size(max = 50) String unitheaduserid, String other,
			@Size(max = 50) String unitheadusername, @Size(max = 50) String unitheadstatus, Timestamp unitheadsubdate,
			@Size(max = 255) String unitheadcmnt, @Size(max = 50) String isrmheaduserid, String department,
			@Size(max = 50) String isrmheadusername, @Size(max = 50) String isrmheadstatus, Timestamp isrmheadsubdate,
			@Size(max = 255) String isrmheadcmnt, @Size(max = 50) String citouserid,
			@Size(max = 50) String citousername, @Size(max = 50) String citostatus, Timestamp citosubdate,
			@Size(max = 255) String citocmnt, @Size(max = 50) String implbyunitheaduserid,
			@Size(max = 50) String implbyunitheadusername, @Size(max = 50) String implbyunitheadstatus,
			@Size(max = 255) String implbyunitheadcmnt, Timestamp implbyunitheadsubdate,
			@Size(max = 50) String implementedbyuserid, @Size(max = 50) String implementedbyusername,
			@Size(max = 50) String implementedbystatus, Timestamp implementedbysubdate, Long implementedbydeptid) {
		super();
		this.id = id;
		this.formid = formid;
		this.userid = userid;
		this.referencevalue = referencevalue;
		this.action = action;
		this.actype = actype;
		this.tempdatefrom = tempdatefrom;
		this.tempdateto = tempdateto;
		this.temptimefrom = temptimefrom;
		this.temptimeto = temptimeto;
		this.accesstodatabase = accesstodatabase;
		this.submitdate = submitdate;
		this.submittime = submittime;
		this.unitheaduserid = unitheaduserid;
		this.unitheadusername = unitheadusername;
		this.unitheadstatus = unitheadstatus;
		this.unitheadsubdate = unitheadsubdate;
		this.unitheadcmnt = unitheadcmnt;
		this.isrmheaduserid = isrmheaduserid;
		this.isrmheadusername = isrmheadusername;
		this.isrmheadstatus = isrmheadstatus;
		this.isrmheadsubdate = isrmheadsubdate;
		this.isrmheadcmnt = isrmheadcmnt;
		this.citouserid = citouserid;
		this.citousername = citousername;
		this.citostatus = citostatus;
		this.citosubdate = citosubdate;
		this.citocmnt = citocmnt;
		this.implbyunitheaduserid = implbyunitheaduserid;
		this.implbyunitheadusername = implbyunitheadusername;
		this.implbyunitheadstatus = implbyunitheadstatus;
		this.implbyunitheadcmnt = implbyunitheadcmnt;
		this.implbyunitheadsubdate = implbyunitheadsubdate;
		this.implementedbyuserid = implementedbyuserid;
		this.implementedbyusername = implementedbyusername;
		this.implementedbystatus = implementedbystatus;
		this.implementedbysubdate = implementedbysubdate;
		this.implementedbydeptid = implementedbydeptid;
		this.other = other;
		this.branchCode = branchCode;
		this.department = department;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFormid() {
		return formid;
	}

	public void setFormid(String formid) {
		this.formid = formid;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getReferencevalue() {
		return referencevalue;
	}

	public void setReferencevalue(String referencevalue) {
		this.referencevalue = referencevalue;
	}

	public String[] getAction() {
		return action;
	}

	public void setAction(String[] action) {
		this.action = action;
	}

	public String getActype() {
		return actype;
	}

	public void setActype(String actype) {
		this.actype = actype;
	}

	public Date getTempdatefrom() {
		return tempdatefrom;
	}

	public void setTempdatefrom(Date tempdatefrom) {
		this.tempdatefrom = tempdatefrom;
	}

	public Date getTempdateto() {
		return tempdateto;
	}

	public void setTempdateto(Date tempdateto) {
		this.tempdateto = tempdateto;
	}

	public Time getTemptimefrom() {
		return temptimefrom;
	}

	public void setTemptimefrom(Time temptimefrom) {
		this.temptimefrom = temptimefrom;
	}

	public Time getTemptimeto() {
		return temptimeto;
	}

	public void setTemptimeto(Time temptimeto) {
		this.temptimeto = temptimeto;
	}

	public String[] getAccesstodatabase() {
		return accesstodatabase;
	}

	public void setAccesstodatabase(String[] accesstodatabase) {
		this.accesstodatabase = accesstodatabase;
	}

	public Date getSubmitdate() {
		return submitdate;
	}

	public void setSubmitdate(Date submitdate) {
		this.submitdate = submitdate;
	}

	public Timestamp getSubmittime() {
		return submittime;
	}

	public void setSubmittime(Timestamp submittime) {
		this.submittime = submittime;
	}

	public String getUnitheaduserid() {
		return unitheaduserid;
	}

	public void setUnitheaduserid(String unitheaduserid) {
		this.unitheaduserid = unitheaduserid;
	}

	public String getUnitheadusername() {
		return unitheadusername;
	}

	public void setUnitheadusername(String unitheadusername) {
		this.unitheadusername = unitheadusername;
	}

	public String getUnitheadstatus() {
		return unitheadstatus;
	}

	public void setUnitheadstatus(String unitheadstatus) {
		this.unitheadstatus = unitheadstatus;
	}

	public Timestamp getUnitheadsubdate() {
		return unitheadsubdate;
	}

	public void setUnitheadsubdate(Timestamp unitheadsubdate) {
		this.unitheadsubdate = unitheadsubdate;
	}

	public String getUnitheadcmnt() {
		return unitheadcmnt;
	}

	public void setUnitheadcmnt(String unitheadcmnt) {
		this.unitheadcmnt = unitheadcmnt;
	}

	public String getIsrmheaduserid() {
		return isrmheaduserid;
	}

	public void setIsrmheaduserid(String isrmheaduserid) {
		this.isrmheaduserid = isrmheaduserid;
	}

	public String getIsrmheadusername() {
		return isrmheadusername;
	}

	public void setIsrmheadusername(String isrmheadusername) {
		this.isrmheadusername = isrmheadusername;
	}

	public String getIsrmheadstatus() {
		return isrmheadstatus;
	}

	public void setIsrmheadstatus(String isrmheadstatus) {
		this.isrmheadstatus = isrmheadstatus;
	}

	public Timestamp getIsrmheadsubdate() {
		return isrmheadsubdate;
	}

	public void setIsrmheadsubdate(Timestamp isrmheadsubdate) {
		this.isrmheadsubdate = isrmheadsubdate;
	}

	public String getIsrmheadcmnt() {
		return isrmheadcmnt;
	}

	public void setIsrmheadcmnt(String isrmheadcmnt) {
		this.isrmheadcmnt = isrmheadcmnt;
	}

	public String getCitouserid() {
		return citouserid;
	}

	public void setCitouserid(String citouserid) {
		this.citouserid = citouserid;
	}

	public String getCitousername() {
		return citousername;
	}

	public void setCitousername(String citousername) {
		this.citousername = citousername;
	}

	public String getCitostatus() {
		return citostatus;
	}

	public void setCitostatus(String citostatus) {
		this.citostatus = citostatus;
	}

	public Timestamp getCitosubdate() {
		return citosubdate;
	}

	public void setCitosubdate(Timestamp citosubdate) {
		this.citosubdate = citosubdate;
	}

	public String getCitocmnt() {
		return citocmnt;
	}

	public void setCitocmnt(String citocmnt) {
		this.citocmnt = citocmnt;
	}

	public String getImplbyunitheaduserid() {
		return implbyunitheaduserid;
	}

	public void setImplbyunitheaduserid(String implbyunitheaduserid) {
		this.implbyunitheaduserid = implbyunitheaduserid;
	}

	public String getImplbyunitheadusername() {
		return implbyunitheadusername;
	}

	public void setImplbyunitheadusername(String implbyunitheadusername) {
		this.implbyunitheadusername = implbyunitheadusername;
	}

	public String getImplbyunitheadstatus() {
		return implbyunitheadstatus;
	}

	public void setImplbyunitheadstatus(String implbyunitheadstatus) {
		this.implbyunitheadstatus = implbyunitheadstatus;
	}

	public String getImplbyunitheadcmnt() {
		return implbyunitheadcmnt;
	}

	public void setImplbyunitheadcmnt(String implbyunitheadcmnt) {
		this.implbyunitheadcmnt = implbyunitheadcmnt;
	}

	public Timestamp getImplbyunitheadsubdate() {
		return implbyunitheadsubdate;
	}

	public void setImplbyunitheadsubdate(Timestamp implbyunitheadsubdate) {
		this.implbyunitheadsubdate = implbyunitheadsubdate;
	}

	public String getImplementedbyuserid() {
		return implementedbyuserid;
	}

	public void setImplementedbyuserid(String implementedbyuserid) {
		this.implementedbyuserid = implementedbyuserid;
	}

	public String getImplementedbyusername() {
		return implementedbyusername;
	}

	public void setImplementedbyusername(String implementedbyusername) {
		this.implementedbyusername = implementedbyusername;
	}

	public String getImplementedbystatus() {
		return implementedbystatus;
	}

	public void setImplementedbystatus(String implementedbystatus) {
		this.implementedbystatus = implementedbystatus;
	}

	public Timestamp getImplementedbysubdate() {
		return implementedbysubdate;
	}

	public void setImplementedbysubdate(Timestamp implementedbysubdate) {
		this.implementedbysubdate = implementedbysubdate;
	}

	public Long getImplementedbydeptid() {
		return implementedbydeptid;
	}

	public void setImplementedbydeptid(Long implementedbydeptid) {
		this.implementedbydeptid = implementedbydeptid;
	}

	public String getOther() {
		return other;
	}

	public void setOther(String other) {
		this.other = other;
	}
	
	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	
	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}
}
