package com.fsiberp.frms.services.impl;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.NoSuchElementException;

import org.springframework.stereotype.Service;

import com.fsiberp.frms.model.FunctionalRole;
import com.fsiberp.frms.model.IncidentReport;
import com.fsiberp.frms.model.StatusUpdateRequest;
import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.AuthRepository;
import com.fsiberp.frms.repository.FunctionalRoleRepository;
import com.fsiberp.frms.repository.IncidentReportRepository;
import com.fsiberp.frms.services.EmailService;
import com.fsiberp.frms.services.IncidentReportService;
import com.fsiberp.frms.services.NotificationService;
import com.fsiberp.frms.services.ProfileService;
import jakarta.transaction.Transactional;

@Service
public class IncidentReportServiceImpl implements IncidentReportService {

    private final IncidentReportRepository incidentReportRepository;
    private final NotificationService notificationService;
    private final ProfileService profileService;
    private final FunctionalRoleRepository functionalRoleRepository;
    private final AuthRepository authRepository;
    private EmailService emailService;
    

    public IncidentReportServiceImpl(IncidentReportRepository incidentReportRepository, NotificationService notificationService,
            ProfileService profileService, FunctionalRoleRepository functionalRoleRepository,
            AuthRepository authRepository, EmailService emailService) {
        this.incidentReportRepository = incidentReportRepository;
        this.notificationService = notificationService;
        this.profileService = profileService;
        this.functionalRoleRepository = functionalRoleRepository;
        this.authRepository = authRepository;
        this.emailService = emailService;
    }

    @Override
    public IncidentReport createForm(IncidentReport incidentReport) {
        IncidentReport savedForm = incidentReportRepository.save(incidentReport);

        if (incidentReport.getUnitheaduserid() != null) {
            User user = profileService.getUserByUserid(incidentReport.getUserid());
            String username = user != null ? user.getUsername() : "Unknown User";

            notificationService.createNotification(
                    incidentReport.getUnitheaduserid(),
                    "A new Incident Report has been submitted by " + username + " (" + incidentReport.getUserid() + ")",
                    incidentReport.getUserid(),
                    incidentReport.getFormid(), 
                    incidentReport.getId(),
                    false
            );
        }

        return savedForm;
    }

    @Transactional
    public IncidentReport saveForm(IncidentReport form) {
        // Save the report temporarily to generate the ID
        IncidentReport savedForm = incidentReportRepository.save(form);

        // Generate the reference value using the generated ID
        String currentYear = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        String paddedReportId = String.format("%05d", savedForm.getId()); // Padded with zeros
        String referenceValue = currentYear + "-1006/" + paddedReportId;

        // Set the reference value
        savedForm.setReferenceValue(referenceValue);

        // Save the report again with the reference value
        savedForm = incidentReportRepository.save(savedForm);

        // Trigger notification for the assigned user if the userid is set
        if (savedForm.getUnitheaduserid() != null) {
            User user = profileService.getUserByUserid(savedForm.getUserid());
            String username = user != null ? user.getUsername() : "Unknown User";

            notificationService.createNotification(
                    savedForm.getUnitheaduserid(),
                    "A new Incident Report form has been submitted by " + username + " (" + savedForm.getUserid() + ")",
                    savedForm.getUserid(),
                    savedForm.getFormid(), 
                    savedForm.getId(),     
                    false                    
                );
            
            //     unit head email
            emailService.sendNotificationEmail(user, savedForm.getUnitheaduserid(),1);
            }

        return savedForm;
    }

    @Override
    public IncidentReport updateStatus(Long id, String userid, StatusUpdateRequest request, Timestamp currentTimestamp) {
        IncidentReport incidentReport = incidentReportRepository.findById(id)
                .orElseThrow(NoSuchElementException::new);

        if ("Pending".equals(incidentReport.getUnitheadstatus()) || 
            "Rejected".equals(incidentReport.getUnitheadstatus()) || 
            incidentReport.getUnitheadstatus() == null) {

            // Handle Unit Head status update
            incidentReport.setUnitheadstatus(request.getStatus());
            incidentReport.setUnitheadcmnt(request.getComment());
            incidentReport.setUnitheadsubdate(currentTimestamp);

            notificationService.createNotification(
                incidentReport.getUserid(),
                "Your Incident Report was " + request.getStatus() + " by Unit Head " + incidentReport.getUnitheadusername() + " (" + incidentReport.getUnitheaduserid() + ")",
                incidentReport.getUserid(),
                incidentReport.getFormid(),
                incidentReport.getId(),
                false // Not viewed by default
            );

            if ("Accepted".equalsIgnoreCase(request.getStatus())) {
                User user = profileService.getUserByUserid(incidentReport.getUserid());
//                String username = user != null ? user.getUsername() : "Unknown User";


                User formSubmitter = profileService.getUserByUserid(incidentReport.getUserid());
				String deptName = formSubmitter != null ? formSubmitter.getDepartment() : "Unknown Branch";
				String branchCode = formSubmitter != null ? formSubmitter.getBranchcode() : "Unknown Code";

                
                
                notificationService.createNotification(
                    incidentReport.getIsrmheaduserid(),
                    "A new Incident Report has been submitted from "+ formSubmitter.getUsername() + "(" + formSubmitter.getUserid()  + "), " + deptName + " (" + branchCode + ") requires your approval.",
					incidentReport.getUserid(),
                    incidentReport.getFormid(),
                    incidentReport.getId(),
                    false // 
                );

//              isrm head email
                emailService.sendNotificationEmail(user, incidentReport.getIsrmheaduserid(),1);
            }

        } else {
            FunctionalRole functionalRole = functionalRoleRepository.findByUserid(userid)
                    .orElseThrow(() -> new NoSuchElementException("No such user role found"));

            switch (functionalRole.getFunctionalrole().toLowerCase()) {
                case "isrm":
                    incidentReport.setIsrmheadstatus(request.getStatus());
                    incidentReport.setIsrmheadcmnt(request.getComment());
                    incidentReport.setIsrmheadsubdate(currentTimestamp);

                    notificationService.createNotification(
                        incidentReport.getUserid(),
                        "Your Incident Report was " + request.getStatus() + " by ISRM Head " + incidentReport.getIsrmheadusername() + " (" + incidentReport.getIsrmheaduserid() + ").",
                        incidentReport.getUserid(),
                        incidentReport.getFormid(),
                        incidentReport.getId(),
                        false // Not viewed by default
                    );

                    if ("Accepted".equalsIgnoreCase(request.getStatus())) {
                        User user = profileService.getUserByUserid(incidentReport.getUserid());
//                        String username = user != null ? user.getUsername() : "Unknown User";


                        User formSubmitter = profileService.getUserByUserid(incidentReport.getUserid());
        				String deptName = formSubmitter != null ? formSubmitter.getDepartment() : "Unknown Branch";
        				String branchCode = formSubmitter != null ? formSubmitter.getBranchcode() : "Unknown Code";
              
                        notificationService.createNotification(
                            incidentReport.getCitouserid(),
                            "A new Incident Report has been submitted from "+ formSubmitter.getUsername() + "(" + formSubmitter.getUserid()  + "), " + deptName + " (" + branchCode + ") requires your approval.",
        					incidentReport.getUserid(),
                            incidentReport.getFormid(),
                            incidentReport.getId(),
                            false // Not viewed by default
                        );
                        

//                      cito email
                        emailService.sendNotificationEmail(user, incidentReport.getCitouserid(),1);
                    }
                    break;
                case "cito":
                    incidentReport.setCitostatus(request.getStatus());
                    incidentReport.setCitocmnt(request.getComment());
                    incidentReport.setCitosubdate(currentTimestamp);

                    notificationService.createNotification(
                        incidentReport.getUserid(),
                        "Your Incident Report was " + request.getStatus() + " by CITO " + incidentReport.getCitousername() + " (" + incidentReport.getCitouserid() + ").",
                        incidentReport.getUserid(),
                        incidentReport.getFormid(),
                        incidentReport.getId(),
                        false // Not viewed by default
                    );
                    
//                  user email
      	            User userinfo = authRepository.findByUserid(incidentReport.getUserid()).orElse(null);
      	            emailService.sendNotificationEmailForUser(userinfo, incidentReport.getUserid(),1);
      		            
                    break;
                default:
                    throw new IllegalArgumentException("Invalid role");
            }
        }

        return incidentReportRepository.save(incidentReport);
    }

}
