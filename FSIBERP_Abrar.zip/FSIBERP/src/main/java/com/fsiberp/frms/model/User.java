package com.fsiberp.frms.model;

import java.sql.Timestamp;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import jakarta.validation.constraints.NotBlank;


@Entity
@Table( name = "sys_app_user" )
public class User {
	
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  
  @NotBlank
  @Size(max = 20)
  @Column(name = "user_id")
  private String userid;
  
  @Size(max = 100)
  @Column(name = "emp_id")
  private String empid;

  @NotBlank
  @Size(max = 255)
  private String password;
  
  @Size(max = 100)
  @Column(name = "user_name")
  private String username;
  
  @Size(max = 50)
  @Column(name = "user_grp")
  private String usergrp;
  
  @Column(name = "ch_pass_on_logon", columnDefinition = "VARCHAR(1)")
  private String chngpassword;
  
  @Size(max = 50)
  @Column(name = "designation")
  private String designation;
  
  @Size(max = 20)
  @Column(name = "contact_no")
  private String contactno;
  
  @Size(max = 20)
  @Column(name = "branch_code")
  private String branchcode;
  
  @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSX")
  @Column(name = "create_date")
  private Timestamp createdate;
  
  @Size(max = 20)
  @Column(name = "created_by")
  private String createdby;
  
  @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
  @Column(name = "update_date")
  private Timestamp updatedate;
  
  @Size(max = 60)
  @Column(name = "email_id")
  private String email;
  
  @Column(name = "last_pass_chng_date")
  private Timestamp lastpasschngdate;
  
  @Column(name = "role_id")
  private Integer roleid;
  
  @Size(max = 50)
  @Column(name = "department")
  private String department;
  
  @Size(max = 100)
  @Column(name = "unit")
  private String unit;
  
  @Size(max = 50)
  @Column(name = "machine_ip")
  private String machineIp;
  
  @Size(max = 50)
  @Column(name = "date_of_joining")
  private String dateofjoining;
  
  @Column(name = "role_chng")
  private Integer rolechng;

public User() {
	  
  }

public User(Long id, String empid, String userid, String password, String username, String usergrp, String chngpassword, String designation, 
		String contactno, String branchcode, Timestamp createdate, String createdby, Timestamp updatedate, String email, 
		Timestamp lastpasschngdate, Integer roleid, String department, String unit, String machineIp, String dateofjoining, Integer rolechng) {
	super();
	this.id = id;
	this.userid = userid;
	this.empid = empid;
	this.password = password;
	this.username = username;
	this.usergrp = usergrp;
	this.chngpassword = chngpassword;
	this.designation = designation;
	this.contactno = contactno;
	this.branchcode = branchcode;
	this.createdate = createdate;
	this.createdby = createdby;
	this.updatedate = updatedate;
	this.email = email;
	this.lastpasschngdate = lastpasschngdate;
	this.roleid = roleid;
	this.department = department;
	this.unit = unit;
	this.machineIp = machineIp;
	this.dateofjoining = dateofjoining;
	this.rolechng = rolechng;
}

public Long getId() {
	return id;
}

public String getUserid() {
	return userid;
}

public String getPassword() {
	return password;
}

public String getUsername() {
	return username;
}

public String getUsergrp() {
	return usergrp;
}

public String getChngpassword() {
	return chngpassword;
}

public String getDesignation() {
	return designation;
}

public String getContactno() {
	return contactno;
}

public String getBranchcode() {
	return branchcode;
}

public Timestamp getCreatedate() {
	return createdate;
}

public String getCreatedby() {
	return createdby;
}

public Timestamp getUpdatedate() {
	return updatedate;
}

public String getEmail() {
	return email;
}

public Timestamp getLastpasschngdate() {
	return lastpasschngdate;
}

public Integer getRoleid() {
	return roleid;
}

public void setId(Long id) {
	this.id = id;
}

public void setUserid(String userid) {
	this.userid = userid;
}

public void setPassword(String password) {
	this.password = password;
}

public void setUsername(String username) {
	this.username = username;
}

public void setUsergrp(String usergrp) {
	this.usergrp = usergrp;
}

public void setChngpassword(String chngpassword) {
	this.chngpassword = chngpassword;
}

public void setDesignation(String designation) {
	this.designation = designation;
}

public void setContactno(String contactno) {
	this.contactno = contactno;
}

public void setBranchcode(String branchcode) {
	this.branchcode = branchcode;
}

public void setCreatedate(Timestamp createdate) {
	this.createdate = createdate;
}

public void setCreatedby(String createdby) {
	this.createdby = createdby;
}

public void setUpdatedate(Timestamp updatedate) {
	this.updatedate = updatedate;
}

public void setEmail(String email) {
	this.email = email;
}

public void setLastpasschngdate(Timestamp lastpasschngdate) {
	this.lastpasschngdate = lastpasschngdate;
}

public void setRoleid(Integer roleid) {
	this.roleid = roleid;
}
  
public String getDepartment() {
	return department;
}

public void setDepartment(String department) {
	this.department = department;
}

public String getUnit() {
	return unit;
}

public void setUnit(String unit) {
	this.unit = unit;
}
@Transient
private String confirmPassword;

public String getConfirmPassword() {
	return confirmPassword;
}
public void setConfirmPassword(String confirmPassword) {
	this.confirmPassword = confirmPassword;
}

public String getMachineIp() {
	return machineIp;
}

public void setMachineIp(String machineIp) {
	this.machineIp = machineIp;
}

public String getDateofjoining() {
	return dateofjoining;
}

public void setDateofjoining(String dateofjoining) {
	this.dateofjoining = dateofjoining;
}

public String getEmpid() {
	return empid;
}

public void setEmpid(String empid) {
	this.empid = empid;
}

public Integer getRolechng() {
	return rolechng;
}

public void setRolechng(Integer rolechng) {
	this.rolechng = rolechng;
}

}
