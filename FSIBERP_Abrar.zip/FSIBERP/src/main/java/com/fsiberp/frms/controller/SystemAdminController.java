package com.fsiberp.frms.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fsiberp.bms.model.UnitHead;
import com.fsiberp.bms.services.UnitHeadService;
import com.fsiberp.frms.model.FunctionalRole;
import com.fsiberp.frms.services.SystemAdminService;

import jakarta.validation.Valid;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/admin/")
public class SystemAdminController {
	
	@Autowired
	private UnitHeadService unitHeadService;
	
	@Autowired
	private SystemAdminService systemAdminService;
	
	

    // Add a new member
    @PostMapping("members")
    public ResponseEntity<FunctionalRole> addMember(@Valid @RequestBody FunctionalRole functionalRole) {
        FunctionalRole newRole = systemAdminService.addMember(functionalRole);
        return ResponseEntity.ok(newRole);
    }
    
    
    @PutMapping("members/update/{userid}")
    public ResponseEntity<FunctionalRole> updateMember(
            @PathVariable String userid, 
            @RequestBody @Valid FunctionalRole updatedRole) {
        
        FunctionalRole result = systemAdminService.updateMember(userid, updatedRole);
        if (result != null) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }


    // Get all members
    @GetMapping("members")
    public ResponseEntity<List<FunctionalRole>> getAllMembers() {
        List<FunctionalRole> members = systemAdminService.getAllMembers();
        return ResponseEntity.ok(members);
    }

    // Get a member by userid
    @GetMapping("members/{userid}")
    public ResponseEntity<Optional<FunctionalRole>> getMemberByUserId(@PathVariable String userid) {
        Optional<FunctionalRole> member = systemAdminService.getMemberByUserId(userid);
        if (member.isPresent()) {
            return ResponseEntity.ok(member);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
    @PutMapping("members/temporarily-update-role/{userid}")
    public ResponseEntity<String> temporarilyUpdateRole(
            @PathVariable String userid,
            @RequestBody @Valid Map<String, Integer> requestBody) {

        Integer newRoleId = requestBody.get("newRoleId");
        Integer hours = requestBody.get("hours");

        if (newRoleId == null || hours == null) {
            return ResponseEntity.badRequest().body("Missing required fields: newRoleId or minutes.");
        }

        boolean success = systemAdminService.temporarilyUpdateRole(userid, newRoleId, hours);
        if (success) {
            return ResponseEntity.ok("Role updated successfully and will revert after " + hours + " hours.");
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Failed to update role.");
        }
        
    }
    
    @PostMapping("unit-heads")
    public ResponseEntity<?> addUnitHead(@Valid @RequestBody Map<String, String> request) {

        String existingUserid = request.get("existingUserid");
        String newUserid = request.get("newUserid");
        String funcDesCode = request.get("funcDesCode");
        String funcDesignation = request.get("funcDesignation");
        String existingUseridStatus = request.get("existingUseridstatus");
        String durationInMinutesStr = request.get("durationInMinutes");
        
        if (existingUserid == null || newUserid == null || funcDesCode == null ||
            funcDesignation == null || existingUseridStatus == null || durationInMinutesStr == null) {
            return ResponseEntity.badRequest().body("All fields are required.");
        }
        
        long durationInMinutes;
        try {
            durationInMinutes = Long.parseLong(durationInMinutesStr);
        } catch (NumberFormatException e) {
            return ResponseEntity.badRequest().body("Invalid duration specified.");
        }

        UnitHead newUnitHead;
        try {
        	newUnitHead = unitHeadService.addUnitHead(newUserid, funcDesCode, funcDesignation, existingUserid, existingUseridStatus, durationInMinutes);
        } catch (RuntimeException e) {
        	System.out.println("ok");
            return ResponseEntity.badRequest().body(e.getMessage());
        }

        return ResponseEntity.ok(newUnitHead);
    }
}
