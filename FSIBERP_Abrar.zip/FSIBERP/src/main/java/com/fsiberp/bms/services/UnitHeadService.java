package com.fsiberp.bms.services;

import java.util.Optional;

import com.fsiberp.bms.model.UnitHead;
import com.fsiberp.frms.model.User;

public interface UnitHeadService {
    UnitHead addUnitHead(String newUserid, String funcDesCode, String funcDesignation, String existingUserid, String existingUseridStatus, long durationInMinutes);
    Optional<User> findUserById(String userid);
    void revertChangesAfterDuration(String existingUserid, String newUserid);
}


