package com.fsiberp.bms.model;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "form_debit_voucher")
public class DebitVoucher {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "form_id")
	private String formid;

	
	@Size(max = 50)
	@Column(name = "user_id")
	private String userid;

	@Column(name = "ref")
	private String referenceValue;

	@Column(name = "des_to")
	private String desTo;

	@Column(name = "des_from")
	private String desFrom;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "date_to")
	private Date dateTo;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "date_from")
	private Date dateFrom;

	@Column(name = "vehicle")
	private String vehicle;

	@Column(name = "travel_type")
	private String[] travelType;

	@Column(name = "voucher_type")
	private String voucherType;

	@Column(name = "amount")
	private long amount;

	@Size(max = 255)
	@Column(name = "purpose")
	private String purpose;

	@Size(max = 255)
	@Column(name = "receiver")
	private String receiver;

	@Column(name = "submit_date")
	private Date submitDate;

	@Column(name = "submit_time")
	private Timestamp submitTime;

	@Size(max = 50)
	@Column(name = "second_man_userid")
	private String secondmanuserid;

	@Size(max = 50)
	@Column(name = "second_man_username")
	private String secondmanusername;

	@Size(max = 50)
	@Column(name = "second_man_status")
	private String secondmanstatus;

	@Column(name = "second_man_sub_date")
	private Timestamp secondmansubdate;

	@Size(max = 255)
	@Column(name = "second_man_cmnt")
	private String secondmancmnt;

	@Size(max = 50)
	@Column(name = "unit_head_userid")
	private String unitheaduserid;

	@Size(max = 50)
	@Column(name = "unit_head_username")
	private String unitheadusername;

	@Size(max = 50)
	@Column(name = "unit_head_status")
	private String unitheadstatus;

	@Column(name = "unit_head_sub_date")
	private Timestamp unitheadsubdate;

	@Size(max = 255)
	@Column(name = "unit_head_cmnt")
	private String unitheadcmnt;

	@Size(max = 50)
	@Column(name = "fad_head_userid")
	private String fadheaduserid;

	@Size(max = 50)
	@Column(name = "fad_head_username")
	private String fadheadusername;

	@Size(max = 50)
	@Column(name = "fad_head_status")
	private String fadheadstatus;

	@Column(name = "fad_head_sub_date")
	private Timestamp fadheadsubdate;

	@Size(max = 255)
	@Column(name = "fad_head_cmnt")
	private String fadheadcmnt;

	@Size(max = 50)
	@Column(name = "fad_second_man_userid")
	private String fadsecondmanuserid;

	@Size(max = 50)
	@Column(name = "fad_second_man_username")
	private String fadsecondmanusername;

	@Size(max = 50)
	@Column(name = "fad_second_man_status")
	private String fadsecondmanstatus;

	@Column(name = "fad_second_man_sub_date")
	private Timestamp fadsecondmansubdate;

	@Size(max = 255)
	@Column(name = "fad_second_man_cmnt")
	private String fadsecondmancmnt;

	@Size(max = 50)
	@Column(name = "amd_userid")
	private String amduserid;

	@Size(max = 50)
	@Column(name = "amd_username")
	private String amdusername;

	@Size(max = 50)
	@Column(name = "amd_status")
	private String amdstatus;

	@Column(name = "amd_sub_date")
	private Timestamp amdsubdate;

	@Size(max = 255)
	@Column(name = "amd_cmnt")
	private String amdcmnt;

	@Size(max = 50)
	@Column(name = "dmd_userid")
	private String dmduserid;

	@Size(max = 50)
	@Column(name = "dmd_username")
	private String dmdusername;

	@Size(max = 50)
	@Column(name = "dmd_status")
	private String dmdstatus;

	@Column(name = "dmd_sub_date")
	private Timestamp dmdsubdate;

	@Size(max = 255)
	@Column(name = "dmd_cmnt")
	private String dmdcmnt;

	@Size(max = 50)
	@Column(name = "implemented_by_userid")
	private String implementedbyuserid;

	@Size(max = 50)
	@Column(name = "implemented_by_username")
	private String implementedbyusername;

	@Size(max = 50)
	@Column(name = "implemented_by_status")
	private String implementedbystatus;

	@Size(max = 255)
	@Column(name = "implemented_by_cmnt")
	private String implementedbycmnt;

	@Column(name = "implemented_by_sub_date")
	private Timestamp implementedbysubdate;

	@Column(name = "implemented_by_dept_id")
	private Integer implementedbydeptid;
	
	@Size(max = 1024)
	@Column(name = "document_paths")
	private List<String> documentPaths;


	@Transient
	private List<String> documentDownloadUrl;

	public DebitVoucher() {
		super();

	}

	public DebitVoucher(Long id, String formid, String userid, String referenceValue, String desTo, 
			String desFrom, Date dateTo, Date dateFrom, String vehicle, String[] travelType, String voucherType, 
			long amount, String purpose, String receiver, Date submitDate, Timestamp submitTime, String secondmanuserid,
			String secondmanusername, String secondmanstatus, Timestamp secondmansubdate, String secondmancmnt, String unitheaduserid,
			String unitheadusername, String unitheadstatus, Timestamp unitheadsubdate, String unitheadcmnt, String fadheaduserid,
			String fadheadusername, String fadheadstatus, Timestamp fadheadsubdate, String fadheadcmnt, String fadsecondmanuserid,
			String fadsecondmanusername, String fadsecondmanstatus, Timestamp fadsecondmansubdate, String fadsecondmanfadcmnt,
			String amduserid, String amdusername, String amdstatus, Timestamp amdsubdate, String amdcmnt, String dmduserid,
			String dmdusername, String dmdstatus, Timestamp dmdsubdate, String dmdcmnt, String implementedbyuserid,
			String implementedbyusername, String implementedbystatus, String implementedbycmnt, Timestamp implementedbysubdate, 
			Integer implementedbydeptid, String documentPath, List<String> documentPaths ) {
		super();
		this.id = id;
		this.formid = formid;
		this.userid = userid;
		this.referenceValue = referenceValue;
		this.desTo = desTo;
		this.desFrom = desFrom;
		this.dateTo = dateTo;
		this.dateFrom = dateFrom;
		this.vehicle = vehicle;
		this.travelType = travelType;
		this.voucherType = voucherType;
		this.amount = amount;
		this.purpose = purpose;
		this.receiver = receiver;
		this.submitDate = submitDate;
		this.submitTime = submitTime;
		this.secondmanuserid = secondmanuserid;
		this.secondmanusername = secondmanusername;
		this.secondmanstatus = secondmanstatus;
		this.secondmansubdate = secondmansubdate;
		this.secondmancmnt = secondmancmnt;
		this.unitheaduserid = unitheaduserid;
		this.unitheadusername = unitheadusername;
		this.unitheadstatus = unitheadstatus;
		this.unitheadsubdate = unitheadsubdate;
		this.unitheadcmnt = unitheadcmnt;
		this.fadheaduserid = fadheaduserid;
		this.fadheadusername = fadheadusername;
		this.fadheadstatus = fadheadstatus;
		this.fadheadsubdate = fadheadsubdate;
		this.fadheadcmnt = fadheadcmnt;
		this.fadsecondmanuserid = fadsecondmanuserid;
		this.fadsecondmanusername = fadsecondmanusername;
		this.fadsecondmanstatus = fadsecondmanstatus;
		this.fadsecondmansubdate = fadsecondmansubdate;
		this.fadsecondmancmnt = fadsecondmanfadcmnt;
		this.amduserid = amduserid;
		this.amdusername = amdusername;
		this.amdstatus = amdstatus;
		this.amdsubdate = amdsubdate;
		this.amdcmnt = amdcmnt;
		this.dmduserid = dmduserid;
		this.dmdusername = dmdusername;
		this.dmdstatus = dmdstatus;
		this.dmdsubdate = dmdsubdate;
		this.dmdcmnt = dmdcmnt;
		this.implementedbyuserid = implementedbyuserid;
		this.implementedbyusername = implementedbyusername;
		this.implementedbystatus = implementedbystatus;
		this.implementedbycmnt = implementedbycmnt;
		this.implementedbysubdate = implementedbysubdate;
		this.implementedbydeptid = implementedbydeptid;
		this.documentPaths = documentPaths;
		
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFormid() {
		return formid;
	}

	public void setFormid(String formid) {
		this.formid = formid;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getReferenceValue() {
		return referenceValue;
	}

	public void setReferenceValue(String referenceValue) {
		this.referenceValue = referenceValue;
	}

	public String getDesTo() {
		return desTo;
	}

	public void setDesTo(String desTo) {
		this.desTo = desTo;
	}

	public String getDesFrom() {
		return desFrom;
	}

	public void setDesFrom(String desFrom) {
		this.desFrom = desFrom;
	}

	public Date getDateTo() {
		return dateTo;
	}

	public void setDateTo(Date dateTo) {
		this.dateTo = dateTo;
	}

	public Date getDateFrom() {
		return dateFrom;
	}

	public void setDateFrom(Date dateFrom) {
		this.dateFrom = dateFrom;
	}

	public String getVehicle() {
		return vehicle;
	}

	public void setVehicle(String vehicle) {
		this.vehicle = vehicle;
	}

	public String[] getTravelType() {
		return travelType;
	}

	public void setTravelType(String[] travelType) {
		this.travelType = travelType;
	}

	public String getVoucherType() {
		return voucherType;
	}

	public void setVoucherType(String voucherType) {
		this.voucherType = voucherType;
	}

	public long getAmount() {
		return amount;
	}

	public void setAmount(long amount) {
		this.amount = amount;
	}

	public String getPurpose() {
		return purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public String getReceiver() {
		return receiver;
	}

	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}

	public Date getSubmitDate() {
		return submitDate;
	}

	public void setSubmitDate(Date submitDate) {
		this.submitDate = submitDate;
	}

	public Timestamp getSubmitTime() {
		return submitTime;
	}

	public void setSubmitTime(Timestamp submitTime) {
		this.submitTime = submitTime;
	}

	public String getSecondmanuserid() {
		return secondmanuserid;
	}

	public void setSecondmanuserid(String secondmanuserid) {
		this.secondmanuserid = secondmanuserid;
	}

	public String getSecondmanusername() {
		return secondmanusername;
	}

	public void setSecondmanusername(String secondmanusername) {
		this.secondmanusername = secondmanusername;
	}

	public String getSecondmanstatus() {
		return secondmanstatus;
	}

	public void setSecondmanstatus(String secondmanstatus) {
		this.secondmanstatus = secondmanstatus;
	}

	public Timestamp getSecondmansubdate() {
		return secondmansubdate;
	}

	public void setSecondmansubdate(Timestamp secondmansubdate) {
		this.secondmansubdate = secondmansubdate;
	}

	public String getSecondmancmnt() {
		return secondmancmnt;
	}

	public void setSecondmancmnt(String secondmancmnt) {
		this.secondmancmnt = secondmancmnt;
	}

	public String getUnitheaduserid() {
		return unitheaduserid;
	}

	public void setUnitheaduserid(String unitheaduserid) {
		this.unitheaduserid = unitheaduserid;
	}

	public String getUnitheadusername() {
		return unitheadusername;
	}

	public void setUnitheadusername(String unitheadusername) {
		this.unitheadusername = unitheadusername;
	}

	public String getUnitheadstatus() {
		return unitheadstatus;
	}

	public void setUnitheadstatus(String unitheadstatus) {
		this.unitheadstatus = unitheadstatus;
	}

	public Timestamp getUnitheadsubdate() {
		return unitheadsubdate;
	}

	public void setUnitheadsubdate(Timestamp unitheadsubdate) {
		this.unitheadsubdate = unitheadsubdate;
	}

	public String getUnitheadcmnt() {
		return unitheadcmnt;
	}

	public void setUnitheadcmnt(String unitheadcmnt) {
		this.unitheadcmnt = unitheadcmnt;
	}

	public String getFadheaduserid() {
		return fadheaduserid;
	}

	public void setFadheaduserid(String fadheaduserid) {
		this.fadheaduserid = fadheaduserid;
	}

	public String getFadheadusername() {
		return fadheadusername;
	}

	public void setFadheadusername(String fadheadusername) {
		this.fadheadusername = fadheadusername;
	}

	public String getFadheadstatus() {
		return fadheadstatus;
	}

	public void setFadheadstatus(String fadheadstatus) {
		this.fadheadstatus = fadheadstatus;
	}

	public Timestamp getFadheadsubdate() {
		return fadheadsubdate;
	}

	public void setFadheadsubdate(Timestamp fadheadsubdate) {
		this.fadheadsubdate = fadheadsubdate;
	}

	public String getFadheadcmnt() {
		return fadheadcmnt;
	}

	public void setFadheadcmnt(String fadheadcmnt) {
		this.fadheadcmnt = fadheadcmnt;
	}

	public String getFadsecondmanuserid() {
		return fadsecondmanuserid;
	}

	public void setFadsecondmanuserid(String fadsecondmanuserid) {
		this.fadsecondmanuserid = fadsecondmanuserid;
	}

	public String getFadsecondmanusername() {
		return fadsecondmanusername;
	}

	public void setFadsecondmanusername(String fadsecondmanusername) {
		this.fadsecondmanusername = fadsecondmanusername;
	}

	public String getFadsecondmanstatus() {
		return fadsecondmanstatus;
	}

	public void setFadsecondmanstatus(String fadsecondmanstatus) {
		this.fadsecondmanstatus = fadsecondmanstatus;
	}

	public Timestamp getFadsecondmansubdate() {
		return fadsecondmansubdate;
	}

	public void setFadsecondmansubdate(Timestamp fadsecondmansubdate) {
		this.fadsecondmansubdate = fadsecondmansubdate;
	}

	public String getFadsecondmancmnt() {
		return fadsecondmancmnt;
	}

	public void setFadsecondmancmnt(String fadsecondmancmnt) {
		this.fadsecondmancmnt = fadsecondmancmnt;
	}

	public String getAmduserid() {
		return amduserid;
	}

	public void setAmduserid(String amduserid) {
		this.amduserid = amduserid;
	}

	public String getAmdusername() {
		return amdusername;
	}

	public void setAmdusername(String amdusername) {
		this.amdusername = amdusername;
	}

	public String getAmdstatus() {
		return amdstatus;
	}

	public void setAmdstatus(String amdstatus) {
		this.amdstatus = amdstatus;
	}

	public Timestamp getAmdsubdate() {
		return amdsubdate;
	}

	public void setAmdsubdate(Timestamp amdsubdate) {
		this.amdsubdate = amdsubdate;
	}

	public String getAmdcmnt() {
		return amdcmnt;
	}

	public void setAmdcmnt(String amdcmnt) {
		this.amdcmnt = amdcmnt;
	}

	public String getDmduserid() {
		return dmduserid;
	}

	public void setDmduserid(String dmduserid) {
		this.dmduserid = dmduserid;
	}

	public String getDmdusername() {
		return dmdusername;
	}

	public void setDmdusername(String dmdusername) {
		this.dmdusername = dmdusername;
	}

	public String getDmdstatus() {
		return dmdstatus;
	}

	public void setDmdstatus(String dmdstatus) {
		this.dmdstatus = dmdstatus;
	}

	public Timestamp getDmdsubdate() {
		return dmdsubdate;
	}

	public void setDmdsubdate(Timestamp dmdsubdate) {
		this.dmdsubdate = dmdsubdate;
	}

	public String getDmdcmnt() {
		return dmdcmnt;
	}

	public void setDmdcmnt(String dmdcmnt) {
		this.dmdcmnt = dmdcmnt;
	}

	public String getImplementedbyuserid() {
		return implementedbyuserid;
	}

	public void setImplementedbyuserid(String implementedbyuserid) {
		this.implementedbyuserid = implementedbyuserid;
	}

	public String getImplementedbyusername() {
		return implementedbyusername;
	}

	public void setImplementedbyusername(String implementedbyusername) {
		this.implementedbyusername = implementedbyusername;
	}

	public String getImplementedbystatus() {
		return implementedbystatus;
	}

	public void setImplementedbystatus(String implementedbystatus) {
		this.implementedbystatus = implementedbystatus;
	}

	public String getImplementedbycmnt() {
		return implementedbycmnt;
	}

	public void setImplementedbycmnt(String implementedbycmnt) {
		this.implementedbycmnt = implementedbycmnt;
	}

	public Timestamp getImplementedbysubdate() {
		return implementedbysubdate;
	}

	public void setImplementedbysubdate(Timestamp implementedbysubdate) {
		this.implementedbysubdate = implementedbysubdate;
	}

	public Integer getImplementedbydeptid() {
		return implementedbydeptid;
	}

	public void setImplementedbydeptid(Integer implementedbydeptid) {
		this.implementedbydeptid = implementedbydeptid;
	}

	public List<String> getDocumentDownloadUrl() {
		return documentDownloadUrl;
	}

	public List<String> getDocumentPaths() {
		return documentPaths;
	}

	public void setDocumentPaths(List<String> documentPaths) {
		this.documentPaths = documentPaths;
	}

	public void setDocumentDownloadUrl(List<String> documentDownloadUrl) {
		this.documentDownloadUrl = documentDownloadUrl;
	}
}