package com.fsiberp.bms.services;

import java.sql.Timestamp;

import com.fsiberp.bms.model.BMSStatusUpdateRequest;
import com.fsiberp.bms.model.DebitVoucher;

public interface DebitVoucherService {
	DebitVoucher createForm(DebitVoucher debitVoucher);
	DebitVoucher saveForm(DebitVoucher form);
	DebitVoucher updateStatus(Long id, String userid, BMSStatusUpdateRequest request, Timestamp currentTimestamp);
}
