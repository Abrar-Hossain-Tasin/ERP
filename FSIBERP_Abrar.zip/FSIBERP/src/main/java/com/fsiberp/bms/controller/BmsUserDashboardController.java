package com.fsiberp.bms.controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fsiberp.bms.model.BMSView;
import com.fsiberp.bms.model.DebitVoucher;
import com.fsiberp.bms.repository.DebitVoucherRepository;
import com.fsiberp.frms.controller.PostGRESQLConnUtils;
import com.fsiberp.frms.model.BranchInfo;
import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.AuthRepository;
import com.fsiberp.frms.repository.BranchInfoRepository;
import com.fsiberp.frms.services.ProfileService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/bms_dashboard")
public class BmsUserDashboardController {
	
	private AuthRepository authRepository;
	private BranchInfoRepository branchInfoRepository;
	private ProfileService profileService;
	private DebitVoucherRepository debitVoucherRepository;
	
	public BmsUserDashboardController(AuthRepository authRepository, ProfileService profileService, BranchInfoRepository branchInfoRepository,
			DebitVoucherRepository debitVoucherRepository) {
		
	        this.authRepository = authRepository;
	        this.profileService = profileService;
	        this.branchInfoRepository = branchInfoRepository;
	        this.debitVoucherRepository = debitVoucherRepository;
	    }
	
	@GetMapping("emplist/{id}")
	public List<User>  emplist(@PathVariable(name = "id") String userid) {
		User user = profileService.getUserByUserid(userid);
		
		if (user.getBranchcode().equals("0100")) {
			if (user.getDepartment().equals("I C T Div., Head Office, Dhaka")) {
				
				List<String> unitfuncDesig = null;
				
				if (user.getRoleid() == 3) {
					unitfuncDesig = Arrays.asList("FD002", "FD010");
				}
				else {
					unitfuncDesig = Arrays.asList("FD002", "FD001");
				}
				return authRepository.findAllByDepartmentAndFuncdescode(user.getDepartment(), unitfuncDesig);
			}
			else {
				return authRepository.findAllByDepartmentAndRoleid(user.getDepartment(), 2);
			}
		}
		else {
			if (user.getRoleid() == 3) {
				return authRepository.findAllByBranchcodeAndRoleidAndUseridNot(user.getBranchcode(), 2, userid);
			}
			else {
				BranchInfo branchInfo = branchInfoRepository.findByBranchcode(user.getBranchcode());
				
				List<String> branchcode = null;
				
				if (user.getUsergrp().equals("Manager")) {
					if (branchInfo.getZonalcode().equals("0100")) {
						branchcode = Arrays.asList("0506", "0507");
					}
					else {
						branchcode = Arrays.asList(branchInfo.getZonalcode());
					}
				}
				else {
					branchcode = Arrays.asList(user.getBranchcode());
				}
				return authRepository.findAllByBranchcodeAndRoleid(branchcode, 2);
			}
		}
	}

	@GetMapping("viewform/{userid}/{formid}/{id}")
    public ResponseEntity<?> viewForms(@PathVariable("userid") String userid, @PathVariable("formid") String formid,
    		@PathVariable("id") Long id){
		
			if (formid.equals("3001")) {
			    DebitVoucher debitVoucher = debitVoucherRepository.findAllByUseridAndFormidAndId(userid, formid, id);
			    if (debitVoucher == null) {
			        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			    } 
			// Set download URLs if the document paths are not null
		    List<String> documentPaths = debitVoucher.getDocumentPaths();
		    if (documentPaths != null && !documentPaths.isEmpty()) {
		        List<String> documentDownloadUrls = new ArrayList<>();

		        for (int i = 0; i < documentPaths.size(); i++) {
		            // Add the proper URL pattern to download the document
		            String documentDownloadUrl = "/api/debit/download/document/" + debitVoucher.getId() + "/" + i;
		            documentDownloadUrls.add(documentDownloadUrl);
		        }

		        debitVoucher.setDocumentDownloadUrl(documentDownloadUrls); // Add this field in the model for URLs
		    }

		    return new ResponseEntity<>(debitVoucher, HttpStatus.OK);
		}
			else {
			    return new ResponseEntity<>("Invalid formid", HttpStatus.BAD_REQUEST);
			}
	}
	
	@GetMapping("pending/{id}")
    public List<BMSView> pendingForms(@PathVariable("id") String userid){

		Connection con = null;
		List<BMSView> debitVoucher = new ArrayList<>();
		List<BMSView> dashboard = new ArrayList<>();
		
        try {
            con = PostGRESQLConnUtils.getPostGreSQLConnection();
            con.setAutoCommit(false);
            Statement stmt = con.createStatement();

//          For debit Voucher Form
          
          ResultSet dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
          		+ "WHERE far.user_id = '" + userid + "' "
          		+ "AND NOT ((far.unit_head_status IS NOT NULL AND far.unit_head_status = 'Rejected') "
          		+ "OR (far.second_man_status IS NOT NULL AND far.second_man_status = 'Rejected') "
          		+ "OR (far.fad_second_man_status IS NOT NULL AND far.fad_second_man_status = 'Rejected') "
          		+ "OR (far.fad_head_status IS NOT NULL AND far.fad_head_status = 'Rejected') "
          		+ "OR (far.implemented_by_status IS NOT NULL AND far.implemented_by_status = 'Done') "
          		+ "OR (far.dmd_status IS NOT NULL AND far.dmd_status = 'Rejected') "
          		+ "OR (far.amd_status IS NOT NULL AND far.amd_status = 'Rejected'))"
          		+ "AND (far.unit_head_status = 'Pending' OR far.second_man_status = 'Pending' "
          		+ "OR far.fad_second_man_status = 'Pending' OR far.fad_head_status = 'Pending' "
          		+ "OR far.implemented_by_status = 'Pending' OR far.dmd_status = 'Pending' "
          		+ "OR far.amd_status = 'Pending')");
          
          if (dv != null) {
	            while (dv.next()) {
	            	BMSView bmsView = new BMSView();
	
	                long id = dv.getLong("id");
	                String users = dv.getString("user_id");
	                String username = dv.getString("user_name");
	                String formid = dv.getString("form_id");
	                String formname = dv.getString("form_name");
	                Timestamp submittime = dv.getTimestamp("submit_time");
	                String branch = dv.getString("branch_code");
	                String secondmanstatus = dv.getString("second_man_status");
	            	String unitheadstatus = dv.getString("unit_head_status");
	            	String fadsecondstatus = dv.getString("fad_second_man_status");
	            	String fadheadstatus = dv.getString("fad_head_status");
	            	String dmdstatus = dv.getString("dmd_status");
	            	String amdstatus = dv.getString("amd_status");
	            	String implementerstatus = dv.getString("implemented_by_status");
	
	                bmsView.setId(id);
	                bmsView.setUserid(users);
	                bmsView.setUsername(username);
	                bmsView.setFormid(formid);
	                bmsView.setFormname(formname);
	                bmsView.setSubmittime(submittime);
	                bmsView.setBranchcode(branch);
	                bmsView.setSecondmanstatus(secondmanstatus);
	                bmsView.setUnitheadstatus(unitheadstatus);
	                bmsView.setFadsecondstatus(fadsecondstatus);
	                bmsView.setFadheadstatus(fadheadstatus);
	                bmsView.setDmdstatus(dmdstatus);
	                bmsView.setAmdstatus(amdstatus);
	                bmsView.setImplementerstatus(implementerstatus);
	
	                debitVoucher.add(bmsView);
	            }
          }
          dashboard.addAll(debitVoucher);
          con.close();
          
          
      } catch (Exception e) {
          e.printStackTrace(); 
      }
		
      return dashboard;
	}
	
	@GetMapping("accepted/{id}")
    public List<BMSView> acceptedForms(@PathVariable("id") String userid){

		Connection con = null;
		List<BMSView> debitVoucher = new ArrayList<>();
		List<BMSView> dashboard = new ArrayList<>();

        try {
            con = PostGRESQLConnUtils.getPostGreSQLConnection();
            con.setAutoCommit(false);
            Statement stmt = con.createStatement();

//          For debit Voucher Form
          
          ResultSet dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
          		+ "WHERE far.user_id = '" + userid + "' "
          		+ "AND (far.implemented_by_status = 'Done')");
          
          if (dv != null) {
	            while (dv.next()) {
	            	BMSView bmsView = new BMSView();
	            	
	                long id = dv.getLong("id");
	                String users = dv.getString("user_id");
	                String username = dv.getString("user_name");
	                String formid = dv.getString("form_id");
	                String formname = dv.getString("form_name");
	                Timestamp submittime = dv.getTimestamp("submit_time");
	                String branch = dv.getString("branch_code");
	                String secondmanstatus = dv.getString("second_man_status");
	            	String unitheadstatus = dv.getString("unit_head_status");
	            	String fadsecondstatus = dv.getString("fad_second_man_status");
	            	String fadheadstatus = dv.getString("fad_head_status");
	            	String dmdstatus = dv.getString("dmd_status");
	            	String amdstatus = dv.getString("amd_status");
	            	String implementerstatus = dv.getString("implemented_by_status");
	
	                bmsView.setId(id);
	                bmsView.setUserid(users);
	                bmsView.setUsername(username);
	                bmsView.setFormid(formid);
	                bmsView.setFormname(formname);
	                bmsView.setSubmittime(submittime);
	                bmsView.setBranchcode(branch);
	                bmsView.setSecondmanstatus(secondmanstatus);
	                bmsView.setUnitheadstatus(unitheadstatus);
	                bmsView.setFadsecondstatus(fadsecondstatus);
	                bmsView.setFadheadstatus(fadheadstatus);
	                bmsView.setDmdstatus(dmdstatus);
	                bmsView.setAmdstatus(amdstatus);
	                bmsView.setImplementerstatus(implementerstatus);
	
	                debitVoucher.add(bmsView);
	            }
          }
          dashboard.addAll(debitVoucher);
          con.close();
          
          
      } catch (Exception e) {
          e.printStackTrace(); 
      }
		
      return dashboard;
	}
	
	@GetMapping("rejected/{id}")
    public List<BMSView> rejectedForms(@PathVariable("id") String userid){

		Connection con = null;
		List<BMSView> debitVoucher = new ArrayList<>();
		List<BMSView> dashboard = new ArrayList<>();

        try {
            con = PostGRESQLConnUtils.getPostGreSQLConnection();
            con.setAutoCommit(false);
            Statement stmt = con.createStatement();

//          For debit Voucher Form
          
          ResultSet dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
          		+ "WHERE far.user_id = '" + userid + "' "
          		+ "AND (far.unit_head_status = 'Rejected' "
          		+ "OR far.second_man_status = 'Rejected' "
          		+ "OR far.fad_second_man_status = 'Rejected' "
          		+ "OR far.fad_head_status = 'Rejected' "
          		+ "OR far.dmd_status = 'Rejected' "
          		+ "OR far.amd_status = 'Rejected' "
          		+ "OR far.implemented_by_status = 'Rejected' ) ");
          
          if (dv != null) {
	            while (dv.next()) {
	            	BMSView bmsView = new BMSView();
	            	
	                long id = dv.getLong("id");
	                String users = dv.getString("user_id");
	                String username = dv.getString("user_name");
	                String formid = dv.getString("form_id");
	                String formname = dv.getString("form_name");
	                Timestamp submittime = dv.getTimestamp("submit_time");
	                String branch = dv.getString("branch_code");
	                String secondmanstatus = dv.getString("second_man_status");
	            	String unitheadstatus = dv.getString("unit_head_status");
	            	String fadsecondstatus = dv.getString("fad_second_man_status");
	            	String fadheadstatus = dv.getString("fad_head_status");
	            	String dmdstatus = dv.getString("dmd_status");
	            	String amdstatus = dv.getString("amd_status");
	            	String implementerstatus = dv.getString("implemented_by_status");
	
	                bmsView.setId(id);
	                bmsView.setUserid(users);
	                bmsView.setUsername(username);
	                bmsView.setFormid(formid);
	                bmsView.setFormname(formname);
	                bmsView.setSubmittime(submittime);
	                bmsView.setBranchcode(branch);
	                bmsView.setSecondmanstatus(secondmanstatus);
	                bmsView.setUnitheadstatus(unitheadstatus);
	                bmsView.setFadsecondstatus(fadsecondstatus);
	                bmsView.setFadheadstatus(fadheadstatus);
	                bmsView.setDmdstatus(dmdstatus);
	                bmsView.setAmdstatus(amdstatus);
	                bmsView.setImplementerstatus(implementerstatus);
	
	                debitVoucher.add(bmsView);
	            }
          }
          dashboard.addAll(debitVoucher);
          con.close();
          
          
      } catch (Exception e) {
          e.printStackTrace(); 
      }
		
      return dashboard;
	}

}
