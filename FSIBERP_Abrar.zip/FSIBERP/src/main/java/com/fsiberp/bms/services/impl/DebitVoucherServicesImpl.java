package com.fsiberp.bms.services.impl;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.NoSuchElementException;

import org.springframework.stereotype.Service;

import com.fsiberp.bms.model.DebitVoucher;
import com.fsiberp.bms.repository.DebitVoucherRepository;
import com.fsiberp.bms.services.DebitVoucherService;
import com.fsiberp.bms.model.BMSStatusUpdateRequest;
import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.AuthRepository;
import com.fsiberp.bms.services.BMSNotificationService;
import com.fsiberp.frms.services.EmailService;
import com.fsiberp.frms.services.ProfileService;
import jakarta.transaction.Transactional;

@Service
public class DebitVoucherServicesImpl implements DebitVoucherService {

	private DebitVoucherRepository debitVoucherRepository;
	private final BMSNotificationService bmsNotificationService; // Added NotificationService
	private final ProfileService profileService;
	private final AuthRepository authRepository;
	private EmailService emailService;

	public DebitVoucherServicesImpl(DebitVoucherRepository debitVoucherRepository, EmailService emailService,
			BMSNotificationService bmsNotificationService, ProfileService profileService, AuthRepository authRepository) {

		this.debitVoucherRepository = debitVoucherRepository;
		this.bmsNotificationService = bmsNotificationService;
		this.profileService = profileService;
		this.authRepository = authRepository;
		this.emailService = emailService;
	}

	@Override
	public DebitVoucher createForm(DebitVoucher debitVoucher) {
		DebitVoucher savedForm = debitVoucherRepository.save(debitVoucher);
		if (debitVoucher.getSecondmanuserid() != null) {
			User user = profileService.getUserByUserid(debitVoucher.getUserid());
			String username = user != null ? user.getUsername() : "Unknown User";

			bmsNotificationService.createNotification(
					debitVoucher.getSecondmanuserid(), "A new Debit Voucher form has been submitted by " + username
							+ " (" + debitVoucher.getUserid() + ")",
					debitVoucher.getUserid(), debitVoucher.getFormid(), debitVoucher.getId(), false);
		}
		return savedForm;
	}

	@Transactional
	public DebitVoucher saveForm(DebitVoucher form) {
		// Save the form temporarily to generate the ID
		DebitVoucher savedForm = debitVoucherRepository.save(form);

		// Generate the reference value using the generated ID
		String currentYear = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
		String paddedSubmissionId = String.format("%05d", savedForm.getId()); // Padded with zeros
		String referenceValue = currentYear + "-3001/" + paddedSubmissionId;

		// Set the reference value
		savedForm.setReferenceValue(referenceValue);

		// Save the form again with the reference value
		savedForm = debitVoucherRepository.save(savedForm);

		// Trigger notification for the unit head if the userid is set
		User user = profileService.getUserByUserid(savedForm.getUserid());
		if (savedForm.getSecondmanuserid() != null) {
			String username = user != null ? user.getUsername() : "Unknown User";

			bmsNotificationService.createNotification(savedForm.getSecondmanuserid(),
					"A new Debit Voucher form has been submitted by " + username + " (" + savedForm.getUserid() + ")",
					savedForm.getUserid(), savedForm.getFormid(), savedForm.getId(), false);
		}
		

//      2nd man email
        	emailService.sendNotificationEmail(user,savedForm.getSecondmanuserid(),2);
        

		// Return the saved DebitVoucher object
		return savedForm;
	}

	@Override
	public DebitVoucher updateStatus(Long id, String userid, BMSStatusUpdateRequest request,
			Timestamp currentTimestamp) {
		DebitVoucher debitVoucher = debitVoucherRepository.findById(id)
				.orElseThrow(() -> new NoSuchElementException("Form not found"));

		// Define status reversal notification message
		String reversalMessage = "Your Debit Voucher request status was reversed from Accepted to Rejected by %s (%s).";
		String ignoreMessage = "Please ignore the previous notification; the status of the Debit Voucher request has been reversed.";

		// Get form submitter details
		User formSubmitter = profileService.getUserByUserid(debitVoucher.getUserid());
		String submitterName = formSubmitter != null ? formSubmitter.getUsername() : "Unknown User";
		String deptName = formSubmitter != null ? formSubmitter.getDepartment() : "Unknown Branch";
		String branchCode = formSubmitter != null ? formSubmitter.getBranchcode() : "Unknown Code";

		// Check and update Second Man status
		if (userid.equals(debitVoucher.getSecondmanuserid()) || debitVoucher.getSecondmanstatus() == null) {
			String previousStatus = debitVoucher.getSecondmanstatus();
			String newStatus = request.getStatus();

			debitVoucher.setSecondmanstatus(newStatus);
			debitVoucher.setSecondmancmnt(request.getComment());
			debitVoucher.setSecondmansubdate(currentTimestamp);

			// Trigger reversal notification only when status changes from Accepted to
			// Rejected
			if ("Accepted".equalsIgnoreCase(previousStatus) && "Rejected".equalsIgnoreCase(newStatus)) {
				bmsNotificationService.createNotification(debitVoucher.getUserid(),
						String.format(reversalMessage, debitVoucher.getSecondmanusername(),
								debitVoucher.getSecondmanuserid()),
						debitVoucher.getUserid(), debitVoucher.getFormid(), debitVoucher.getId(), false);

				// Send ignore notification to the next authorized person (Unit Head)
				if (debitVoucher.getUnitheaduserid() != null) {
					bmsNotificationService.createNotification(debitVoucher.getUnitheaduserid(),
							String.format(ignoreMessage + " (Form submitted by: %s, %s [%s])", submitterName, deptName,
									branchCode),
							debitVoucher.getUserid(), debitVoucher.getFormid(), debitVoucher.getId(), false);
				}
			} else {
				bmsNotificationService.createNotification(debitVoucher.getUserid(),
						"Your Debit Voucher request was " + newStatus.toLowerCase() + " by "
								+ debitVoucher.getSecondmanusername() + " (" + debitVoucher.getSecondmanuserid() + ")",
						debitVoucher.getUserid(), debitVoucher.getFormid(), debitVoucher.getId(), false);
			}

			// Notify the Unit Head if the status is Accepted
			if ("Accepted".equalsIgnoreCase(newStatus)) {
				if (debitVoucher.getUnitheaduserid() != null) {
					bmsNotificationService.createNotification(debitVoucher.getUnitheaduserid(),
							String.format("A new Debit Voucher request from %s (%s), %s [%s] requires your approval.",
									submitterName, debitVoucher.getUserid(), deptName, branchCode),
							debitVoucher.getUserid(), debitVoucher.getFormid(), debitVoucher.getId(), false);
				}

//		      unit head email
		        emailService.sendNotificationEmail(formSubmitter,debitVoucher.getUnitheaduserid(),2);
			}
		}

		// Check and update Unit Head status
		else if (userid.equals(debitVoucher.getUnitheaduserid())) {
			String previousStatus = debitVoucher.getUnitheadstatus();
			String newStatus = request.getStatus();

			debitVoucher.setUnitheadstatus(newStatus);
			debitVoucher.setUnitheadcmnt(request.getComment());
			debitVoucher.setUnitheadsubdate(currentTimestamp);

			// Trigger reversal notification only when status changes from Accepted to
			// Rejected
			if ("Accepted".equalsIgnoreCase(previousStatus) && "Rejected".equalsIgnoreCase(newStatus)) {
				bmsNotificationService.createNotification(debitVoucher.getUserid(),
						String.format(reversalMessage, debitVoucher.getUnitheadusername(),
								debitVoucher.getUnitheaduserid()),
						debitVoucher.getUserid(), debitVoucher.getFormid(), debitVoucher.getId(), false);

				// Send ignore notification to the next authorized person (FAD Second Man or
				// DMD)
				if (debitVoucher.getFadsecondmanuserid() != null) {
					bmsNotificationService.createNotification(debitVoucher.getFadsecondmanuserid(),
							String.format(ignoreMessage + " (Form submitted by: %s, %s [%s])", submitterName, deptName,
									branchCode),
							debitVoucher.getUserid(), debitVoucher.getFormid(), debitVoucher.getId(), false);
				} else {
					// Notify DMD
					if (debitVoucher.getDmduserid() != null) {
						bmsNotificationService.createNotification(debitVoucher.getDmduserid(),
								String.format(ignoreMessage + " (Form submitted by: %s, %s [%s])", submitterName,
										deptName, branchCode),
								debitVoucher.getUserid(), debitVoucher.getFormid(), debitVoucher.getId(), false);
					}

					// Notify AMD
					if (debitVoucher.getAmduserid() != null) {
						bmsNotificationService.createNotification(debitVoucher.getAmduserid(),
								String.format(ignoreMessage + " (Form submitted by: %s, %s [%s])", submitterName,
										deptName, branchCode),
								debitVoucher.getUserid(), debitVoucher.getFormid(), debitVoucher.getId(), false);
					}
				}
			} else {
				bmsNotificationService.createNotification(debitVoucher.getUserid(),
						"Your Debit Voucher request was " + newStatus.toLowerCase() + " by "
								+ debitVoucher.getUnitheadusername() + " (" + debitVoucher.getUnitheaduserid() + ")",
						debitVoucher.getUserid(), debitVoucher.getFormid(), debitVoucher.getId(), false);
			}

			// Notify the next role if the status is Accepted
			if ("Accepted".equalsIgnoreCase(newStatus)) {
				// Check FAD Second Man, DMD, and AMD for next notifications
				if (debitVoucher.getFadsecondmanuserid() != null) {
					bmsNotificationService.createNotification(debitVoucher.getFadsecondmanuserid(),
							String.format("A new Debit Voucher request from %s (%s), %s [%s] requires your approval.",
									submitterName, debitVoucher.getUserid(), deptName, branchCode),
							debitVoucher.getUserid(), debitVoucher.getFormid(), debitVoucher.getId(), false);
				
//				      fad 2nd email
			        emailService.sendNotificationEmail(formSubmitter,debitVoucher.getFadsecondmanuserid(),2);
				
				} else {
					bmsNotificationService.createNotification(debitVoucher.getDmduserid(),
							String.format("A new Debit Voucher request from %s (%s), %s [%s] requires your approval.",
									submitterName, debitVoucher.getUserid(), deptName, branchCode),
							debitVoucher.getUserid(), debitVoucher.getFormid(), debitVoucher.getId(), false);

					bmsNotificationService.createNotification(debitVoucher.getAmduserid(),
							String.format("A new Debit Voucher request from %s (%s), %s [%s] requires your approval.",
									submitterName, debitVoucher.getUserid(), deptName, branchCode),
							debitVoucher.getUserid(), debitVoucher.getFormid(), debitVoucher.getId(), false);
					
//				      dmd email
			        emailService.sendNotificationEmail(formSubmitter,debitVoucher.getDmduserid(),2);
			        
//				      amd email
			        emailService.sendNotificationEmail(formSubmitter,debitVoucher.getAmduserid(),2);
				}
			}
		}

		// Further status checks and updates for other roles like FAD Second Man, DMD,
		// AMD, and Implementer can follow similarly...

		// Check and update FAD Second Man status
		else if (userid.equals(debitVoucher.getFadsecondmanuserid())) {
			String previousStatus = debitVoucher.getFadsecondmanstatus();
			String newStatus = request.getStatus();

			debitVoucher.setFadsecondmanstatus(newStatus);
			debitVoucher.setFadsecondmancmnt(request.getComment());
			debitVoucher.setFadsecondmansubdate(currentTimestamp);

			// Trigger reversal notification only when status changes from Accepted to
			// Rejected
			if ("Accepted".equalsIgnoreCase(previousStatus) && "Rejected".equalsIgnoreCase(newStatus)) {
				bmsNotificationService.createNotification(debitVoucher.getUserid(),
						String.format(reversalMessage, debitVoucher.getFadsecondmanusername(),
								debitVoucher.getFadsecondmanuserid()),
						debitVoucher.getUserid(), debitVoucher.getFormid(), debitVoucher.getId(), false);

				// Send ignore notification to the FAD Head
				if (debitVoucher.getFadheaduserid() != null) {
					bmsNotificationService.createNotification(debitVoucher.getFadheaduserid(),
							String.format(ignoreMessage + " (Form submitted by: %s, %s [%s])", submitterName, deptName,
									branchCode),
							debitVoucher.getUserid(), debitVoucher.getFormid(), debitVoucher.getId(), false);
				}
			} else {
				bmsNotificationService.createNotification(debitVoucher.getUserid(),
						"Your Debit Voucher request was " + newStatus.toLowerCase() + " by "
								+ debitVoucher.getFadsecondmanusername() + " (" + debitVoucher.getFadsecondmanuserid()
								+ ")",
						debitVoucher.getUserid(), debitVoucher.getFormid(), debitVoucher.getId(), false);
			}

			// Notify the FAD Head if the status is Accepted
			if ("Accepted".equalsIgnoreCase(newStatus)) {
				if (debitVoucher.getFadheaduserid() != null) {
					bmsNotificationService.createNotification(debitVoucher.getFadheaduserid(),
							String.format("A new Debit Voucher request from %s (%s), %s [%s] requires your approval.",
									submitterName, debitVoucher.getUserid(), deptName, branchCode),
							debitVoucher.getUserid(), debitVoucher.getFormid(), debitVoucher.getId(), false);
				}
				

//			      fad head email
		        emailService.sendNotificationEmail(formSubmitter,debitVoucher.getFadheaduserid(),2);
			}
		}
		// Check and update FAD Head status
		else if (userid.equals(debitVoucher.getFadheaduserid())) {
			String previousStatus = debitVoucher.getFadheadstatus();
			String newStatus = request.getStatus();

			debitVoucher.setFadheadstatus(newStatus);
			debitVoucher.setFadheadcmnt(request.getComment());
			debitVoucher.setFadheadsubdate(currentTimestamp);

			// Trigger reversal notification only when status changes from Accepted to
			// Rejected
			if ("Accepted".equalsIgnoreCase(previousStatus) && "Rejected".equalsIgnoreCase(newStatus)) {
				bmsNotificationService.createNotification(debitVoucher.getUserid(),
						String.format(reversalMessage, debitVoucher.getFadheadusername(),
								debitVoucher.getFadheaduserid()),
						debitVoucher.getUserid(), debitVoucher.getFormid(), debitVoucher.getId(), false);

				// Send ignore notification to the Implementer
				if (debitVoucher.getImplementedbyuserid() != null) {
					bmsNotificationService.createNotification(debitVoucher.getImplementedbyuserid(),
							String.format(ignoreMessage + " (Form submitted by: %s, %s [%s])", submitterName, deptName,
									branchCode),
							debitVoucher.getUserid(), debitVoucher.getFormid(), debitVoucher.getId(), false);
				}
			} else {
				bmsNotificationService.createNotification(debitVoucher.getUserid(),
						"Your Debit Voucher request was " + newStatus.toLowerCase() + " by "
								+ debitVoucher.getFadheadusername() + " (" + debitVoucher.getFadheaduserid() + ")",
						debitVoucher.getUserid(), debitVoucher.getFormid(), debitVoucher.getId(), false);
			}

			// Notify the Implementer if the status is Accepted
			if ("Accepted".equalsIgnoreCase(newStatus)) {
				if (debitVoucher.getImplementedbyuserid() != null) {
					bmsNotificationService.createNotification(debitVoucher.getImplementedbyuserid(),
							String.format("A new Debit Voucher request from %s (%s), %s [%s] requires your approval.",
									submitterName, debitVoucher.getUserid(), deptName, branchCode),
							debitVoucher.getUserid(), debitVoucher.getFormid(), debitVoucher.getId(), false);
				}
				

//			      Implementers email
		        emailService.sendNotificationEmail(formSubmitter,debitVoucher.getImplementedbyuserid(),2);
			}
		}

		// DMD and AMD status update logic
		// Check and update AMD or DMD status
		else if (userid.equals(debitVoucher.getAmduserid())
				|| userid.equals(debitVoucher.getDmduserid()) && debitVoucher.getFadsecondmanuserid() == null) {

			// Store the previous statuses
			String previousAmdStatus = debitVoucher.getAmdstatus();
			String previousDmdStatus = debitVoucher.getDmdstatus();

			// Update AMD or DMD statuses based on the request
			if (userid.equals(debitVoucher.getDmduserid()) && "Accepted".equalsIgnoreCase(request.getStatus())) {
				debitVoucher.setDmdstatus("Accepted");
				debitVoucher.setDmdsubdate(currentTimestamp);
				debitVoucher.setDmdcmnt(request.getComment());
				debitVoucher.setAmdstatus("Accepted");

			} else if (userid.equals(debitVoucher.getAmduserid()) && "Accepted".equalsIgnoreCase(request.getStatus())) {
				debitVoucher.setAmdstatus("Accepted");
				debitVoucher.setAmdsubdate(currentTimestamp);
				debitVoucher.setAmdcmnt(request.getComment());
				debitVoucher.setDmdstatus("Accepted");

			} else if (userid.equals(debitVoucher.getDmduserid()) && "Rejected".equalsIgnoreCase(request.getStatus())) {
				debitVoucher.setDmdstatus("Rejected");
				debitVoucher.setDmdsubdate(currentTimestamp);
				debitVoucher.setDmdcmnt(request.getComment());
				debitVoucher.setAmdstatus("Rejected");

			} else if (userid.equals(debitVoucher.getAmduserid()) && "Rejected".equalsIgnoreCase(request.getStatus())) {
				debitVoucher.setAmdstatus("Rejected");
				debitVoucher.setAmdsubdate(currentTimestamp);
				debitVoucher.setAmdcmnt(request.getComment());
				debitVoucher.setDmdstatus("Rejected");
			}

			// Trigger ignore message notification if status changes from Accepted to
			// Rejected
			if ("Accepted".equalsIgnoreCase(previousAmdStatus)
					&& "Rejected".equalsIgnoreCase(debitVoucher.getAmdstatus())
					|| "Accepted".equalsIgnoreCase(previousDmdStatus)
							&& "Rejected".equalsIgnoreCase(debitVoucher.getDmdstatus())) {

				if (debitVoucher.getImplementedbyuserid() != null) {
					bmsNotificationService.createNotification(debitVoucher.getImplementedbyuserid(),
							String.format(ignoreMessage + " (Form submitted by: %s, %s [%s])", submitterName, deptName,
									branchCode),
							debitVoucher.getUserid(), debitVoucher.getFormid(), debitVoucher.getId(), false);
				}
			}

			// Mark notifications as viewed
			bmsNotificationService.markNotificationsAsViewedForUserAndForm(debitVoucher.getAmduserid(),
					debitVoucher.getFormid(), debitVoucher.getId());
			bmsNotificationService.markNotificationsAsViewedForUserAndForm(debitVoucher.getDmduserid(),
					debitVoucher.getFormid(), debitVoucher.getId());

			// Notify implemented person to take final action
			if ("Accepted".equalsIgnoreCase(debitVoucher.getAmdstatus())
					|| "Accepted".equalsIgnoreCase(debitVoucher.getDmdstatus())) {
				bmsNotificationService.createNotification(debitVoucher.getImplementedbyuserid(),
						"A new Debit Voucher request from " + deptName + " (" + branchCode
								+ ") requires your approval.",
						debitVoucher.getUserid(), debitVoucher.getFormid(), debitVoucher.getId(), false);
//			      Implementers email
		        emailService.sendNotificationEmail(formSubmitter,debitVoucher.getImplementedbyuserid(),2);
			
			}

			// New Notification: Notify the form submitter about AMD/DMD status change
			bmsNotificationService.createNotification(debitVoucher.getUserid(),
					"Your Debit Voucher request has been " + request.getStatus().toLowerCase() + " by "
							+ (userid.equals(debitVoucher.getDmduserid()) ? "DMD" : "AMD") + " (" + userid + ").",
					debitVoucher.getUserid(), debitVoucher.getFormid(), debitVoucher.getId(), false);
		}

		// Final implementation step
		if ("Done".equalsIgnoreCase(request.getStatus())) {
			debitVoucher.setImplementedbystatus(request.getStatus());
			debitVoucher.setImplementedbycmnt(request.getComment());
			debitVoucher.setImplementedbysubdate(currentTimestamp);

			bmsNotificationService.createNotification(debitVoucher.getUserid(),
					"Your Debit Voucher request has been fully completed by " + debitVoucher.getImplementedbyusername()
							+ " (" + debitVoucher.getImplementedbyuserid() + ").",
					debitVoucher.getUserid(), debitVoucher.getFormid(), debitVoucher.getId(), false // Not viewed
																									// (false)
			);
			
			User userinfo = authRepository.findByUserid(debitVoucher.getUserid()).orElse(null);
	        emailService.sendNotificationEmailForUser(userinfo, debitVoucher.getUserid(),2);
		}

		debitVoucherRepository.save(debitVoucher);
		return debitVoucher;
	}

}