package com.fsiberp.bms.controller;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fsiberp.bms.model.BMSNotification;
import com.fsiberp.bms.services.BMSNotificationService;


@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/bms/notifications/")
public class BMSNotificationController {

    private final BMSNotificationService bmsNotificationService;

    public BMSNotificationController(BMSNotificationService bmsNotificationService) {
        this.bmsNotificationService = bmsNotificationService;
    }

    @GetMapping("{userid}")
    public List<BMSNotification> getUserNotifications(@PathVariable("userid") String userid) {
        return bmsNotificationService.getNotifications(userid);
    }

    @PutMapping("view/{id}")
    public void markNotificationAsViewed(@PathVariable("id") Long id) {
    	bmsNotificationService.markAsViewed(id);
    }
}