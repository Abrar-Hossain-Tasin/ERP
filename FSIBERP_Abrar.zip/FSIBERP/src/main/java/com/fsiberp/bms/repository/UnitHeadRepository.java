package com.fsiberp.bms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.fsiberp.bms.model.UnitHead;

@Repository
public interface UnitHeadRepository extends JpaRepository<UnitHead, Long>{

	@Query("SELECT sf FROM UnitHead sf JOIN AppUser far ON sf.empcode = far.empid "
		       + "WHERE far.department = :department "
		       + "AND far.branchcode = :branchCode "
		       + "AND sf.funcdescode IN :funcDesCodes " 
		       + "AND sf.status = :status")
	List<UnitHead> findActiveUnitHeads(String department,String branchCode,List<String> funcDesCodes,  // Change type to List
		                                    String status);

	@Query("SELECT sf FROM UnitHead sf JOIN AppUser far ON sf.empcode = far.empid "
		       + "WHERE far.branchcode = :branchCode "
		       + "AND sf.funcdescode IN :funcDesCodes " 
		       + "AND sf.status = :status")
	List<UnitHead> findAllActiveUnitHeads(@Param("branchCode") String branchCode,
            @Param("funcDesCodes") List<String> funcDesCodes,
            @Param("status") String status);


	Optional<UnitHead> findByEmpcode(String empcode);
	List<UnitHead> findByEmpcodeAndStatus(String empcode, String status);
	
	@Query("SELECT sf FROM UnitHead sf "
		       + "WHERE sf.empcode = :empcode "
		       + "AND sf.funcdescode IN :funcDesCodes")
	List<UnitHead> findByEmpcodeAndFuncdescode(String empcode, List<String> funcDesCodes);
	
	@Query("SELECT sf FROM UnitHead sf "
		       + "WHERE sf.empcode = :empcode "
		       + "AND sf.funcdescode IN (:funcDesCodes) " 
		       + "AND sf.status = :status")
	 List<UnitHead> findByEmpcodeAndFuncdescodeAndStatus(String empcode, List<String> funcDesCodes, String status);
}