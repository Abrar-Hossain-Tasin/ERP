package com.fsiberp.bms.services.impl;

import java.util.List;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.fsiberp.bms.exception.ResourceNotFoundException;
import com.fsiberp.bms.model.BMSNotification;
import com.fsiberp.bms.repository.BMSNotificationRepository;
import com.fsiberp.bms.services.BMSNotificationService;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.transaction.Transactional;

@Service
public class BMSNotificationServiceImpl implements BMSNotificationService {

    private final BMSNotificationRepository notificationRepository;
    private EntityManager entityManager;

    public BMSNotificationServiceImpl(BMSNotificationRepository notificationRepository,
    		EntityManager entityManager) {
        this.notificationRepository = notificationRepository;
        this.entityManager = entityManager;
    }

    @Override
    public BMSNotification createNotification(String userid, String message, String fuserid, String formid, Long submissionId, boolean viewed) {
        BMSNotification notification = new BMSNotification();
        notification.setUserid(userid);
        notification.setMessage(message);
        notification.setFuserid(fuserid);
        notification.setFormid(formid);
        notification.setSubmissionId(submissionId);
        notification.setViewed(viewed);
        return notificationRepository.save(notification);
    }

    @Override
    public List<BMSNotification> getNotifications(String userid) {
        return notificationRepository.findByUserid(userid);
    }

    @Override
    public void markAsViewed(Long id) {
        BMSNotification notification = notificationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Notification not found with ID: " + id));
        notification.setViewed(true);
        notificationRepository.save(notification);
    }

    @Override
    public boolean areNotificationsViewed(String formId) {
        List<BMSNotification> notifications = notificationRepository.findByFormid(formId);
        return notifications.stream().allMatch(BMSNotification::isViewed);
    }

    @Override
    public void markNotificationsAsViewedForUserAndForm(String userid, String formId) {
        List<BMSNotification> notifications = notificationRepository.findByUseridAndFormid(userid, formId);
        if (notifications.isEmpty()) {
            throw new ResourceNotFoundException("No notifications found for User ID: " + userid + " and Form ID: " + formId);
        }
        for (BMSNotification notification : notifications) {
            notification.setViewed(true);
        }
        notificationRepository.saveAll(notifications);
    }

    @Override
    public void markNotificationsAsViewedForUserAndForm(String userid, String formid, Long submissionId) {
        List<BMSNotification> notifications = notificationRepository.findByUseridAndFormidAndSubmissionId(userid, formid, submissionId);
        if (notifications.isEmpty()) {
            throw new ResourceNotFoundException("No notifications found for User ID: " + userid + ", Form ID: " + formid + " and Submission ID: " + submissionId);
        }
        for (BMSNotification notification : notifications) {
            notification.setViewed(true); // Mark notification as viewed
        }
        notificationRepository.saveAll(notifications);
    }
    
    @Override
    @Transactional
    @Scheduled(cron = "0 0 0 */30 * ?") // Runs at midnight every 30 days
    public void bmsArchiveOldNotifications() {
        // Move notifications older than 30 days to archived_notifications
        String moveQuery = "INSERT INTO sys_bms_notifications_archive (id, created_at, message, userid, viewed, formid, fuserid, submission_id) " +
                           "SELECT id, created_at, message, userid, viewed, formid, fuserid, submission_id " +
                           "FROM sys_bms_notifications " +
                           "WHERE created_at < NOW() - INTERVAL '30 days'";

        // Execute the move operation
        Query moveToArchive = entityManager.createNativeQuery(moveQuery);
        int movedRows = moveToArchive.executeUpdate();
        System.out.println("Moved " + movedRows + " notifications to bms_archived_notifications.");

        // Delete old notifications after moving them
        String deleteQuery = "DELETE FROM sys_bms_notifications WHERE created_at < NOW() - INTERVAL '30  days'";
        Query deleteOldNotifications = entityManager.createNativeQuery(deleteQuery);
        int deletedRows = deleteOldNotifications.executeUpdate();
        System.out.println("Deleted " + deletedRows + " old notifications from sys_bms_notifications.");
    }
}
