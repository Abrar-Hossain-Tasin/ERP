package com.fsiberp.bms.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "sys_unit_head")
public class UnitHead {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "branch")
	private String branch;
	
	@Column(name = "emp_code")
	private String empcode;
	
	@Column(name = "emp_name")
	private String empname;
	
	@Column(name = "func_des_code")
	private String funcdescode;
	
	@Column(name = "func_designation")
	private String funcdesignation;
	
	@Column(name = "status")
	private String status;

	public UnitHead() {
		
	}

	public UnitHead(Long id, String branch, String empcode, String empname, 
			String funcdescode, String funcdesignation, String status) {
		super();
		this.id = id;
		this.branch = branch;
		this.empcode = empcode;
		this.empname = empname;
		this.funcdescode = funcdescode;
		this.funcdesignation = funcdesignation;
		this.status = status;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getEmpcode() {
		return empcode;
	}

	public void setEmpcode(String empcode) {
		this.empcode = empcode;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public String getFuncdescode() {
		return funcdescode;
	}

	public void setFuncdescode(String funcdescode) {
		this.funcdescode = funcdescode;
	}

	public String getFuncdesignation() {
		return funcdesignation;
	}

	public void setFuncdesignation(String funcdesignation) {
		this.funcdesignation = funcdesignation;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
