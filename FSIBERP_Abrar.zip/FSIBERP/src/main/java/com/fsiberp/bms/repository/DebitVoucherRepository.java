package com.fsiberp.bms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fsiberp.bms.model.DebitVoucher;

@Repository
public interface DebitVoucherRepository extends JpaRepository<DebitVoucher, Long>  {
	DebitVoucher findTopByUseridOrderByIdDesc(String userid);
	List<DebitVoucher> findByUserid(String userid);
	DebitVoucher findAllByUseridAndFormidAndId(String userid, String formid, Long id);
	List<DebitVoucher> findByImplementedbydeptid(Integer implementedbydeptid);
}
