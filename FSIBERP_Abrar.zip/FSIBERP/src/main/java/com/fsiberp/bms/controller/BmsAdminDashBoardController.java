package com.fsiberp.bms.controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fsiberp.bms.model.BMSView;
import com.fsiberp.bms.model.UnitHead;
import com.fsiberp.bms.repository.UnitHeadRepository;
import com.fsiberp.frms.controller.PostGRESQLConnUtils;
import com.fsiberp.frms.model.FunctionalRole;
import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.FunctionalRoleRepository;
import com.fsiberp.frms.services.ProfileService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/bms_dashboard/admin")
public class BmsAdminDashBoardController {
	
	private ProfileService profileService;
	private FunctionalRoleRepository functionalRoleRepository;
	private UnitHeadRepository unitHeadRepository;
	
	public BmsAdminDashBoardController(ProfileService profileService, 
			FunctionalRoleRepository functionalRoleRepository, UnitHeadRepository unitHeadRepository) {
		
	        this.profileService = profileService;
	        this.functionalRoleRepository = functionalRoleRepository;
	        this.unitHeadRepository = unitHeadRepository;
	    }
	
	@GetMapping("pending/{id}")
    public List<BMSView> pendingForms(@PathVariable("id") String userid) throws ClassNotFoundException, SQLException{
		
		FunctionalRole functionalRole = functionalRoleRepository.findByUseridAndStatus(userid, "Active");
		User user = profileService.getUserByUserid(userid);
		
		Connection con = null;
		List<BMSView> debitVoucher = new ArrayList<>();
		List<BMSView> debitVoucherFad = new ArrayList<>();
		List<BMSView> dashboard = new ArrayList<>();

            con = PostGRESQLConnUtils.getPostGreSQLConnection();
            con.setAutoCommit(false);
            Statement stmt = con.createStatement();
            ResultSet dv = null;
            ResultSet fad  = null;
            Integer role = 0;
           
            	
            try {
	//          For debit Voucher Form
				        	    	
            	if (functionalRole != null) {     
				    if (functionalRole.getFunctionalroleid() == 8) {
				           dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
				          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
				          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
				          		+ "WHERE far.fad_head_userid = '" + userid + "' "
				          		+ "AND (far.fad_second_man_status = 'Accepted' "
				        		+ "AND far.fad_head_status = 'Pending') ");
				    } 
				    else if (functionalRole.getFunctionalroleid() == 9) {
					    	dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
					          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
					          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
					          		+ "WHERE far.amd_userid = '" + userid + "' "
					          		+ "AND (far.unit_head_status = 'Accepted' "
					        		+ "AND far.amd_status = 'Pending') ");
				    }
				    else if (functionalRole.getFunctionalroleid() == 10) {
				    	dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
				          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
				          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
				          		+ "WHERE far.dmd_userid = '" + userid + "' "
				          		+ "AND (far.unit_head_status = 'Accepted' "
				        		+ "AND far.dmd_status = 'Pending') ");
				    }
				    else if (functionalRole.getFunctionalroleid() == 11) {
				    	dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
				          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
				          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
				          		+ "WHERE far.implemented_by_userid = '" + userid + "' "
				          		+ "AND ((far.fad_head_status = 'Accepted' "
				          		+ "OR far.dmd_status = 'Accepted' "
				          		+ "OR far.amd_status = 'Accepted') "
				        		+ "AND far.implemented_by_status = 'Pending') ");
				    }
				    else {
				    	
				    	List<UnitHead> unithead = unitHeadRepository.findByEmpcodeAndStatus(user.getEmpid(), "Active");
				    	for (UnitHead head : unithead) {
				    	    if (head.getFuncdescode().equals("FD001") || head.getFuncdescode().equals("FD003") ||
				    	    		head.getFuncdescode().equals("FD011") || head.getFuncdescode().equals("FD022")) {
				    	    	
				    	    	dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
						          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
						          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
						          		+ "WHERE far.unit_head_userid = '" + userid + "' "
						          		+ "AND (far.second_man_status = 'Accepted' "
						        		+ "AND far.unit_head_status = 'Pending') ");
				    	    }
				    	    else if (head.getFuncdescode().equals("FD002") || head.getFuncdescode().equals("FD009") || head.getFuncdescode().equals("FD016")) {
				    	    	if (user.getDepartment().equals("F A D, Head Office, Dhaka")) {
				    	    		
				    	    		dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
							          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
							          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
							          		+ "WHERE far.fad_second_man_userid = '" + userid + "' "
							          		+ "AND (far.unit_head_status = 'Accepted' "
							        		+ "AND far.fad_second_man_status = 'Pending') ");
				    	    	}
				    	    	else {
				    	    		dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
							          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
							          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
							          		+ "WHERE far.second_man_userid = '" + userid + "' "
							        		+ "AND far.second_man_status = 'Pending' ");
				    	    	}
				    	    }
				    	}
				    }
            	}
            	else {
            		List<UnitHead> unithead = unitHeadRepository.findByEmpcodeAndStatus(user.getEmpid(), "Active");
            		if (unithead != null) {
				    	for (UnitHead head : unithead) {
				    	    if (head.getFuncdescode().equals("FD001") || head.getFuncdescode().equals("FD003") ||
				    	    		head.getFuncdescode().equals("FD011") || head.getFuncdescode().equals("FD022")) {
				    	    	
				    	    	dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
						          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
						          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
						          		+ "WHERE far.unit_head_userid = '" + userid + "' "
						          		+ "AND (far.second_man_status = 'Accepted' "
						        		+ "AND far.unit_head_status = 'Pending') ");
				    	    }
				    	    else if (head.getFuncdescode().equals("FD002") || head.getFuncdescode().equals("FD009") || head.getFuncdescode().equals("FD016")) {
				    	    	if (user.getDepartment().equals("F A D, Head Office, Dhaka")) {
				    	    		
				    	    		role = 1;
				    	    		dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
							          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
							          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
							          		+ "WHERE far.fad_second_man_userid = '" + userid + "' "
							          		+ "AND (far.unit_head_status = 'Accepted' "
							        		+ "AND far.fad_second_man_status = 'Pending') ");
				    	    		
				    	    	}
				    	    	else {
				    	    		dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
							          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
							          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
							          		+ "WHERE far.second_man_userid = '" + userid + "' "
							        		+ "AND far.second_man_status = 'Pending' ");
				    	    	}
				    	    }
				    	}
            	}
        		else {
        			dv = null;
        		}
            	}
		          if (dv != null) {
			            while (dv.next()) {
			            	BMSView bmsView = new BMSView();
			            	
			                long id = dv.getLong("id");
			                String users = dv.getString("user_id");
			                String username = dv.getString("user_name");
			                String formid = dv.getString("form_id");
			                String formname = dv.getString("form_name");
			                Timestamp submittime = dv.getTimestamp("submit_time");
			                String branch = dv.getString("branch_code");
			                String secondmanstatus = dv.getString("second_man_status");
			            	String unitheadstatus = dv.getString("unit_head_status");
			            	String fadsecondstatus = dv.getString("fad_second_man_status");
			            	String fadheadstatus = dv.getString("fad_head_status");
			            	String dmdstatus = dv.getString("dmd_status");
			            	String amdstatus = dv.getString("amd_status");
			            	String implementerstatus = dv.getString("implemented_by_status");
			
			                bmsView.setId(id);
			                bmsView.setUserid(users);
			                bmsView.setUsername(username);
			                bmsView.setFormid(formid);
			                bmsView.setFormname(formname);
			                bmsView.setSubmittime(submittime);
			                bmsView.setBranchcode(branch);
			                bmsView.setSecondmanstatus(secondmanstatus);
			                bmsView.setUnitheadstatus(unitheadstatus);
			                bmsView.setFadsecondstatus(fadsecondstatus);
			                bmsView.setFadheadstatus(fadheadstatus);
			                bmsView.setDmdstatus(dmdstatus);
			                bmsView.setAmdstatus(amdstatus);
			                bmsView.setImplementerstatus(implementerstatus);
			
			                debitVoucher.add(bmsView);
			            }
		          }
		          dashboard.addAll(debitVoucher);
		          
		          if (user.getDepartment().equals("F A D, Head Office, Dhaka") && role == 1) {
	    	    		
	    	    		fad  = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
				          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
				          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
				          		+ "WHERE far.second_man_userid = '" + userid + "' "
				        		+ "AND far.second_man_status = 'Pending' ");
	    	    	
	    	    		
	    	            if (fad != null) {
	    	                while (fad.next()) {
	    	                    BMSView bmsView = new BMSView();
	    	                    bmsView.setId(fad.getLong("id"));
	    	                    bmsView.setUserid(fad.getString("user_id"));
	    	                    bmsView.setUsername(fad.getString("user_name"));
	    	                    bmsView.setFormid(fad.getString("form_id"));
	    	                    bmsView.setFormname(fad.getString("form_name"));
	    	                    bmsView.setSubmittime(fad.getTimestamp("submit_time"));
	    	                    bmsView.setBranchcode(fad.getString("branch_code"));
	    	                    bmsView.setSecondmanstatus(fad.getString("second_man_status"));
	    	                    bmsView.setUnitheadstatus(fad.getString("unit_head_status"));
	    	                    bmsView.setFadsecondstatus(fad.getString("fad_second_man_status"));
	    	                    bmsView.setFadheadstatus(fad.getString("fad_head_status"));
	    	                    bmsView.setDmdstatus(fad.getString("dmd_status"));
	    	                    bmsView.setAmdstatus(fad.getString("amd_status"));
	    	                    bmsView.setImplementerstatus(fad.getString("implemented_by_status"));

	    	                    debitVoucherFad.add(bmsView);
	    	                }
	    	            }

	    	            dashboard.addAll(debitVoucherFad);
	    	    	}
	    	    	
				          
				      } catch (Exception e) {
				          e.printStackTrace(); 
				      }
            
			con.close();
            return dashboard;
	}
	
	@GetMapping("accepted/{id}")
    public List<BMSView> acceptedForms(@PathVariable("id") String userid) throws ClassNotFoundException, SQLException{
		
		FunctionalRole functionalRole = functionalRoleRepository.findByUseridAndStatus(userid, "Active");
		User user = profileService.getUserByUserid(userid);
		
		Connection con = null;
		List<BMSView> debitVoucher = new ArrayList<>();
		List<BMSView> debitVoucherFad = new ArrayList<>();
		List<BMSView> dashboard = new ArrayList<>();

            con = PostGRESQLConnUtils.getPostGreSQLConnection();
            con.setAutoCommit(false);
            Statement stmt = con.createStatement();
            ResultSet dv = null;
            ResultSet fad = null;
            Integer role = 0;
            
            	
            try {
				        	
	//          For debit Voucher Form
				        	
            	if (functionalRole != null) {     
				    if (functionalRole.getFunctionalroleid() == 8) {
				           dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
				          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
				          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
				          		+ "WHERE far.fad_head_userid = '" + userid + "' "
				        		+ "AND far.fad_head_status = 'Accepted' ");
				    } 
				    else if (functionalRole.getFunctionalroleid() == 9) {
					    	dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
					          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
					          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
					          		+ "WHERE far.amd_userid = '" + userid + "' "
					        		+ "AND far.amd_status = 'Accepted' ");
				    }
				    else if (functionalRole.getFunctionalroleid() == 10) {
				    	dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
				          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
				          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
				          		+ "WHERE far.dmd_userid = '" + userid + "' "
				        		+ "AND far.dmd_status = 'Accepted' ");
				    }
				    else if (functionalRole.getFunctionalroleid() == 11) {
				    	dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
				          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
				          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
				          		+ "WHERE far.implemented_by_userid = '" + userid + "' "
				        		+ "AND far.implemented_by_status = 'Done' ");
				    }
				    else {
				    	
				    	List<UnitHead> unithead = unitHeadRepository.findByEmpcodeAndStatus(user.getEmpid(), "Active");
				    	for (UnitHead head : unithead) {
				    	    if (head.getFuncdescode().equals("FD001") || head.getFuncdescode().equals("FD003") ||
				    	    		head.getFuncdescode().equals("FD011") || head.getFuncdescode().equals("FD022")) {
				    	    	
				    	    	dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
						          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
						          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
						          		+ "WHERE far.unit_head_userid = '" + userid + "' "
						        		+ "AND far.unit_head_status = 'Accepted' ");
				    	    }
				    	    else if (head.getFuncdescode().equals("FD002") || head.getFuncdescode().equals("FD009") || head.getFuncdescode().equals("FD016")) {
				    	    	if (user.getDepartment().equals("F A D, Head Office, Dhaka")) {
				    	    		
				    	    		dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
							          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
							          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
							          		+ "WHERE far.fad_second_man_userid = '" + userid + "' "
							        		+ "AND far.fad_second_man_status = 'Accepted' ");
				    	    		
				    	    	}
				    	    	else {
				    	    		dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
							          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
							          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
							          		+ "WHERE far.second_man_userid = '" + userid + "' "
							        		+ "AND far.second_man_status = 'Accepted' ");
				    	    	}
				    	    }
				    	}
				    }
            	}
            	else {
            		List<UnitHead> unithead = unitHeadRepository.findByEmpcodeAndStatus(user.getEmpid(), "Active");
            		if (unithead != null) {
				    	for (UnitHead head : unithead) {
				    	    if (head.getFuncdescode().equals("FD001") || head.getFuncdescode().equals("FD003") ||
				    	    		head.getFuncdescode().equals("FD011") || head.getFuncdescode().equals("FD022")) {
				    	    	
				    	    	dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
						          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
						          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
						          		+ "WHERE far.unit_head_userid = '" + userid + "' "
						        		+ "AND far.unit_head_status = 'Accepted' ");
				    	    }
				    	    else if (head.getFuncdescode().equals("FD002") || head.getFuncdescode().equals("FD009") || head.getFuncdescode().equals("FD016")) {
				    	    	if (user.getDepartment().equals("F A D, Head Office, Dhaka")) {
				    	    		
				    	    		role = 1;
				    	    		dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
							          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
							          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
							          		+ "WHERE far.fad_second_man_userid = '" + userid + "' "
							        		+ "AND far.fad_second_man_status = 'Accepted' ");
				    	    		
				    	    	}
				    	    	else {
				    	    		dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
							          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
							          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
							          		+ "WHERE far.second_man_userid = '" + userid + "' "
							        		+ "AND far.second_man_status = 'Accepted' ");
				    	    	}
				    	    }
				    	}
            	}
        		else {
        			dv = null;
        		}
            	}
		          if (dv != null) {
			            while (dv.next()) {
			            	BMSView bmsView = new BMSView();
			            	
			                long id = dv.getLong("id");
			                String users = dv.getString("user_id");
			                String username = dv.getString("user_name");
			                String formid = dv.getString("form_id");
			                String formname = dv.getString("form_name");
			                Timestamp submittime = dv.getTimestamp("submit_time");
			                String branch = dv.getString("branch_code");
			                String secondmanstatus = dv.getString("second_man_status");
			            	String unitheadstatus = dv.getString("unit_head_status");
			            	String fadsecondstatus = dv.getString("fad_second_man_status");
			            	String fadheadstatus = dv.getString("fad_head_status");
			            	String dmdstatus = dv.getString("dmd_status");
			            	String amdstatus = dv.getString("amd_status");
			            	String implementerstatus = dv.getString("implemented_by_status");
			
			                bmsView.setId(id);
			                bmsView.setUserid(users);
			                bmsView.setUsername(username);
			                bmsView.setFormid(formid);
			                bmsView.setFormname(formname);
			                bmsView.setSubmittime(submittime);
			                bmsView.setBranchcode(branch);
			                bmsView.setSecondmanstatus(secondmanstatus);
			                bmsView.setUnitheadstatus(unitheadstatus);
			                bmsView.setFadsecondstatus(fadsecondstatus);
			                bmsView.setFadheadstatus(fadheadstatus);
			                bmsView.setDmdstatus(dmdstatus);
			                bmsView.setAmdstatus(amdstatus);
			                bmsView.setImplementerstatus(implementerstatus);
			
			                debitVoucher.add(bmsView);
			            }
		          }
		          dashboard.addAll(debitVoucher);
		          
		          if (user.getDepartment().equals("F A D, Head Office, Dhaka") && role ==1) {
		        	  
		        	  fad = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
				          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
				          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
				          		+ "WHERE far.second_man_userid = '" + userid + "' "
				        		+ "AND far.second_man_status = 'Accepted' ");
		        	  
		        	  if (fad != null) {
				            while (fad.next()) {
				            	BMSView bmsView = new BMSView();
				            	
				                long id = fad.getLong("id");
				                String users = fad.getString("user_id");
				                String username = fad.getString("user_name");
				                String formid = fad.getString("form_id");
				                String formname = fad.getString("form_name");
				                Timestamp submittime = fad.getTimestamp("submit_time");
				                String branch = fad.getString("branch_code");
				                String secondmanstatus = fad.getString("second_man_status");
				            	String unitheadstatus = fad.getString("unit_head_status");
				            	String fadsecondstatus = fad.getString("fad_second_man_status");
				            	String fadheadstatus = fad.getString("fad_head_status");
				            	String dmdstatus = fad.getString("dmd_status");
				            	String amdstatus = fad.getString("amd_status");
				            	String implementerstatus = fad.getString("implemented_by_status");
				
				                bmsView.setId(id);
				                bmsView.setUserid(users);
				                bmsView.setUsername(username);
				                bmsView.setFormid(formid);
				                bmsView.setFormname(formname);
				                bmsView.setSubmittime(submittime);
				                bmsView.setBranchcode(branch);
				                bmsView.setSecondmanstatus(secondmanstatus);
				                bmsView.setUnitheadstatus(unitheadstatus);
				                bmsView.setFadsecondstatus(fadsecondstatus);
				                bmsView.setFadheadstatus(fadheadstatus);
				                bmsView.setDmdstatus(dmdstatus);
				                bmsView.setAmdstatus(amdstatus);
				                bmsView.setImplementerstatus(implementerstatus);
				
				                debitVoucherFad.add(bmsView);
				            }
			          }
			          dashboard.addAll(debitVoucherFad);
		        	  
		          }
				          
				      } catch (Exception e) {
				          e.printStackTrace(); 
				      }
            
			con.close();
            return dashboard;
	}
	
	@GetMapping("rejected/{id}")
    public List<BMSView> rejectedForms(@PathVariable("id") String userid) throws ClassNotFoundException, SQLException{
		
		FunctionalRole functionalRole = functionalRoleRepository.findByUseridAndStatus(userid, "Active");
		User user = profileService.getUserByUserid(userid);
		
		Connection con = null;
		List<BMSView> debitVoucher = new ArrayList<>();
		List<BMSView> debitVoucherFad = new ArrayList<>();
		List<BMSView> dashboard = new ArrayList<>();

            con = PostGRESQLConnUtils.getPostGreSQLConnection();
            con.setAutoCommit(false);
            Statement stmt = con.createStatement();
            ResultSet dv = null;
            ResultSet fad = null;
            Integer role = 0;
            	
            try {
				        	
	//          For debit Voucher Form
				        	
            	if (functionalRole != null) {     
				    if (functionalRole.getFunctionalroleid() == 8) {
				           dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
				          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
				          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
				          		+ "WHERE far.fad_head_userid = '" + userid + "' "
				        		+ "AND far.fad_head_status = 'Rejected' ");
				    } 
				    else if (functionalRole.getFunctionalroleid() == 9) {
					    	dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
					          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
					          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
					          		+ "WHERE far.amd_userid = '" + userid + "' "
					        		+ "AND far.amd_status = 'Rejected' ");
				    }
				    else if (functionalRole.getFunctionalroleid() == 10) {
				    	dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
				          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
				          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
				          		+ "WHERE far.dmd_userid = '" + userid + "' "
				        		+ "AND far.dmd_status = 'Rejected' ");
				    }
				    else if (functionalRole.getFunctionalroleid() == 11) {
				    	dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
				          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
				          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
				          		+ "WHERE far.implemented_by_userid = '" + userid + "' "
				        		+ "AND far.implemented_by_status = 'Rejected' ");
				    }
				    else {
				    	
				    	List<UnitHead> unithead = unitHeadRepository.findByEmpcodeAndStatus(user.getEmpid(), "Active");
				    	for (UnitHead head : unithead) {
				    	    if (head.getFuncdescode().equals("FD001") || head.getFuncdescode().equals("FD003") ||
				    	    		head.getFuncdescode().equals("FD011") || head.getFuncdescode().equals("FD022")) {
				    	    	
				    	    	dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
						          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
						          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
						          		+ "WHERE far.unit_head_userid = '" + userid + "' "
						        		+ "AND far.unit_head_status = 'Rejected' ");
				    	    }
				    	    else if (head.getFuncdescode().equals("FD002") || head.getFuncdescode().equals("FD009") || head.getFuncdescode().equals("FD016")) {
				    	    	if (user.getDepartment().equals("F A D, Head Office, Dhaka")) {
				    	    		
				    	    		dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
							          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
							          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
							          		+ "WHERE far.fad_second_man_userid = '" + userid + "' "
							        		+ "AND far.fad_second_man_status = 'Rejected' ");
				    	    		
				    	    	}
				    	    	else {
				    	    		dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
							          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
							          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
							          		+ "WHERE far.second_man_userid = '" + userid + "' "
							        		+ "AND far.second_man_status = 'Rejected' ");
				    	    	}
				    	    }
				    	}
				    }
            	}
            	else {
            		List<UnitHead> unithead = unitHeadRepository.findByEmpcodeAndStatus(user.getEmpid(), "Active");
            		if (unithead != null) {
				    	for (UnitHead head : unithead) {
				    	    if (head.getFuncdescode().equals("FD001") || head.getFuncdescode().equals("FD003") ||
				    	    		head.getFuncdescode().equals("FD011") || head.getFuncdescode().equals("FD022")) {
				    	    	
				    	    	role = 1;
				    	    	dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
						          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
						          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
						          		+ "WHERE far.unit_head_userid = '" + userid + "' "
						        		+ "AND far.unit_head_status = 'Rejected' ");
				    	    }
				    	    else if (head.getFuncdescode().equals("FD002") || head.getFuncdescode().equals("FD009") || head.getFuncdescode().equals("FD016")) {
				    	    	if (user.getDepartment().equals("F A D, Head Office, Dhaka")) {
				    	    		
				    	    		dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
							          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
							          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
							          		+ "WHERE far.fad_second_man_userid = '" + userid + "' "
							        		+ "AND far.fad_second_man_status = 'Rejected' ");
				    	    		
				    	    	}
				    	    	else {
				    	    		dv = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
							          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
							          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
							          		+ "WHERE far.second_man_userid = '" + userid + "' "
							        		+ "AND far.second_man_status = 'Rejected' ");
				    	    	}
				    	    }
				    	}
            	}
        		else {
        			dv = null;
        		}
            	}
		          if (dv != null) {
			            while (dv.next()) {
			            	BMSView bmsView = new BMSView();
			            	
			                long id = dv.getLong("id");
			                String users = dv.getString("user_id");
			                String username = dv.getString("user_name");
			                String formid = dv.getString("form_id");
			                String formname = dv.getString("form_name");
			                Timestamp submittime = dv.getTimestamp("submit_time");
			                String branch = dv.getString("branch_code");
			                String secondmanstatus = dv.getString("second_man_status");
			            	String unitheadstatus = dv.getString("unit_head_status");
			            	String fadsecondstatus = dv.getString("fad_second_man_status");
			            	String fadheadstatus = dv.getString("fad_head_status");
			            	String dmdstatus = dv.getString("dmd_status");
			            	String amdstatus = dv.getString("amd_status");
			            	String implementerstatus = dv.getString("implemented_by_status");
			
			                bmsView.setId(id);
			                bmsView.setUserid(users);
			                bmsView.setUsername(username);
			                bmsView.setFormid(formid);
			                bmsView.setFormname(formname);
			                bmsView.setSubmittime(submittime);
			                bmsView.setBranchcode(branch);
			                bmsView.setSecondmanstatus(secondmanstatus);
			                bmsView.setUnitheadstatus(unitheadstatus);
			                bmsView.setFadsecondstatus(fadsecondstatus);
			                bmsView.setFadheadstatus(fadheadstatus);
			                bmsView.setDmdstatus(dmdstatus);
			                bmsView.setAmdstatus(amdstatus);
			                bmsView.setImplementerstatus(implementerstatus);
			
			                debitVoucher.add(bmsView);
			            }
		          }
		          dashboard.addAll(debitVoucher);
		          
		          if (user.getDepartment().equals("F A D, Head Office, Dhaka") && role ==1) {
		        	  
		        	  fad = stmt.executeQuery("SELECT * FROM form_debit_voucher far "
				          		+ "JOIN stp_forms sf ON far.form_id = sf.form_id "
				          		+ "JOIN sys_app_user sau ON far.user_id = sau.user_id "
				          		+ "WHERE far.second_man_userid = '" + userid + "' "
				        		+ "AND far.second_man_status = 'Accepted' ");
		        	  
		        	  if (fad != null) {
				            while (fad.next()) {
				            	BMSView bmsView = new BMSView();
				            	
				                long id = fad.getLong("id");
				                String users = fad.getString("user_id");
				                String username = fad.getString("user_name");
				                String formid = fad.getString("form_id");
				                String formname = fad.getString("form_name");
				                Timestamp submittime = fad.getTimestamp("submit_time");
				                String branch = fad.getString("branch_code");
				                String secondmanstatus = fad.getString("second_man_status");
				            	String unitheadstatus = fad.getString("unit_head_status");
				            	String fadsecondstatus = fad.getString("fad_second_man_status");
				            	String fadheadstatus = fad.getString("fad_head_status");
				            	String dmdstatus = fad.getString("dmd_status");
				            	String amdstatus = fad.getString("amd_status");
				            	String implementerstatus = fad.getString("implemented_by_status");
				
				                bmsView.setId(id);
				                bmsView.setUserid(users);
				                bmsView.setUsername(username);
				                bmsView.setFormid(formid);
				                bmsView.setFormname(formname);
				                bmsView.setSubmittime(submittime);
				                bmsView.setBranchcode(branch);
				                bmsView.setSecondmanstatus(secondmanstatus);
				                bmsView.setUnitheadstatus(unitheadstatus);
				                bmsView.setFadsecondstatus(fadsecondstatus);
				                bmsView.setFadheadstatus(fadheadstatus);
				                bmsView.setDmdstatus(dmdstatus);
				                bmsView.setAmdstatus(amdstatus);
				                bmsView.setImplementerstatus(implementerstatus);
				
				                debitVoucherFad.add(bmsView);
				            }
		        	  }
			          dashboard.addAll(debitVoucherFad);
		          }  
				      } catch (Exception e) {
				          e.printStackTrace(); 
				      }
            
			con.close();
            return dashboard;
	}
}
