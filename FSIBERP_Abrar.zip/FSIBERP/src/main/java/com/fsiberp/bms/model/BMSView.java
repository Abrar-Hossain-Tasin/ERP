package com.fsiberp.bms.model;

import java.sql.Timestamp;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class BMSView {
	
	@Id
	private Long id;
	private String formid;
	private String formname;
	private String userid;
	private String username;
	private String secondmanstatus;
	private String unitheadstatus;
	private String fadsecondstatus;
	private String fadheadstatus;
	private String dmdstatus;
	private String amdstatus;
	private String implementerstatus;
	private Timestamp submittime;
	private String branchcode;
	private String department;
	private String mdstatus;
	
	public BMSView() {
		super();
	}

	public BMSView(Long id, String formid, String formname, String userid, String username, String secondmanstatus,
			String unitheadstatus, String fadsecondstatus, String fadheadstatus, String dmdstatus, String amdstatus,
			String implementerstatus, Timestamp submittime, String branchcode, String mdstatus, String department) {
		super();
		this.id = id;
		this.formid = formid;
		this.formname = formname;
		this.userid = userid;
		this.username = username;
		this.secondmanstatus = secondmanstatus;
		this.unitheadstatus = unitheadstatus;
		this.fadsecondstatus = fadsecondstatus;
		this.fadheadstatus = fadheadstatus;
		this.dmdstatus = dmdstatus;
		this.amdstatus = amdstatus;
		this.implementerstatus = implementerstatus;
		this.submittime = submittime;
		this.branchcode = branchcode;
		this.mdstatus = mdstatus;
		this.department = department;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFormid() {
		return formid;
	}

	public void setFormid(String formid) {
		this.formid = formid;
	}

	public String getFormname() {
		return formname;
	}

	public void setFormname(String formname) {
		this.formname = formname;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getSecondmanstatus() {
		return secondmanstatus;
	}

	public void setSecondmanstatus(String secondmanstatus) {
		this.secondmanstatus = secondmanstatus;
	}

	public String getUnitheadstatus() {
		return unitheadstatus;
	}

	public void setUnitheadstatus(String unitheadstatus) {
		this.unitheadstatus = unitheadstatus;
	}

	public String getFadsecondstatus() {
		return fadsecondstatus;
	}

	public void setFadsecondstatus(String fadsecondstatus) {
		this.fadsecondstatus = fadsecondstatus;
	}

	public String getFadheadstatus() {
		return fadheadstatus;
	}

	public void setFadheadstatus(String fadheadstatus) {
		this.fadheadstatus = fadheadstatus;
	}

	public String getDmdstatus() {
		return dmdstatus;
	}

	public void setDmdstatus(String dmdstatus) {
		this.dmdstatus = dmdstatus;
	}

	public String getAmdstatus() {
		return amdstatus;
	}

	public void setAmdstatus(String amdstatus) {
		this.amdstatus = amdstatus;
	}

	public String getImplementerstatus() {
		return implementerstatus;
	}

	public void setImplementerstatus(String implementerstatus) {
		this.implementerstatus = implementerstatus;
	}

	public Timestamp getSubmittime() {
		return submittime;
	}

	public void setSubmittime(Timestamp submittime) {
		this.submittime = submittime;
	}

	public String getBranchcode() {
		return branchcode;
	}

	public void setBranchcode(String branchcode) {
		this.branchcode = branchcode;
	}

	public String getMdstatus() {
		return mdstatus;
	}

	public void setMdstatus(String mdstatus) {
		this.mdstatus = mdstatus;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

}
