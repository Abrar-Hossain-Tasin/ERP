package com.fsiberp.bms.exception;

public class BatchUpdateFailedException extends RuntimeException {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BatchUpdateFailedException(String message) {
        super(message);
    }
}
