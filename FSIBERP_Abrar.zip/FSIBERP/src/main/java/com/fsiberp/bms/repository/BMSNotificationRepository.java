package com.fsiberp.bms.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.fsiberp.bms.model.BMSNotification;
import org.springframework.stereotype.Repository;

@Repository
public interface BMSNotificationRepository extends JpaRepository<BMSNotification, Long> {

    List<BMSNotification> findByFormid(String formId);
    List<BMSNotification> findByUserid(String userid); 
    List<BMSNotification> findByUseridAndFormid(String userid, String formId);
    List<BMSNotification> findByUseridAndFormidAndSubmissionId(String userid, String formid, Long submissionId);

}
