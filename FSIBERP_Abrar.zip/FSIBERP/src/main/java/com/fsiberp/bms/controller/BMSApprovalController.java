package com.fsiberp.bms.controller;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.fsiberp.bms.services.DebitVoucherService;
import com.fsiberp.bms.exception.InvalidFormIdException;
import com.fsiberp.bms.model.BMSStatusUpdateRequest;

@RestController
@RequestMapping("/api/bms/approval")
@CrossOrigin(origins = "*", maxAge = 3600)
public class BMSApprovalController {

    private final DebitVoucherService debitVoucherService;

    public BMSApprovalController(DebitVoucherService debitVoucherService) {
        this.debitVoucherService = debitVoucherService;
    }

    @PutMapping("{userid}/{formId}/{id}")
    public ResponseEntity<?> updateStatus(@PathVariable("userid") String userid, @PathVariable("formId") String formId,
                                          @PathVariable("id") Long id, @RequestBody BMSStatusUpdateRequest request) {

        Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());

        if (request.getFormUpdates() != null && !request.getFormUpdates().isEmpty()) {
            Map<String, Object> results = new HashMap<>();

            // Batch update case
            for (Map<String, Object> formUpdate : request.getFormUpdates()) {
                Long batchId = Long.valueOf(formUpdate.get("id").toString());
                String batchFormId = formUpdate.get("formId").toString();

                switch (batchFormId) {
                    case "3001": // DebitVoucher
                        results.put("DebitVoucher", debitVoucherService.updateStatus(batchId, userid, request, currentTimestamp));
                        break;
                    
                    default:
                        return new ResponseEntity<>("Invalid form ID: " + batchFormId, HttpStatus.BAD_REQUEST);
                }
            }
            return new ResponseEntity<>(results, HttpStatus.OK);
        } else {
            // Single update case
            switch (formId) {
                case "3001": // DebitVoucher
                    return new ResponseEntity<>(debitVoucherService.updateStatus(id, userid, request, currentTimestamp), HttpStatus.OK);
              
                default:
                    throw new InvalidFormIdException("Invalid form ID: " + formId);
            }
        }
    }
}