package com.fsiberp.bms.services;

import java.util.List;
import com.fsiberp.bms.model.BMSNotification;

public interface BMSNotificationService {
    BMSNotification createNotification(String userid, String message, String fuserid, String formid, Long submissionId, boolean viewed);
    List<BMSNotification> getNotifications(String userid);
    void markAsViewed(Long id);
    void bmsArchiveOldNotifications();
    boolean areNotificationsViewed(String formId); 
    void markNotificationsAsViewedForUserAndForm(String userid, String formId);
    void markNotificationsAsViewedForUserAndForm(String userid, String formid, Long submissionId);
}
