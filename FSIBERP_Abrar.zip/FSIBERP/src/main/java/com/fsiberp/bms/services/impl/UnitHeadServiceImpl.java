package com.fsiberp.bms.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.stereotype.Service;

import com.fsiberp.bms.model.UnitHead;
import com.fsiberp.bms.repository.UnitHeadRepository;
import com.fsiberp.bms.services.UnitHeadService;
import com.fsiberp.frms.model.User;
import com.fsiberp.frms.repository.AuthRepository;

import java.util.Optional;
import java.util.concurrent.TimeUnit;

@Service
public class UnitHeadServiceImpl implements UnitHeadService {

    @Autowired
    private AuthRepository authRepository;

    @Autowired
    private UnitHeadRepository unitHeadRepository;

    @Autowired
    private ThreadPoolTaskScheduler taskScheduler;

    @SuppressWarnings("deprecation")
	@Override
    public UnitHead addUnitHead(String newUserid, String funcDesCode, String funcDesignation, String existingUserid, String existingUseridStatus, long durationInMinutes) {
    	
        User newUser = authRepository.findByUserid(newUserid)
                .orElseThrow(() -> new RuntimeException("User not found for userid: " + newUserid));

        User existingUser = authRepository.findByUserid(existingUserid)
                .orElseThrow(() -> new RuntimeException("User not found for userid: " + existingUserid));

   
        UnitHead existingUnitHead = unitHeadRepository.findByEmpcode(existingUser.getEmpid())
                .orElseThrow(() -> new RuntimeException("Unit Head not found for emp_id: " + existingUser.getEmpid()));
        existingUnitHead.setStatus(existingUseridStatus);
        unitHeadRepository.save(existingUnitHead);

   
        UnitHead newUnitHead = new UnitHead();
        newUnitHead.setBranch(newUser.getBranchcode());
        newUnitHead.setEmpcode(newUser.getEmpid());
        newUnitHead.setEmpname(newUser.getUsername());
        newUnitHead.setFuncdescode(funcDesCode);
        newUnitHead.setFuncdesignation(funcDesignation);
        newUnitHead.setStatus("Active");


        // Schedule a task to revert changes after the specified duration in minutes
        long durationInMillis = TimeUnit.MINUTES.toMillis(durationInMinutes);
        taskScheduler.schedule(() -> revertChangesAfterDuration(existingUserid, newUserid), 
            new java.util.Date(System.currentTimeMillis() + durationInMillis));
        
        unitHeadRepository.save(newUnitHead);

        return newUnitHead;
    }

    @Override
    public Optional<User> findUserById(String userid) {
        return authRepository.findByUserid(userid);
    }

    @Override
    public void revertChangesAfterDuration(String existingUserid, String newUserid) {
        // Fetch the existing user and revert their status
        User existingUser = authRepository.findByUserid(existingUserid)
                .orElseThrow(() -> new RuntimeException("User not found for userid: " + existingUserid));

        UnitHead existingUnitHead = unitHeadRepository.findByEmpcode(existingUser.getEmpid())
                .orElseThrow(() -> new RuntimeException("Unit Head not found for emp_id: " + existingUser.getEmpid()));
        existingUnitHead.setStatus("Active");
        unitHeadRepository.save(existingUnitHead);

        // Delete the newly added unit head
        User newUser = authRepository.findByUserid(newUserid)
                .orElseThrow(() -> new RuntimeException("User not found for userid: " + newUserid));

        UnitHead newUnitHead = unitHeadRepository.findByEmpcode(newUser.getEmpid())
                .orElseThrow(() -> new RuntimeException("Unit Head not found for emp_id: " + newUser.getEmpid()));
        unitHeadRepository.delete(newUnitHead);
    }
}

