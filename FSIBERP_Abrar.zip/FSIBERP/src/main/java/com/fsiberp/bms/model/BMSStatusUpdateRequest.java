package com.fsiberp.bms.model;

import java.util.List;
import java.util.Map;


public class BMSStatusUpdateRequest {
    private String status;
    private String userid;
    private String comment;
    private String comment2;
    
    private List<Map<String, Object>> formUpdates; // For batch updates

    // Getters and setters
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public List<Map<String, Object>> getFormUpdates() {
        return formUpdates;
    }

    public void setFormUpdates(List<Map<String, Object>> formUpdates) {
        this.formUpdates = formUpdates;
    }

	public String getComment2() {
		return comment2;
	}

	public void setComment2(String comment2) {
		this.comment2 = comment2;
	}
    
}